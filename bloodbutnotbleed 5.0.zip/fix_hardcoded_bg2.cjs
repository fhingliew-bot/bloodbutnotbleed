const fs = require('fs');

let code = fs.readFileSync('src/App.tsx', 'utf8');

// Replace border border-slate-800 or similar trailing borders
// We want to turn `{isDarkMode ? "..." : "..."} border border-slate-800` into `{isDarkMode ? "..." : "..."} border`

code = code.replace(/\$\{isDarkMode \? "([^"]+)" : "([^"]+)"\} rounded-lg border border-slate-800\/40/g, 'rounded-lg border ${isDarkMode ? "$1" : "$2"}');
code = code.replace(/\$\{isDarkMode \? "([^"]+)" : "([^"]+)"\} border border-slate-800\/40/g, 'border ${isDarkMode ? "$1" : "$2"}');
code = code.replace(/\$\{isDarkMode \? "([^"]+)" : "([^"]+)"\} border border-slate-800\/80/g, 'border ${isDarkMode ? "$1" : "$2"}');
code = code.replace(/\$\{isDarkMode \? "([^"]+)" : "([^"]+)"\} border border-slate-800/g, 'border ${isDarkMode ? "$1" : "$2"}');

fs.writeFileSync('src/App.tsx', code);
console.log('Fixed trailing borders');
