const fs = require('fs');

let code = fs.readFileSync('src/App.tsx', 'utf8');
code = code.replace(
  /import \{ dbEMTS \} from "\.\/data\/emts";/,
  'import { dbEMTS } from "./data/emts";\nimport { dbChecklists } from "./data/checklists";'
);
code = code.replace(
  /import \{ LabTest, DilutionDrug, RenalStableDrug, RenalICUDrug, EMTSDrug \} from "\.\/types";/,
  'import { LabTest, DilutionDrug, RenalStableDrug, RenalICUDrug, EMTSDrug, Checklist } from "./types";'
);

fs.writeFileSync('src/App.tsx', code);
