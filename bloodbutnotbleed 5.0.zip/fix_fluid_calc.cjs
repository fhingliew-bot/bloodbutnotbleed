const fs = require('fs');
let code = fs.readFileSync('src/App.tsx', 'utf8');

const fluidState = `
  // Maintenance Fluid State
  const [fluidWeight, setFluidWeight] = useState("");
  const [fluidResult, setFluidResult] = useState<number | null>(null);

  const calculateFluid = () => {
    const w = parseFloat(fluidWeight);
    if (!isNaN(w) && w > 0) {
      let rate = 0;
      if (w <= 10) rate = w * 4;
      else if (w <= 20) rate = 40 + ((w - 10) * 2);
      else rate = 60 + ((w - 20) * 1);
      setFluidResult(rate);
    }
  };
`;
// Insert before const isDarkMode
code = code.replace(/const isDarkMode = theme === "dark";/, fluidState + '\n  const isDarkMode = theme === "dark";');

// Change grid columns from 3 to 2 for better layout (or 4 if wide)
code = code.replace(/className="grid grid-cols-1 lg:grid-cols-3 gap-6"/, 'className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-4 gap-6"');

const fluidUI = `
              {/* Maintenance Fluid Calculator */}
              <div className={\`p-5 rounded-xl border flex flex-col justify-between \${
                isDarkMode ? "bg-[#111827] border-slate-800" : "bg-white border-slate-200 shadow-sm"
              }\`}>
                <div>
                  <div className="flex items-center gap-2.5 mb-4">
                    <div className={\`p-2 rounded bg-sky-500/10 \${isDarkMode ? "text-sky-400" : "text-sky-700"}\`}>
                      <Calculator className="h-4.5 w-4.5" />
                    </div>
                    <h3 className={\`font-bold \${isDarkMode ? "text-slate-200" : "text-slate-800"}\`}>Maintenance Fluids</h3>
                  </div>
                  <p className={\`text-[10px] \${isDarkMode ? "text-slate-400" : "text-slate-500"} mb-4\`}>
                    4-2-1 Rule (Holliday-Segar) for hourly maintenance rate.
                  </p>

                  <div className="space-y-4">
                    <div>
                      <label className={\`text-[11px] font-semibold \${isDarkMode ? "text-slate-400" : "text-slate-700"} block mb-1\`}>Weight (kg)</label>
                      <input 
                        type="number" 
                        value={fluidWeight}
                        onChange={e => setFluidWeight(e.target.value)}
                        className={\`w-full p-2.5 rounded-lg text-sm border outline-none transition-all \${
                          isDarkMode 
                            ? "bg-slate-900/50 border-slate-700 focus:border-sky-500/50 text-slate-200" 
                            : "bg-white border-slate-300 focus:border-sky-500 text-slate-800 shadow-sm"
                        }\`}
                        placeholder="e.g. 15"
                      />
                      <div className="flex gap-1.5 mt-2 flex-wrap">
                        {[5, 10, 15, 20, 50, 70].map(v => (
                          <button key={v} type="button" onClick={() => { setFluidWeight(v.toString()); setFluidResult(null); }} className={\`px-1.5 py-0.5 rounded text-[10px] \${isDarkMode ? "bg-slate-800 text-slate-300 hover:bg-slate-700" : "bg-slate-100 text-slate-800 hover:bg-slate-200"} font-mono\`}>{v}kg</button>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>

                <div className="mt-5 pt-4 border-t border-slate-800/40">
                  <button 
                    onClick={calculateFluid}
                    className="w-full py-2.5 rounded-lg bg-sky-600 hover:bg-sky-500 text-white text-xs font-bold transition-colors"
                  >
                    Calculate Rate
                  </button>
                  
                  {fluidResult !== null && (
                    <div className="mt-3 p-3 rounded-lg bg-sky-500/10 border border-sky-500/20 text-center animate-fade-in">
                      <span className={\`text-[11px] uppercase tracking-wider font-bold \${isDarkMode ? "text-sky-400" : "text-sky-700"} block mb-1\`}>Hourly Rate</span>
                      <div className="flex items-baseline justify-center gap-1">
                        <span className={\`text-2xl font-bold \${isDarkMode ? "text-slate-100" : "text-slate-900"} font-mono\`}>{fluidResult}</span>
                        <span className={\`text-xs \${isDarkMode ? "text-slate-400" : "text-slate-500"} font-mono\`}>mL/hr</span>
                      </div>
                      <div className={\`mt-2 pt-2 border-t border-sky-500/20 text-[10px] \${isDarkMode ? "text-sky-200/60" : "text-sky-800/60"}\`}>
                        24h Volume: {(fluidResult * 24).toLocaleString()} mL
                      </div>
                    </div>
                  )}
                </div>
              </div>
`;

code = code.replace(/<div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-4 gap-6">/, '<div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-4 gap-6">\n' + fluidUI);

fs.writeFileSync('src/App.tsx', code);
