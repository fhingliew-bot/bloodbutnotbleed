const fs = require('fs');
let code = fs.readFileSync('src/data/labs.ts', 'utf8');

const testsToAdd = `
  {
    test: "Anti-Beta-2 Glycoprotein I (IgG & IgM) [Referred]",
    lab: "Ref: IMR",
    container: "Plain gel tube",
    specimen: "Serum",
    volume: "3 ml",
    ltat: "2 - 4 weeks",
    remark: "Key marker for Antiphospholipid Syndrome (APS). Should be evaluated with Lupus Anticoagulant and Anti-Cardiolipin.",
    ranges: "Negative. (> 40 U/ml is considered high positive)."
  },
  {
    test: "Anti-Cardiolipin Antibodies (IgG & IgM) [Referred]",
    lab: "Ref: IMR",
    container: "Plain gel tube",
    specimen: "Serum",
    volume: "3 ml",
    ltat: "2 - 4 weeks",
    remark: "Core component of Antiphospholipid Syndrome (APS) diagnostic criteria.",
    ranges: "Negative."
  },
  {
    test: "HLA-B27 Typing [Referred]",
    lab: "Ref: IMR / NBB",
    container: "EDTA Tube (Purple cap)",
    specimen: "Whole Blood",
    volume: "4 ml",
    ltat: "2 - 4 weeks",
    remark: "Used to aid in the diagnosis of ankylosing spondylitis and other spondyloarthropathies.",
    ranges: "Negative / Not Detected."
  },
  {
    test: "Cryoglobulins (Qualitative / Quantitative) [Referred]",
    lab: "Ref: IMR",
    container: "Plain red top tube (MUST be kept at 37°C)",
    specimen: "Serum",
    volume: "10 ml",
    ltat: "2 - 4 weeks",
    remark: "CRITICAL: Sample must be drawn into pre-warmed tubes and transported strictly at 37°C (in a thermos with warm water). Cold temperatures before separation will cause false negatives.",
    ranges: "Negative."
  },
  {
    test: "Myositis Autoantibody Panel [Referred]",
    lab: "Ref: IMR",
    container: "Plain gel tube",
    specimen: "Serum",
    volume: "3 ml",
    ltat: "2 - 4 weeks",
    remark: "For idiopathic inflammatory myopathies (e.g., Polymyositis, Dermatomyositis). Detects MSA like Anti-Jo-1, Anti-Mi-2, Anti-SRP, Anti-TIF1-gamma, Anti-MDA5.",
    ranges: "Negative."
  },
  {
    test: "Anti-Glomerular Basement Membrane (Anti-GBM) [Referred]",
    lab: "Ref: IMR",
    container: "Plain gel tube",
    specimen: "Serum",
    volume: "3 ml",
    ltat: "14 working days",
    remark: "To diagnose Goodpasture's disease (Anti-GBM disease). Often requested alongside ANCA for pulmonary-renal syndrome.",
    ranges: "Negative."
  },
  {
    test: "Anti-MAG (Myelin-Associated Glycoprotein) Antibody [Referred]",
    lab: "Ref: IMR",
    container: "Plain gel tube",
    specimen: "Serum",
    volume: "3 ml",
    ltat: "2 - 4 weeks",
    remark: "Associated with autoimmune peripheral neuropathies, particularly IgM paraproteinemic demyelinating neuropathy.",
    ranges: "Negative."
  },
  {
    test: "CSF IgG Index and Synthesis Rate [Referred]",
    lab: "Ref: IMR",
    container: "Sterile CSF container & Plain gel tube",
    specimen: "CSF (2 ml) and matched Serum (3 ml)",
    volume: "CSF + Serum",
    ltat: "14 working days",
    remark: "Must send paired CSF and serum samples taken on the same day. Often run together with Oligoclonal Bands for Multiple Sclerosis evaluation.",
    ranges: "IgG Index < 0.70. Higher values suggest intrathecal IgG synthesis."
  }
`;

const index = code.lastIndexOf('}');
if (index !== -1) {
  code = code.substring(0, index + 1) + ',' + testsToAdd + '\n];';
  fs.writeFileSync('src/data/labs.ts', code);
  console.log('Successfully appended rheumatology & neurology tests.');
} else {
  console.log('Could not find the end of the array.');
}
