export interface LabTest {
  test: string;
  lab: string;
  container: string;
  specimen: string;
  volume: string;
  ltat: string;
  remark: string;
  ranges: string;
}

export interface DilutionDrug {
  drug: string;
  reconstitution: string;
  dilution: string;
  infusion: string;
}

export interface RenalStableDrug {
  drug: string;
  dose: string;
  adjustments: string;
}

export interface RenalICUDrug {
  drug: string;
  dose: string;
  cr3050: string;
  cr1030: string;
  cr10: string;
  rrt: string;
}

export interface EMTSDrug {
  drug: string;
  indication: string;
  category: "Resuscitation" | "Shock/Inotropes" | "Hypertension" | "Sedation/Analgesia" | "Respiratory/Other" | "Metabolic";
  preparation: string;
  bolus: string;
  infusion: string;
  precautions: string;
}

