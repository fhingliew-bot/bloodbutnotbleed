import { DilutionDrug, RenalStableDrug, RenalICUDrug } from "../types";

export const dbDilution: DilutionDrug[] = [
  {
    "drug": "Cefepime 1g",
    "reconstitution": "Reconstitute 1 vial with 10ml of WFI",
    "dilution": "Further dilute to 100ml of NS or D5. Maximum of 2 vials (2 gram) in 100ml of NS. Diluted solution stable for 48 hours under refrigeration (2-8°C).",
    "infusion": "IV infusion over 30 minutes"
  },
  {
    "drug": "Cloxacillin 500mg",
    "reconstitution": "Reconstitute 1 vial with 5ml of WFI",
    "dilution": "Further dilute to 100ml of NS or D5. Maximum of 4 Vials (2 Gram) to 100ml of NS.",
    "infusion": "IV infusion over 60 minutes"
  },
  {
    "drug": "Ertapenem 1g",
    "reconstitution": "Reconstitute 1 vial with 10ml of NS",
    "dilution": "Further dilute to 50 or 100ml NS. Diluted solution may be stored at RT (25°c) and used within 6 hours or Stored for 24 hours under refrigeration (5°c) and used within 4 hours after removal from refrigerator.",
    "infusion": "IV infusion over 30 minutes"
  },
  {
    "drug": "Imipenem/Cilastatin 500mg/500mg",
    "reconstitution": "Reconstitute 1 vial with 20ml NS",
    "dilution": "Further dilute to 100ml NS or D5. Reconstituted/ diluted solution stable for 4 hours at RT (30°c) and 24 hours in refrigerator (5° C).",
    "infusion": "IV infusion over 4 hours"
  },
  {
    "drug": "Meropenem 1g",
    "reconstitution": "Reconstitute 1 vial with 20ml WFI",
    "dilution": "Further dilute to 100ml NS or D5. Diluted solution stable for 8 hours at RT (25°c) and 48 hours in refrigerator (4 C). Diluted solution with D5 stable for 3 hours at RT (25°c) and 14 hours in refrigerator (4 C).",
    "infusion": "IV infusion over 4 hours (NS). IV infusion over 3 hours (if dilute in D5)."
  },
  {
    "drug": "Piperacillin / tazobactam 4g/0.5g",
    "reconstitution": "Reconstitute 1 vial with 20ml of WFI. Reconstituted solution stable for 24 hours in refrigerator (2-8 C).",
    "dilution": "Further dilute to 100ml NS or D5.",
    "infusion": "IV infusion over 30 minutes."
  },
  {
    "drug": "Vancomycin 500mg",
    "reconstitution": "Reconstitute 1 vial with 10ml of WFI.",
    "dilution": "Final concentration 5 mg/ml (eg: 500mg in 100ml over 1 hour, 1000mg in 200ml over 2 hours). Max concentration is 10mg/ml for fluid restriction.",
    "infusion": "Maximum infusion rate 10mg/min."
  },
  {
    "drug": "Acetylcysteine 5g/25ml",
    "reconstitution": "N/A",
    "dilution": "Preferably D5 as the diluent. NS may be used if D5 is not suitable. The diluted solution is stable for 24 hours when stored at RT (25°C).",
    "infusion": "First Dose: 150 mg/kg in 200ml D5 over 1 hour. Second Dose: 50 mg/kg in 500ml D5 over 4 hours. Third Dose: 100 mg/kg in 1000ml D5 over 16 hours."
  },
  {
    "drug": "Adrenaline 1mg/ml",
    "reconstitution": "Single Strength: Adrenaline 3mg in 50ml NS (60 mcg/ml). Double Strength: Adrenaline 6mg in 50ml NS (120 mcg/ml).",
    "dilution": "Single: Add 3 ampoules of 1 mg/ml Adrenaline to 47ml of NS. Double: Add 6 ampoules of 1 mg/ml Adrenaline to 44ml of NS.",
    "infusion": "0.1 - 0.5 mcg/kg/min via pump."
  },
  {
    "drug": "Aminophylline 250mg/10ml",
    "reconstitution": "N/A",
    "dilution": "Loading ≤250mg: Dilute in 50ml NS or D5. Loading 251-500mg: Dilute in 100ml NS or D5. Maintenance: 1 to 2 ampoules diluted to 250-500ml NS or D5 (Up to 1 mg/ml).",
    "infusion": "Loading: Run over 30 minutes. Maintenance: 24 Hours. Should not exceed 21 mg/hour in patients with cor pulmonale, cardiac decompensation, hepatic impairment, or > 60 years old."
  },
  {
    "drug": "Digoxin 500mcg/2ml",
    "reconstitution": "N/A",
    "dilution": "Loading: Dilute to 50 ml NS or D5. Maintenance: Dilute to 100ml NS or D5 (Max concentration: 62.5mcg/ml). Solution stable for 48 hours under RT.",
    "infusion": "Loading: Run for 15 minutes. Maintenance: Minimum Infusion time: over 10-20 minutes."
  },
  {
    "drug": "Dobutamine 250mg/20ml",
    "reconstitution": "Single Strength: 250mg in 50ml NS (5000 mcg/ml). Double Strength: 500mg in 50ml NS (10000 mcg/ml).",
    "dilution": "Single: Add 1 ampoule to 30ml of NS. Double: Add 2 ampoules to 10ml of NS. Stable for 24 hours at RT.",
    "infusion": "Usual Dose: 2.5-20mcg/kg/min."
  },
  {
    "drug": "Dopamine 200mg/5ml",
    "reconstitution": "Single Strength: 200mg in 50ml NS (4000 mcg/ml). Double Strength: 400mg in 50ml NS (8000 mcg/ml).",
    "dilution": "Single: Add 1 ampoule to 45ml of NS. Double: Add 2 ampoules to 40ml of NS. Stable for 24 hours at RT.",
    "infusion": "Usual Dose: 0.5-20mcg/kg/min."
  },
  {
    "drug": "Esomeprazole 40mg",
    "reconstitution": "IV INFUSION (8MG/H): 5ML NS PER 40MG VIAL",
    "dilution": "Reconstitute 2 VIALS (80MG) and further dilute to 20mL NS (Final: 4mg/mL). Stable for 12 hours in NS under RT (<30°C).",
    "infusion": "2ML/HOUR"
  },
  {
    "drug": "Frusemide 20mg/2ml",
    "reconstitution": "N/A",
    "dilution": "IV Bolus: Use undiluted. IV Infusion: Use Undiluted (100mg/10ml).",
    "infusion": "IV Bolus over 1-2 minutes. IV Infusion: Maximum infusion rate: 4mg/min (240mg/hr)."
  },
  {
    "drug": "Glyceryl Trinitrate 50mg/10ml",
    "reconstitution": "N/A",
    "dilution": "Add 6ml Glyceryl Trinitrate to 44ml of NS or D5 (600 mcg/ml). Stable for 24 hours after dilution at RT (25°C).",
    "infusion": "Max dose: 400mcg/minute."
  },
  {
    "drug": "Isosorbide Dinitrate 10mg/10ml",
    "reconstitution": "N/A",
    "dilution": "Dilute 1 ampoule up to 50ml NS or D5 (0.2mg/ml). 24 Hours at RT.",
    "infusion": "Dose: 2-12mg/hr may increase to 20mg/hr."
  },
  {
    "drug": "Labetalol 25mg/5ml",
    "reconstitution": "N/A",
    "dilution": "Dilute 4 ampoules (100mg) up to 50ml NS or D5 (2mg/ml). 24 Hours at 25°C.",
    "infusion": "Dose: 0.5-2mg/min (Total maximum dose: 300mg/day)."
  },
  {
    "drug": "Lytic Cocktail",
    "reconstitution": "N/A",
    "dilution": "N/A",
    "infusion": "STEP 1: 10ml IV Calcium Gluconate 10% undiluted over 10 minutes. STEP 2: 10 units IV Insulin (Actrapid) undiluted. STEP 3: 50ml IV Dextrose 50% undiluted over 15-30 minutes. In DKA patients or blood glucose level >14mmol/L, OMIT dextrose & monitor blood glucose."
  },
  {
    "drug": "Magnesium Sulfate 2.47g/5ml (10mmol/5ml)",
    "reconstitution": "N/A",
    "dilution": "Acute Asthma / ROF: 1 ampoule in 20ml NS or D5. Non-ROF: 1 ampoule in 100ml NS or D5. Diluted solution stable for 24 hours when stored below 25°C (RT).",
    "infusion": "Acute Asthma / ROF: 20 minutes. Non-ROF: 1 hour. Max daily dose for adults is 30g - 40g."
  },
  {
    "drug": "Noradrenaline 4mg/4ml",
    "reconstitution": "Single Strength: 4mg in 50ml D5% (80 mcg/ml). Double Strength: 8mg in 50ml D5% (160 mcg/ml).",
    "dilution": "Single: Add 1 ampoule to 46ml of D5%. Double: Add 2 ampoules to 42ml of D5%. Stable for 24 hours at 25°C (RT).",
    "infusion": "0.01 to 3 mcg/kg/minute."
  },
  {
    "drug": "Octreotide 0.05mg/ml or 0.1mg/ml",
    "reconstitution": "N/A",
    "dilution": "0.05mg/ml: Dilute 10 ampoules to 50ml of NS. 0.1mg/ml: Dilute 5 ampoules to 50ml of NS. Diluted solution stable for 24 hours below 25°C (RT).",
    "infusion": "Dose 25mcg/H: IVI 2.5ml/H. Dose 50 mcg/H: IVI 5 ml/H."
  },
  {
    "drug": "Pantoprazole 40mg",
    "reconstitution": "10ML NS PER 40MG VIAL",
    "dilution": "IV INFUSION (8MG/H): Reconstitute 2 VIALS (80MG) and add together (Final: 4mg/mL). Stability is 12 hours under RT (<30°C).",
    "infusion": "2ML/HOUR"
  },
  {
    "drug": "Phenytoin Sodium 250mg/5ml",
    "reconstitution": "N/A",
    "dilution": "IV Infusion: Dilute in 100ml of NS. IV Loading: Dilute to 50-100ml NS (Max concentration to 10mg/ml).",
    "infusion": "IV Infusion: Run over 1 hour. Max infusion rate: 50mg/minute. IV Loading: 1 Hour."
  },
  {
    "drug": "Potassium Chloride 10% (1g/10ml)",
    "reconstitution": "N/A",
    "dilution": "Fast Correction: 1g of KCL add to 100mL NS. Continuous: Add 1-1.5g to 500mL NS.",
    "infusion": "Fast: run over 1 hour. Max concentration: 40mmol/L or 1.5g KCL per pint. Max daily dose: 3mmol/kg/day."
  },
  {
    "drug": "Potassium Dihydrogen Phosphate",
    "reconstitution": "N/A",
    "dilution": "Dilute to 100ml NS or D5.",
    "infusion": "4-6 hours. Maximum total daily dose: 20 mmol PO4- (2 ampoules)."
  }
];

export const dbRenalStable: RenalStableDrug[] = [
  {
    "drug": "Amoxicillin (PO)",
    "dose": "250-1000mg TDS",
    "adjustments": "<strong>10-30:</strong> 500mg BD<br><strong>&lt;10:</strong> 500mg OD-BD<br><strong>HD:</strong> 500mg OD-BD, serve post HD on HD day<br><strong>PD:</strong> 500mg BD"
  },
  {
    "drug": "Amoxicillin/Clavulanate (IV)",
    "dose": "1.2g TDS. In serious infection, can increase frequency up to QID",
    "adjustments": "<strong>10-30:</strong> 1.2g BD<br><strong>&lt;10/HD/PD:</strong> 1.2g OD"
  },
  {
    "drug": "Amoxicillin/Clavulanate (PO)",
    "dose": "625mg TDS. H. pylori eradication therapy: 1g BD",
    "adjustments": "<strong>10-30:</strong> usual dose BD<br><strong>&lt;10:</strong> usual dose OD<br><strong>HD:</strong> usual dose OD, additional dose after HD<br><strong>H. pylori CrCl &lt;30 ml/min/HD/PD:</strong> 500mg BD"
  },
  {
    "drug": "Ampicillin (IV)",
    "dose": "1-2g QID / 2g 4H",
    "adjustments": "<strong>30-49:</strong> 1-2g TDS (or 2g QID)<br><strong>15-29:</strong> 1-2g BD (or 2g TDS)<br><strong>&lt;15/PD:</strong> 1-2g OD (or 2g BD)<br><strong>HD:</strong> post HD on HD day"
  },
  {
    "drug": "Ampicillin/sulbactam (IV)",
    "dose": "1.5-3g TDS or QID. Acinetobacter sp MDR: 9g TDS",
    "adjustments": "<strong>15-29:</strong> 1.5-3g BD<br><strong>5-14:</strong> 1.5-3g OD<br><strong>HD:</strong> 1.5-3g OD-BD, serve post HD on HD day<br><strong>PD:</strong> 1.5g BD, or 3g OD<br><strong>MDR Acinetobacter CrCl 20-50:</strong> 6g TDS<br><strong>MDR Acinetobacter CrCl &lt; 20/HD:</strong> 6g BD"
  },
  {
    "drug": "Ampicillin/sulbactam (PO)",
    "dose": "375mg - 750mg BD",
    "adjustments": "No renal dose adjustment. CrCl &lt;10 ml/min: use with caution"
  },
  {
    "drug": "Azithromycin (IV/PO)",
    "dose": "500mg OD",
    "adjustments": "No renal dose adjustment. HD: no supplemental dose necessary"
  },
  {
    "drug": "Benzathine penicillin (IM)",
    "dose": "2.4MU IM stat or weekly for 3 weeks",
    "adjustments": "Renal impairment: no dosage adjustment. Use with caution"
  },
  {
    "drug": "Benzylpenicillin / Penicillin G (IV)",
    "dose": "2-4 MU 4H - QID",
    "adjustments": "<strong>10-50:</strong> 75% of usual dose<br><strong>&lt;10:</strong> 20-50% of usual dose<br><strong>HD:</strong> LD 4mu, then 25-50% of usual dose every 4-6 hrs or 50-100% of usual dose BD-TDS, serve post HD on HD day"
  },
  {
    "drug": "Cefazolin (IV)",
    "dose": "1-2g TDS",
    "adjustments": "<strong>30-49:</strong> 1-2g BD-TDS<br><strong>11-29:</strong> 500mg - 1g BD<br><strong>&lt;10:</strong> 500mg-1g OD<br><strong>HD:</strong> 1g OD (serve post HD on HD day) or 2g EOD post HD (thrice weekly post HD)<br><strong>PD:</strong> 500mg BD or 1g OD"
  },
  {
    "drug": "Cefepime (IV) 1g BD / 1g QID",
    "dose": "1g BD / 1g QID",
    "adjustments": "<strong>1g BD (CrCl 30-60):</strong> 1g OD<br><strong>1g BD (CrCl 11-29):</strong> 500mg OD<br><strong>1g BD (CrCl&lt;11):</strong> 250mg OD<br><strong>1g QID (CrCl 30-60):</strong> 1g TDS<br><strong>1g QID (CrCl 11-29):</strong> 1g BD<br><strong>1g QID (CrCl&lt;11):</strong> 1g OD<br><strong>HD/PD:</strong> 1g OD"
  },
  {
    "drug": "Cefepime (IV) 2g BD / 2g TDS",
    "dose": "2g BD / 2g TDS",
    "adjustments": "<strong>2g BD (CrCl 30-60):</strong> 1g BD<br><strong>2g BD (CrCl 11-29):</strong> 1g OD<br><strong>2g BD (CrCl&lt;11):</strong> 500mg OD<br><strong>2g TDS (CrCl 30-60):</strong> 2g BD<br><strong>2g TDS (CrCl 11-29):</strong> 2g OD or 1g BD<br><strong>2g TDS (CrCl&lt;11):</strong> 1g OD<br><strong>HD/PD:</strong> 1g OD"
  },
  {
    "drug": "Cefoperazone (IV)",
    "dose": "1-2g BD",
    "adjustments": "Renal impairment: no adjustment for usual doses. Hepatic impairment with significant renal disease: Do not exceed 1-2g daily without close monitoring. HD: serve post HD."
  },
  {
    "drug": "Cefoperazone/Sulbactam (IV)",
    "dose": "Acinetobacter sp MDR: 4g QID",
    "adjustments": "<strong>20-50:</strong> 3g QID<br><strong>&lt;20/HD:</strong> 2g QID"
  },
  {
    "drug": "Cefotaxime (IV)",
    "dose": "2g TDS",
    "adjustments": "<strong>11-50:</strong> 2g BD<br><strong>≤10/HD/PD:</strong> 2g OD"
  },
  {
    "drug": "Cetaroline (IV)",
    "dose": "600mg BD (TDS if involved bloodstream infection)",
    "adjustments": "<strong>31-50:</strong> 400mg BD-TDS<br><strong>15-30:</strong> 300mg BD-TDS<br><strong>&lt;15/PD/HD:</strong> 200mg BD-TDS"
  },
  {
    "drug": "Ceftazidime (IV)",
    "dose": "Non Meliodosis: 1-2g TDS",
    "adjustments": "<strong>31-50:</strong> BD<br><strong>16-30:</strong> OD<br><strong>&lt;15:</strong> 500mg - 1g OD<br><strong>HD:</strong> 1g OD (serve post HD on HD day) or 2g EOD post HD<br><strong>PD:</strong> 1g OD"
  },
  {
    "drug": "Ceftazidime (IV) Meliodosis intensive therapy",
    "dose": "100-120 mg/kg/day. Wt >60kg: 2g TDS. Wt <60kg: 1g TDS.",
    "adjustments": "<strong>31-50:</strong> 2g BD (Wt >60) / 1g BD (Wt <60)<br><strong>15-30:</strong> 2g OD (Wt >60) / 1g OD (Wt <60)<br><strong>&lt;15:</strong> As per CrCl <15, serve post HD<br><strong>CAPD:</strong> May give IP with dwell time > 6 hrs and 25% extra dose"
  },
  {
    "drug": "Ceftriaxone (IV)",
    "dose": "1-2g OD",
    "adjustments": "<strong>No renal/hepatic dose adjustment</strong>. For combined renal (CrCl<15) & hepatic impairment: do not exceed 2g/day"
  },
  {
    "drug": "Cefuroxime (IV)",
    "dose": "750mg-1.5g TDS",
    "adjustments": "<strong>10-30:</strong> BD<br><strong>&lt;10/HD/PD:</strong> OD. HD: serve post HD on HD day."
  },
  {
    "drug": "Cefuroxime (PO)",
    "dose": "250-500mg BD",
    "adjustments": "<strong>&lt;10/PD:</strong> 500mg OD<br><strong>HD:</strong> 500mg OD, serve post HD on HD day"
  },
  {
    "drug": "Cephalexin (PO)",
    "dose": "Prophylaxis for recurrent urinary tract infection: 250mg ON",
    "adjustments": "No renal dose adjustment"
  },
  {
    "drug": "Ciprofloxacin (IV)",
    "dose": "250mg-1g QID or 500mg BD (maximum dose: 4g/day)",
    "adjustments": "<strong>15-29:</strong> 250-500mg BD-TDS<br><strong>&lt;15:</strong> 250-500mg OD-BD<br><strong>HD/PD:</strong> 250-500mg OD-BD, serve post HD on HD day"
  },
  {
    "drug": "Ciprofloxacin (PO)",
    "dose": "400mg BD-TDS or 500-750mg BD",
    "adjustments": "<strong>400mg BD-TDS (CrCl &lt;30):</strong> 200-400mg OD-BD<br><strong>400mg BD-TDS (HD/PD):</strong> LD 400mg, then 200-400mg OD, serve post HD<br><strong>500-750mg BD (CrCl 30-50):</strong> 250-500mg BD<br><strong>500-750mg BD (CrCl &lt;30):</strong> 500mg OD<br><strong>500-750mg BD (HD/PD):</strong> 250-500mg OD, serve post HD"
  },
  {
    "drug": "Clarithromycin (PO)",
    "dose": "250-500mg BD",
    "adjustments": "<strong>10-50:</strong> 500mg OD-BD<br><strong>&lt;10:</strong> 500mg OD<br><strong>HD:</strong> 500mg OD, serve post HD on HD day"
  },
  {
    "drug": "Clindamycin (IV/PO)",
    "dose": "Various depend on indication. H. pylori eradication therapy: 500mg BD",
    "adjustments": "No renal dose adjustment<br><strong>H. pylori CrCl &lt;30/HD/PD:</strong> 250mg BD"
  },
  {
    "drug": "Cloxacillin (IV/PO) / Doxycycline (PO) / Erythromycin (IV/PO) / Fusidic acid (PO)",
    "dose": "Various (Doxycycline 100mg BD, Fusidic acid 500mg TDS)",
    "adjustments": "No renal dose adjustment"
  },
  {
    "drug": "Imipenem/Cilastatin (IV)",
    "dose": "500mg QID / 1g TDS / 1g QID (Dosing based on Imipenem component)",
    "adjustments": "<strong>500mg QID:</strong> 30-59: 250mg QID or 500mg TDS. 15-29: 250mg TDS or 500mg BD.<br><strong>1g TDS:</strong> 30-59: 500mg TDS. 15-29: 250mg TDS or 500mg BD.<br><strong>1g QID:</strong> 30-59: 500mg QID. 15-29: 250mg QID.<br><strong>&lt;15 (All Doses):</strong> Do not administer unless HD will begin within 48 hours<br><strong>HD/PD (All Doses):</strong> 250-500mg BD"
  },
  {
    "drug": "Levofloxacin (IV/PO)",
    "dose": "500mg OD / 750mg OD",
    "adjustments": "<strong>500mg OD (CrCl 20-49):</strong> 500mg stat, 250mg OD<br><strong>500mg OD (CrCl &lt;20/HD/PD):</strong> 500mg stat, 250mg EOD<br><strong>TB treatment 750mg-1g OD (CrCl 20-49):</strong> 750mg EOD<br><strong>TB treatment (CrCl &lt; 20/HD/PD):</strong> 750mg stat, 500mg EOD"
  },
  {
    "drug": "Linezolid (IV/PO)",
    "dose": "600mg BD",
    "adjustments": "<strong>No renal dose adjustment</strong>. HD: serve post HD on HD day."
  },
  {
    "drug": "Meropenem (IV)",
    "dose": "1-2g TDS",
    "adjustments": "<strong>26-50:</strong> usual dose BD<br><strong>10-25:</strong> 50% usual dose BD<br><strong>&lt;10/PD:</strong> 50% usual dose OD<br><strong>HD:</strong> 50% usual dose OD (post HD)"
  },
  {
    "drug": "Meropenem (IV) Meliodosis",
    "dose": "If normal dose 1g TDS",
    "adjustments": "<strong>15-50:</strong> 1g BD<br><strong>&lt;15/HD/PD:</strong> 1g OD"
  },
  {
    "drug": "Metronidazole (IV/PO) / Moxifloxacin (PO) / Phenoxymethyl penicillin (PO)",
    "dose": "Various / 400mg OD / Various",
    "adjustments": "No renal dose adjustment (including PD). HD for Metronidazole: consider supplemental dose following HD if administration cannot be separated from dialysis session."
  },
  {
    "drug": "Minocycline (PO)",
    "dose": "100mg BD",
    "adjustments": "CrCl &lt;80 ml/min: Do not exceed 200mg/day"
  },
  {
    "drug": "Nitrofurantoin (PO)",
    "dose": "50-100mg ON to QID depend on indication",
    "adjustments": "CrCl &lt;60 ml/min: Do not use"
  },
  {
    "drug": "Ofloxacin (PO)",
    "dose": "TB Treatment: 400mg BD",
    "adjustments": "CrCl &lt;30 ml/min or HD: 600mg-800mg, 3x/wk"
  },
  {
    "drug": "Piperacillin/Tazobactam (IV)",
    "dose": "4.5g QID",
    "adjustments": "<strong>20-39:</strong> 4.5g TDS<br><strong>&lt;20/HD/PD:</strong> 4.5g BD or 2.25g QID"
  },
  {
    "drug": "Polymyxin E (Colistin) IV",
    "dose": "LD: 9 MU STAT (usual) or weight-based (6-9 MU). MD: 4.5 MU BD",
    "adjustments": "<strong>30-50:</strong> 3 MU BD<br><strong>10-30:</strong> 2.5 MU BD<br><strong>&lt;10:</strong> 2 MU BD<br><strong>HD:</strong> 2 MU BD + 1.5 MU AD<br><strong>CVVH:</strong> 4 MU TDS"
  },
  {
    "drug": "Polymyxin B (IV)",
    "dose": "LD: 25,000u/kg. MD: 15,000u/kg BD",
    "adjustments": "No renal or hepatic dose adjustment required. Max dose: 2,000,000u/day."
  },
  {
    "drug": "Streptomycin (IM)",
    "dose": "Tuberculosis: 15mg/kg OD",
    "adjustments": "No renal dose adjustments specified"
  },
  {
    "drug": "Tetracycline (PO)",
    "dose": "H. pylori eradication therapy: 500mg QID",
    "adjustments": "<strong>50-90:</strong> 250-500mg BD-TDS<br><strong>10-50:</strong> 250-500mg OD-BD<br><strong>&lt;10 / HD/ CAPD:</strong> 250-500mg OD"
  },
  {
    "drug": "Tigecycline (IV)",
    "dose": "100mg LD, then 50mg BD",
    "adjustments": "No renal dose adjustment"
  },
  {
    "drug": "Trimethoprim / Sulfamethoxazole / Bactrim (IV/PO)",
    "dose": "15-20 mg/kg/day, in 2-4 divided doses OR 8-12 mg/kg/day in 2 divided doses. PO: 2 tab BD / 1 tab OD",
    "adjustments": "<strong>15-30:</strong> 7.5-10mg/kg/day OR 4-6mg/kg/day<br><strong>&lt;15/PD/HD:</strong> 4-5mg/kg OD OR 2-3mg/kg OD<br><strong>PO 2 tab BD (CrCl &lt;30/PD):</strong> 1 tab BD<br><strong>PO 2 tab BD (HD):</strong> 1 tab BD, serve post HD<br><strong>1 tab OD:</strong> No renal dose adjustment"
  },
  {
    "drug": "Trimethoprim / Sulfamethoxazole Meliodosis Therapy",
    "dose": "PO (1 tab = 400mg SMX/80mg TMP)",
    "adjustments": "<strong>&lt;40kg:</strong> Usual 4 tab BD. &lt;30/HD/CAPD: 3 tab OD.<br><strong>40-60kg:</strong> Usual 3 tab BD. &lt;30/HD/CAPD: 4 tab OD.<br><strong>&gt;60kg:</strong> Usual 2 tab BD. &lt;30/HD/CAPD: 1 tab BD."
  },
  {
    "drug": "Anidulafungin (IV) / Micafungin (IV)",
    "dose": "200mg stat, 100mg OD / 100mg OD",
    "adjustments": "No dosage adjustment. HD: supplemental dose is not necessary."
  },
  {
    "drug": "Fluconazole (IV/PO)",
    "dose": "100-800mg/day depend on indication",
    "adjustments": "<strong>≤50/PD:</strong> LD followed by 50% of usual MD<br><strong>HD:</strong> LD followed by 50% of usual MD, serve post HD on HD day"
  },
  {
    "drug": "Griseofulvin (PO) / Itraconazole (PO) / Nystatin (PO) / Terbinafine (PO) / Voriconazole (PO)",
    "dose": "Various depend on indication",
    "adjustments": "No dosage adjustment. (Itraconazole: Use with caution in renal impairment)"
  },
  {
    "drug": "Acyclovir (PO)",
    "dose": "400mg BD / 200mg 5x/day / 800mg 5x/day",
    "adjustments": "<strong>10-24:</strong> 200mg-400mg BD / 200mg TDS-5x/day / 800mg TDS<br><strong>&lt;10 / PD / HD:</strong> 200mg BD / 200mg BD / 800mg BD (HD serve post HD)"
  },
  {
    "drug": "Acyclovir (IV)",
    "dose": "5mg/kg/dose TDS / 10mg/kg/dose TDS",
    "adjustments": "<strong>25-50:</strong> 5mg/kg/dose BD / 10mg/kg/dose BD<br><strong>10-24:</strong> 5mg/kg/dose OD / 10mg/kg/dose OD<br><strong>&lt;10:</strong> 2.5mg/kg/dose OD / 5mg/kg/dose OD<br><strong>HD/PD:</strong> 2.5-5mg/kg/dose OD"
  },
  {
    "drug": "Ganciclovir (IV)",
    "dose": "5mg/kg BD / 5mg/kg OD",
    "adjustments": "<strong>50-69:</strong> 2.5mg/kg BD / 2.5mg/kg OD<br><strong>25-49:</strong> 2.5mg/kg OD / 1.25mg/kg OD<br><strong>10-24:</strong> 1.25mg/kg OD / 0.625mg/kg OD<br><strong>&lt;10/PD/HD:</strong> 1.25mg/kg 3x/wk / 0.625mg/kg 3x/wk"
  },
  {
    "drug": "Oseltamivir (PO)",
    "dose": "Treatment dose: 75mg BD",
    "adjustments": "<strong>31-60:</strong> 75mg stat, 30mg BD<br><strong>11-30:</strong> 30mg OD<br><strong>≤10:</strong> 30mg EOD<br><strong>HD:</strong> 30mg stat, 30mg after every HD for 5 days<br><strong>PD:</strong> 75mg stat (drug will last 5 days)"
  },
  {
    "drug": "Valganciclovir (PO)",
    "dose": "900mg BD / 900mg OD",
    "adjustments": "<strong>40-59:</strong> 450mg BD / 450mg OD<br><strong>25-39:</strong> 450mg OD / 450mg EOD<br><strong>10-24:</strong> 450mg EOD / 450mg 2x/wk<br><strong>&lt;10/PD/HD:</strong> Consider using oral solution 200mg 3x/wk / 100mg 3x/wk"
  }
];

export const dbRenalICU: RenalICUDrug[] = [
  {
    "drug": "Acyclovir",
    "dose": "10 mg/kg/dose q8h",
    "cr3050": "10 mg/kg/dose q24hr",
    "cr1030": "10 mg/kg/dose q12h",
    "cr10": "5 mg/kg/dose q24h",
    "rrt": "<strong>HD:</strong> 5 mg/kg q24h<br><strong>CVVH:</strong> 10 mg/kg q24h<br><strong>CVVHD/CVVHDF:</strong> 10 mg/kg q12h<br><strong>CAPD:</strong> 2.5-6.25 mg/kg q24h"
  },
  {
    "drug": "Amoxicillin/Clavulanate",
    "dose": "1.2 g q8h",
    "cr3050": "1.2 g q8h",
    "cr1030": "1.2 g q12h",
    "cr10": "1.2 g q24h",
    "rrt": "<strong>HD:</strong> 1.2 g q24h + 600 mg AD<br><strong>CVVH:</strong> 1.2 g q12h"
  },
  {
    "drug": "Amphotericin",
    "dose": "0.3-1 mg/kg q24h",
    "cr3050": "Refer Appendix 4",
    "cr1030": "Refer Appendix 4",
    "cr10": "Refer Appendix 4",
    "rrt": "Refer Appendix 4"
  },
  {
    "drug": "Ampicillin/Sulbactam",
    "dose": "3 g q6h",
    "cr3050": "3 g q8h",
    "cr1030": "3 g q12h",
    "cr10": "3 g q24h",
    "rrt": "<strong>HD:</strong> 3 g q24h<br><strong>CVVH:</strong> 3 g q8h-q12h<br><strong>CVVHD:</strong> 3 g q8h<br><strong>CVVHDF:</strong> 3 g q6h-q8h<br><strong>CAPD:</strong> 3 g q24h"
  },
  {
    "drug": "Ampicillin/Sulbactam (Acinetobacter sp MDR)",
    "dose": "9 g q8h",
    "cr3050": "6 g q8h (CrCl 20-50)",
    "cr1030": "6 g q12h (CrCl &lt;20)",
    "cr10": "6 g q12h (CrCl &lt;20)",
    "rrt": "<strong>HD:</strong> 6 g q12h<br><strong>CVVH/CVVHD/CVVHDF:</strong> 9 g q8h"
  },
  {
    "drug": "Ampicillin",
    "dose": "2 g q4h - q6h*",
    "cr3050": "2 g q6h-q12h",
    "cr1030": "2 g q6h-q12h",
    "cr10": "2 g q12h-q24h",
    "rrt": "<strong>HD:</strong> 2 g q12h<br><strong>CVVH:</strong> 2 g q8h - q12h<br><strong>CVVHD:</strong> 2 g q8h<br><strong>CVVHDF:</strong> 2 g q6h - q8h<br><strong>CAPD:</strong> 0.5-1 g q12h"
  },
  {
    "drug": "Anidulafungin",
    "dose": "200 mg STAT, then 100 mg q24h",
    "cr3050": "Unchanged",
    "cr1030": "Unchanged",
    "cr10": "Unchanged",
    "rrt": "Unchanged"
  },
  {
    "drug": "Benzylpenicillin",
    "dose": "4 MU q4-6h",
    "cr3050": "1.5-3 MU q4-q6h",
    "cr1030": "1.5-3 MU q4-q6h",
    "cr10": "1-2 MU q4-q6h",
    "rrt": "<strong>HD:</strong> 1-2 MU q4h-q6h<br><strong>CVVH:</strong> 2 MU q4h-q6h<br><strong>CVVHD:</strong> 2-3 MU q4h-q6h<br><strong>CVVHDF:</strong> 2-4 MU q4h-q6h<br><strong>CAPD:</strong> 4 MU q12h"
  },
  {
    "drug": "Cefazolin",
    "dose": "2 g q8h",
    "cr3050": "2 g q12h",
    "cr1030": "2 g q24h",
    "cr10": "1 g q24h",
    "rrt": "<strong>HD:</strong> 1 g q24h<br><strong>CVVH/CVVHD/CVVHDF:</strong> 1 g q8h or 2 g q12h<br><strong>CAPD:</strong> 500 mg q12h"
  },
  {
    "drug": "Cefepime",
    "dose": "2 g q8h - q12h",
    "cr3050": "2 g q12h",
    "cr1030": "1 g q24h",
    "cr10": "1 g q24h",
    "rrt": "<strong>HD:</strong> 1 g q24h +1 g AD<br><strong>CVVH/CVVHD/CVVHDF:</strong> 2 g q8h-q12h<br><strong>CAPD:</strong> 2 g q48h"
  },
  {
    "drug": "Cefoperazone",
    "dose": "1-2 g q12h",
    "cr3050": "Renal impairment: no adjustment",
    "cr1030": "Renal impairment: no adjustment",
    "cr10": "Renal impairment: no adjustment",
    "rrt": "<strong>HD:</strong> serve AD"
  },
  {
    "drug": "Cefotaxime",
    "dose": "2 g q4-8h",
    "cr3050": "2 g q8h-q12h",
    "cr1030": "2 g q12h",
    "cr10": "2 g q24h",
    "rrt": "<strong>HD:</strong> 1 g-2 g q24h<br><strong>CVVH/CVVHD/CVVHDF:</strong> 2 g q12h-q24h<br><strong>CAPD:</strong> 1 g q24h"
  },
  {
    "drug": "Ceftazidime",
    "dose": "2 g q8h",
    "cr3050": "2 g q8h-q12h",
    "cr1030": "2 g q24h",
    "cr10": "1 g q24h",
    "rrt": "<strong>HD:</strong> 2 g q24h + 1 g AD<br><strong>CVVH:</strong> 2 g q12h<br><strong>CVVHD/CVVHDF:</strong> 2 g q8h-q12h<br><strong>CAPD:</strong> 1 g q24h"
  },
  {
    "drug": "Ceftazidime (Meliodosis)",
    "dose": "2 g q6h",
    "cr3050": "Wt &lt; 60kg: 1 g q8h<br>Wt &gt;= 60kg: 2 g q12h (CrCl 31-50)",
    "cr1030": "Wt &lt; 60kg: 1 g q12h<br>Wt &gt;= 60kg: 2 g q24h (CrCl 15-30)",
    "cr10": "Wt &lt; 60kg: 1 g q24h<br>Wt &gt;= 60kg: 1 g q24h (CrCl &lt; 15)",
    "rrt": "<strong>HD/CAPD:</strong> As per CrCl &lt;15, serve post HD"
  },
  {
    "drug": "Ceftriaxone",
    "dose": "2 g stat then 1g q12h",
    "cr3050": "2 g q8h",
    "cr1030": "Unchanged",
    "cr10": "2 g q12h",
    "rrt": "<strong>Unchanged</strong>"
  },
  {
    "drug": "Cefuroxime",
    "dose": "1.5 g q8h",
    "cr3050": "1.5 g q8h",
    "cr1030": "1.5 g q12h",
    "cr10": "1.5 g q24h",
    "rrt": "<strong>HD:</strong> 1.5 g q24h<br><strong>CVVH:</strong> 1.5 g q8-12h<br><strong>CAPD:</strong> 0.75-1.5 g q24h"
  },
  {
    "drug": "Ciprofloxacin",
    "dose": "400 mg LD then 400 mg q8-12h",
    "cr3050": "Unchanged",
    "cr1030": "400 mg q12-24h",
    "cr10": "400 mg q24h",
    "rrt": "<strong>HD:</strong> 400 mg q24h<br><strong>CVVH:</strong> 200 mg-400 mg q12h<br><strong>CVVHD/CVVHDF:</strong> 400 mg q12h<br><strong>CAPD:</strong> 400 mg q24h"
  },
  {
    "drug": "Clindamycin / Cloxacillin / Micafungin",
    "dose": "Depend on indication / 2 g q4-6h / 100 mg q24h",
    "cr3050": "Unchanged",
    "cr1030": "Unchanged",
    "cr10": "Unchanged",
    "rrt": "<strong>Unchanged</strong>"
  },
  {
    "drug": "Fluconazole",
    "dose": "800 mg stat then 400-800 mg q24h",
    "cr3050": "200-400 mg q24h",
    "cr1030": "200-400 mg q24h",
    "cr10": "200-400 mg q24h",
    "rrt": "<strong>HD:</strong> 200-400 mg q24h<br><strong>CVVH:</strong> 400 mg q24h<br><strong>CVVHD/CVVHDF:</strong> 400-800 mg q24h<br><strong>CAPD:</strong> 200 mg q24h"
  },
  {
    "drug": "Imipenem",
    "dose": "1 g q8h",
    "cr3050": "500 mg q6h",
    "cr1030": "500 mg q8h",
    "cr10": "500 mg q12h",
    "rrt": "<strong>HD:</strong> 500 mg q12h<br><strong>CVVH:</strong> 500 mg q8h<br><strong>CVVHD/CVVHDF:</strong> 500 mg q6h<br><strong>CAPD:</strong> 250 mg q12h"
  },
  {
    "drug": "Levofloxacin",
    "dose": "750 mg q24h",
    "cr3050": "750 mg q48h",
    "cr1030": "500 mg q48h",
    "cr10": "500 mg q48h",
    "rrt": "<strong>HD:</strong> 500 mg q48h<br><strong>CVVH:</strong> 250 mg q24h<br><strong>CVVHD:</strong> 500 mg q24h<br><strong>CVVHDF:</strong> 750 mg q24h<br><strong>CAPD:</strong> 500 mg q48h"
  },
  {
    "drug": "Linezolid",
    "dose": "600 mg q12h",
    "cr3050": "Unchanged",
    "cr1030": "Unchanged",
    "cr10": "Unchanged",
    "rrt": "<strong>HD:</strong> serve post HD on HD day"
  },
  {
    "drug": "Meropenem",
    "dose": "1-2 g q8h",
    "cr3050": "1-2 g q12h",
    "cr1030": "500 mg -1 g q12h",
    "cr10": "500 mg q12-24h",
    "rrt": "<strong>HD:</strong> 500 mg -1 g q24h + 250-500 mg AD<br><strong>CVVH/CVVHD/CVVHDF:</strong> 1-2 g q12h<br><strong>CAPD:</strong> 500 mg q24h"
  },
  {
    "drug": "Metronidazole",
    "dose": "500 mg q8h",
    "cr3050": "Unchanged",
    "cr1030": "Unchanged",
    "cr10": "Unchanged",
    "rrt": "<strong>HD/CAPD:</strong> 500 mg q8h<br><strong>CVVH/CVVHD/CVVHDF:</strong> 500 mg q8h"
  },
  {
    "drug": "Oseltamivir",
    "dose": "75 mg q12h",
    "cr3050": "75 mg q24h",
    "cr1030": "75 mg q24h",
    "cr10": "30mg q48h",
    "rrt": "<strong>HD:</strong> 75 mg q24h<br><strong>CVVH/CVVHD/CVVHDF:</strong> 75 mg q12h"
  },
  {
    "drug": "Piperacillin/Tazobactam",
    "dose": "4.5 g q6h",
    "cr3050": "4.5 g q6h",
    "cr1030": "4.5 g q8h",
    "cr10": "2.25 g q6h",
    "rrt": "<strong>HD:</strong> 2.25 g q6h<br><strong>CVVH:</strong> 2.25 g q6h<br><strong>CVVHD/CVVHDF:</strong> 4.5 g q8h<br><strong>CAPD:</strong> 2.25 g q8h"
  },
  {
    "drug": "Tigecycline",
    "dose": "100 mg LD then 50 mg q12h",
    "cr3050": "Unchanged",
    "cr1030": "Unchanged",
    "cr10": "Unchanged",
    "rrt": "Unchanged"
  },
  {
    "drug": "Trimethoprim/Sulfamethoxazole (TMP Content)",
    "dose": "5 mg/kg q6-8h",
    "cr3050": "5 mg/kg q8h",
    "cr1030": "5 mg/kg q12h",
    "cr10": "5-10 mg/kg q24h",
    "rrt": "<strong>HD/CAPD:</strong> 5-10 mg/kg q24h<br><strong>CVVH/CVVHD:</strong> 5 mg/kg q12h<br><strong>CVVHDF:</strong> 10 mg/kg q12h"
  },
  {
    "drug": "Trimethoprim/Sulfamethoxazole (Melioidosis)",
    "dose": "4 mg/kg q12h",
    "cr3050": "4 mg/kg q12h",
    "cr1030": "4 mg/kg q24h",
    "cr10": "4 mg/kg q24h",
    "rrt": "<strong>HD:</strong> 4 mg/kg q24h<br><strong>CVVH/CVVHD/CVVHDF:</strong> 4 mg/kg q12h<br><strong>CAPD:</strong> 4 mg/kg q24h"
  },
  {
    "drug": "Polymyxin E (Colistin)",
    "dose": "LD: 9 MU STAT (usual) or by weight",
    "cr3050": "3 MU BD",
    "cr1030": "2.5 MU BD",
    "cr10": "2 MU BD",
    "rrt": "<strong>CVVH/CWHDF:</strong> 4 MU TDS<br><strong>HD:</strong> 2 MU BD + 1.5 MU AD<br><strong>SLED 4h:</strong> 2 MU BD + 1.5 MU after SLED<br><strong>SLED 6h:</strong> 2 MU BD + 2.5 MU after SLED"
  },
  {
    "drug": "Polymyxin B",
    "dose": "LD: 25,000u/kg (Max 2MU/day)",
    "cr3050": "Unchanged",
    "cr1030": "Unchanged",
    "cr10": "Unchanged",
    "rrt": "<strong>Unchanged</strong>"
  }
];
