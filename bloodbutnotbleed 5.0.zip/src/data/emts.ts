import { EMTSDrug } from "../types";

export const dbEMTS: EMTSDrug[] = [
  {
    drug: "Adrenaline (Epinephrine) 1mg/ml",
    indication: "Cardiac Arrest, Anaphylaxis, Severe Bradycardia / Cardiogenic Shock",
    category: "Resuscitation",
    preparation: "IM (Anaphylaxis): Undiluted 1:1000.\nIV Bolus (CPR): 1:10,000 dilution (Dilute 1ml of 1:1000 Adrenaline with 9ml of NS to make 10ml).\nIV Infusion: Single Strength (3mg in 50ml NS, 60 mcg/ml) or Double Strength (6mg in 50ml NS, 120 mcg/ml).",
    bolus: "Cardiac Arrest: 1mg (10ml of 1:10,000) IV/IO push every 3-5 minutes.\nAnaphylaxis: 0.5mg (0.5ml of 1:1000) IM in anterolateral thigh. Repeat every 5-15 mins if needed.",
    infusion: "0.05 - 0.5 mcg/kg/minute (titrate to maintain SBP >90 mmHg).",
    precautions: "Infuse via large vein / central line if possible to avoid extravasation necrosis. Monitor heart rate and rhythm constantly. Avoid mixing with alkaline solutions like Sodium Bicarbonate."
  },
  {
    drug: "Noradrenaline (Norepinephrine) 4mg/4ml",
    indication: "Septic Shock, Cardiogenic Shock, Refractory Hypotension",
    category: "Shock/Inotropes",
    preparation: "Dilute ONLY in Dextrose 5% or D5% in NS (Glucose prevents oxidation/loss of potency).\nSingle Strength: 4mg (1 ampoule) in 46ml D5% (80 mcg/ml).\nDouble Strength: 8mg (2 ampoules) in 42ml D5% (160 mcg/ml).\nQuadruple Strength: 16mg (4 ampoules) in 34ml D5% (320 mcg/ml).",
    bolus: "N/A (Do NOT administer as an IV bolus; risk of severe acute hypertension and brain hemorrhage).",
    infusion: "0.05 - 1.0 mcg/kg/minute (titrate every 2-5 minutes to maintain Mean Arterial Pressure >65 mmHg).",
    precautions: "MANDATORY administration via a central line or large bore patent cannula in emergency. Monitor for extravasation (causes severe local tissue ischemia/necrosis; antidote is Phentolamine)."
  },
  {
    drug: "Amiodarone (Cordarone) 150mg/3ml",
    indication: "Pulseless VT / VF, Stable Monomorphic VT, Atrial Fibrillation with Rapid Ventricular Response",
    category: "Resuscitation",
    preparation: "Dilute ONLY in Dextrose 5% (Precipitates and crystallizes in Normal Saline).\nCardiac Arrest: 300mg diluted in 20ml D5% in a syringe.\nStable VT (Loading): 150mg diluted in 100ml D5%.\nMaintenance Infusion: 900mg (6 ampoules) diluted in 500ml D5% (1.8 mg/ml).",
    bolus: "Cardiac Arrest: 300mg IV/IO rapid bolus. May give secondary bolus of 150mg once.\nStable VT Loading: 150mg IV over 10 to 20 minutes (using infusion pump).",
    infusion: "First 6 hours: 360mg (1 mg/minute, run at 33.3 ml/hour of a 900mg/500ml infusion).\nNext 18 hours: 540mg (0.5 mg/minute, run at 16.7 ml/hour).",
    precautions: "Irritating to peripheral veins (causes thrombophlebitis; use central line for continuous infusion). Watch for hypotension and bradycardia. Do not mix with other drugs in the same line."
  },
  {
    drug: "Dopamine 200mg/5ml",
    indication: "Symptomatic Bradycardia, Cardiogenic Shock / Hypotension",
    category: "Shock/Inotropes",
    preparation: "Single Strength: 200mg (1 ampoule) in 45ml NS or D5% (4000 mcg/ml).\nDouble Strength: 400mg (2 ampoules) in 40ml NS or D5% (8000 mcg/ml).",
    bolus: "N/A (Do not give as IV bolus).",
    infusion: "2 - 20 mcg/kg/minute.\nLow dose (1-5 mcg/kg/min): renal/dopaminergic.\nMedium dose (5-10 mcg/kg/min): beta-1 inotropic.\nHigh dose (10-20 mcg/kg/min): alpha-1 vasopressor.",
    precautions: "Tachyarrhythmogenic (induces tachycardias easily). Ensure patient is adequately fluid resuscitated before starting pressor doses. Central line or secure patent cannula is critical."
  },
  {
    drug: "Dobutamine 250mg/20ml",
    indication: "Cardiogenic Shock, Decompensated Heart Failure (with SBP >90 mmHg)",
    category: "Shock/Inotropes",
    preparation: "Single Strength: 250mg (1 vial) in 30ml NS or D5% (5000 mcg/ml).\nDouble Strength: 500mg (2 vials) in 10ml NS or D5% (10000 mcg/ml).",
    bolus: "N/A (Do not give as IV bolus).",
    infusion: "2.5 - 20 mcg/kg/minute.",
    precautions: "Powerful inotrope but causes moderate vasodilation, which may trigger or worsen hypotension if blood volume is depleted. Monitor for tachyarrhythmias and myocardial ischemia."
  },
  {
    drug: "Labetalol 25mg/5ml",
    indication: "Hypertensive Crisis, Aortic Dissection, Severe Preeclampsia, Stroke Management",
    category: "Hypertension",
    preparation: "IV Bolus: Use undiluted formulation (5 mg/ml).\nIV Infusion: Dilute 100mg (4 ampoules) in 50ml NS or D5% (2 mg/ml).",
    bolus: "10 - 20mg slow IV push over 2 minutes. Can repeat with double doses (40mg, then 80mg) every 10 minutes until target BP is achieved (Max cumulative dose 300mg).",
    infusion: "1 - 2 mg/minute (30 - 60 ml/hour of 2 mg/ml dilution), titrate to blood pressure response.",
    precautions: "Contraindicated in severe bradycardia, second/third-degree AV block, bronchial asthma, and decompensated heart failure."
  },
  {
    drug: "Sodium Bicarbonate 8.4% (1 mmol/ml)",
    indication: "Severe Metabolic Acidosis (pH <7.1), Hyperkalaemia, Tricyclic Antidepressant (TCA) Overdose",
    category: "Resuscitation",
    preparation: "Standard formulation contains 1 mmol/ml. Use undiluted for emergency bolus.\nIsotonic Bicarbonate Infusion: Dilute 150ml of 8.4% (150 mmol) in 1000ml of Dextrose 5% or Sterile Water.",
    bolus: "TCA Overdose / Hyperkalaemia: 50 - 100 mmol (50 - 100ml) slow IV push over 5-10 minutes. Repeat as needed to keep blood pH 7.45 - 7.55 in TCA toxicity.",
    infusion: "Infuse isotonic bicarbonate solution over 2 - 4 hours to correct severe metabolic acidosis.",
    precautions: "CRITICAL: Never administer in the same line as Calcium Gluconate (forms immediate white chalky calcium carbonate precipitate!). Ensure patent line as it is highly hypertonic."
  },
  {
    drug: "Calcium Gluconate 10% (1g/10ml)",
    indication: "Hyperkalaemia with ECG changes, Hypocalcaemia, Magnesium Toxicity",
    category: "Resuscitation",
    preparation: "Contains 2.25 mmol (4.5 mEq) of elemental Calcium per 10ml ampoule. Use undiluted.",
    bolus: "10ml (1 ampoule) IV slow push over 5 - 10 minutes. May repeat after 5 minutes if ECG abnormalities (peaked T waves, wide QRS) persist.",
    infusion: "For maintenance, dilute 5 - 10g (50 - 100ml) in 250ml NS or D5% and infuse over 2 - 4 hours.",
    precautions: "Do NOT inject rapidly (can cause cardiac arrest and severe bradycardia). Use with extreme caution in patients on Digoxin (can trigger digitalis-induced arrhythmias)."
  },
  {
    drug: "Magnesium Sulfate 50% (2.47g/5ml)",
    indication: "Eclampsia (seizure loading & maintenance), Torsades de Pointes, Severe Refractory Asthma",
    category: "Respiratory/Other",
    preparation: "Contains 10 mmol (20 mEq) Magnesium per 5ml ampoule.\nEclampsia Loading: Dilute 4g (8ml of 50%) with 12ml NS to make a 20ml of 20% solution.\nTorsades / Severe Asthma: Dilute 2g (4ml) in 100ml NS or D5%.",
    bolus: "Eclampsia Loading: Infuse 4g over 15 - 20 minutes (pump preferred).\nTorsades (pulseless): IV/IO bolus over 1 - 2 minutes.\nTorsades (with pulse): Infuse 2g over 10 - 15 minutes.\nSevere Asthma: Infuse 2g over 20 minutes.",
    infusion: "Eclampsia Maintenance: 1 - 2 g/hour continuous infusion (e.g., dilute 10g in 500ml NS and run at 50 - 100 ml/hour).",
    precautions: "Monitor patellar reflexes, respiratory rate (>16 bpm), and hourly urine output. If toxicity occurs, stop infusion and administer Calcium Gluconate 1g IV slow push."
  },
  {
    drug: "Atropine Sulfate 1mg/ml",
    indication: "Symptomatic Bradycardia, Organophosphate / Carbamate Poisoning",
    category: "Resuscitation",
    preparation: "Standard 1mg/ml ampoules. Use undiluted for emergency bolus.",
    bolus: "Bradycardia: 1mg IV bolus every 3-5 minutes (Max total dose: 3mg).\nOrganophosphate Poisoning: 2 - 5mg IV slow push every 5-10 minutes. If no response, double the dose until secretional atropinization (clear lungs, dry skin, HR >80 bpm).",
    infusion: "Organophosphate Maintenance: Continuous infusion of 10 - 20% of the total cumulative dose required for atropinization per hour (diluted in NS).",
    precautions: "Do not give doses <0.5mg as it can cause paradoxical bradycardia. Watch for anticholinergic syndrome (delirium, hyperthermia, flushed dry skin)."
  },
  {
    drug: "Adenosine 6mg/2ml",
    indication: "Paroxysmal Supraventricular Tachycardia (SVT) conversion",
    category: "Resuscitation",
    preparation: "Standard 6mg/2ml formulation. Use undiluted.",
    bolus: "Initial Dose: 6mg RAPID IV push (over 1-2 seconds) in a large proximal vein (e.g., antecubital fossa), immediately followed by a rapid 20ml NS flush (double-syringe or 3-way stopcock method).\nRepeat Dose: If no conversion in 1-2 mins, give 12mg rapid IV push with 20ml flush. Can repeat 12mg once.",
    infusion: "N/A (Extremely short half-life <10 seconds; continuous infusion is not clinically used).",
    precautions: "MANDATORY: Warn patient about severe chest pressure, shortness of breath, and flushing. Keep defibrillator pads on patient. Contraindicated in asthma, and high-degree AV block."
  },
  {
    drug: "Midazolam 15mg/3ml",
    indication: "Status Epilepticus, RSI Sedation, Continuous Ventilation Sedation",
    category: "Sedation/Analgesia",
    preparation: "IV Bolus: Dilute 15mg (3ml) up to 15ml NS to yield 1 mg/ml concentration.\nIM: Use undiluted 5 mg/ml or 15mg/3ml.\nContinuous Infusion: Dilute 50mg in 50ml NS or D5% (Final concentration 1 mg/ml).",
    bolus: "Status Epilepticus: 10mg IM once, or 0.1 - 0.2 mg/kg slow IV push over 2 minutes.\nRSI Sedation: 0.1 - 0.3 mg/kg IV push.",
    infusion: "Continuous ICU Sedation: 1 - 5 mg/hour (1 - 5 ml/hour of 1 mg/ml solution).",
    precautions: "Strong respiratory depressant and hypotensive agent. Always have resuscitation / airway equipment at bedside. Monitor pulse oximetry and ETCO2 continuously."
  },
  {
    drug: "Nicardipine 10mg/10ml",
    indication: "Hypertensive Crises, Acute Ischemic Stroke (to lower BP prior to thrombolysis), Acute Intracerebral Haemorrhage",
    category: "Hypertension",
    preparation: "Continuous Infusion: Dilute 50mg (5 ampoules) in 50ml NS or D5% (concentration: 1 mg/ml). Alternatively, dilute 20mg in 40ml or 50mg in 200ml depending on ward protocol.",
    bolus: "N/A (Do not give as IV bolus).",
    infusion: "Start at 2.5 - 5.0 mg/hour. Increase by 2.5 mg/hour every 5-15 minutes until target BP is achieved. Maximum dose: 15 mg/hour. Once target BP achieved, reduce dose to 3 mg/hour.",
    precautions: "Closely monitor BP continuously. Causes reflex tachycardia and headache. May induce phlebitis; change peripheral infusion site every 12 hours or use central line."
  },
  {
    drug: "Alteplase (rt-PA) 50mg/vial",
    indication: "Acute Ischemic Stroke (within 4.5 hours of onset), Massive Pulmonary Embolism, STEMI (if PCI unavailable)",
    category: "Resuscitation",
    preparation: "Reconstitute with provided sterile water (usually 50mg in 50ml) to a concentration of 1 mg/ml. Do not shake vigorously (swirl gently to avoid foaming).",
    bolus: "Acute Ischemic Stroke: 10% of total dose administered as an IV bolus over 1 minute.\nMassive PE: 10mg IV bolus over 1-2 minutes.",
    infusion: "Acute Ischemic Stroke: Total dose is 0.9 mg/kg (Maximum 90mg). Remaining 90% infused over 60 minutes.\nMassive PE: Remaining 90mg infused over 2 hours.",
    precautions: "Strictly adhere to inclusion/exclusion criteria for thrombolysis. Maintain BP <180/105 mmHg during and 24 hours post-infusion. Do not insert NGT, catheter, or perform arterial puncture during infusion. Monitor for intracranial/systemic bleeding."
  },
  {
    drug: "Vasopressin (Pitressin) 20 units/ml",
    indication: "Septic Shock (refractory to Noradrenaline), GI Bleeding / Variceal Bleed",
    category: "Shock/Inotropes",
    preparation: "Septic Shock: Dilute 20 units (1ml) in 19ml or 49ml NS (1 unit/ml or 0.4 units/ml).\nVariceal Bleed: Dilute 20 units in 50ml NS (0.4 units/ml).",
    bolus: "N/A (Do not bolus in shock).",
    infusion: "Septic Shock: 0.01 - 0.04 units/minute (titrate to maintain MAP, do not exceed 0.04).\nVariceal Bleed: 0.2 - 0.4 units/minute continuous infusion.",
    precautions: "Potent vasoconstrictor; monitor for signs of bowel ischemia and digital ischemia. Ensure central line access."
  },
  {
    drug: "Insulin (Actrapid) - KIM Protocol",
    indication: "Hyperglycemic Emergencies (DKA, HHS), Hyperkalaemia, VRII for Critical Illness",
    category: "Metabolic",
    preparation: "Standard KIM Dilution: 50 units Actrapid in 50ml NS (1 unit/ml).",
    bolus: "Hyperkalaemia: 10 units Actrapid with 50ml of 50% Dextrose (D50) over 15-30 minutes.\nDKA/HHS: 0.1 unit/kg IV bolus (optional, check local protocol).",
    infusion: "DKA/HHS: Start at 0.1 units/kg/hour (e.g. 70kg = 7ml/hour of 1u/ml solution).\nTitrate based on blood glucose and ketone clearance.",
    precautions: "Monitor hourly capillary blood glucose (CBG). Check Potassium every 2-4 hours. Do not stop infusion until ketones cleared and patient is on basal/bolus sc regimen."
  },
  {
    drug: "Potassium Chloride (KCl) 7.5% (1 mmol/ml)",
    indication: "Symptomatic Hypokalaemia (K <3.0 mmol/L)",
    category: "Metabolic",
    preparation: "Peripheral: MAX 10 mmol/hour (e.g. 10ml 7.5% KCl in 500ml NS/D5%).\nCentral: 20 - 40 mmol in 100ml NS (via syringe pump).",
    bolus: "NEVER administer as a bolus or undiluted. Causes immediate cardiac arrest.",
    infusion: "Peripheral: Max 10 mmol/hour.\nCentral: 10 - 20 mmol/hour (requires continuous ECG monitoring).",
    precautions: "Extremely irritating to veins. Check renal function and urine output before aggressive replacement. Use infusion pump for all Central KCl."
  },
  {
    drug: "Lignocaine (Lidocaine) 2% (20mg/ml)",
    indication: "Refractory VF / Pulseless VT (if Amiodarone unavailable), Stable Monomorphic VT",
    category: "Resuscitation",
    preparation: "IV Bolus: Use undiluted 1% or 2% formulation.\nIV Infusion: Dilute 1g (50ml of 2%) in 200ml NS/D5% (Final concentration 4 mg/ml).",
    bolus: "Cardiac Arrest: 1 - 1.5 mg/kg IV/IO. May repeat 0.5 - 0.75 mg/kg every 5-10 mins (Max 3mg/kg).",
    infusion: "1 - 4 mg/minute (15 - 60 ml/hour of 4 mg/ml dilution).",
    precautions: "Toxicity signs: drowsiness, confusion, seizures, peri-oral numbness. Reduce dose in heart failure or liver disease."
  }

];