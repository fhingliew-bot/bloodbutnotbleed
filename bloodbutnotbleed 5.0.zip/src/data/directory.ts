export interface DirectoryItem {
  name: string;
  ext: string;
}

export interface DirectoryDept {
  dept: string;
  items: DirectoryItem[];
}

export const directoryData: DirectoryDept[] = [
  {
    dept: "Chemical Pathology",
    items: [
      { name: "Core Chemistry Lab", ext: "5610 / 7569" },
      { name: "Special Chem / Endocrin", ext: "6102 / 5608" },
      { name: "Phlebotomy (SCACC)", ext: "1005 / 1008" },
      { name: "HKL Main Operator", ext: "03-26155555" }
    ]
  },
  {
    dept: "Hematology Lab",
    items: [
      { name: "Main Lab / FBP Trace", ext: "6374 / 6549" },
      { name: "Blood Bank (GXM/GSH)", ext: "5755 / 6378" },
      { name: "Molecular Hema", ext: "5746 / 5748" },
      { name: "Flow Cytometry", ext: "5753" }
    ]
  },
  {
    dept: "Microbiology",
    items: [
      { name: "Main Lab (Bacto)", ext: "5615" },
      { name: "TB Lab (AFB)", ext: "6860" },
      { name: "Serology / Virology", ext: "6852 / 7436" },
      { name: "Molecular Micro", ext: "5632" }
    ]
  },
  {
    dept: "Pathology (HPE)",
    items: [
      { name: "Frozen Section", ext: "6851 / 5603" },
      { name: "Muscle / Nerve Lab", ext: "6651" },
      { name: "Histology Trace", ext: "5595" },
      { name: "Cytology Trace", ext: "5599" }
    ]
  },
  {
    dept: "Pharmacy Services",
    items: [
      { name: "Main Pharmacy (HKL)", ext: "2514 / 2515" },
      { name: "Inpatient Pharmacy", ext: "2520" },
      { name: "TDM Pharmacy", ext: "2517" },
      { name: "Drug Info Center", ext: "2516" }
    ]
  }
];
