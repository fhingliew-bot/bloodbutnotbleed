import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  Search, 
  Droplet, 
  AlertTriangle, 
  Phone, 
  FileText, 
  Info, 
  Calculator, 
  Clock, 
  Wind, 
  ChevronRight, 
  CheckCircle2, 
  X, 
  HelpCircle, 
  Sparkles,
  Sun,
  Moon,
  Volume2,
  Copy,
  ArrowRight,
  Zap,
  ClipboardList
} from "lucide-react";
import { testDatabase } from "./data/labs";
import { dbDilution, dbRenalStable, dbRenalICU } from "./data/drugs";
import { dbEMTS } from "./data/emts";
import { LabTest, DilutionDrug, RenalStableDrug, RenalICUDrug, EMTSDrug } from "./types";
import { directoryData } from "./data/directory";

export default function App() {
  // Theme State
  const [theme, setTheme] = useState<"dark" | "light">("dark");
  
  // Synonym dictionary for clinical terms
  const getSynonyms = (query: string): string[] => {
    const qRaw = query.toLowerCase().trim();
    // Normalize common typos or variations, removing hyphens and spaces for spelling-level comparison
    let q = qRaw.replace(/[-\s]+/g, "");
    if (q.includes("anticaar") || q.includes("anticar") || q === "acl" || q.includes("cardiolipin")) {
      q = "anticardiolipin";
    }
    if (q.includes("phospholipid") || q === "aps" || q === "apl") {
      q = "antiphospholipid";
    }

    const synonyms: string[] = [qRaw, q];
    
    // Dictionary matching for clinical syndromes
    if (q === "anticardiolipin" || q === "antiphospholipid" || q === "lupusanticoagulant" || q === "beta2" || q === "b2gp1") {
      synonyms.push("anticardiolipin", "acl", "aps", "antiphospholipid", "lupus anticoagulant", "anti-dsdna", "beta-2 glycoprotein", "b2gp1", "sle", "lupus", "rheumatoid", "serology");
    }
    if (q === "sle" || q === "lupus" || q === "dsdna" || q === "ana" || q === "autoimmune") {
      synonyms.push("sle", "lupus", "dsdna", "anti-dsdna", "anti-nuclear", "ana", "autoimmune", "anticardiolipin", "lupus anticoagulant", "serology");
    }
    if (q === "renal" || q === "rft" || q === "rp" || q === "kidney") {
      synonyms.push("renal profile", "urea", "creatinine", "sodium", "potassium", "chloride", "gfr", "clearance");
    }
    if (q === "lft" || q === "liver") {
      synonyms.push("liver function test", "alt", "ast", "alp", "bilirubin", "albumin", "total protein", "gamma-glutamyltransferase");
    }
    if (q === "dic" || q === "divc") {
      synonyms.push("divc", "d-dimer", "fibrinogen", "aptt", "prothrombin");
    }
    if (q === "coag" || q === "clotting" || q === "coagulation") {
      synonyms.push("coagulation", "pt", "inr", "aptt", "fibrinogen", "lupus anticoagulant", "citrate", "blue cap");
    }
    if (q === "cardiac" || q === "heart" || q === "mi") {
      synonyms.push("troponin", "creatine kinase", "ast", "lactate dehydrogenase", "ckmb", "cardiac");
    }
    if (q === "bone" || q === "calcium") {
      synonyms.push("calcium", "phosphate", "alkaline phosphatase", "parathyroid", "vitamin d", "ipth");
    }
    if (q === "std" || q === "vdrl" || q === "hiv") {
      synonyms.push("syphilis", "hiv", "hepatitis", "gonococcal", "ct/ng");
    }
    if (q === "lipid" || q === "cholesterol") {
      synonyms.push("cholesterol", "triglycerides", "hdl", "fasting serum lipid", "fsl");
    }
    if (q === "tft" || q === "thyroid") {
      synonyms.push("thyroid", "tsh", "ft4", "ft3", "free t4", "free t3");
    }
    if (q === "ufeme" || q === "feme" || q === "urine") {
      synonyms.push("urine biochemistry", "feme", "dysmorphic");
    }
    if (q === "fbc" || q === "fbp" || q === "full blood") {
      synonyms.push("full blood count", "full blood picture", "fbp", "fbc", "hemoglobin", "haemoglobin", "platelet", "wbc", "edta tube", "purple");
    }
    if (q === "abg" || q === "vbg" || q === "gas" || q === "blood gas") {
      synonyms.push("blood gases", "cooximetry", "preheparinized syringe", "lactate", "ph");
    }
    if (q === "gxm" || q === "gsh" || q === "crossmatch" || q === "transfusion") {
      synonyms.push("group and crossmatch", "gsh", "blood bank", "screen and hold");
    }
    if (q === "neuro" || q === "neurology") {
      synonyms.push("acetylcholine", "musk", "aquaporin", "nmo", "mog", "encephalitis", "paraneoplastic", "14-3-3", "oligoclonal", "vdrl");
    }
    if (q === "endo" || q === "endocrinology") {
      synonyms.push("synacthen", "dexamethasone", "growth hormone", "water deprivation", "insulin tolerance", "aldosterone", "renin", "cortisol", "metanephrine");
    }
    if (q === "piptazo") {
      synonyms.push("piperacillin", "piperacilin/tazobactam");
    }
    if (q === "coamox" || q === "augmentin") {
      synonyms.push("amoxicillin/clavulanate");
    }
    if (q === "cloxa") {
      synonyms.push("cloxacillin");
    }
    if (q === "bactrim") {
      synonyms.push("trimethoprim / sulfamethoxazole", "tmp");
    }
    if (q === "hba1c") {
      synonyms.push("haemoglobin a1c");
    }
    if (q === "trop") {
      synonyms.push("troponin t high sensitive");
    }
    if (q === "lytic") {
      synonyms.push("lytic cocktail");
    }
    if (q === "paracetamol" || q === "panadol" || q === "pcm") {
      synonyms.push("acetaminophen", "paracetamol", "plain tube without gel", "pcm", "panadol");
    }
    if (q === "yellow" || q === "gold" || q === "sst") {
      synonyms.push("plain tube with gel (yellow cap)", "gel", "yellow cap", "sst");
    }
    if (q === "blue" || q === "citrate") {
      synonyms.push("blue cap (citrate)", "trisodium citrate", "blue cap");
    }
    if (q === "purple" || q === "lavender" || q === "edta") {
      synonyms.push("edta tube", "purple");
    }
    if (q === "green" || q === "heparin") {
      synonyms.push("lithium heparin", "green");
    }
    if (q === "grey" || q === "fluoride" || q === "sugar") {
      synonyms.push("grey cap", "fluoride", "grey");
    }

    return Array.from(new Set(synonyms));
  };

  const matchesQuery = (textToSearch: string, query: string) => {
    if (!query) return true;
    const target = textToSearch.toLowerCase();
    const targetNormalized = target.replace(/[-\s]+/g, "");
    
    // Normalize search query inputs and typos
    const cleanQuery = query.toLowerCase()
      .replace(/anticaardiolpin/g, "anticardiolipin")
      .replace(/anticaar/g, "anticar");
    const cleanQueryNormalized = cleanQuery.replace(/[-\s]+/g, "");
    
    // Direct matches on normalized strings (handles "anti-cardiolipin" to "anticardiolipin" flawlessly)
    if (targetNormalized.includes(cleanQueryNormalized)) return true;
    
    const words = cleanQuery.split(/\s+/).filter(Boolean);
    if (words.length === 0) return true;

    // Check if every word in the search query matches the target directly or via its individual synonyms
    const matchesAllWords = words.every(word => {
      if (target.includes(word)) return true;
      
      const normWord = word.replace(/[-\s]+/g, "");
      if (targetNormalized.includes(normWord)) return true;
      
      const wordSyns = getSynonyms(word);
      return wordSyns.some(syn => {
        const normSyn = syn.replace(/[-\s]+/g, "");
        return target.includes(syn) || targetNormalized.includes(normSyn);
      });
    });

    if (matchesAllWords) return true;

    // Fallback: Check if the whole query string matches via synonyms
    const wholeSyns = getSynonyms(cleanQuery);
    return wholeSyns.some(syn => {
      const normSyn = syn.replace(/[-\s]+/g, "");
      return target.includes(syn) || targetNormalized.includes(normSyn);
    });
  };

  const highlightMatch = (text: string, query: string) => {
    if (!query) return <span>{text}</span>;
    const words = query.toLowerCase().split(/\s+/).filter(Boolean);
    if (words.length === 0) return <span>{text}</span>;
    
    // Escape and build regex to match words
    const escapedWords = words.map(w => w.replace(/[-\/\\^$*+?.()|[\]{}]/g, '\\$&'));
    const regex = new RegExp(`(${escapedWords.join('|')})`, 'gi');
    const parts = text.split(regex);
    
    return (
      <span>
        {parts.map((part, i) => 
          regex.test(part) ? (
            <mark key={i} className={`px-0.5 rounded font-semibold ${isDarkMode ? "bg-amber-400/40 text-amber-200" : "bg-amber-400/30 text-amber-900"}`}>
              {part}
            </mark>
          ) : (
            part
          )
        )}
      </span>
    );
  };

  const [activeTab, setActiveTab] = useState<"labs" | "dilution" | "renal" | "endocrine" | "directory" | "emts" | "calc" | "ho_guide">("labs");
  const [renalSubTab, setRenalSubTab] = useState<"stable" | "icu">("stable");

  // House Officer Ward Guide States
  const [hoActiveGuide, setHoActiveGuide] = useState<"pleural" | "ascites" | "csf" | "bma" | "hemolytic">("pleural");
  const [hoChecklist, setHoChecklist] = useState<Record<string, boolean>>({});

  // Interactive clinical scoring calculator inputs
  const [hoPleuralFluidProtein, setHoPleuralFluidProtein] = useState("");
  const [hoSerumProtein, setHoSerumProtein] = useState("");
  const [hoPleuralFluidLdh, setHoPleuralFluidLdh] = useState("");
  const [hoSerumLdh, setHoSerumLdh] = useState("");
  const [hoSerumLdhUpperLimit, setHoSerumLdhUpperLimit] = useState("200");

  const [hoSerumAlbumin, setHoSerumAlbumin] = useState("");
  const [hoAscitesAlbumin, setHoAscitesAlbumin] = useState("");

  const [hoCsfGlucose, setHoCsfGlucose] = useState("");
  const [hoRandomBloodSugar, setHoRandomBloodSugar] = useState("");

  // Search & Filter State
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedLabFilter, setSelectedLabFilter] = useState<string>("All");
  const [selectedEMTSCategory, setSelectedEMTSCategory] = useState<string>("All");

  // EMTS Calculator States
  const [emtsSelectedDrug, setEmtsSelectedDrug] = useState<"adrenaline" | "noradrenaline" | "dopamine" | "dobutamine" | "labetalol">("noradrenaline");
  const [emtsStrength, setEmtsStrength] = useState<"single" | "double">("single");
  const [emtsWeight, setEmtsWeight] = useState("");
  const [emtsDose, setEmtsDose] = useState(""); // mcg/kg/min or mg/min
  const [emtsResult, setEmtsResult] = useState<{ mlPerHour: number; concentration: number; prepText: string } | null>(null);

  // Calculator States
  const [cgAge, setCgAge] = useState("");
  const [cgWeight, setCgWeight] = useState("");
  const [cgHeight, setCgHeight] = useState("");
  const [cgCreatinine, setCgCreatinine] = useState("");
  const [cgSex, setCgSex] = useState<"male" | "female">("male");
  const [cgWeightType, setCgWeightType] = useState<"actual" | "ideal" | "adjusted">("actual");
  const [cgResult, setCgResult] = useState<number | null>(null);
  const [cgCalculatedWeights, setCgCalculatedWeights] = useState<{ ibw: number; ajbw: number; bmi: number; isObese: boolean; recommended: "actual" | "ideal" | "adjusted" } | null>(null);

  // Lab Interpreter States
  const [selectedInterpreterTest, setSelectedInterpreterTest] = useState("");
  const [interpreterValue, setInterpreterValue] = useState("");
  const [interpreterResult, setInterpreterResult] = useState<{ status: "low" | "normal" | "high" | "critical-low" | "critical-high"; text: string; action: string } | null>(null);

  // Bedside Calculators Sub-Tab State
  const [calcSubTab, setCalcSubTab] = useState<"standard" | "infusion">("standard");

  // Interactive Drug Infusion Calculator States
  const [infDrug, setInfDrug] = useState<"noradrenaline" | "adrenaline" | "dopamine" | "dobutamine" | "insulin" | "heparin" | "custom">("noradrenaline");
  const [infWeight, setInfWeight] = useState<string>("70");
  const [infPrep, setInfPrep] = useState<"single" | "double" | "custom">("single");
  const [infCustomConc, setInfCustomConc] = useState<string>("80"); // mcg/ml, units/ml, or mg/ml
  const [infCustomUnit, setInfCustomUnit] = useState<"mcg/kg/min" | "mcg/min" | "units/hr" | "mg/hr">("mcg/kg/min");
  const [infTargetDose, setInfTargetDose] = useState<string>("0.1");
  const [infMlPerHour, setInfMlPerHour] = useState<string>("2.63");
  const [infCalcMode, setInfCalcMode] = useState<"doseToRate" | "rateToDose">("doseToRate");

  // Bedside Reconstitution / Dilution Dosing Helper states
  const [selectedReconDrug, setSelectedReconDrug] = useState<string>("");
  const [reconDoseInput, setReconDoseInput] = useState("");
  const [reconResultText, setReconResultText] = useState<string>("");

  const [caMeasured, setCaMeasured] = useState("");
  const [caAlbumin, setCaAlbumin] = useState("");
  const [caResult, setCaResult] = useState<number | null>(null);

  const [infusionVol, setInfusionVol] = useState("");
  const [infusionDuration, setInfusionVolDuration] = useState("");
  const [infusionDropFactor, setInfusionDropFactor] = useState("20"); // 20 drops/ml standard IV, 60 microdrip
  const [infusionResult, setInfusionResult] = useState<{ mlPerHour: number; dropsPerMin: number } | null>(null);

  // Collapsible states for bedside calculators
  const [isCgExpanded, setIsCgExpanded] = useState(false);
  const [isCaExpanded, setIsCaExpanded] = useState(false);
  const [isInfusionExpanded, setIsInfusionExpanded] = useState(false);

  // Breathing Assistant State
  const [isBreathingOpen, setIsBreathingOpen] = useState(false);
  const [breathingPhase, setBreathingPhase] = useState<"Inhale" | "Hold (Full)" | "Exhale" | "Hold (Empty)">("Inhale");
  const [breathingTimer, setBreathingTimer] = useState(4);

  // Copy success notification
  const [copyFeedback, setCopySuccess] = useState<string | null>(null);

  // Rejection prevention panel
  const [showRejectionTips, setShowRejectionTips] = useState(false);

  // Toggle Theme
  const toggleTheme = () => {
    setTheme(prev => prev === "dark" ? "light" : "dark");
  };

  // Keyboard shortcut to focus search
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        document.getElementById('global-search-input')?.focus();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  // Breathing loop
  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isBreathingOpen) {
      interval = setInterval(() => {
        setBreathingTimer(prev => {
          if (prev <= 1) {
            setBreathingPhase(current => {
              switch (current) {
                case "Inhale": return "Hold (Full)";
                case "Hold (Full)": return "Exhale";
                case "Exhale": return "Hold (Empty)";
                case "Hold (Empty)": return "Inhale";
              }
            });
            return 4;
          }
          return prev - 1;
        });
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [isBreathingOpen]);

  // Handle Calculators
  const calculateCrCl = () => {
    const age = parseFloat(cgAge);
    const weight = parseFloat(cgWeight);
    const height = parseFloat(cgHeight);
    const creatinine = parseFloat(cgCreatinine);

    if (age && weight && creatinine) {
      let ibw = weight;
      let ajbw = weight;
      let bmi = 0;
      let isObese = false;
      let recommended: "actual" | "ideal" | "adjusted" = "actual";

      if (height) {
        const heightInInches = height / 2.54;
        const inchesOver5Feet = Math.max(0, heightInInches - 60);
        ibw = cgSex === "male" 
          ? 50.0 + 2.3 * inchesOver5Feet 
          : 45.5 + 2.3 * inchesOver5Feet;
        
        bmi = weight / ((height / 100) ** 2);
        isObese = bmi >= 30 || weight > 1.2 * ibw;
        
        if (weight > 1.2 * ibw) {
          ajbw = ibw + 0.4 * (weight - ibw);
          recommended = "adjusted";
        } else if (weight < ibw) {
          recommended = "actual";
        } else {
          recommended = "ideal";
        }

        setCgCalculatedWeights({
          ibw: parseFloat(ibw.toFixed(1)),
          ajbw: parseFloat(ajbw.toFixed(1)),
          bmi: parseFloat(bmi.toFixed(1)),
          isObese,
          recommended
        });
      } else {
        setCgCalculatedWeights(null);
      }

      // Determine weight to use in formula based on selection
      let weightToUse = weight;
      if (height) {
        if (cgWeightType === "ideal") weightToUse = ibw;
        else if (cgWeightType === "adjusted") weightToUse = ajbw;
      }

      const factor = cgSex === "male" ? 1.23 : 1.04;
      const crcl = ((140 - age) * weightToUse * factor) / creatinine;
      setCgResult(crcl);
    } else {
      setCgResult(null);
      setCgCalculatedWeights(null);
    }
  };

  const calculateCalcium = () => {
    const ca = parseFloat(caMeasured);
    const alb = parseFloat(caAlbumin);

    if (ca && alb) {
      // Corrected Ca = Measured Ca + 0.02 * (40 - Albumin)
      const corrected = ca + 0.02 * (40 - alb);
      setCaResult(corrected);
    } else {
      setCaResult(null);
    }
  };

  const calculateInfusion = () => {
    const vol = parseFloat(infusionVol);
    const hrs = parseFloat(infusionDuration);
    const df = parseFloat(infusionDropFactor);

    if (vol && hrs && df) {
      const mlPerHour = vol / hrs;
      const dropsPerMin = (vol * df) / (hrs * 60);
      setInfusionResult({ mlPerHour, dropsPerMin });
    } else {
      setInfusionResult(null);
    }
  };

  const calculateEMTSDrip = () => {
    const weight = parseFloat(emtsWeight);
    const dose = parseFloat(emtsDose);
    if (!dose || isNaN(dose)) {
      setEmtsResult(null);
      return;
    }

    let conc = 0; // mcg/ml or mg/ml
    let prep = "";
    let rate = 0; // ml/hour

    if (emtsSelectedDrug === "noradrenaline") {
      if (emtsStrength === "single") {
        conc = 80; // 80 mcg/ml
        prep = "Dilute 4mg (1 ampoule) Noradrenaline in 46ml D5% (Total 50ml)";
      } else {
        conc = 160; // 160 mcg/ml
        prep = "Dilute 8mg (2 ampoules) Noradrenaline in 42ml D5% (Total 50ml)";
      }
      const wt = isNaN(weight) || weight <= 0 ? 1 : weight;
      rate = (dose * wt * 60) / conc;
    } else if (emtsSelectedDrug === "adrenaline") {
      if (emtsStrength === "single") {
        conc = 60; // 60 mcg/ml
        prep = "Dilute 3mg (3 ampoules) Adrenaline in 47ml NS or D5% (Total 50ml)";
      } else {
        conc = 120; // 120 mcg/ml
        prep = "Dilute 6mg (6 ampoules) Adrenaline in 44ml NS or D5% (Total 50ml)";
      }
      const wt = isNaN(weight) || weight <= 0 ? 1 : weight;
      rate = (dose * wt * 60) / conc;
    } else if (emtsSelectedDrug === "dopamine") {
      if (emtsStrength === "single") {
        conc = 4000; // 4000 mcg/ml
        prep = "Dilute 200mg (1 ampoule) Dopamine in 45ml NS or D5% (Total 50ml)";
      } else {
        conc = 8000; // 8000 mcg/ml
        prep = "Dilute 400mg (2 ampoules) Dopamine in 40ml NS or D5% (Total 50ml)";
      }
      const wt = isNaN(weight) || weight <= 0 ? 70 : weight;
      rate = (dose * wt * 60) / conc;
    } else if (emtsSelectedDrug === "dobutamine") {
      if (emtsStrength === "single") {
        conc = 5000; // 5000 mcg/ml
        prep = "Dilute 250mg (1 vial) Dobutamine in 30ml NS or D5% (Total 50ml)";
      } else {
        conc = 10000; // 10000 mcg/ml
        prep = "Dilute 500mg (2 vials) Dobutamine in 10ml NS or D5% (Total 50ml)";
      }
      const wt = isNaN(weight) || weight <= 0 ? 70 : weight;
      rate = (dose * wt * 60) / conc;
    } else if (emtsSelectedDrug === "labetalol") {
      conc = 2; // 2 mg/ml
      prep = "Dilute 100mg (4 ampoules) Labetalol in 50ml NS or D5% (Total 50ml)";
      rate = (dose * 60) / conc;
    }

    setEmtsResult({
      mlPerHour: parseFloat(rate.toFixed(2)),
      concentration: conc,
      prepText: prep
    });
  };

  useEffect(() => {
    calculateEMTSDrip();
  }, [emtsSelectedDrug, emtsStrength, emtsWeight, emtsDose]);

  useEffect(() => {
    calculateCrCl();
  }, [cgAge, cgWeight, cgHeight, cgCreatinine, cgSex, cgWeightType]);

  useEffect(() => {
    calculateCalcium();
  }, [caMeasured, caAlbumin]);

  useEffect(() => {
    calculateInfusion();
  }, [infusionVol, infusionDuration, infusionDropFactor]);

  // Lab interpreter logic
  useEffect(() => {
    const val = parseFloat(interpreterValue);
    if (!selectedInterpreterTest || isNaN(val)) {
      setInterpreterResult(null);
      return;
    }

    let status: "low" | "normal" | "high" | "critical-low" | "critical-high" = "normal";
    let text = "";
    let action = "";

    if (selectedInterpreterTest === "potassium") {
      if (val < 2.5) {
        status = "critical-low";
        text = `Potassium is ${val} mmol/L (Severe Hypokalemia)`;
        action = "CRITICAL ALERT: High risk of lethal cardiac arrhythmias and respiratory paralysis! Notify physician immediately, run a 12-lead ECG, monitor cardiac rhythm constantly, and initiate urgent IV Potassium chloride replacement (not exceeding 10-20 mmol/hour via central line or under cardiac monitoring).";
      } else if (val < 3.5) {
        status = "low";
        text = `Potassium is ${val} mmol/L (Mild to Moderate Hypokalemia)`;
        action = "Action: Correct with oral potassium supplements (e.g., Mist. KCl) or add KCl to IV fluids. Recheck level after replacement. Check magnesium levels as hypomagnesemia makes hypokalemia refractory to treatment.";
      } else if (val <= 5.0) {
        status = "normal";
        text = `Potassium is ${val} mmol/L (Normal)`;
        action = "Action: Within standard reference limits (3.5 - 5.0 mmol/L). Maintain maintenance fluid protocols.";
      } else if (val < 6.0) {
        status = "high";
        text = `Potassium is ${val} mmol/L (Mild to Moderate Hyperkalemia)`;
        action = "Action: Exclude sample hemolysis (pseudohyperkalemia). Restrict dietary/IV potassium intake, stop potassium-sparing medications (e.g., Spironolactone, ACE inhibitors), and monitor ECG.";
      } else {
        status = "critical-high";
        text = `Potassium is ${val} mmol/L (Severe Hyperkalemia)`;
        action = "CRITICAL ALERT: Extreme risk of ventricular fibrillation, sinusoidal ECG pattern, and cardiac arrest! Action: Notify physician immediately. Run 12-lead ECG. Administer 10ml Calcium Gluconate 10% IV over 5-10 mins (stabilizes cardiac membrane), run Insulin-Dextrose infusion (10U Actrapid in 50ml D50% IV), Salbutamol nebulization, and consider potassium binders or hemodialysis.";
      }
    } else if (selectedInterpreterTest === "sodium") {
      if (val < 120) {
        status = "critical-low";
        text = `Sodium is ${val} mmol/L (Severe Hyponatremia)`;
        action = "CRITICAL ALERT: Risk of cerebral edema, status epilepticus, permanent neurological damage, and coma! Action: Notify specialist. If symptomatic (seizures, altered mental state), consider hypertonic saline (3% NaCl) 100ml IV over 10-20 mins, capped at 4-6 mmol/L rise in 24 hours to prevent Central Pontine Myelinolysis.";
      } else if (val < 135) {
        status = "low";
        text = `Sodium is ${val} mmol/L (Mild to Moderate Hyponatremia)`;
        action = "Action: Investigate volume status (hypovolemic, euvolemic, hypervolemic) and urine/serum osmolality. Restrict free water intake if euvolemic/SIADH; give normal saline if hypovolemic.";
      } else if (val <= 145) {
        status = "normal";
        text = `Sodium is ${val} mmol/L (Normal)`;
        action = "Action: Within standard reference limits (135 - 145 mmol/L).";
      } else if (val <= 155) {
        status = "high";
        text = `Sodium is ${val} mmol/L (Mild to Moderate Hypernatremia)`;
        action = "Action: Calculate free water deficit. Administer oral hydration or slow IV D5% infusion to lower sodium by ≤10 mmol/L per 24 hours to prevent cerebral edema.";
      } else {
        status = "critical-high";
        text = `Sodium is ${val} mmol/L (Severe Hypernatremia)`;
        action = "CRITICAL ALERT: Severe cellular dehydration, risk of vascular rupture, intracranial hemorrhage, and hyperthermia! Action: Notify physician. Administer slow hypotonic fluids under rigorous electrolyte monitoring.";
      }
    } else if (selectedInterpreterTest === "platelet") {
      if (val < 20) {
        status = "critical-low";
        text = `Platelets are ${val} x10^9/L (Severe Thrombocytopenia)`;
        action = "CRITICAL ALERT: High risk of spontaneous life-threatening hemorrhage (e.g., intracranial, gastrointestinal)! Action: Restrict patient's physical activity to bed rest. Avoid intramuscular (IM) injections and NSAIDs. Order immediate platelet transfusion. Investigate for Dengue Severe phase, ITP, sepsis, or DIC.";
      } else if (val < 150) {
        status = "low";
        text = `Platelets are ${val} x10^9/L (Mild to Moderate Thrombocytopenia)`;
        action = "Action: Monitor for bleeding/bruising/petechiae. Investigate underlying etiology (dengue serology, drug-induced, EDTA-induced clumping - request blood smear).";
      } else if (val <= 400) {
        status = "normal";
        text = `Platelets are ${val} x10^9/L (Normal)`;
        action = "Action: Within standard reference limits (150 - 400 x10^9/L).";
      } else {
        status = "high";
        text = `Platelets are ${val} x10^9/L (Thrombocytosis)`;
        action = "Action: Exclude reactive causes (infection, iron deficiency, post-splenectomy, tissue inflammation). If persistent and extremely high (>1000), consult hematology for primary myeloproliferative disorder evaluation.";
      }
    } else if (selectedInterpreterTest === "hb") {
      if (val < 7.0) {
        status = "critical-low";
        text = `Hemoglobin is ${val} g/dL (Severe Anemia)`;
        action = "CRITICAL ALERT: High risk of high-output heart failure and severe tissue hypoxia! Action: Cross-match and prepare Packed Red Blood Cells (PRBC) for transfusion (usually transfuse to target Hb 7-8 g/dL, or >9 g/dL in acute coronary syndrome). Monitor vitals closely.";
      } else if (val < 12.0) {
        status = "low";
        text = `Hemoglobin is ${val} g/dL (Mild to Moderate Anemia)`;
        action = "Action: Assess iron indices (ferritin, transferrin), serum folate, Vitamin B12, renal function (EPO deficiency), and check for occult bleeding (Fecal Occult Blood Test).";
      } else if (val <= 17.5) {
        status = "normal";
        text = `Hemoglobin is ${val} g/dL (Normal)`;
        action = "Action: Within standard reference limits (12.0 - 17.5 g/dL).";
      } else {
        status = "high";
        text = `Hemoglobin is ${val} g/dL (Erythrocytosis)`;
        action = "Action: Assess hydration status (hemoconcentration). Exclude chronic hypoxemia (COPD, sleep apnea, smoking) or polycythemia vera. Consider hematology consultation.";
      }
    } else if (selectedInterpreterTest === "wbc") {
      if (val < 1.0) {
        status = "critical-low";
        text = `WBC is ${val} x10^9/L (Critical Leukopenia/Neutropenia)`;
        action = "CRITICAL ALERT: Extreme vulnerability to life-threatening infections! Action: Isolate patient in a single room (reverse isolation). Initiate neutropenic sepsis precautions (avoid raw foods, strict hand hygiene). If febrile (T ≥ 38.0°C), treat as a medical emergency and administer broad-spectrum IV antibiotics (e.g. Tazocin or Meropenem) within 1 hour.";
      } else if (val < 4.0) {
        status = "low";
        text = `WBC is ${val} x10^9/L (Leukopenia)`;
        action = "Action: Perform Full Blood Picture (FBP) for differential count. Check for viral infections, autoimmune conditions, bone marrow depression, or chemotherapy drug toxicity.";
      } else if (val <= 11.0) {
        status = "normal";
        text = `WBC is ${val} x10^9/L (Normal)`;
        action = "Action: Within standard reference limits (4.0 - 11.0 x10^9/L).";
      } else if (val < 30.0) {
        status = "high";
        text = `WBC is ${val} x10^9/L (Leukocytosis)`;
        action = "Action: Assess for clinical signs of infection, inflammation, trauma, or recent corticosteroid therapy. Check differential count (neutrophilia vs lymphocytosis).";
      } else {
        status = "critical-high";
        text = `WBC is ${val} x10^9/L (Severe Leukocytosis / Hyperleukocytosis)`;
        action = "CRITICAL ALERT: Extreme leukocytosis. Action: Investigate for hematological malignancies (Leukemia - AML, CML, CLL, ALL) or extreme leukemoid reaction in severe necrotizing infections. Order peripheral blood smear and consult hematology.";
      }
    }

    setInterpreterResult({ status, text, action });
  }, [selectedInterpreterTest, interpreterValue]);

  // Drug Reconstitution / Dilution helper logic
  useEffect(() => {
    if (!selectedReconDrug) {
      setReconResultText("");
      return;
    }

    const dose = parseFloat(reconDoseInput);
    if (isNaN(dose) || dose <= 0) {
      setReconResultText("Please enter a valid dose above 0.");
      return;
    }

    let text = "";
    const d = selectedReconDrug.toLowerCase();

    if (d.includes("noradrenaline")) {
      const conc = 80; // mcg/ml (4mg in 50ml)
      const rate = (dose * 60) / conc;
      text = `Dilution: Single Strength (4mg in 50ml D5%, Conc: 80 mcg/ml)\nTarget Dose: ${dose} mcg/min\nRequired Pump Flow Rate: ${rate.toFixed(1)} ml/hour.`;
    } else if (d.includes("adrenaline")) {
      const conc = 60; // mcg/ml (3mg in 50ml)
      const rate = (dose * 60) / conc;
      text = `Dilution: Single Strength (3mg in 50ml NS/D5%, Conc: 60 mcg/ml)\nTarget Dose: ${dose} mcg/min\nRequired Pump Flow Rate: ${rate.toFixed(1)} ml/hour.`;
    } else if (d.includes("amiodarone")) {
      const conc = 6; // mg/ml (300mg in 50ml D5%)
      const rate = dose / conc;
      text = `Dilution: Amiodarone (300mg in 50ml D5%, Conc: 6 mg/ml)\nTarget Maintenance Dose: ${dose} mg/hour\nRequired Pump Flow Rate: ${rate.toFixed(1)} ml/hour.`;
    } else if (d.includes("insulin") || d.includes("actrapid")) {
      const rate = dose; // 1U/ml, so ml/hr = U/hr
      text = `Dilution: Actrapid (50U in 50ml Normal Saline, Conc: 1 U/ml)\nTarget Dose: ${dose} U/hour\nRequired Pump Flow Rate: ${rate.toFixed(1)} ml/hour.\n\n*Check Capillary Blood Glucose (CBG) hourly!`;
    } else if (d.includes("fentanyl")) {
      const conc = 10; // mcg/ml (500mcg in 50ml)
      const rate = dose / conc;
      text = `Dilution: Fentanyl (500 mcg in 50ml NS, Conc: 10 mcg/ml)\nTarget Dose: ${dose} mcg/hour\nRequired Pump Flow Rate: ${rate.toFixed(1)} ml/hour.`;
    } else if (d.includes("pantoprazole")) {
      const conc = 4; // mg/ml (40mg reconstituted in 10ml)
      const vol = dose / conc;
      text = `Reconstitution: Pantoprazole 40mg vial reconstituted with 10ml Normal Saline (Conc: 4 mg/ml)\nTarget Dose: ${dose} mg\nRequired volume to draw: ${vol.toFixed(1)} ml of reconstituted solution.`;
    } else if (d.includes("piperacillin") || d.includes("tazocin")) {
      const conc = 225; // mg/ml (4.5g in 20ml)
      const vol = (dose * 1000) / conc;
      text = `Reconstitution: Tazocin 4.5g reconstituted with 20ml Normal Saline (Conc: 225 mg/ml)\nTarget Dose: ${dose} g (${dose * 1000} mg)\nRequired volume to draw: ${vol.toFixed(1)} ml of reconstituted solution.\nDilute in 100ml NS/D5% and infuse over 3-4 hours.`;
    } else {
      text = `General Calculation:\nFor dose of ${dose} units/mg, with concentration C, draw (Target Dose / C) ml.`;
    }

    setReconResultText(text);
  }, [selectedReconDrug, reconDoseInput]);

  // Copy helper
  const handleCopy = (text: string, identifier: string) => {
    navigator.clipboard.writeText(text);
    setCopySuccess(identifier);
    setTimeout(() => setCopySuccess(null), 2000);
  };

  // Filtering Labs
  const getFilteredLabs = () => {
    const hasSearch = searchQuery.trim().length > 0;
    return testDatabase.filter(item => {

      // Improved text search with synonym-aware matching
      const contentString = `${item.test} ${item.container} ${item.specimen} ${item.remark} ${item.ranges} ${item.lab}`;
      const matchesSearch = matchesQuery(contentString, searchQuery);

      if (!matchesSearch) return false;

      // If there's an active text search, we bypass quick category filters so they find it globally
      if (hasSearch) return true;

      // Category Quick Filters
      if (selectedLabFilter === "All") return true;
      if (selectedLabFilter === "Blood") {
        return item.specimen.toLowerCase().includes("blood") || 
               item.specimen.toLowerCase().includes("serum") || 
               item.specimen.toLowerCase().includes("plasma");
      }
      if (selectedLabFilter === "Urine") {
        return item.specimen.toLowerCase().includes("urine");
      }
      if (selectedLabFilter === "CSF/Fluid") {
        return item.specimen.toLowerCase().includes("csf") || 
               item.specimen.toLowerCase().includes("fluid");
      }
      if (selectedLabFilter === "Urgent") {
        return item.ltat.toLowerCase().includes("hour") || 
               item.ltat.toLowerCase().includes("min");
      }
      if (selectedLabFilter === "Ice") {
        return item.remark.toLowerCase().includes("ice") || 
               item.container.toLowerCase().includes("ice");
      }
      if (selectedLabFilter === "Referred") {
        return item.test.toLowerCase().includes("referred") || 
               item.lab.toLowerCase().includes("ref:");
      }

      return true;
    });
  };

  // Filtering Drugs (Dilution)
  const getFilteredDilutions = () => {
    return dbDilution.filter(item => {
      const contentString = `${item.drug} ${item.dilution} ${item.reconstitution} ${item.infusion}`;
      return matchesQuery(contentString, searchQuery);
    });
  };

  // Filtering Renal Stable
  const getFilteredRenalStable = () => {
    return dbRenalStable.filter(item => {
      const contentString = `${item.drug} ${item.dose} ${item.adjustments}`;
      return matchesQuery(contentString, searchQuery);
    });
  };

  // Filtering Renal ICU
  const getFilteredRenalICU = () => {
    return dbRenalICU.filter(item => {
      const contentString = `${item.drug} ${item.dose} ${item.rrt}`;
      return matchesQuery(contentString, searchQuery);
    });
  };

  // Filtering EMTS Drugs
  const getFilteredEMTS = () => {
    return dbEMTS.filter(item => {
      const contentString = `${item.drug} ${item.indication} ${item.preparation} ${item.bolus} ${item.infusion} ${item.precautions}`;
      const matchesSearch = matchesQuery(contentString, searchQuery);
      
      if (selectedEMTSCategory === "All") return matchesSearch;
      return matchesSearch && item.category === selectedEMTSCategory;
    });
  };

  // Tube visual colors map
  const getTubeCapColor = (container: string) => {
    const text = container.toLowerCase();
    if (text.includes("yellow") || text.includes("gold") || text.includes("separating")) {
      return { bg: "bg-amber-400", border: "border-amber-500", label: "Yellow (SST)" };
    }
    if (text.includes("pink")) {
      return { bg: "bg-pink-400", border: "border-pink-500", label: "Pink" };
    }
    if (text.includes("red") || text.includes("without gel")) {
      return { bg: "bg-rose-600", border: "border-rose-700", label: "Red (Plain)" };
    }
    if (text.includes("purple") || text.includes("edta")) {
      return { bg: "bg-violet-600", border: "border-violet-700", label: "Purple (EDTA)" };
    }
    if (text.includes("green") || text.includes("heparin")) {
      return { bg: "bg-emerald-600", border: "border-emerald-700", label: "Green (Heparin)" };
    }
    if (text.includes("blue") || text.includes("citrate")) {
      return { bg: "bg-sky-500", border: "border-sky-600", label: "Blue (Citrate)" };
    }
    if (text.includes("grey") || text.includes("fluoride")) {
      return { bg: "bg-slate-400", border: "border-slate-500", label: "Grey (Fluoride)" };
    }
    if (text.includes("sterile") || text.includes("container") || text.includes("bottle") || text.includes("bijou")) {
      return { bg: "bg-amber-100", border: "border-slate-300", label: "Sterile Container" };
    }
    return { bg: "bg-slate-300", border: "border-slate-400", label: "Other" };
  };

  
  
  // Maintenance Fluid State
  const [fluidWeight, setFluidWeight] = useState("");
  const [fluidResult, setFluidResult] = useState<number | null>(null);

  const calculateFluid = () => {
    const w = parseFloat(fluidWeight);
    if (!isNaN(w) && w > 0) {
      let rate = 0;
      if (w <= 10) rate = w * 4;
      else if (w <= 20) rate = 40 + ((w - 10) * 2);
      else rate = 60 + ((w - 20) * 1);
      setFluidResult(rate);
    }
  };

  const isDarkMode = theme === "dark";

  return (
    <div className={`min-height-screen font-sans transition-colors duration-150 ${
      isDarkMode ? "bg-[#0b0f19] text-slate-100" : "bg-slate-50 text-slate-900"
    }`}>
      
      {/* HEADER SECTION */}
      <header className={`sticky top-0 z-40 border-b backdrop-blur-md ${
        isDarkMode ? "bg-[#0b0f19]/90 border-slate-800" : "bg-white/90 border-slate-200"
      } py-4 px-4 sm:px-6`}>
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <div className="flex items-center gap-3">
              <div className="flex-shrink-0">
                <img 
                  src="/logo.jpg" 
                  alt="Blood But Not Bleed Logo" 
                  className="w-12 h-12 rounded-lg object-contain shadow-sm"
                  referrerPolicy="no-referrer"
                />
              </div>
              <div>
                <h1 className={`text-xl sm:text-2xl font-bold tracking-tight ${isDarkMode ? "text-slate-100" : "text-slate-900"} flex flex-col sm:flex-row sm:items-center gap-1 sm:gap-2`}>
                  Blood But Not Bleed
                  <span className={`text-[10px] sm:text-xs px-2 py-0.5 rounded-full bg-rose-700/10 ${isDarkMode ? "text-rose-400" : "text-rose-700"} border border-rose-700/20 font-mono font-normal w-fit`}>
                    6th Ed. 2026
                  </span>
                </h1>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-3">
            {/* Mindful Pause Button */}
            <button 
              onClick={() => setIsBreathingOpen(!isBreathingOpen)}
              className={`flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-semibold transition-all ${
                isBreathingOpen 
                  ? "bg-teal-500 text-white shadow-lg shadow-teal-500/20" 
                  : isDarkMode 
                    ? "bg-slate-900 text-teal-400 hover:bg-slate-800 border border-slate-800" 
                    : "bg-teal-50 text-teal-700 hover:bg-teal-100 border border-teal-100"
              }`}
            >
              <Wind className={`w-4 h-4 ${isBreathingOpen ? "animate-spin" : ""}`} />
              {isBreathingOpen ? "Mindful Breath Active" : "Take a 16s Pause"}
            </button>

            {/* Theme Toggle */}
            <button 
              onClick={toggleTheme}
              className={`p-2 rounded-lg border transition-colors ${
                isDarkMode 
                  ? "bg-slate-900 border-slate-800 text-yellow-400 hover:bg-slate-800" 
                  : "bg-slate-100 border-slate-200 text-slate-700 hover:bg-slate-200"
              }`}
              title={isDarkMode ? "Switch to daylight mode" : "Switch to twilight mode"}
            >
              {isDarkMode ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
            </button>
          </div>
        </div>
      </header>

      {/* DETAILED MINDFUL BREATHING ASSISTANT */}
      <AnimatePresence>
        {isBreathingOpen && (
          <motion.div 
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className={`overflow-hidden border-b ${
              isDarkMode ? "bg-slate-950 border-teal-900/30" : "bg-teal-50/50 border-teal-100"
            }`}
          >
            <div className="max-w-xl mx-auto px-4 py-8 text-center flex flex-col items-center gap-4">
              <div className="flex justify-between items-center w-full">
                <span className={`text-xs uppercase tracking-wider ${isDarkMode ? "text-teal-400" : "text-teal-700"} font-bold font-mono`}>Box Breathing Relief</span>
                <button 
                  onClick={() => setIsBreathingOpen(false)}
                  className={`${isDarkMode ? "text-slate-400" : "text-slate-700"} hover:${isDarkMode ? "text-slate-200" : "text-slate-700"}`}
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Pulsing Breathing Circle */}
              <div className="relative w-32 h-32 flex items-center justify-center">
                <motion.div 
                  animate={{
                    scale: breathingPhase === "Inhale" ? 1.4 : breathingPhase === "Hold (Full)" ? 1.4 : breathingPhase === "Exhale" ? 0.9 : 0.9
                  }}
                  transition={{ duration: 4, ease: "easeInOut" }}
                  className="absolute inset-0 rounded-full bg-teal-500/10 border-2 border-teal-500/40"
                />
                <motion.div 
                  animate={{
                    scale: breathingPhase === "Inhale" ? 1.2 : breathingPhase === "Hold (Full)" ? 1.2 : breathingPhase === "Exhale" ? 1.0 : 1.0
                  }}
                  transition={{ duration: 4, ease: "easeInOut" }}
                  className="absolute w-24 h-24 rounded-full bg-teal-500/20 flex flex-col items-center justify-center"
                />
                <div className={`z-10 font-bold ${isDarkMode ? "text-teal-400" : "text-teal-700"} font-mono text-lg`}>
                  {breathingTimer}s
                </div>
              </div>

              <div>
                <h3 className={`font-bold text-lg ${isDarkMode ? "text-teal-300" : "text-teal-700"}`}>{breathingPhase}</h3>
                <p className={`text-xs ${isDarkMode ? "text-slate-400" : "text-slate-700"} mt-1 max-w-sm mx-auto`}>
                  {breathingPhase === "Inhale" && "Draw air deep into your abdomen... expand your lungs."}
                  {breathingPhase === "Hold (Full)" && "Relax your neck and shoulders, let the stillness settle."}
                  {breathingPhase === "Exhale" && "Slowly release the breath, letting go of any clinical stress."}
                  {breathingPhase === "Hold (Empty)" && "Stay completely clear and calm before the next inhale."}
                </p>
              </div>

              <div className="flex gap-2">
                <span className={`w-2 h-2 rounded-full ${breathingPhase === "Inhale" ? "bg-teal-400" : "bg-slate-700"}`} />
                <span className={`w-2 h-2 rounded-full ${breathingPhase === "Hold (Full)" ? "bg-teal-400" : "bg-slate-700"}`} />
                <span className={`w-2 h-2 rounded-full ${breathingPhase === "Exhale" ? "bg-teal-400" : "bg-slate-700"}`} />
                <span className={`w-2 h-2 rounded-full ${breathingPhase === "Hold (Empty)" ? "bg-teal-400" : "bg-slate-700"}`} />
              </div>
              <div className="mt-4 pt-4 border-t border-teal-500/20 w-full text-center space-y-3">
                <p className={`text-[11px] ${isDarkMode ? "text-teal-300/80" : "text-teal-800/80"}`}>
                  You are not alone. If you're feeling overwhelmed or burned out:
                </p>
                <div className="flex flex-col sm:flex-row justify-center gap-2">
                  <a href="tel:0340411140" className={`text-[11px] px-3 py-1.5 rounded-full border ${isDarkMode ? "bg-slate-900 border-teal-900 text-teal-400 hover:bg-slate-800" : "bg-white border-teal-200 text-teal-700 hover:bg-teal-50"}`}>
                    📞 MMA HelpDoc Hotline
                  </a>
                  <a href="tel:0376272929" className={`text-[11px] px-3 py-1.5 rounded-full border ${isDarkMode ? "bg-slate-900 border-teal-900 text-teal-400 hover:bg-slate-800" : "bg-white border-teal-200 text-teal-700 hover:bg-teal-50"}`}>
                    📞 Befrienders KL
                  </a>
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 py-4 pb-24">

        {/* STICKY NAVIGATION & SEARCH HEADER */}
        <div className={`sticky top-0 z-40 -mx-4 px-4 sm:mx-0 sm:px-0 pt-2 pb-4 mb-6 backdrop-blur-md border-b ${
          isDarkMode ? "bg-[#0b0f19]/90 border-slate-800/60 shadow-lg shadow-black/20" : "bg-white/90 border-slate-200 shadow-sm shadow-slate-200/50"
        }`}>
          {/* NAVIGATION TABS */}
          <div className="hidden sm:grid sm:grid-cols-4 xl:grid-cols-8 sm:gap-2.5 pb-2">
            {[
              { id: "labs", label: "Labs", icon: <FileText className="w-4 h-4" /> },
              { id: "ho_guide", label: "HO Guide", icon: <ClipboardList className="w-4 h-4" /> },
              { id: "dilution", label: "Dilution", icon: <Droplet className="w-4 h-4" /> },
              { id: "renal", label: "Renal Dose", icon: <AlertTriangle className="w-4 h-4" /> },
              { id: "emts", label: "EM Drug", icon: <Zap className="w-4 h-4" /> },
              { id: "endocrine", label: "Endo", icon: <HelpCircle className="w-4 h-4" /> },
              { id: "calc", label: "Calc", icon: <Calculator className="w-4 h-4" /> },
              { id: "directory", label: "Directory", icon: <Phone className="w-4 h-4" /> }
            ].map((tab) => (
              <button 
                key={tab.id}
                onClick={() => { setActiveTab(tab.id as any); setSearchQuery(""); }}
                className={`flex flex-col items-center justify-center gap-1.5 p-2 sm:p-3 rounded-xl border transition-all min-w-0 ${
                  activeTab === tab.id
                    ? "bg-teal-500/10 border-teal-500/50 text-teal-400 shadow-lg shadow-teal-500/5 ring-1 ring-teal-500/20"
                    : isDarkMode 
                      ? "bg-slate-900/40 border-slate-800/60 text-slate-400 hover:bg-slate-800 hover:text-slate-300"
                      : "bg-white border-slate-200 text-slate-600 hover:bg-slate-50 hover:border-slate-300 shadow-sm"
                }`}
              >
                <div className={`p-1.5 rounded-lg flex-shrink-0 ${activeTab === tab.id ? "bg-teal-500 text-slate-950" : isDarkMode ? "bg-slate-800 text-slate-400" : "bg-slate-100 text-slate-600"}`}>
                  {tab.icon}
                </div>
                <span className="text-[10px] font-bold uppercase tracking-tight whitespace-nowrap">{tab.label}</span>
              </button>
            ))}
          </div>
          
          <div className="block sm:hidden pb-2">
            <select
              value={activeTab}
              onChange={(e) => { setActiveTab(e.target.value as any); setSearchQuery(""); }}
              className={`w-full p-3.5 rounded-xl border text-sm font-bold appearance-none bg-no-repeat bg-[url('data:image/svg+xml;charset=US-ASCII,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%22292.4%22%20height%3D%22292.4%22%3E%3Cpath%20fill%3D%22%2314b8a6%22%20d%3D%22M287%2069.4a17.6%2017.6%200%200%200-13-5.4H18.4c-5%200-9.3%201.8-12.9%205.4A17.6%2017.6%200%200%200%200%2082.2c0%205%201.8%209.3%205.4%2012.9l128%20127.9c3.6%203.6%207.8%205.4%2012.8%205.4s9.2-1.8%2012.8-5.4L287%2095c3.5-3.5%205.4-7.8%205.4-12.8%200-5-1.9-9.2-5.5-12.8z%22%2F%3E%3C%2Fsvg%3E')] bg-[length:12px_12px] bg-[position:right_1rem_center] pr-10 focus:outline-none focus:ring-2 focus:ring-teal-500/50 ${
                isDarkMode 
                  ? "bg-slate-900 border-slate-700 text-teal-400"
                  : "bg-white border-slate-200 text-teal-700 shadow-sm"
              }`}
            >
              <option value="labs">📁 Labs Reference</option>
              <option value="ho_guide">📝 HO Bedside Guide</option>
              <option value="dilution">💧 Drug Dilutions</option>
              <option value="renal">⚠️ Antibiotic Renal Dosing</option>
              <option value="emts">⚡ EMTS Drugs</option>
              <option value="endocrine">🧪 Endocrine Protocols</option>
              <option value="calc">🧮 Calculators</option>
              <option value="directory">📞 Directory</option>
            </select>
          </div>

          {/* Sub-tabs and Search Bar */}
          <div className="mt-4 space-y-4">
            {activeTab === "labs" && (
              <div className="flex overflow-x-auto scrollbar-none gap-2">
                {["All", "Blood", "Urine", "CSF/Fluid", "Urgent", "Ice", "Referred"].map((filt) => (
                  <button
                    key={filt}
                    onClick={() => setSelectedLabFilter(filt)}
                    className={`flex-shrink-0 px-3 py-1.5 rounded-full text-[10px] font-semibold border transition-all cursor-pointer whitespace-nowrap ${
                      selectedLabFilter === filt
                        ? isDarkMode 
                          ? "bg-teal-500/20 text-teal-400 border-teal-500/40" 
                          : "bg-teal-100 text-teal-800 border-teal-300 shadow-sm"
                        : isDarkMode
                          ? "bg-slate-900 border-slate-800 text-slate-400 hover:bg-slate-800 hover:text-slate-300"
                          : "bg-slate-100 border-slate-200 text-slate-600 hover:bg-slate-200 hover:text-slate-700"
                    }`}
                  >
                    {filt === "All" && "📁 All Tests"}
                    {filt === "Blood" && "🩸 Blood"}
                    {filt === "Urine" && "💧 Urine"}
                    {filt === "CSF/Fluid" && "🧠 Fluids"}
                    {filt === "Urgent" && "🚨 Urgent"}
                    {filt === "Ice" && "❄️ ICE"}
                    {filt === "Referred" && "✈️ Referred"}
                  </button>
                ))}
              </div>
            )}

            {activeTab === "renal" && (
              <div className="flex gap-2">
                <button 
                  onClick={() => setRenalSubTab("stable")}
                  className={`flex-1 py-2 rounded-lg border text-[10px] font-bold uppercase transition-all ${
                    renalSubTab === "stable"
                      ? "bg-amber-500 text-slate-950 border-amber-500 shadow-lg shadow-amber-500/20"
                      : isDarkMode 
                        ? "bg-slate-900 border-slate-800 text-slate-400" 
                        : "bg-slate-100 border-slate-200 text-slate-600"
                  }`}
                >
                  Stable CKD
                </button>
                <button 
                  onClick={() => setRenalSubTab("icu")}
                  className={`flex-1 py-2 rounded-lg border text-[10px] font-bold uppercase transition-all ${
                    renalSubTab === "icu"
                      ? "bg-rose-500 text-slate-950 border-rose-500 shadow-lg shadow-rose-500/20"
                      : isDarkMode 
                        ? "bg-slate-900 border-slate-800 text-slate-400" 
                        : "bg-slate-100 border-slate-200 text-slate-600"
                  }`}
                >
                  ICU / CRRT
                </button>
              </div>
            )}

            {/* SEARCH BAR (Context-aware search for active tab) */}
            {activeTab !== "directory" && activeTab !== "calc" && activeTab !== "ho_guide" && (
              <div className="relative">
                <Search className={`absolute left-4 top-1/2 -translate-y-1/2 ${isDarkMode ? "text-slate-400" : "text-slate-500"} w-4 h-4`} />
                <input 
                  id="global-search-input"
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder={
                    activeTab === "labs" 
                      ? "Search 200+ lab tests..."
                      : activeTab === "dilution"
                        ? "Search drug reconstitution..."
                        : activeTab === "renal"
                          ? "Search antibiotic renal dose..."
                          : activeTab === "emts"
                            ? "Search EM drug dilution..."
                            : activeTab === "endocrine"
                              ? "Search endocrine protocols..."
                              : "Search directory..."
                  }
                  className={`w-full py-2.5 pl-10 pr-10 rounded-xl border text-xs sm:text-sm transition-all outline-none ${
                    isDarkMode 
                      ? "bg-slate-950/40 border-slate-800/80 text-slate-100 focus:border-teal-400 focus:ring-1 focus:ring-teal-500/20 placeholder:text-slate-600" 
                      : "bg-white border-slate-200 text-slate-900 focus:border-teal-500 focus:ring-1 focus:ring-teal-500/20 shadow-sm placeholder:text-slate-400"
                  }`}
                />
                {searchQuery && (
                  <button 
                    onClick={() => setSearchQuery("")}
                    className={`absolute right-3 top-1/2 -translate-y-1/2 p-1.5 rounded-full transition-colors ${
                      isDarkMode ? "hover:bg-slate-800 text-slate-500" : "hover:bg-slate-100 text-slate-400"
                    }`}
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>
            )}

            {searchQuery && activeTab !== "directory" && activeTab !== "calc" && activeTab !== "ho_guide" && (
              <div className={`p-2.5 rounded-lg border text-[10px] flex justify-between items-center animate-fade-in ${
                isDarkMode ? "bg-teal-500/5 border-teal-500/10 text-teal-400" : "bg-teal-50 border-teal-100 text-teal-700 shadow-sm"
              }`}>
                <span className="font-medium truncate mr-2">
                  🔍 Searching for: <span className="font-bold underline">"{searchQuery}"</span>
                </span>
                <span className="font-mono bg-teal-500/10 px-2 py-0.5 rounded-full border border-teal-500/20 flex-shrink-0">
                  {activeTab === "labs" ? `${getFilteredLabs().length} test(s)` :
                   activeTab === "dilution" ? `${getFilteredDilutions().length} drug(s)` :
                   activeTab === "renal" ? `${renalSubTab === "stable" ? getFilteredRenalStable().length : getFilteredRenalICU().length} drug(s)` :
                   activeTab === "emts" ? `${getFilteredEMTS().length} drug(s)` :
                   activeTab === "endocrine" ? `${getFilteredLabs().length} item(s)` :
                   "matching items"}
                </span>
              </div>
            )}
          </div>
        </div>


        {/* TAB 1: LABS REFERENCE SECTION */}
        {activeTab === "labs" && (
          <div>
            {/* Quick Categories Filter row */}
            {/* Labs Reference Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {getFilteredLabs().map((lab, i) => {
                const tubeConfig = getTubeCapColor(lab.container);
                const isUrgent = lab.ltat.toLowerCase().includes("hour") || lab.ltat.toLowerCase().includes("min");
                const hasIce = lab.remark.toLowerCase().includes("ice") || lab.container.toLowerCase().includes("ice") || lab.test.toLowerCase().includes("ice");

                return (
                  <motion.div 
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: Math.min(i * 0.03, 0.4) }}
                    key={`${lab.test}-${lab.lab}-${i}`}
                    className={`p-5 rounded-xl border flex flex-col justify-between transition-all ${
                      isDarkMode ? "bg-[#111827] border-slate-800 hover:border-slate-700" : "bg-white border-slate-200 hover:border-slate-300 shadow-sm"
                    }`}
                  >
                    <div>
                      {/* Title & Lab Department */}
                      <div className="flex justify-between items-start gap-4 mb-3">
                        <div>
                          <h3 className={`font-bold text-base tracking-tight ${isDarkMode ? 'text-teal-400' : 'text-teal-700'}`}>{highlightMatch(lab.test, searchQuery)}</h3>
                          <span className={`text-[10px] uppercase font-mono tracking-wider font-semibold ${isDarkMode ? "text-slate-400" : "text-slate-700"} block mt-0.5`}>
                            {lab.lab}
                          </span>
                        </div>
                        {/* Highlights */}
                        <div className="flex flex-col gap-1 items-end">
                          {isUrgent && (
                            <span className={`text-[9px] px-2 py-0.5 rounded-full bg-rose-500/10 ${isDarkMode ? "text-rose-400" : "text-rose-700"} border border-rose-500/20 font-mono font-semibold uppercase`}>
                              🚨 Urgent
                            </span>
                          )}
                          {hasIce && (
                            <span className="badge badge-ice bg-sky-950 text-sky-400 text-[10px] px-2 py-0.5 rounded border border-sky-800">❄️ ICE bath</span>
                          )}
                        </div>
                      </div>

                      {/* Specimen and Cap visual */}
                      <div className={`flex items-center gap-3 my-3 p-2 ${isDarkMode ? "bg-slate-500/10" : "bg-slate-100"} rounded-lg`}>
                        <div className={`w-8 h-8 rounded-full ${tubeConfig.bg} ${tubeConfig.border} flex items-center justify-center border-2 shadow-sm`}>
                          <span className="text-[10px] font-bold text-white uppercase">{tubeConfig.label.charAt(0)}</span>
                        </div>
                        <div>
                          <span className="text-xs font-semibold block">{highlightMatch(lab.container, searchQuery)}</span>
                          <span className={`text-[10px] ${isDarkMode ? "text-slate-400" : "text-slate-700"}`}>Specimen: <strong className={`${isDarkMode ? "text-slate-300" : "text-slate-800"}`}>{highlightMatch(lab.specimen, searchQuery)}</strong> ({lab.volume})</span>
                        </div>
                      </div>

                      {/* Ranges & Reference Parameters */}
                      <div className={`mt-3 p-3 rounded-lg border ${isDarkMode ? "bg-slate-950/20 border-slate-800" : "bg-slate-50 border-slate-200"}`}>
                        <span className={`text-[10px] ${isDarkMode ? "text-slate-400" : "text-slate-700"} font-bold block mb-1`}>Reference Range / Profile limits:</span>
                        <p className={`text-xs ${isDarkMode ? "text-teal-300" : "text-teal-700"} font-mono leading-relaxed`}>{highlightMatch(lab.ranges, searchQuery)}</p>
                      </div>

                      {/* Remark / Guide */}
                      {lab.remark && (
                        <div className={`mt-3 text-xs ${isDarkMode ? "text-slate-300" : "text-slate-800"} flex items-start gap-2`}>
                          <Info className={`w-4 h-4 ${isDarkMode ? "text-slate-400" : "text-slate-700"} flex-shrink-0 mt-0.5`} />
                          <p className="leading-normal"><span className={`font-semibold ${isDarkMode ? "text-slate-400" : "text-slate-700"}`}>Action Remarks: </span>{highlightMatch(lab.remark, searchQuery)}</p>
                        </div>
                      )}
                    </div>

                    <div className={`mt-4 pt-3 border-t border-slate-800/80 flex items-center justify-between text-xs ${isDarkMode ? "text-slate-400" : "text-slate-700"}`}>
                      <span>Lab Turnaround Time:</span>
                      <strong className={isUrgent ? "text-rose-400" : "text-slate-300"}>{lab.ltat}</strong>
                    </div>
                  </motion.div>
                );
              })}
            </div>
            {getFilteredLabs().length === 0 && (
              <div className={`text-center py-12 ${isDarkMode ? "text-slate-400" : "text-slate-700"} font-mono text-sm`}>
                No matching laboratory references found. Try adjusting filters or search terms.
              </div>
            )}
          </div>
        )}

        {/* TAB 2: DRUG DOSING & DILUTION SECTION */}
        {activeTab === "dilution" && (
          <div>
            <div className={`p-4 rounded-lg bg-teal-500/5 border border-teal-500/20 ${isDarkMode ? "text-teal-400" : "text-teal-700"} text-xs mb-6 max-w-3xl flex gap-2`}>
              <Sparkles className="w-4 h-4 flex-shrink-0 mt-0.5 animate-bounce" />
              <div>
                <strong>Reduce Bedside Cognitive Error:</strong> Select a drug card to copy pre-formatted, standardized bedside reconstitution & infusion details for electronic logs or immediate clinical orders.
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {getFilteredDilutions().map((item, i) => (
                <motion.div 
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: Math.min(i * 0.03, 0.4) }}
                  key={`dilution-${item.drug}-${i}`}
                  className={`p-5 rounded-xl border flex flex-col justify-between transition-all ${
                    isDarkMode ? "bg-[#111827] border-slate-800 hover:border-slate-700" : "bg-white border-slate-200 hover:border-slate-300 shadow-sm"
                  }`}
                >
                  <div>
                    <div className="flex justify-between items-start gap-4 mb-3">
                      <h3 className={`font-bold text-base ${isDarkMode ? "text-teal-400" : "text-teal-700"}`}>{highlightMatch(item.drug, searchQuery)}</h3>
                      <button 
                        onClick={() => handleCopy(`${item.drug} -> Reconstitution: ${item.reconstitution} | Dilution: ${item.dilution} | Infusion: ${item.infusion}`, item.drug)}
                        className={`p-1.5 rounded border text-xs font-semibold flex items-center gap-1 transition-all ${
                          copyFeedback === item.drug 
                            ? "bg-teal-500 border-teal-500 text-slate-950 font-bold" 
                            : isDarkMode 
                              ? "bg-slate-900 border-slate-800 text-slate-300 hover:bg-slate-800" 
                              : "bg-slate-100 border-slate-200 text-slate-700 hover:bg-slate-200"
                        }`}
                      >
                        <Copy className="w-3.5 h-3.5" />
                        {copyFeedback === item.drug ? "Copied Order!" : "Copy Order Layout"}
                      </button>
                    </div>

                    <div className="space-y-3 text-xs leading-normal">
                      {/* Reconstitution */}
                      {item.reconstitution && (
                        <div>
                          <strong className={`${isDarkMode ? "text-slate-400" : "text-slate-700"} block text-[10px] uppercase font-bold`}>1. Reconstitution</strong>
                          <p className={`${isDarkMode ? "text-slate-200" : "text-slate-700"}`}>{highlightMatch(item.reconstitution, searchQuery)}</p>
                        </div>
                      )}

                      {/* Dilution */}
                      {item.dilution && (
                        <div>
                          <strong className={`${isDarkMode ? "text-slate-400" : "text-slate-700"} block text-[10px] uppercase font-bold`}>2. Dilution Pathway</strong>
                          <p className={`${isDarkMode ? "text-slate-200" : "text-slate-700"}`}>{highlightMatch(item.dilution, searchQuery)}</p>
                        </div>
                      )}
                    </div>
                  </div>

                  <div className="mt-4 pt-3 border-t border-slate-800/80 flex items-center justify-between text-xs">
                    <span className={`${isDarkMode ? "text-slate-400" : "text-slate-700"} font-bold uppercase text-[9px] tracking-wider font-mono`}>Infusion Parameter:</span>
                    <strong className={`${isDarkMode ? "text-teal-400" : "text-teal-700"}`}>{highlightMatch(item.infusion, searchQuery)}</strong>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        )}

        {/* TAB 3: RENAL DOSE GUIDE SECTION */}
        {activeTab === "renal" && (
          <div>
            {/* RENAL SUB TAB 1: STABLE WARD */}
            {renalSubTab === "stable" && (
              <div className="grid grid-cols-1 gap-4">
                {getFilteredRenalStable().map((item, i) => (
                  <motion.div 
                    initial={{ opacity: 0, y: 8 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: Math.min(i * 0.02, 0.4) }}
                    key={`renal-stable-${item.drug}-${i}`}
                    className={`p-4 rounded-xl border flex flex-col md:flex-row md:items-start md:justify-between gap-4 transition-all ${
                      isDarkMode ? "bg-[#111827] border-slate-800 hover:border-slate-700" : "bg-white border-slate-200 hover:border-slate-300 shadow-sm"
                    }`}
                  >
                    <div className="md:w-1/4">
                      <h3 className={`font-bold ${isDarkMode ? "text-teal-400" : "text-teal-700"} text-base`}>{highlightMatch(item.drug, searchQuery)}</h3>
                      <span className={`text-[10px] ${isDarkMode ? "text-slate-400" : "text-slate-700"} mt-0.5 block`}>Standard Ward Dose:</span>
                      <span className={`text-xs font-semibold ${isDarkMode ? "text-slate-200" : "text-slate-700"} font-mono block mt-0.5`}>{highlightMatch(item.dose, searchQuery)}</span>
                    </div>

                    <div className={`md:w-3/4 p-3 border ${isDarkMode ? "bg-slate-950/25 border-slate-800/40" : "bg-slate-50 border-slate-200"} rounded-lg`}>
                      <span className={`text-[10px] ${isDarkMode ? "text-teal-400" : "text-teal-700"} font-bold uppercase tracking-wider block mb-1`}>Renal Adjustments & Dialysis Clearance:</span>
                      <p className={`text-xs ${isDarkMode ? "text-slate-200" : "text-slate-700"} leading-normal font-mono whitespace-pre-line`}>{highlightMatch(item.adjustments, searchQuery)}</p>
                    </div>
                  </motion.div>
                ))}
              </div>
            )}

            {/* RENAL SUB TAB 2: ICU & RRT */}
            {renalSubTab === "icu" && (
              <div className="grid grid-cols-1 gap-4">
                {getFilteredRenalICU().map((item, i) => (
                  <motion.div 
                    initial={{ opacity: 0, y: 8 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: Math.min(i * 0.02, 0.4) }}
                    key={`renal-icu-${item.drug}-${i}`}
                    className={`p-4 rounded-xl border transition-all ${
                      isDarkMode ? "bg-[#111827] border-slate-800 hover:border-slate-700" : "bg-white border-slate-200 hover:border-slate-300 shadow-sm"
                    }`}
                  >
                    <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-800/60 pb-3 mb-3">
                      <div>
                        <h3 className={`font-bold ${isDarkMode ? "text-teal-400" : "text-teal-700"} text-base`}>{highlightMatch(item.drug, searchQuery)}</h3>
                        <p className={`text-xs ${isDarkMode ? "text-slate-400" : "text-slate-700"} mt-0.5`}>
                          Standard Loading/Dose: <strong className={`${isDarkMode ? "text-slate-300" : "text-slate-800"} font-mono`}>{highlightMatch(item.dose, searchQuery)}</strong>
                        </p>
                      </div>
                      <div className="flex flex-wrap gap-2 text-xs font-mono">
                        <span className="px-2 py-1 bg-slate-900 border border-slate-800 rounded">
                          CrCl 30-50: <strong className={`${isDarkMode ? "text-teal-400" : "text-teal-700"}`}>{highlightMatch(item.cr3050, searchQuery)}</strong>
                        </span>
                        <span className="px-2 py-1 bg-slate-900 border border-slate-800 rounded">
                          CrCl 10-30: <strong className={`${isDarkMode ? "text-teal-400" : "text-teal-700"}`}>{highlightMatch(item.cr1030, searchQuery)}</strong>
                        </span>
                        <span className="px-2 py-1 bg-slate-900 border border-slate-800 rounded">
                          CrCl &lt;10: <strong className={`${isDarkMode ? "text-teal-400" : "text-teal-700"}`}>{highlightMatch(item.cr10, searchQuery)}</strong>
                        </span>
                      </div>
                    </div>

                    <div className={`p-3 border ${isDarkMode ? "bg-slate-950/25 border-slate-800/40" : "bg-slate-50 border-slate-200"} rounded flex gap-2 items-start`}>
                      <Info className={`w-4 h-4 ${isDarkMode ? "text-teal-400" : "text-teal-700"} flex-shrink-0 mt-0.5`} />
                      <div>
                        <span className={`text-[10px] uppercase font-bold ${isDarkMode ? "text-teal-400" : "text-teal-700"} font-mono tracking-wider`}>Continuous Renal Replacement Therapy (RRT / CVVH / CVVHDF) Guidelines:</span>
                        <p className={`text-xs ${isDarkMode ? "text-slate-300" : "text-slate-800"} mt-1 leading-normal font-sans`} dangerouslySetInnerHTML={{ __html: item.rrt }} />
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* TAB 4: SPECIALIZED PROTOCOLS */}
        {activeTab === "endocrine" && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            
            {/* Dynamic endocrine tests list */}
            <div className={`p-5 rounded-xl border ${
              isDarkMode ? "bg-[#111827] border-slate-800" : "bg-white border-slate-200"
            }`}>
              <div className="flex items-center gap-2 mb-4">
                <Clock className={`${isDarkMode ? "text-teal-400" : "text-teal-700"} h-5 w-5`} />
                <h2 className="text-base font-semibold">MOH/MEMS Dynamic Endocrinology</h2>
              </div>
              <p className={`text-xs ${isDarkMode ? "text-slate-400" : "text-slate-700"} leading-normal mb-4`}>
                These tests require strict diagnostic timing and synchronization of samples. Double-check request forms.
              </p>

              <div className="space-y-4">
                {/* Short Synacthen Test */}
                <div className={`p-3 rounded-lg border ${isDarkMode ? "bg-slate-950/20 border-slate-800" : "bg-slate-50 border-slate-200"}`}>
                  <h3 className={`font-bold text-sm ${isDarkMode ? "text-teal-400" : "text-teal-700"} mb-1`}>Short Synacthen Test (ACTH Stimulation)</h3>
                  <div className={`text-xs space-y-1.5 ${isDarkMode ? "text-slate-300" : "text-slate-800"}`}>
                    <p><strong className={`${isDarkMode ? "text-slate-400" : "text-slate-700"}`}>Timeline:</strong> Draw baseline cortisol (T=0). Inject Synacthen 250 µg IV or IM. Draw cortisol at exactly 30 mins and 60 mins.</p>
                    <p><strong className={`${isDarkMode ? "text-slate-400" : "text-slate-700"}`}>Interpretation:</strong> Stimulated peak cortisol must cross &gt;420 nmol/L (or &gt;500 nmol/L depending on assay kit) to rule out primary adrenal insufficiency.</p>
                  </div>
                </div>

                {/* Overnight Dex Suppression Test */}
                <div className={`p-3 rounded-lg border ${isDarkMode ? "bg-slate-950/20 border-slate-800" : "bg-slate-50 border-slate-200"}`}>
                  <h3 className={`font-bold text-sm ${isDarkMode ? "text-teal-400" : "text-teal-700"} mb-1`}>Overnight Dexamethasone Suppression (ODST)</h3>
                  <div className={`text-xs space-y-1.5 ${isDarkMode ? "text-slate-300" : "text-slate-800"}`}>
                    <p><strong className={`${isDarkMode ? "text-slate-400" : "text-slate-700"}`}>Timeline:</strong> Patient ingests 1 mg oral Dexamethasone at 11:00 PM - midnight. Draw single serum cortisol the next morning at 8:00 AM.</p>
                    <p><strong className={`${isDarkMode ? "text-slate-400" : "text-slate-700"}`}>Interpretation:</strong> Normal axis response suppresses serum cortisol safely to &lt;50 nmol/L (&lt;1.8 µg/dL). Failure to suppress suggests Cushing's syndrome.</p>
                  </div>
                </div>

                {/* Growth Hormone Suppression */}
                <div className={`p-3 rounded-lg border ${isDarkMode ? "bg-slate-950/20 border-slate-800" : "bg-slate-50 border-slate-200"}`}>
                  <h3 className={`font-bold text-sm ${isDarkMode ? "text-teal-400" : "text-teal-700"} mb-1`}>Growth Hormone Suppression Test (OGTT-GH)</h3>
                  <div className={`text-xs space-y-1.5 ${isDarkMode ? "text-slate-300" : "text-slate-800"}`}>
                    <p><strong className={`${isDarkMode ? "text-slate-400" : "text-slate-700"}`}>Timeline:</strong> Administer standard 75g oral glucose load. Draw synchronized pairs of Growth Hormone and Glucose at 0, 30, 60, 90, and 120 minutes.</p>
                    <p><strong className={`${isDarkMode ? "text-slate-400" : "text-slate-700"}`}>Interpretation:</strong> Glucose suppresses normal Growth Hormone to &lt;1.0 µg/L. Failure to suppress confirms Acromegaly.</p>
                  </div>
                </div>

                {/* Water Deprivation Test */}
                <div className={`p-3 rounded-lg border ${isDarkMode ? "bg-slate-950/20 border-slate-800" : "bg-slate-50 border-slate-200"}`}>
                  <h3 className={`font-bold text-sm ${isDarkMode ? "text-teal-400" : "text-teal-700"} mb-1`}>Water Deprivation Test (Fluid Deprivation)</h3>
                  <div className={`text-xs space-y-1.5 ${isDarkMode ? "text-slate-300" : "text-slate-800"}`}>
                    <p><strong className={`${isDarkMode ? "text-slate-400" : "text-slate-700"}`}>Timeline:</strong> Restrict all fluids from 07:30 AM. Collect baseline weight, BP, serum & urine osmolality, and serum Na+. Measure these parameters hourly. Once serum osmolality &gt;295 mOsm/kg or serum Na+ &gt;145 mmol/L (with urine remaining dilute), administer 2 µg Desmopressin (DDAVP) SC/IM. Measure urine osmolality at 1 hour and 2 hours post-DDAVP.</p>
                    <p><strong className={`${isDarkMode ? "text-slate-400" : "text-slate-700"}`}>Safety Cutoffs:</strong> Stop immediately if body weight loss exceeds 3% (risk of severe dehydration/vascular collapse), or if the patient becomes hypotensive or distressed.</p>
                    <p><strong className={`${isDarkMode ? "text-slate-400" : "text-slate-700"}`}>Interpretation:</strong></p>
                    <ul className="list-disc pl-4 space-y-1 text-[11px]">
                      <li><strong className={`${isDarkMode ? "text-teal-300" : "text-teal-700"}`}>Normal / Primary Polydipsia:</strong> Urine concentrates well (&gt;600 mOsm/kg) during fluid deprivation; DDAVP produces &lt;10% further rise.</li>
                      <li><strong className={`${isDarkMode ? "text-teal-300" : "text-teal-700"}`}>Cranial (Central) DI:</strong> Urine remains dilute (&lt;300 mOsm/kg) during deprivation, but rises significantly (&gt;50% increase) after DDAVP.</li>
                      <li><strong className={`${isDarkMode ? "text-teal-300" : "text-teal-700"}`}>Nephrogenic DI:</strong> Urine remains dilute (&lt;300 mOsm/kg) during deprivation, and fails to concentrate (&lt;50% increase) after DDAVP.</li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>

            {/* Other specialty dynamic protocols */}
            <div className={`p-5 rounded-xl border ${
              isDarkMode ? "bg-[#111827] border-slate-800" : "bg-white border-slate-200"
            }`}>
              <div className="flex items-center gap-2 mb-4">
                <FileText className={`${isDarkMode ? "text-teal-400" : "text-teal-700"} h-5 w-5`} />
                <h2 className="text-base font-semibold">Specialty Biopsy Protocols</h2>
              </div>
              <p className={`text-xs ${isDarkMode ? "text-slate-400" : "text-slate-700"} leading-normal mb-4`}>
                Specialized tissue biopsies are highly fragile. Ensure exact preparation parameters are followed to prevent re-taking samples.
              </p>

              <div className="space-y-4">
                {/* Muscle Biopsy */}
                <div className={`p-3 rounded-lg border ${isDarkMode ? "bg-slate-950/20 border-slate-800" : "bg-slate-50 border-slate-200"}`}>
                  <h3 className={`font-bold text-sm ${isDarkMode ? "text-teal-400" : "text-teal-700"} mb-1`}>Muscle Biopsy (Myopathy/Neuromuscular)</h3>
                  <div className={`text-xs space-y-1.5 ${isDarkMode ? "text-slate-300" : "text-slate-800"}`}>
                    <p><strong className={`${isDarkMode ? "text-slate-400" : "text-slate-700"}`}>Pre-Biopsy:</strong> Contact MLT concerned (ext 5605) at least 24h before. Deliver fresh. Do not stretch or tie the muscle cylinder.</p>
                    <p><strong className={`${isDarkMode ? "text-slate-400" : "text-slate-700"}`}>Prep:</strong> Wrap tissue in aluminium foil, place in a dry clean container, and pack in a larger container with gel ice for transport immediately.</p>
                    <p><strong className={`${isDarkMode ? "text-slate-400" : "text-slate-700"}`}>Stability:</strong> Must reach Histopathology Lab (Pintu 6) within 4-6 hours of excision.</p>
                  </div>
                </div>

                {/* Renal Biopsy */}
                <div className={`p-3 rounded-lg border ${isDarkMode ? "bg-slate-950/20 border-slate-800" : "bg-slate-50 border-slate-200"}`}>
                  <h3 className={`font-bold text-sm ${isDarkMode ? "text-teal-400" : "text-teal-700"} mb-1`}>Renal Biopsy (Glomerulonephritis/Nephrotic)</h3>
                  <div className={`text-xs space-y-1.5 ${isDarkMode ? "text-slate-300" : "text-slate-800"}`}>
                    <p><strong className={`${isDarkMode ? "text-slate-400" : "text-slate-700"}`}>Pre-Biopsy:</strong> Always notify the duty Pathologist for urgent or immunofluorescence evaluations.</p>
                    <p><strong className={`${isDarkMode ? "text-slate-400" : "text-slate-700"}`}>Cores Required:</strong> Two tissue cores recommended: 1) Formalin-fixed for ordinary light microscopy (H&E), and 2) Fresh tissue core in phosphate buffer for immunofluorescence.</p>
                    <p><strong className={`${isDarkMode ? "text-slate-400" : "text-slate-700"}`}>Warning:</strong> Do NOT place fresh immunofluorescence samples on dry gauze as it absorbs the solution and degrades the core tissue.</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 6: EM DRUG DILUTION GUIDELINES */}
        {activeTab === "emts" && (
          <div>
            <div className={`p-4 rounded-lg bg-emerald-500/5 border border-emerald-500/20 ${isDarkMode ? "text-emerald-400" : "text-emerald-700"} text-xs mb-6 max-w-3xl flex gap-2`}>
              <AlertTriangle className="w-4 h-4 flex-shrink-0 mt-0.5 animate-pulse" />
              <div>
                <strong>EM Drug Dilution Guidelines Integration:</strong> This library integrates clinical protocols for Emergency Medicine (EM) drug preparation and dilution based on international consensus and MOH guidelines. Click <strong>Copy Preparation Order</strong> to export complete clinical directives.
              </div>
            </div>

            {/* Bedside Emergency Infusion (Drip) Calculator */}
            <div className={`p-5 rounded-xl border mb-6 ${
              isDarkMode ? "bg-[#111827] border-emerald-500/10" : "bg-white border-emerald-200"
            }`}>
              <div className="flex items-center gap-2 mb-3">
                <Calculator className={`${isDarkMode ? "text-emerald-400" : "text-emerald-700"} h-5 w-5`} />
                <h2 className="text-base font-semibold">EM Bedside Drip Rate Calculator</h2>
                <span className={`text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/10 ${isDarkMode ? "text-emerald-400" : "text-emerald-700"} border border-emerald-500/20 font-mono`}>
                  Adaptive
                </span>
              </div>
              <p className={`text-xs ${isDarkMode ? "text-slate-400" : "text-slate-700"} mb-4`}>
                Instantly calculates pump flow rates in <strong>ml/hour</strong> for critical emergency infusions based on EM drug dilution guidelines.
              </p>

              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div>
                  <label className={`text-xs ${isDarkMode ? "text-slate-400" : "text-slate-700"} block mb-1`}>1. Select Emergency Drug</label>
                  <select
                    value={emtsSelectedDrug}
                    onChange={(e) => {
                      const drug = e.target.value as any;
                      setEmtsSelectedDrug(drug);
                      // Set default doses for selected drug
                      if (drug === "noradrenaline" || drug === "adrenaline") setEmtsDose("0.1");
                      else if (drug === "dopamine" || drug === "dobutamine") setEmtsDose("5");
                      else if (drug === "labetalol") setEmtsDose("1");
                    }}
                    className={`w-full p-2.5 rounded border text-xs outline-none ${
                      isDarkMode ? "bg-[#0b0f19] border-slate-800 text-slate-200" : "bg-white border-slate-200 text-slate-900 shadow-sm"
                    }`}
                  >
                    <option value="noradrenaline">Noradrenaline (mcg/kg/min)</option>
                    <option value="adrenaline">Adrenaline (mcg/kg/min)</option>
                    <option value="dopamine">Dopamine (mcg/kg/min)</option>
                    <option value="dobutamine">Dobutamine (mcg/kg/min)</option>
                    <option value="labetalol">Labetalol (mg/minute)</option>
                  </select>
                </div>

                {emtsSelectedDrug !== "labetalol" ? (
                  <div>
                    <label className={`text-xs ${isDarkMode ? "text-slate-400" : "text-slate-700"} block mb-1`}>2. Concentration Strength</label>
                    <select
                      value={emtsStrength}
                      onChange={(e) => setEmtsStrength(e.target.value as any)}
                      className={`w-full p-2.5 rounded border text-xs outline-none ${
                        isDarkMode ? "bg-[#0b0f19] border-slate-800 text-slate-200" : "bg-white border-slate-200 text-slate-900 shadow-sm"
                      }`}
                    >
                      <option value="single">Single Strength</option>
                      <option value="double">Double Strength</option>
                    </select>
                  </div>
                ) : (
                  <div>
                    <label className={`text-xs ${isDarkMode ? "text-slate-400" : "text-slate-700"} block mb-1`}>2. Concentration Strength</label>
                    <div className={`p-2.5 rounded border border-dashed text-xs font-semibold ${
                      isDarkMode ? "bg-[#0b0f19] border-slate-800 text-slate-400" : "bg-slate-100 border-slate-200 text-slate-700"
                    }`}>
                      Standard Dilution (2 mg/ml)
                    </div>
                  </div>
                )}

                {emtsSelectedDrug !== "labetalol" ? (
                  <div>
                    <label className={`text-xs ${isDarkMode ? "text-slate-400" : "text-slate-700"} block mb-1`}>3. Patient Weight (kg)</label>
                    <input
                      type="number"
                      placeholder="e.g. 70"
                      value={emtsWeight}
                      onChange={(e) => setEmtsWeight(e.target.value)}
                      className={`w-full p-2 rounded border text-xs outline-none ${
                        isDarkMode ? "bg-[#0b0f19] border-slate-800 text-slate-200" : "bg-white border-slate-200 text-slate-900 shadow-sm"
                      }`}
                    />
                  </div>
                ) : (
                  <div>
                    <label className={`text-xs ${isDarkMode ? "text-slate-400" : "text-slate-700"} block mb-1`}>3. Patient Weight (kg)</label>
                    <div className={`p-2.5 rounded border border-dashed text-xs font-semibold ${
                      isDarkMode ? "bg-[#0b0f19] border-slate-800 text-slate-400" : "bg-slate-100 border-slate-200 text-slate-700"
                    }`}>
                      N/A (Non-Weight Based)
                    </div>
                  </div>
                )}

                <div>
                  <label className={`text-xs ${isDarkMode ? "text-slate-400" : "text-slate-700"} block mb-1`}>
                    4. Target Dose {emtsSelectedDrug === "labetalol" ? "(mg/min)" : "(mcg/kg/min)"}
                  </label>
                  <input
                    type="number"
                    step="0.01"
                    placeholder={emtsSelectedDrug === "labetalol" ? "e.g. 1.0" : "e.g. 0.1"}
                    value={emtsDose}
                    onChange={(e) => setEmtsDose(e.target.value)}
                    className={`w-full p-2 rounded border text-xs outline-none ${
                      isDarkMode ? "bg-[#0b0f19] border-slate-800 text-slate-200" : "bg-white border-slate-200 text-slate-900 shadow-sm"
                    }`}
                  />
                </div>
              </div>

              {emtsResult && (
                <motion.div 
                  initial={{ opacity: 0, y: 5 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="mt-4 p-4 rounded-lg bg-rose-500/5 border border-rose-500/10 grid grid-cols-1 md:grid-cols-3 gap-4 items-center"
                >
                  <div>
                    <span className={`text-[10px] ${isDarkMode ? "text-slate-400" : "text-slate-700"} uppercase font-bold block`}>1. Preparation & Potency</span>
                    <p className={`text-xs font-semibold ${isDarkMode ? "text-slate-200" : "text-slate-700"} mt-0.5`}>{emtsResult.prepText}</p>
                    <span className={`text-[10px] ${isDarkMode ? "text-slate-400" : "text-slate-700"} mt-1 block`}>Concentration: <strong className={`${isDarkMode ? "text-teal-400" : "text-teal-700"}`}>{emtsResult.concentration} {emtsSelectedDrug === "labetalol" ? "mg/ml" : "mcg/ml"}</strong></span>
                  </div>
                  <div className="p-3 bg-rose-500/10 rounded-lg text-center border border-rose-500/20">
                    <span className={`text-[10px] ${isDarkMode ? "text-rose-400" : "text-rose-700"} uppercase font-bold block`}>Required Pump Rate</span>
                    <strong className="text-2xl text-white font-mono">{emtsResult.mlPerHour} ml/hour</strong>
                  </div>
                  <div>
                    <span className={`text-[10px] ${isDarkMode ? "text-slate-400" : "text-slate-700"} uppercase font-bold block`}>Bedside Ordering Order</span>
                    <button 
                      onClick={() => handleCopy(
                        `Emergency Infusion Order: ${emtsSelectedDrug.toUpperCase()} ${emtsStrength.toUpperCase()} Strength. Dose: ${emtsDose} ${emtsSelectedDrug === "labetalol" ? "mg/min" : "mcg/kg/min"}. Prep: ${emtsResult.prepText}. Run pump at ${emtsResult.mlPerHour} ml/hour.`,
                        "emts_calc"
                      )}
                      className={`w-full mt-1.5 py-1.5 rounded text-xs font-bold transition-all flex items-center justify-center gap-1 ${
                        copyFeedback === "emts_calc" 
                          ? "bg-teal-500 text-slate-950" 
                          : "bg-slate-850 text-slate-200 hover:bg-slate-700"
                      }`}
                    >
                      <Copy className="w-3.5 h-3.5" />
                      {copyFeedback === "emts_calc" ? "Copied Infusion Order!" : "Copy Infusion Order"}
                    </button>
                  </div>
                </motion.div>
              )}
            </div>

            {/* Quick Categories Filter row */}
            <div className="flex flex-wrap gap-2 mb-6">
              {["All", "Resuscitation", "Shock/Inotropes", "Hypertension", "Sedation/Analgesia", "Respiratory/Other"].map((cat) => (
                <button
                  key={cat}
                  onClick={() => setSelectedEMTSCategory(cat)}
                  className={`px-3 py-1.5 rounded-full text-xs font-semibold border transition-all cursor-pointer ${
                    selectedEMTSCategory === cat
                      ? "bg-emerald-500/20 text-emerald-400 border-emerald-500/40"
                      : isDarkMode
                        ? "bg-[#111827] border-slate-800 text-slate-400 hover:bg-slate-800 hover:text-slate-300"
                        : "bg-slate-100 border-slate-200 text-slate-600 hover:bg-slate-200 hover:text-slate-700"
                  }`}
                >
                  {cat === "All" && "📁 All EM Drugs"}
                  {cat === "Resuscitation" && "🚨 Resuscitation"}
                  {cat === "Shock/Inotropes" && "⚡ Shock & Inotropes"}
                  {cat === "Hypertension" && "🩸 Hypertension"}
                  {cat === "Sedation/Analgesia" && "🧠 Sedation & Analgesia"}
                  {cat === "Respiratory/Other" && "🌬️ Respiratory & Antidotes"}
                </button>
              ))}
            </div>

            {/* Drugs List Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {getFilteredEMTS().map((item, i) => (
                <motion.div 
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: Math.min(i * 0.03, 0.4) }}
                  key={`emts-${item.drug}-${i}`}
                  className={`p-5 rounded-xl border flex flex-col justify-between transition-all ${
                    isDarkMode ? "bg-[#111827] border-slate-800 hover:border-slate-700" : "bg-white border-slate-200 hover:border-slate-300 shadow-sm"
                  }`}
                >
                  <div>
                    <div className="flex justify-between items-start gap-4 mb-3">
                      <div>
                        <h3 className={`font-bold text-base ${isDarkMode ? "text-emerald-400" : "text-emerald-700"}`}>{highlightMatch(item.drug, searchQuery)}</h3>
                        <span className={`text-[10px] ${isDarkMode ? "text-slate-400" : "text-slate-700"} uppercase font-bold tracking-wider`}>{item.category}</span>
                      </div>
                      <button 
                        onClick={() => handleCopy(`${item.drug} -> Indications: ${item.indication} | Prep: ${item.preparation} | Bolus: ${item.bolus} | Infusion: ${item.infusion} | Safety Precautions: ${item.precautions}`, item.drug)}
                        className={`p-1.5 rounded border text-xs font-semibold flex items-center gap-1 transition-all ${
                          copyFeedback === item.drug 
                            ? "bg-emerald-500 border-emerald-500 text-slate-950 font-bold" 
                            : isDarkMode 
                              ? "bg-[#0b0f19] border-slate-800 text-slate-300 hover:bg-slate-800" 
                              : "bg-slate-100 border-slate-200 text-slate-700 hover:bg-slate-200"
                        }`}
                      >
                        <Copy className="w-3.5 h-3.5" />
                        {copyFeedback === item.drug ? "Copied Order!" : "Copy Order Layout"}
                      </button>
                    </div>

                    <div className="space-y-3 text-xs leading-normal">
                      <div>
                        <strong className={`${isDarkMode ? "text-slate-400" : "text-slate-700"} block text-[10px] uppercase font-bold`}>Indication</strong>
                        <p className={`${isDarkMode ? "text-slate-200" : "text-slate-700"}`}>{highlightMatch(item.indication, searchQuery)}</p>
                      </div>

                      <div>
                        <strong className={`${isDarkMode ? "text-slate-400" : "text-slate-700"} block text-[10px] uppercase font-bold`}>Preparation & Strengths</strong>
                        <p className={`${isDarkMode ? "text-slate-200" : "text-slate-700"} whitespace-pre-line`}>{highlightMatch(item.preparation, searchQuery)}</p>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div>
                          <strong className={`${isDarkMode ? "text-slate-400" : "text-slate-700"} block text-[10px] uppercase font-bold`}>Bolus Guideline</strong>
                          <p className={`${isDarkMode ? "text-slate-200" : "text-slate-700"} whitespace-pre-line`}>{highlightMatch(item.bolus, searchQuery)}</p>
                        </div>
                        <div>
                          <strong className={`${isDarkMode ? "text-slate-400" : "text-slate-700"} block text-[10px] uppercase font-bold`}>Infusion Guideline</strong>
                          <p className={`${isDarkMode ? "text-slate-200" : "text-slate-700"} whitespace-pre-line`}>{highlightMatch(item.infusion, searchQuery)}</p>
                        </div>
                      </div>

                      <div className="pt-2 border-t border-slate-800/60">
                        <strong className={`${isDarkMode ? "text-emerald-400" : "text-emerald-700"} block text-[10px] uppercase font-bold flex items-center gap-1`}>
                          <AlertTriangle className="w-3.5 h-3.5 text-emerald-500 animate-pulse" /> Bedside Precautions & Warnings
                        </strong>
                        <p className={`${isDarkMode ? "text-slate-300" : "text-slate-800"} mt-0.5`}>{highlightMatch(item.precautions, searchQuery)}</p>
                      </div>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>

            {getFilteredEMTS().length === 0 && (
              <div className={`text-center py-12 ${isDarkMode ? "text-slate-400" : "text-slate-700"} font-mono text-sm`}>
                No matching EM drug dilutions found. Try adjusting filters or search terms.
              </div>
            )}
          </div>
        )}

        {/* TAB 5: TELEPHONE DIRECTORY & REQUISITION FORMS */}
        {activeTab === "directory" && (
          <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
            
            {/* Column: Contacts & Forms */}
            <div className="space-y-6">
              
              {/* Operator Extensions */}
              <div className={`p-4 sm:p-5 rounded-xl border ${
                isDarkMode ? "bg-[#111827] border-slate-800" : "bg-white border-slate-200"
              }`}>
                <div className="flex items-center gap-2 mb-4">
                  <Phone className={`${isDarkMode ? "text-teal-400" : "text-teal-700"} h-5 w-5`} />
                  <h2 className="text-sm sm:text-base font-semibold">Hospital Directory & Lab Contacts</h2>
                </div>
                
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4">
                  {directoryData.map((dept, idx) => (
                    <div key={idx} className={`p-2.5 border ${isDarkMode ? "bg-slate-950/20 border-slate-800" : "bg-slate-50 border-slate-200"} rounded-lg`}>
                      <span className={`text-[10px] font-semibold ${isDarkMode ? "text-teal-300" : "text-teal-700"} block mb-2 border-b ${isDarkMode ? "border-slate-800" : "border-slate-200"} pb-1`}>
                        {dept.dept}
                      </span>
                      <div className={`space-y-1.5 ${isDarkMode ? "text-slate-300" : "text-slate-800"} text-[10px] font-mono`}>
                        {dept.items.map((item, i) => (
                          <div key={i} className="flex justify-between items-center group">
                            <span className="truncate pr-2">{item.name}:</span>
                            <div className="flex gap-1">
                              {item.ext.split(" / ").map((num, nidx) => (
                                <a 
                                  key={nidx}
                                  href={`tel:${num.startsWith("0") ? num : (dept.dept.includes("HKL") || item.name.includes("HKL") ? "0326155555" : "") + (num.length === 4 ? "," + num : num)}`}
                                  className={`px-1 rounded ${isDarkMode ? "text-teal-400 bg-teal-500/5 hover:bg-teal-500/10" : "text-teal-700 bg-teal-50 hover:bg-teal-100"} transition-colors whitespace-nowrap`}
                                >
                                  {num}{nidx < item.ext.split(" / ").length - 1 ? "" : ""}
                                </a>
                              ))}
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Right Column: Requisition Forms */}
            <div className={`p-5 rounded-xl border ${
              isDarkMode ? "bg-[#111827] border-slate-800" : "bg-white border-slate-200 shadow-sm"
            }`}>
              <div className="flex items-center gap-2 mb-4">
                <FileText className={`${isDarkMode ? "text-teal-400" : "text-teal-700"} h-5 w-5`} />
                <h2 className="text-base font-semibold">Required Requisition Forms</h2>
              </div>
              <p className={`text-xs ${isDarkMode ? "text-slate-400" : "text-slate-700"} leading-normal mb-4`}>
                Ensure correct forms are used to avoid processing delays.
              </p>

              <div className="space-y-3 text-xs">
                {[
                  { title: "PER-PAT 301 Form", desc: "General default form for chemical pathology, hematology, and microbiology. Must be stamped and signed." },
                  { title: "AUTOIMMUNE FORM (v4.0)", desc: "Required for immunofluorescence assays (IMR) e.g. Anti-AChR, AQP4." },
                  { title: "ENDOCRINE REQUEST FORM", desc: "For specialized endocrine assays referred to HKL or IMR (e.g. AMH, Diabetes antibodies)." },
                  { title: "TBIS 20C Form", desc: "Specifically required for tuberculosis diagnostics (AFB smears, PCR, and cultures)." }
                ].map((form, i) => (
                  <div key={i} className={`p-3 rounded-lg border ${isDarkMode ? "bg-slate-950/20 border-slate-800" : "bg-slate-50 border-slate-200"}`}>
                    <strong className={`block ${isDarkMode ? "text-teal-300" : "text-teal-700"} mb-1`}>{form.title}</strong>
                    <span className={`${isDarkMode ? "text-slate-400" : "text-slate-700"} text-[11px] leading-relaxed block`}>
                      {form.desc}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* TAB: HOUSE OFFICER PROCEDURES & SAMPLING GUIDE */}
        {activeTab === "ho_guide" && (
          <div className="space-y-6 animate-fade-in">
            {/* Header / Intro */}
            <div className={`p-5 rounded-2xl border ${
              isDarkMode ? "bg-[#111827] border-slate-800" : "bg-white border-slate-200 shadow-sm"
            }`}>
              <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                <div>
                  <h2 className={`text-lg sm:text-xl font-bold font-sans ${isDarkMode ? "text-teal-400" : "text-teal-700"} flex items-center gap-2`}>
                    <ClipboardList className="w-5 h-5" /> House Officer Bedside Procedures & Fluid Sampling Guide
                  </h2>
                  <p className={`text-xs mt-1 ${isDarkMode ? "text-slate-400" : "text-slate-500"}`}>
                    Comprehensive ward reference for interactive checklists, bottle-matching rules, concurrent blood requirements, and bedside clinical calculators.
                  </p>
                </div>
                <div className="flex gap-2 flex-wrap">
                  <button
                    onClick={() => setHoChecklist({})}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold uppercase tracking-wider transition-all border ${
                      isDarkMode 
                        ? "bg-[#ef4444]/10 text-rose-400 border-[#ef4444]/20 hover:bg-[#ef4444]/20" 
                        : "bg-rose-50 text-rose-700 border-rose-200 hover:bg-rose-100"
                    }`}
                  >
                    Reset All Checklists
                  </button>
                </div>
              </div>
            </div>

            {/* Protocol Tabs */}
            <div className="flex overflow-x-auto pb-1 scrollbar-none gap-2">
              {[
                { id: "pleural", label: "Pleural Fluid", desc: "Light's Criteria", icon: "🧪" },
                { id: "ascites", label: "Ascitic Fluid", desc: "SAAG Gradient", icon: "💧" },
                { id: "csf", label: "CSF Bedside", desc: "Meningitis Panel", icon: "🧠" },
                { id: "bma", label: "BMA & Trephine", desc: "BMAT & TB Marrow", icon: "🩸" },
                { id: "hemolytic", label: "Hemolytic Anemia", desc: "Hemolysis Workup", icon: "🔍" }
              ].map((sub) => {
                const isActive = hoActiveGuide === sub.id;
                return (
                  <button
                    key={sub.id}
                    onClick={() => setHoActiveGuide(sub.id as any)}
                    className={`flex-shrink-0 flex items-center gap-2.5 p-3 rounded-xl border transition-all text-left w-48 sm:w-52 cursor-pointer ${
                      isActive
                        ? isDarkMode
                          ? "bg-teal-500/10 border-teal-500 ring-1 ring-teal-500/20 shadow-md shadow-teal-500/5 text-teal-400"
                          : "bg-teal-50 border-teal-400 shadow-md shadow-teal-100 text-teal-900"
                        : isDarkMode
                          ? "bg-slate-900/60 border-slate-800/80 hover:bg-slate-800/80 text-slate-400"
                          : "bg-slate-50 border-slate-200 hover:bg-slate-100 text-slate-600"
                    }`}
                  >
                    <span className="text-xl">{sub.icon}</span>
                    <div className="truncate">
                      <div className="text-xs font-bold leading-tight">
                        {sub.label}
                      </div>
                      <div className="text-[10px] text-slate-500 leading-tight">
                        {sub.desc}
                      </div>
                    </div>
                  </button>
                );
              })}
            </div>

            {/* Active Guide Content */}
            <div className="grid grid-cols-1 xl:grid-cols-12 gap-6 items-start">
              
              {/* Left Column: Information, Guides & Calculations (7 cols) */}
              <div className="xl:col-span-7 space-y-6">
                
                {/* 1. PLEURAL FLUID INTERACTIVE GUIDE */}
                {hoActiveGuide === "pleural" && (
                  <div className="space-y-6">
                    {/* Clinical Overview Card */}
                    <div className={`p-4 sm:p-5 rounded-2xl border space-y-3 ${
                      isDarkMode ? "bg-[#111827] border-slate-800" : "bg-white border-slate-200 shadow-sm"
                    }`}>
                      <div className="flex items-center gap-2 text-rose-400 font-bold text-xs sm:text-sm uppercase tracking-wider">
                        <span>💡</span> Clinical Bedside Rule No. 1
                      </div>
                      <h3 className={`font-bold font-sans text-sm sm:text-base ${isDarkMode ? "text-slate-100" : "text-slate-900"}`}>
                        Matching Concurrent Serum Samples Required!
                      </h3>
                      <p className={`text-xs leading-relaxed ${isDarkMode ? "text-slate-300" : "text-slate-600"}`}>
                        When sending pleural fluid chemistry, you <strong className="text-rose-400">MUST</strong> draw matching concurrent blood/serum samples for <strong className="text-teal-400">Glucose, Protein, Albumin, and LDH</strong>. Ratios of fluid-to-serum are calculated to distinguish between **Exudate** and **Transudate** via Light's Criteria.
                      </p>
                      <div className={`p-3 rounded-xl border text-[11px] leading-relaxed ${isDarkMode ? "bg-slate-950/40 border-slate-800" : "bg-slate-50 border-slate-200"}`}>
                        <span className="font-bold text-amber-400 uppercase tracking-wider block mb-1">🧪 Bedside pH Pearl:</span>
                        For accurate pH, sample must be collected anaerobically in a heparinised syringe (pre-flushed like an ABG syringe) and sent on ice <strong className="text-rose-400">immediately</strong> to the lab. Exposed air or prolonged waiting alters the pleural pH.
                      </div>
                    </div>

                    {/* Light's Criteria Interactive Calculator */}
                    <div className={`p-5 rounded-2xl border space-y-4 ${
                      isDarkMode ? "bg-[#111827] border-slate-800" : "bg-white border-slate-200 shadow-sm"
                    }`}>
                      <div className="flex justify-between items-center border-b border-slate-800/60 pb-3">
                        <h3 className={`text-sm sm:text-base font-bold flex items-center gap-2 ${isDarkMode ? "text-teal-400" : "text-teal-700"}`}>
                          <span>🧮</span> Light's Criteria Calculator
                        </h3>
                        <span className="text-[10px] bg-teal-500/10 text-teal-400 font-mono font-bold px-2 py-0.5 rounded border border-teal-500/20">AUTOMATIC CALCULATION</span>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div className="space-y-3">
                          <h4 className={`text-xs font-bold uppercase tracking-wider ${isDarkMode ? "text-slate-400" : "text-slate-600"}`}>Pleural Fluid Chemistry</h4>
                          <div className="space-y-2">
                            <div>
                              <label className="text-[10px] font-bold text-slate-400 block mb-1">Pleural Protein (g/L)</label>
                              <input
                                type="number"
                                placeholder="e.g. 35"
                                value={hoPleuralFluidProtein}
                                onChange={(e) => setHoPleuralFluidProtein(e.target.value)}
                                className={`w-full p-2.5 rounded-xl border text-xs font-mono outline-none ${
                                  isDarkMode ? "bg-slate-900 border-slate-800 text-white" : "bg-slate-50 border-slate-200 text-slate-900"
                                }`}
                              />
                            </div>
                            <div>
                              <label className="text-[10px] font-bold text-slate-400 block mb-1">Pleural LDH (U/L)</label>
                              <input
                                type="number"
                                placeholder="e.g. 240"
                                value={hoPleuralFluidLdh}
                                onChange={(e) => setHoPleuralFluidLdh(e.target.value)}
                                className={`w-full p-2.5 rounded-xl border text-xs font-mono outline-none ${
                                  isDarkMode ? "bg-slate-900 border-slate-800 text-white" : "bg-slate-50 border-slate-200 text-slate-900"
                                }`}
                              />
                            </div>
                          </div>
                        </div>

                        <div className="space-y-3">
                          <h4 className={`text-xs font-bold uppercase tracking-wider ${isDarkMode ? "text-slate-400" : "text-slate-600"}`}>Serum / Blood Chemistry</h4>
                          <div className="space-y-2">
                            <div>
                              <label className="text-[10px] font-bold text-slate-400 block mb-1">Serum Protein (g/L)</label>
                              <input
                                type="number"
                                placeholder="e.g. 64"
                                value={hoSerumProtein}
                                onChange={(e) => setHoSerumProtein(e.target.value)}
                                className={`w-full p-2.5 rounded-xl border text-xs font-mono outline-none ${
                                  isDarkMode ? "bg-slate-900 border-slate-800 text-white" : "bg-slate-50 border-slate-200 text-slate-900"
                                }`}
                              />
                            </div>
                            <div>
                              <label className="text-[10px] font-bold text-slate-400 block mb-1">Serum LDH (U/L)</label>
                              <input
                                type="number"
                                placeholder="e.g. 180"
                                value={hoSerumLdh}
                                onChange={(e) => setHoSerumLdh(e.target.value)}
                                className={`w-full p-2.5 rounded-xl border text-xs font-mono outline-none ${
                                  isDarkMode ? "bg-slate-900 border-slate-800 text-white" : "bg-slate-50 border-slate-200 text-slate-900"
                                }`}
                              />
                            </div>
                          </div>
                        </div>
                      </div>

                      <div className="pt-2">
                        <label className="text-[10px] font-bold text-slate-400 block mb-1">Serum LDH Upper Limit of Normal (U/L)</label>
                        <input
                          type="number"
                          placeholder="e.g. 200"
                          value={hoSerumLdhUpperLimit}
                          onChange={(e) => setHoSerumLdhUpperLimit(e.target.value)}
                          className={`w-28 p-2 rounded-xl border text-xs font-mono outline-none ${
                            isDarkMode ? "bg-slate-900 border-slate-800 text-white" : "bg-slate-50 border-slate-200 text-slate-900"
                          }`}
                        />
                      </div>

                      {/* Result Box */}
                      {(() => {
                        const pfProt = parseFloat(hoPleuralFluidProtein);
                        const sProt = parseFloat(hoSerumProtein);
                        const pfLdh = parseFloat(hoPleuralFluidLdh);
                        const sLdh = parseFloat(hoSerumLdh);
                        const sLdhUln = parseFloat(hoSerumLdhUpperLimit) || 200;

                        if (isNaN(pfProt) || isNaN(sProt) || isNaN(pfLdh) || isNaN(sLdh)) {
                          return (
                            <div className="p-3 text-center text-[11px] text-slate-500 bg-slate-950/20 rounded-xl border border-dashed border-slate-800">
                              Input Pleural and Serum Protein & LDH values to calculate Light's Criteria.
                            </div>
                          );
                        }

                        const protRatio = pfProt / sProt;
                        const ldhRatio = pfLdh / sLdh;
                        const ldhLimit = (2/3) * sLdhUln;
                        const meetsLimit = pfLdh > ldhLimit;

                        const isProtExudate = protRatio > 0.5;
                        const isLdhExudate = ldhRatio > 0.6;
                        const isLimitExudate = meetsLimit;

                        const isExudate = isProtExudate || isLdhExudate || isLimitExudate;

                        return (
                          <div className={`p-4 rounded-xl border ${
                            isExudate 
                              ? isDarkMode ? "bg-rose-950/10 border-rose-500/20" : "bg-rose-50 border-rose-200"
                              : isDarkMode ? "bg-emerald-950/10 border-emerald-500/20" : "bg-emerald-50 border-emerald-200"
                          } space-y-3`}>
                            <div className="flex justify-between items-center">
                              <span className="text-[10px] uppercase font-bold text-slate-500 tracking-wider">Light's Criteria Result:</span>
                              <span className={`text-xs font-extrabold px-3 py-1 rounded-md uppercase ${
                                isExudate 
                                  ? "bg-rose-500/20 text-rose-400 border border-rose-500/30"
                                  : "bg-emerald-500/20 text-emerald-400 border border-emerald-500/30"
                              }`}>
                                {isExudate ? "EXUDATIVE PLEURAL EFFUSION" : "TRANSUDATIVE PLEURAL EFFUSION"}
                              </span>
                            </div>

                            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs font-mono">
                              <div className={`p-2.5 rounded-lg border ${isProtExudate ? "border-rose-500/20 bg-rose-500/5 text-rose-400" : "border-slate-800 bg-slate-950/10 text-slate-400"}`}>
                                <div className="text-[10px] uppercase text-slate-500 font-bold font-sans">Protein Ratio</div>
                                <div className="text-sm font-bold">{protRatio.toFixed(2)}</div>
                                <div className="text-[9px] mt-0.5">{isProtExudate ? "Meets (>0.5) ✓" : "Does not meet (≤0.5)"}</div>
                              </div>
                              <div className={`p-2.5 rounded-lg border ${isLdhExudate ? "border-rose-500/20 bg-rose-500/5 text-rose-400" : "border-slate-800 bg-slate-950/10 text-slate-400"}`}>
                                <div className="text-[10px] uppercase text-slate-500 font-bold font-sans">LDH Ratio</div>
                                <div className="text-sm font-bold">{ldhRatio.toFixed(2)}</div>
                                <div className="text-[9px] mt-0.5">{isLdhExudate ? "Meets (>0.6) ✓" : "Does not meet (≤0.6)"}</div>
                              </div>
                              <div className={`p-2.5 rounded-lg border ${isLimitExudate ? "border-rose-500/20 bg-rose-500/5 text-rose-400" : "border-slate-800 bg-slate-950/10 text-slate-400"}`}>
                                <div className="text-[10px] uppercase text-slate-500 font-bold font-sans">Fluid LDH</div>
                                <div className="text-sm font-bold">{pfLdh.toFixed(0)} <span className="text-[10px] text-slate-500">vs {ldhLimit.toFixed(0)}</span></div>
                                <div className="text-[9px] mt-0.5">{isLimitExudate ? "Meets (>2/3 ULN) ✓" : "Does not meet"}</div>
                              </div>
                            </div>

                            <p className="text-[11px] leading-relaxed text-slate-400">
                              {isExudate ? (
                                <span><strong>Common Exudate Etiology:</strong> Parapneumonic effusion/empyema, malignant effusion, tuberculosis, pulmonary embolism, connective tissue diseases, pancreatitis, drug-induced.</span>
                              ) : (
                                <span><strong>Common Transudate Etiology:</strong> Congestive cardiac failure (CCF), hepatic cirrhosis (hepatic hydrothorax), nephrotic syndrome, severe hypoalbuminemia, peritoneal dialysis, superior vena cava obstruction.</span>
                              )}
                            </p>
                          </div>
                        );
                      })()}
                    </div>
                  </div>
                )}

                {/* 2. ASCITIC FLUID INTERACTIVE GUIDE */}
                {hoActiveGuide === "ascites" && (
                  <div className="space-y-6">
                    {/* Clinical Overview Card */}
                    <div className={`p-4 sm:p-5 rounded-2xl border space-y-3 ${
                      isDarkMode ? "bg-[#111827] border-slate-800" : "bg-white border-slate-200 shadow-sm"
                    }`}>
                      <div className="flex items-center gap-2 text-rose-400 font-bold text-xs sm:text-sm uppercase tracking-wider">
                        <span>💡</span> Clinical Bedside Rule No. 2
                      </div>
                      <h3 className={`font-bold font-sans text-sm sm:text-base ${isDarkMode ? "text-slate-100" : "text-slate-900"}`}>
                        SAAG Gradient & Immediate Inoculation
                      </h3>
                      <p className={`text-xs leading-relaxed ${isDarkMode ? "text-slate-300" : "text-slate-600"}`}>
                        When sending ascitic fluid chemistry, you <strong className="text-rose-400">MUST</strong> draw a matching concurrent blood sample for <strong className="text-teal-400">Serum Albumin</strong>. This allows the calculation of the SAAG gradient.
                      </p>
                      <div className={`p-3 rounded-xl border text-[11px] leading-relaxed ${isDarkMode ? "bg-slate-950/40 border-slate-800" : "bg-slate-50 border-slate-200"}`}>
                        <span className="font-bold text-amber-400 uppercase tracking-wider block mb-1">🦠 Bedside Culture Pearl:</span>
                        For suspected **Spontaneous Bacterial Peritonitis (SBP)**, inoculate the fluid <strong className="text-rose-400">DIRECTLY into blood culture bottles (Aerobic & Anaerobic) at the bedside</strong>. Sending fluid in a sterile container has a significantly lower diagnostic yield due to rapid bactericidal action of cellular elements!
                      </div>
                    </div>

                    {/* SAAG Calculator */}
                    <div className={`p-5 rounded-2xl border space-y-4 ${
                      isDarkMode ? "bg-[#111827] border-slate-800" : "bg-white border-slate-200 shadow-sm"
                    }`}>
                      <div className="flex justify-between items-center border-b border-slate-800/60 pb-3">
                        <h3 className={`text-sm sm:text-base font-bold flex items-center gap-2 ${isDarkMode ? "text-teal-400" : "text-teal-700"}`}>
                          <span>🧮</span> SAAG (Serum-Ascites Albumin Gradient) Calculator
                        </h3>
                        <span className="text-[10px] bg-teal-500/10 text-teal-400 font-mono font-bold px-2 py-0.5 rounded border border-teal-500/20">AUTOMATIC CALCULATION</span>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div>
                          <label className="text-[10px] font-bold text-slate-400 block mb-1">Serum Albumin (g/L)</label>
                          <input
                            type="number"
                            placeholder="e.g. 32"
                            value={hoSerumAlbumin}
                            onChange={(e) => setHoSerumAlbumin(e.target.value)}
                            className={`w-full p-2.5 rounded-xl border text-xs font-mono outline-none ${
                              isDarkMode ? "bg-slate-900 border-slate-800 text-white" : "bg-slate-50 border-slate-200 text-slate-900"
                            }`}
                          />
                        </div>
                        <div>
                          <label className="text-[10px] font-bold text-slate-400 block mb-1">Ascitic Fluid Albumin (g/L)</label>
                          <input
                            type="number"
                            placeholder="e.g. 15"
                            value={hoAscitesAlbumin}
                            onChange={(e) => setHoAscitesAlbumin(e.target.value)}
                            className={`w-full p-2.5 rounded-xl border text-xs font-mono outline-none ${
                              isDarkMode ? "bg-slate-900 border-slate-800 text-white" : "bg-slate-50 border-slate-200 text-slate-900"
                            }`}
                          />
                        </div>
                      </div>

                      {/* SAAG Result */}
                      {(() => {
                        const sAlb = parseFloat(hoSerumAlbumin);
                        const aAlb = parseFloat(hoAscitesAlbumin);

                        if (isNaN(sAlb) || isNaN(aAlb)) {
                          return (
                            <div className="p-3 text-center text-[11px] text-slate-500 bg-slate-950/20 rounded-xl border border-dashed border-slate-800">
                              Input Serum and Ascitic Albumin values to calculate the SAAG.
                            </div>
                          );
                        }

                        const saagVal = sAlb - aAlb;
                        const isHighSaag = saagVal >= 11;

                        return (
                          <div className={`p-4 rounded-xl border ${
                            isHighSaag
                              ? isDarkMode ? "bg-[#b45309]/10 border-[#b45309]/20" : "bg-amber-50 border-amber-200"
                              : isDarkMode ? "bg-rose-950/10 border-rose-500/20" : "bg-rose-50 border-rose-200"
                          } space-y-3`}>
                            <div className="flex justify-between items-center">
                              <span className="text-[10px] uppercase font-bold text-slate-500 tracking-wider font-mono">SAAG Gradient:</span>
                              <span className={`text-xs font-extrabold px-3 py-1 rounded-md uppercase ${
                                isHighSaag
                                  ? "bg-amber-500/20 text-amber-400 border border-amber-500/30"
                                  : "bg-rose-500/20 text-rose-400 border border-rose-500/30"
                              }`}>
                                {isHighSaag ? "HIGH GRADIENT (SAAG ≥ 11 g/L)" : "LOW GRADIENT (SAAG < 11 g/L)"}
                              </span>
                            </div>

                            <div className="text-center p-3 rounded-lg bg-slate-950/40 border border-slate-800 text-sm font-mono text-white">
                              Calculated SAAG = <strong className="text-teal-400 text-base">{saagVal.toFixed(1)}</strong> g/L
                            </div>

                            <p className="text-[11px] leading-relaxed text-slate-400">
                              {isHighSaag ? (
                                <span><strong>High SAAG Differential (Portal Hypertension present - 97% accuracy):</strong> Liver cirrhosis, alcoholic hepatitis, congestive heart failure/cardiac ascites, Budd-Chiari syndrome, portal vein thrombosis, mixed ascites.</span>
                              ) : (
                                <span><strong>Low SAAG Differential (No Portal Hypertension - related to peritoneal pathology):</strong> Peritoneal carcinomatosis, peritoneal tuberculosis, pancreatitis, biliary leak, nephrotic syndrome, serositis (SLE/autoimmune).</span>
                              )}
                            </p>
                          </div>
                        );
                      })()}
                    </div>
                  </div>
                )}

                {/* 3. CSF INTERACTIVE GUIDE */}
                {hoActiveGuide === "csf" && (
                  <div className="space-y-6">
                    {/* Clinical Overview Card */}
                    <div className={`p-4 sm:p-5 rounded-2xl border space-y-3 ${
                      isDarkMode ? "bg-[#111827] border-slate-800" : "bg-white border-slate-200 shadow-sm"
                    }`}>
                      <div className="flex items-center gap-2 text-rose-400 font-bold text-xs sm:text-sm uppercase tracking-wider">
                        <span>💡</span> Clinical Bedside Rule No. 3
                      </div>
                      <h3 className={`font-bold font-sans text-sm sm:text-base ${isDarkMode ? "text-slate-100" : "text-slate-900"}`}>
                        CSF Opening Pressure, Inspection & Serum Glucose
                      </h3>
                      <p className={`text-xs leading-relaxed ${isDarkMode ? "text-slate-300" : "text-slate-600"}`}>
                        Before collecting fluid, ensure you measure the **Opening Pressure** (normal: 80–200 mmH₂O) and visually inspect the sample (e.g. crystal clear, turbid, blood-stained, xanthochromic). Always pair with an immediate <strong className="text-rose-400">Random Blood Sugar (RBS)</strong> or blood glucose.
                      </p>
                      <div className={`p-3 rounded-xl border text-[11px] leading-relaxed ${isDarkMode ? "bg-slate-950/40 border-slate-800" : "bg-slate-50 border-slate-200"}`}>
                        <span className="font-bold text-amber-400 uppercase tracking-wider block mb-1">🧪 Critical Storage Rule:</span>
                        Do <strong className="text-rose-400">NOT</strong> refrigerate CSF samples for culture. Keep them at room temperature or send immediately. Standard bacteria like Neisseria meningitidis are extremely sensitive to cold temperatures and will die!
                      </div>
                    </div>

                    {/* CSF Glucose Ratio Calculator */}
                    <div className={`p-5 rounded-2xl border space-y-4 ${
                      isDarkMode ? "bg-[#111827] border-slate-800" : "bg-white border-slate-200 shadow-sm"
                    }`}>
                      <div className="flex justify-between items-center border-b border-slate-800/60 pb-3">
                        <h3 className={`text-sm sm:text-base font-bold flex items-center gap-2 ${isDarkMode ? "text-teal-400" : "text-teal-700"}`}>
                          <span>🧮</span> CSF/Serum Glucose Ratio Calculator
                        </h3>
                        <span className="text-[10px] bg-teal-500/10 text-teal-400 font-mono font-bold px-2 py-0.5 rounded border border-teal-500/20">AUTOMATIC CALCULATION</span>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div>
                          <label className="text-[10px] font-bold text-slate-400 block mb-1">CSF Glucose (mmol/L)</label>
                          <input
                            type="number"
                            placeholder="e.g. 1.8"
                            value={hoCsfGlucose}
                            onChange={(e) => setHoCsfGlucose(e.target.value)}
                            className={`w-full p-2.5 rounded-xl border text-xs font-mono outline-none ${
                              isDarkMode ? "bg-slate-900 border-slate-800 text-white" : "bg-slate-50 border-slate-200 text-slate-900"
                            }`}
                          />
                        </div>
                        <div>
                          <label className="text-[10px] font-bold text-slate-400 block mb-1">Random Blood Sugar (mmol/L)</label>
                          <input
                            type="number"
                            placeholder="e.g. 6.5"
                            value={hoRandomBloodSugar}
                            onChange={(e) => setHoRandomBloodSugar(e.target.value)}
                            className={`w-full p-2.5 rounded-xl border text-xs font-mono outline-none ${
                              isDarkMode ? "bg-slate-900 border-slate-800 text-white" : "bg-slate-50 border-slate-200 text-slate-900"
                            }`}
                          />
                        </div>
                      </div>

                      {/* CSF Glucose Ratio Result */}
                      {(() => {
                        const csfG = parseFloat(hoCsfGlucose);
                        const rbsVal = parseFloat(hoRandomBloodSugar);

                        if (isNaN(csfG) || isNaN(rbsVal)) {
                          return (
                            <div className="p-3 text-center text-[11px] text-slate-500 bg-slate-950/20 rounded-xl border border-dashed border-slate-800">
                              Input CSF Glucose and RBS values to calculate the ratio.
                            </div>
                          );
                        }

                        const ratio = csfG / rbsVal;
                        const isLowRatio = ratio < 0.4;

                        return (
                          <div className={`p-4 rounded-xl border ${
                            isLowRatio
                              ? isDarkMode ? "bg-rose-950/10 border-rose-500/20" : "bg-rose-50 border-rose-200"
                              : isDarkMode ? "bg-emerald-950/10 border-emerald-500/20" : "bg-emerald-50 border-emerald-200"
                          } space-y-3`}>
                            <div className="flex justify-between items-center">
                              <span className="text-[10px] uppercase font-bold text-slate-500 tracking-wider font-mono">CSF/Serum Ratio:</span>
                              <span className={`text-xs font-extrabold px-3 py-1 rounded-md uppercase ${
                                isLowRatio
                                  ? "bg-rose-500/20 text-rose-400 border border-rose-500/30"
                                  : "bg-emerald-500/20 text-emerald-400 border border-emerald-500/30"
                              }`}>
                                {isLowRatio ? "LOW RATIO (Ratio < 0.4)" : "NORMAL/ELEVATED RATIO"}
                              </span>
                            </div>

                            <div className="text-center p-3 rounded-lg bg-slate-950/40 border border-slate-800 text-sm font-mono text-white">
                              Calculated Ratio = <strong className="text-teal-400 text-base">{ratio.toFixed(2)}</strong>
                            </div>

                            <p className="text-[11px] leading-relaxed text-slate-400">
                              {isLowRatio ? (
                                <span><strong>Significant Glucose Depletion (Typical of Bacterial, Fungal or TB Meningitis):</strong> High cells, high protein (&gt;0.45 g/L), and low glucose indicates consumption of glucose by pathogens or leukocytes. Low ratio + neutrophilic predominance is pathognomonic for Acute Bacterial Meningitis.</span>
                              ) : (
                                <span><strong>Preserved Glucose Level (Typical of Viral Meningitis):</strong> Normal or slightly elevated protein, mononuclear/lymphocytic predominance, and normal CSF/Serum ratio (&gt;0.5) is the classic hallmark of viral meningitis/aseptic meningitis.</span>
                              )}
                            </p>
                          </div>
                        );
                      })()}
                    </div>
                  </div>
                )}

                {/* 4. BMA & TREPHINE GUIDE */}
                {hoActiveGuide === "bma" && (
                  <div className="space-y-6">
                    {/* Clinical Overview Card */}
                    <div className={`p-4 sm:p-5 rounded-2xl border space-y-3 ${
                      isDarkMode ? "bg-[#111827] border-slate-800" : "bg-white border-slate-200 shadow-sm"
                    }`}>
                      <div className="flex items-center gap-2 text-rose-400 font-bold text-xs sm:text-sm uppercase tracking-wider">
                        <span>💡</span> BM Aspirate & Trephine (BMAT) Protocol
                      </div>
                      <h3 className={`font-bold font-sans text-sm sm:text-base ${isDarkMode ? "text-slate-100" : "text-slate-900"}`}>
                        Critical Clinical Bottle Tracker
                      </h3>
                      <p className={`text-xs leading-relaxed ${isDarkMode ? "text-slate-300" : "text-slate-600"}`}>
                        Bone marrow collections are scarce, precious, and painful bedside procedures. Standardize your bottle preparation strictly to prevent missing clinical samples or invalidating the draw.
                      </p>

                      {/* BMA Bottle Inoculation Rules */}
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-[11px] pt-1">
                        <div className={`p-3 rounded-xl border ${isDarkMode ? "bg-slate-950/40 border-slate-800" : "bg-slate-50 border-slate-200"}`}>
                          <strong className="text-rose-400 block mb-1">🍄 Fungal & Acid-Fast Culture:</strong>
                          Inoculate BMA fungal C&S and Mycobacterium tuberculosis cultures in <strong className="text-amber-400">Fungal C&S Bottles (Myco/F Lytic blood culture bottle)</strong>. Never put fungal cultures into standard CSF sterile containers!
                        </div>
                        <div className={`p-3 rounded-xl border ${isDarkMode ? "bg-slate-950/40 border-slate-800" : "bg-slate-50 border-slate-200"}`}>
                          <strong className="text-rose-400 block mb-1">🧪 TB PCR (Marrow):</strong>
                          Unlike TB cultures, TB PCR on bone marrow must be sent in a <strong className="text-violet-400">CSF sterile container / sterile plain bottle</strong>, NOT in the culture bottles.
                        </div>
                      </div>

                      <div className={`p-3 rounded-xl border text-[11px] leading-relaxed ${isDarkMode ? "bg-slate-950/40 border-slate-800" : "bg-slate-50 border-slate-200"}`}>
                        <span className="font-bold text-amber-400 uppercase tracking-wider block mb-1">📞 Trephine TB GeneXpert Approval:</span>
                        For **Trephine TB Gene Xpert**, you <strong className="text-rose-400">must call the IPR (Institute of Respiratory Medicine) Respi team for approval</strong> before sending the specimen!
                      </div>
                    </div>

                    {/* Standard BMAT Workup Package */}
                    <div className={`p-5 rounded-2xl border space-y-4 ${
                      isDarkMode ? "bg-[#111827] border-slate-800" : "bg-white border-slate-200 shadow-sm"
                    }`}>
                      <h3 className={`text-sm sm:text-base font-bold flex items-center gap-2 ${isDarkMode ? "text-teal-400" : "text-teal-700"}`}>
                        <span>🔬</span> Standard Bone Marrow Workup Road Map (BMAT)
                      </h3>
                      <div className="space-y-2.5 text-xs text-left">
                        <div className="flex gap-2.5 items-start">
                          <span className="text-teal-400 font-mono font-bold">1. Blood FBP:</span>
                          <p className={isDarkMode ? "text-slate-300" : "text-slate-700"}>Ensure a matching Full Blood Picture (FBP) is sent alongside BMA to allow immediate clinical correlation by the hematopathologist.</p>
                        </div>
                        <div className="flex gap-2.5 items-start border-t border-slate-800/40 pt-2">
                          <span className="text-teal-400 font-mono font-bold">2. BMA Smear:</span>
                          <p className={isDarkMode ? "text-slate-300" : "text-slate-700"}>Bedside preparation of thin BMA smears on clean glass slides. Must be dry-fixed immediately to preserve cytological morphology.</p>
                        </div>
                        <div className="flex gap-2.5 items-start border-t border-slate-800/40 pt-2">
                          <span className="text-teal-400 font-mono font-bold">3. Molecular:</span>
                          <p className={isDarkMode ? "text-slate-300" : "text-slate-700"}>Molecular studies (e.g. BCR-ABL, JAK2 mutation, CALR). Sent in Purple (EDTA) or Yellow (SST) tube depending on local pathology directions.</p>
                        </div>
                        <div className="flex gap-2.5 items-start border-t border-slate-800/40 pt-2">
                          <span className="text-teal-400 font-mono font-bold">4. Flow Cytometry:</span>
                          <p className={isDarkMode ? "text-slate-300" : "text-slate-700"}>BMA Immunophenotyping (usually sent in EDTA or heparinized tube, kept room temperature, sent rapidly to capture viable leukocytes).</p>
                        </div>
                        <div className="flex gap-2.5 items-start border-t border-slate-800/40 pt-2">
                          <span className="text-teal-400 font-mono font-bold">5. Cytogenetics:</span>
                          <p className={isDarkMode ? "text-slate-300" : "text-slate-700"}>Karyotyping & FISH (BMA cytogenetics must be inoculated directly into specialized **sodium heparin** tube to keep cells alive for chromosome analysis).</p>
                        </div>
                        <div className="flex gap-2.5 items-start border-t border-slate-800/40 pt-2">
                          <span className="text-teal-400 font-mono font-bold">6. Trephine:</span>
                          <p className={isDarkMode ? "text-slate-300" : "text-slate-700"}>Trephine biopsy tissue specimen. Must be placed immediately into **10% Formalin bottle** for histopathology and immunohistochemical staining.</p>
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                {/* 5. HEMOLYTIC ANEMIA CODES */}
                {hoActiveGuide === "hemolytic" && (
                  <div className="space-y-6">
                    {/* Clinical Overview Card */}
                    <div className={`p-4 sm:p-5 rounded-2xl border space-y-3 ${
                      isDarkMode ? "bg-[#111827] border-slate-800" : "bg-white border-slate-200 shadow-sm"
                    }`}>
                      <div className="flex items-center gap-2 text-rose-400 font-bold text-xs sm:text-sm uppercase tracking-wider">
                        <span>💡</span> Suspected Hemolytic Anemia Protocol
                      </div>
                      <h3 className={`font-bold font-sans text-sm sm:text-base ${isDarkMode ? "text-slate-100" : "text-slate-900"}`}>
                        Hemolysis Screen & Blood Film Importance
                      </h3>
                      <p className={`text-xs leading-relaxed ${isDarkMode ? "text-slate-300" : "text-slate-600"}`}>
                        Hemolysis must be suspected when there is a sudden drop in hemoglobin (Hb) paired with jaundice, dark urine, or splenomegaly. Workup must establish both **evidence of hemolysis** (LDH, unconjugated bilirubin, reticulocytes) and **etiology** (Direct/Indirect Coombs, peripheral blood film).
                      </p>
                    </div>

                    {/* Investigation Rationale Map */}
                    <div className={`p-5 rounded-2xl border space-y-4 ${
                      isDarkMode ? "bg-[#111827] border-slate-800" : "bg-white border-slate-200 shadow-sm"
                    }`}>
                      <h3 className={`text-sm sm:text-base font-bold flex items-center gap-2 ${isDarkMode ? "text-teal-400" : "text-teal-700"}`}>
                        <span>🩸</span> Hemolysis Screening Rationale
                      </h3>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                        <div className={`p-3 rounded-xl border ${isDarkMode ? "bg-slate-950/40 border-slate-800" : "bg-slate-50 border-slate-200"}`}>
                          <strong className="text-teal-400 block mb-1">📈 Reticulocyte Count (with FBC):</strong>
                          Evaluates bone marrow erythropoietic response. High reticulocytes indicate hyperactive marrow compensation for RBC destruction.
                        </div>
                        <div className={`p-3 rounded-xl border ${isDarkMode ? "bg-slate-950/40 border-slate-800" : "bg-slate-50 border-slate-200"}`}>
                          <strong className="text-teal-400 block mb-1">🧪 TSB (Direct & Indirect Bilirubin):</strong>
                          RBC rupture spills hemoglobin, which is metabolized into **indirect/unconjugated bilirubin**. High indirect fraction is hallmark!
                        </div>
                        <div className={`p-3 rounded-xl border ${isDarkMode ? "bg-slate-950/40 border-slate-800" : "bg-slate-50 border-slate-200"}`}>
                          <strong className="text-teal-400 block mb-1">⚡ Lactate Dehydrogenase (LDH):</strong>
                          LDH is abundant inside RBCs. Destructive hemolysis triggers marked serum LDH elevations, serving as a reliable severity index.
                        </div>
                        <div className={`p-3 rounded-xl border ${isDarkMode ? "bg-slate-950/40 border-slate-800" : "bg-slate-50 border-slate-200"}`}>
                          <strong className="text-teal-400 block mb-1">🛡️ Coombs Test (Direct & Indirect):</strong>
                          Differentiates immune-mediated hemolytic anemia (e.g., Warm/Cold AIHA, Drug-induced) from microangiopathic or hereditary causes.
                        </div>
                        <div className={`p-3 rounded-xl border ${isDarkMode ? "bg-slate-950/40 border-slate-800" : "bg-slate-50 border-slate-200"}`}>
                          <strong className="text-teal-400 block mb-1">🔍 UFEME (Urobilinogen):</strong>
                          Urinary urobilinogen is increased due to high bilirubin turnover. Hemoglobinuria can occur in intravascular hemolysis.
                        </div>
                        <div className={`p-3 rounded-xl border ${isDarkMode ? "bg-slate-950/40 border-slate-800" : "bg-slate-50 border-slate-200"}`}>
                          <strong className="text-teal-400 block mb-1">🔬 Peripheral Blood Film (PBF):</strong>
                          Crucial! Identifies **Schistocytes** (microangiopathic hemolysis e.g. TTP/HUS/DIC), **Spherocytes** (hereditary or autoimmune), or **Bite cells** (G6PD deficiency).
                        </div>
                      </div>
                    </div>
                  </div>
                )}

              </div>

              {/* Right Column: Interactive Bedside checklist & Tube Cap Matching Guide (5 cols) */}
              <div className="xl:col-span-5 space-y-6">
                {/* Checklist Panel */}
                <div className={`p-4 sm:p-5 rounded-2xl border ${
                  isDarkMode ? "bg-[#111827] border-slate-800" : "bg-white border-slate-200 shadow-sm"
                }`}>
                  <div className="flex justify-between items-center mb-3">
                    <h3 className="font-bold text-xs sm:text-sm uppercase tracking-wider text-rose-400 flex items-center gap-1.5">
                      <span>📝</span> Ward Checklist & Bottle Guide
                    </h3>
                    <span className="text-[10px] font-mono text-slate-500 font-bold">BEDSIDE TRACKER</span>
                  </div>

                  {/* Checklist progress bar */}
                  {(() => {
                    // Filter checklist items for the active guide
                    const getActiveChecklistItems = () => {
                      if (hoActiveGuide === "pleural") {
                        return [
                          { id: "pf_biochem", test: "Pleural Biochem (Alb, Prot, Glu, LDH, Chol, Amylase, pH)", container: "SST (Yellow) & Heparinised Syringe" },
                          { id: "pf_feme", test: "Pleural Fluid FEME (Cell count/differential)", container: "EDTA (Purple)" },
                          { id: "pf_gram", test: "Pleural Gram Stain", container: "Sterile Plain Container" },
                          { id: "pf_cyt", test: "Pleural Cytology", container: "Sterile Plain Container" },
                          { id: "pf_cs", test: "Pleural Culture & Sensitivity", container: "Sterile Container / Inoculate Directly" },
                          { id: "pf_afb", test: "Pleural AFB (acid-fast bacilli smear)", container: "Sterile Plain Container" },
                          { id: "pf_tbpcr", test: "Pleural TB PCR", container: "Sterile Plain Container" },
                          { id: "pf_mtbcns", test: "Pleural MTB Culture n Sensitivity", container: "Sterile Plain Container" },
                          { id: "pf_tg", test: "Pleural Triglycerides & Cholesterol", container: "SST (Yellow)" },
                          { id: "pf_bloods", test: "SENT BLOODS: Glucose, Protein, Albumin, LDH (for Light's)", container: "SST (Yellow) & Fluoride (Grey)" }
                        ];
                      } else if (hoActiveGuide === "ascites") {
                        return [
                          { id: "as_app", test: "Ascites physical appearance record", container: "Bedside Record" },
                          { id: "as_feme", test: "FEME, cell count & differentials", container: "EDTA (Purple)" },
                          { id: "as_gram", test: "Ascites Gram Stain", container: "Sterile Plain Container" },
                          { id: "as_biochem", test: "Biochemistry (Alb, Prot, LDH, Amylase, TG, Bilirubin)", container: "SST (Yellow)" },
                          { id: "as_cs", test: "Culture & Sensitivity (direct bottle inoculation)", container: "Blood Culture Bottles" },
                          { id: "as_cyt", test: "Ascites Cytology", container: "Sterile Plain Container" },
                          { id: "as_mtbcns", test: "Ascites MTB Culture & Sensitivity", container: "Sterile Plain Container" },
                          { id: "as_afb", test: "Ascites AFB Smear", container: "Sterile Plain Container" },
                          { id: "as_tbpcr", test: "Ascites TB PCR", container: "Sterile Plain Container" },
                          { id: "as_cea", test: "Ascites CEA marker", container: "SST (Yellow)" },
                          { id: "as_bloods", test: "SENT BLOODS: Serum Albumin (for SAAG)", container: "SST (Yellow)" }
                        ];
                      } else if (hoActiveGuide === "csf") {
                        return [
                          { id: "csf_press", test: "Opening/Closing Pressure, appearance observation", container: "Bedside Record" },
                          { id: "csf_biochem", test: "Biochemistry (Protein & Glucose)", container: "Fluoride (Grey) & Plain Tube" },
                          { id: "csf_feme", test: "FEME (Appearance, cell count, LAT, Gram, Indian Ink)", container: "Plain Container / Tube 1" },
                          { id: "csf_cyt", test: "CSF Cytology", container: "Plain Container" },
                          { id: "csf_cs", test: "CSF Culture and Sensitivity", container: "Plain Container / Tube 2 (Room Temp)" },
                          { id: "csf_mtbcns", test: "CSF MTB Culture and Sensitivity", container: "Plain Container" },
                          { id: "csf_vir", test: "CSF Virology (HSV 1 & 2, VZV)", container: "Plain Container / PCR Tube" },
                          { id: "csf_tbpcr", test: "CSF TB PCR", container: "Plain Container" },
                          { id: "csf_aqp", test: "CSF & Serum Aquaporin-4 (AQP4) Abs", container: "SST (Yellow) & Plain CSF Container" },
                          { id: "csf_ocb", test: "CSF & Serum Oligoclonal Bands (OCB)", container: "SST (Yellow) & Plain CSF Container" },
                          { id: "csf_bacag", test: "CSF Bacterial Antigen (Latex Agglutination)", container: "Plain Container" },
                          { id: "csf_crypto", test: "CSF Cryptococcal Antigen & Indian Ink", container: "Plain Container" },
                          { id: "csf_fungal", test: "CSF Fungal Culture and Sensitivity", container: "Plain Container" },
                          { id: "csf_vdrl", test: "CSF VDRL (Syphilis test)", container: "Plain Container" },
                          { id: "csf_cmv", test: "CSF CMV PCR", container: "Plain Container" },
                          { id: "csf_vzv", test: "CSF Varicella Zoster PCR", container: "Plain Container" },
                          { id: "csf_hsv", test: "CSF Herpes Simplex PCR", container: "Plain Container" },
                          { id: "csf_bloods", test: "SENT BLOODS: Random Blood Sugar (RBS)", container: "Fluoride (Grey)" }
                        ];
                      } else if (hoActiveGuide === "bma") {
                        return [
                          { id: "bma_fung", test: "Fungal C&S from marrow in fungal CNS bottle", container: "Myco/F Lytic Bottle" },
                          { id: "bma_myco", test: "Mycobacterium culture from marrow", container: "Myco/F Lytic Bottle" },
                          { id: "bma_bcs", test: "Marrow Culture and Sensitivity (Aerobic & Anaerobic)", container: "Blood Culture Bottles" },
                          { id: "bma_tbpcr", test: "TB PCR (marrow) in CSF bottle", container: "Plain Sterile Tube" },
                          { id: "bma_tbcns", test: "BMA TB C&S - Conventional", container: "Plain Sterile Tube / Lowenstein" },
                          { id: "bma_tbbact", test: "BMA TB Culture (BACTEC)", container: "Myco/F Lytic Bottle" },
                          { id: "bma_genex", test: "Trephine TB Gene Xpert (IPR Respi approved!)", container: "Sterile container (with approval)" },
                          { id: "bma_fbp", test: "BLOODS: Full Blood Picture (FBP)", container: "EDTA (Purple)" },
                          { id: "bma_smear", test: "BMA Smear Slides", container: "Dry Smears on glass slides" },
                          { id: "bma_mole", test: "BMA Molecular Studies", container: "EDTA (Purple)" },
                          { id: "bma_flow", test: "BMA Immunophenotyping (Flow cytometry)", container: "EDTA (Purple) / Heparin" },
                          { id: "bma_cyto", test: "BMA Cytogenetics (Karyotyping / FISH)", container: "Sodium Heparin" },
                          { id: "bma_treph", test: "Trephine Biopsy", container: "10% Formalin Bottle" }
                        ];
                      } else {
                        return [
                          { id: "ha_fbc", test: "FBC with Reticulocyte count", container: "EDTA (Purple)" },
                          { id: "ha_tsb", test: "TSB Direct & Indirect Bilirubin", container: "SST (Yellow)" },
                          { id: "ha_ldh", test: "Lactate Dehydrogenase (LDH)", container: "SST (Yellow)" },
                          { id: "ha_coombs", test: "Coombs Test (Direct & Indirect)", container: "EDTA (Purple) & SST" },
                          { id: "ha_ufeme", test: "UFEME (look for urobilinogen / dark urine)", container: "Urine Container" },
                          { id: "ha_pbf", test: "Peripheral Blood Film (PBF) for Schistocytes/Spherocytes", container: "EDTA (Purple) or Bedside Slides" }
                        ];
                      }
                    };

                    const items = getActiveChecklistItems();
                    const checkedCount = items.filter(item => hoChecklist[item.id]).length;
                    const percent = Math.round((checkedCount / items.length) * 100) || 0;

                    return (
                      <div className="space-y-4">
                        {/* Progress meter */}
                        <div className="space-y-1.5">
                          <div className="flex justify-between items-center text-[10px] font-bold font-mono">
                            <span className={isDarkMode ? "text-slate-400" : "text-slate-500"}>SAMPLING COMPLETION STATUS:</span>
                            <span className={isDarkMode ? "text-teal-400" : "text-teal-700"}>{checkedCount} / {items.length} ({percent}%)</span>
                          </div>
                          <div className={`w-full h-2 rounded-full overflow-hidden ${isDarkMode ? "bg-slate-950" : "bg-slate-100"}`}>
                            <div 
                              className="h-full bg-teal-50 rounded-full transition-all duration-300"
                              style={{ width: `${percent}%` }}
                            ></div>
                          </div>
                        </div>

                        {/* Checklist items */}
                        <div className="space-y-2 max-h-[380px] overflow-y-auto pr-1 scrollbar-thin">
                          {items.map((item) => {
                            const isChecked = hoChecklist[item.id] || false;
                            return (
                              <div
                                key={item.id}
                                onClick={() => setHoChecklist(prev => ({ ...prev, [item.id]: !isChecked }))}
                                className={`flex items-start gap-2.5 p-2.5 rounded-xl border transition-all cursor-pointer ${
                                  isChecked
                                    ? isDarkMode 
                                      ? "bg-teal-500/5 border-teal-500/20 text-slate-300" 
                                      : "bg-teal-50/50 border-teal-200 text-slate-800"
                                    : isDarkMode
                                      ? "bg-[#111827] border-slate-800 hover:border-slate-700 text-slate-400"
                                      : "bg-white border-slate-200 hover:border-slate-300 text-slate-700 shadow-sm"
                                }`}
                              >
                                <div className={`w-4.5 h-4.5 rounded border flex items-center justify-center flex-shrink-0 transition-colors mt-0.5 ${
                                  isChecked
                                    ? "bg-teal-500 border-teal-500 text-slate-950"
                                    : isDarkMode 
                                      ? "border-slate-700 bg-slate-950" 
                                      : "border-slate-300 bg-slate-50"
                                }`}>
                                  {isChecked && <span className="text-[10px] font-black">✓</span>}
                                </div>
                                <div className="text-[11px] leading-tight flex-1">
                                  <div className={`font-semibold ${isChecked ? (isDarkMode ? "text-slate-100" : "text-slate-900") : ""}`}>
                                    {item.test}
                                  </div>
                                  <div className={`text-[9px] font-mono mt-0.5 ${isDarkMode ? "text-teal-400" : "text-teal-700"}`}>
                                    Container: {item.container}
                                  </div>
                                </div>
                              </div>
                            );
                          })}
                        </div>

                        {/* Copy To Clipboard Clinical Summary */}
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            const summaryText = `--- WARDSAMPLING SUMMARY [${hoActiveGuide.toUpperCase()}] ---\n` +
                              items.map(i => `${hoChecklist[i.id] ? "[✓]" : "[ ]"} ${i.test} -> Container: ${i.container}`).join("\n") +
                              `\nGenerated via Dr FH Liew Clinical Assistant`;
                            handleCopy(summaryText, `ho-guide-${hoActiveGuide}`);
                          }}
                          className={`w-full py-2.5 rounded-xl font-bold uppercase text-[10px] transition-all border flex items-center justify-center gap-2 cursor-pointer ${
                            copyFeedback === `ho-guide-${hoActiveGuide}`
                              ? "bg-emerald-500/10 text-emerald-400 border-emerald-500/30 font-extrabold"
                              : isDarkMode 
                                ? "bg-slate-900 border-slate-800 text-slate-300 hover:bg-slate-800" 
                                : "bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100 shadow-sm"
                          }`}
                        >
                          {copyFeedback === `ho-guide-${hoActiveGuide}` ? "Summary Copied! ✓" : "Copy Ward Summary"}
                        </button>
                      </div>
                    );
                  })()}
                </div>
              </div>

            </div>
          </div>
        )}


        {/* TAB: BEDSIDE CALCULATORS (Active Tab) */}
        {activeTab === "calc" && (() => {
          // Calculate active infusion values on render to prevent infinite loop updates
          const weight = parseFloat(infWeight) || 70;
          let defaultConc = 80; // mcg/ml or units/ml
          let unit: "mcg/kg/min" | "mcg/min" | "units/hr" | "mg/hr" = "mcg/kg/min";
          let drugName = "Noradrenaline";
          let preparationText = "";
          let standardDoses = [0.05, 0.1, 0.25, 0.5];
          let clinicalNotes = "";

          if (infDrug === "noradrenaline") {
            unit = "mcg/kg/min";
            drugName = "Noradrenaline";
            standardDoses = [0.05, 0.1, 0.2, 0.5, 0.8];
            clinicalNotes = "First-line vasopressor for septic shock. Standard target Mean Arterial Pressure (MAP) is ≥65 mmHg. Always administer via a central venous catheter. Monitor infusion site closely for extravasation (consider phentolamine if occurs). Avoid abrupt cessation.";
            if (infPrep === "single") {
              defaultConc = 80; // 4mg in 50ml
              preparationText = "Dilute 4mg (1 ampoule) Noradrenaline in 46ml D5% (Total 50ml)";
            } else if (infPrep === "double") {
              defaultConc = 160; // 8mg in 50ml
              preparationText = "Dilute 8mg (2 ampoules) Noradrenaline in 42ml D5% (Total 50ml)";
            } else {
              defaultConc = parseFloat(infCustomConc) || 80;
              preparationText = `Custom Preparation: Concentration ${defaultConc} mcg/mL`;
            }
          } else if (infDrug === "adrenaline") {
            unit = "mcg/kg/min";
            drugName = "Adrenaline";
            standardDoses = [0.05, 0.1, 0.2, 0.5, 1.0];
            clinicalNotes = "Primary agent for anaphylaxis and cardiac arrest. Used as second-line add-on in refractory septic shock. Highly arrhythmogenic; watch for severe tachycardia, peripheral ischemia, and transient lactic acidosis.";
            if (infPrep === "single") {
              defaultConc = 60; // 3mg in 50ml
              preparationText = "Dilute 3mg (3 ampoules) Adrenaline in 47ml NS or D5% (Total 50ml)";
            } else if (infPrep === "double") {
              defaultConc = 120; // 6mg in 50ml
              preparationText = "Dilute 6mg (6 ampoules) Adrenaline in 44ml NS or D5% (Total 50ml)";
            } else {
              defaultConc = parseFloat(infCustomConc) || 60;
              preparationText = `Custom Preparation: Concentration ${defaultConc} mcg/mL`;
            }
          } else if (infDrug === "dopamine") {
            unit = "mcg/kg/min";
            drugName = "Dopamine";
            standardDoses = [2.5, 5.0, 10.0, 15.0, 20.0];
            clinicalNotes = "Beta-adrenergic inotrope that increases cardiac contractility. Highly arrhythmogenic. Mostly superseded by Noradrenaline and Dobutamine at the bedside. Run via central venous catheter.";
            if (infPrep === "single") {
              defaultConc = 4000; // 200mg in 50ml
              preparationText = "Dilute 200mg (1 ampoule) Dopamine in 45ml NS or D5% (Total 50ml)";
            } else if (infPrep === "double") {
              defaultConc = 8000; // 400mg in 50ml
              preparationText = "Dilute 400mg (2 ampoules) Dopamine in 40ml NS or D5% (Total 50ml)";
            } else {
              defaultConc = parseFloat(infCustomConc) || 4000;
              preparationText = `Custom Preparation: Concentration ${defaultConc} mcg/mL`;
            }
          } else if (infDrug === "dobutamine") {
            unit = "mcg/kg/min";
            drugName = "Dobutamine";
            standardDoses = [2.5, 5.0, 10.0, 15.0, 20.0];
            clinicalNotes = "First-line inotrope for cardiogenic shock and severe acute decompensated heart failure. Enhances myocardial contractility and stroke volume. May cause systemic vasodilation (mild hypotension) and tachyarrhythmias.";
            if (infPrep === "single") {
              defaultConc = 5000; // 250mg in 50ml
              preparationText = "Dilute 250mg (1 vial) Dobutamine in 30ml NS or D5% (Total 50ml)";
            } else if (infPrep === "double") {
              defaultConc = 10000; // 500mg in 50ml
              preparationText = "Dilute 500mg (2 vials) Dobutamine in 10ml NS or D5% (Total 50ml)";
            } else {
              defaultConc = parseFloat(infCustomConc) || 5000;
              preparationText = `Custom Preparation: Concentration ${defaultConc} mcg/mL`;
            }
          } else if (infDrug === "insulin") {
            unit = "units/hr";
            drugName = "Actrapid Insulin";
            defaultConc = 1; // 50 units in 50ml
            standardDoses = [0.5, 1.0, 2.0, 4.0, 6.0, 8.0];
            clinicalNotes = "Standard protocol for DKA, HHS, and severe hyperglycemia. Run via dedicated line. Monitor capillary blood glucose every 1-2 hours. Ensure serum potassium is >3.3 mmol/L before commencing insulin infusion.";
            preparationText = "Draw 50 units (0.5ml of 100 U/ml) Actrapid Insulin and dilute with 49.5ml NS (Total 50ml; Concentration 1 unit/ml)";
          } else if (infDrug === "heparin") {
            unit = "units/hr";
            drugName = "Unfractionated Heparin";
            defaultConc = 500; // 25,000 units in 50ml
            standardDoses = [500, 800, 1000, 1250, 1500, 1800];
            clinicalNotes = "Anticoagulation for ACS, PE, acute DVT, or arterial emboli. Requires baseline APTT/PT/INR. Typically adjusted dynamically based on sliding-scale aPTT protocols (checked every 6 hours). Watch for Heparin-Induced Thrombocytopenia (HIT).";
            preparationText = "Dilute 25,000 units Unfractionated Heparin (5ml) with 45ml NS or D5% (Total 50ml; Concentration 500 units/ml)";
          } else {
            unit = infCustomUnit;
            drugName = "Custom Infusion";
            defaultConc = parseFloat(infCustomConc) || 1;
            standardDoses = unit.includes("mcg/kg") ? [0.05, 0.1, 0.25, 0.5, 1.0] : [1, 2, 5, 10, 20];
            clinicalNotes = "Custom medication profile. Always perform dual independent clinician verification of concentrations, dosage units, and pump flow rates at the bedside before starting infusion.";
            preparationText = `Custom Infusion Setup: Concentration ${defaultConc} units/mL`;
          }

          // Dose to Rate calculation
          const targetDoseNum = parseFloat(infTargetDose) || 0;
          let calcRate = 0;
          if (unit === "mcg/kg/min") {
            calcRate = (targetDoseNum * weight * 60) / defaultConc;
          } else if (unit === "mcg/min") {
            calcRate = (targetDoseNum * 60) / defaultConc;
          } else if (unit === "units/hr" || unit === "mg/hr") {
            calcRate = targetDoseNum / defaultConc;
          }

          // Rate to Dose calculation
          const mlPerHourNum = parseFloat(infMlPerHour) || 0;
          let calcDose = 0;
          if (unit === "mcg/kg/min") {
            calcDose = (mlPerHourNum * defaultConc) / (weight * 60);
          } else if (unit === "mcg/min") {
            calcDose = (mlPerHourNum * defaultConc) / 60;
          } else if (unit === "units/hr" || unit === "mg/hr") {
            calcDose = mlPerHourNum * defaultConc;
          }

          const inf = {
            weight,
            concentration: defaultConc,
            unit,
            drugName,
            preparationText,
            standardDoses,
            clinicalNotes,
            calculatedRate: parseFloat(calcRate.toFixed(2)),
            calculatedDose: parseFloat(calcDose.toFixed(3)),
          };

          return (
            <div className="space-y-6 animate-fade-in">
              {/* Header */}
              <div className="px-1 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                <div>
                  <h2 className={`text-lg sm:text-xl font-bold font-sans ${isDarkMode ? "text-teal-400" : "text-teal-700"} flex items-center gap-2`}>
                    <span>🧮</span> Clinical Calculators & Infusions
                  </h2>
                  <p className={`text-[10px] sm:text-xs ${isDarkMode ? "text-slate-400" : "text-slate-700"} mt-0.5`}>
                    Validated calculators for renal clearance, calcium adjustment, and active drug infusion pump rates.
                  </p>
                </div>
                
                {/* SUB-TAB TOGGLES */}
                <div className="flex bg-slate-900/60 border border-slate-800 p-1 rounded-xl self-start sm:self-center">
                  <button
                    onClick={() => setCalcSubTab("standard")}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 ${
                      calcSubTab === "standard"
                        ? "bg-teal-500 text-slate-950 shadow-md"
                        : "text-slate-400 hover:text-slate-200"
                    }`}
                  >
                    📊 Standard
                  </button>
                  <button
                    onClick={() => setCalcSubTab("infusion")}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 ${
                      calcSubTab === "infusion"
                        ? "bg-teal-500 text-slate-950 shadow-md"
                        : "text-slate-400 hover:text-slate-200"
                    }`}
                    id="btn-subtab-infusion"
                  >
                    💉 Infusion Converter
                  </button>
                </div>
              </div>

              {/* SECTION A: STANDARD BEDSIDE CALCULATORS */}
              {calcSubTab === "standard" && (
                <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4 sm:gap-6">
                  {/* Maintenance Fluid Calculator */}
                  <div className={`p-5 rounded-xl border ${
                    isDarkMode ? "bg-[#111827] border-slate-800" : "bg-white border-slate-200 shadow-sm"
                  }`}>
                    <div className="flex items-center gap-2.5 mb-4">
                      <div className={`p-2 rounded bg-sky-500/10 ${isDarkMode ? "text-sky-400" : "text-sky-700"}`}>
                        <Droplet className="h-4.5 w-4.5" />
                      </div>
                      <h3 className={`font-bold text-sm ${isDarkMode ? "text-slate-200" : "text-slate-800"}`}>Maintenance Fluids</h3>
                    </div>
                    
                    <div className="space-y-4">
                      <div>
                        <label className={`text-[11px] font-semibold ${isDarkMode ? "text-slate-400" : "text-slate-700"} block mb-1`}>Patient Weight (kg)</label>
                        <div className="flex gap-2">
                          <input 
                            type="number" 
                            value={fluidWeight}
                            onChange={e => setFluidWeight(e.target.value)}
                            className={`flex-1 p-2.5 rounded-lg text-sm border outline-none transition-all ${
                              isDarkMode 
                                ? "bg-slate-900/50 border-slate-700 focus:border-sky-500/50 text-slate-200" 
                                : "bg-white border-slate-300 focus:border-sky-500 text-slate-800 shadow-sm"
                            }`}
                            placeholder="e.g. 70"
                          />
                        </div>
                        <div className="flex gap-1.5 mt-2 flex-wrap">
                          {[10, 20, 50, 70, 85].map(v => (
                            <button key={v} type="button" onClick={() => { setFluidWeight(v.toString()); setFluidResult(null); }} className={`px-1.5 py-0.5 rounded text-[10px] ${isDarkMode ? "bg-slate-800 text-slate-300 hover:bg-slate-700" : "bg-slate-100 text-slate-800 hover:bg-slate-200"} font-mono`}>{v}kg</button>
                          ))}
                        </div>
                      </div>

                      <button 
                        onClick={calculateFluid}
                        className="w-full py-2.5 rounded-lg bg-sky-600 hover:bg-sky-500 text-white text-xs font-bold transition-colors uppercase tracking-wider shadow-md"
                      >
                        Calculate 4-2-1
                      </button>

                      {fluidResult !== null && (
                        <div className="p-3 rounded-lg bg-sky-500/10 border border-sky-500/20 text-center animate-fade-in">
                          <span className={`text-[10px] uppercase tracking-wider font-bold ${isDarkMode ? "text-sky-400" : "text-sky-700"} block mb-0.5`}>Maintenance Rate</span>
                          <div className="flex items-baseline justify-center gap-1">
                            <span className={`text-xl font-bold ${isDarkMode ? "text-slate-100" : "text-slate-900"} font-mono`}>{fluidResult}</span>
                            <span className={`text-xs ${isDarkMode ? "text-slate-400" : "text-slate-500"} font-mono`}>mL/hr</span>
                          </div>
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Cockcroft-Gault Calculator */}
                  <div className={`p-4 sm:p-5 rounded-xl border flex flex-col justify-between ${
                    isDarkMode ? "bg-[#111827] border-slate-800" : "bg-white border-slate-200 shadow-sm"
                  }`}>
                    <div>
                      <div className="flex items-center gap-2.5 mb-4">
                        <div className={`p-2 rounded bg-teal-500/10 ${isDarkMode ? "text-teal-400" : "text-teal-700"}`}>
                          <Calculator className="h-4.5 w-4.5" />
                        </div>
                        <div>
                          <h3 className={`font-bold text-sm ${isDarkMode ? "text-slate-200" : "text-slate-700"}`}>Cockcroft-Gault CrCl</h3>
                          <p className={`text-[10px] ${isDarkMode ? "text-slate-400" : "text-slate-700"}`}>Renal Clearance Estimation</p>
                        </div>
                      </div>

                      <div className="space-y-3.5 text-xs text-left">
                        <div>
                          <label className={`text-[11px] font-semibold ${isDarkMode ? "text-slate-400" : "text-slate-700"} block mb-1`}>Age (years)</label>
                          <input 
                            type="number" 
                            value={cgAge} 
                            onChange={(e) => { setCgAge(e.target.value); setCgResult(null); }}
                            placeholder="e.g. 65" 
                            className={`w-full p-2.5 rounded-lg border bg-slate-900 border-slate-800 text-white`}
                          />
                          <div className="flex gap-1 mt-1 flex-wrap">
                            {["45", "65", "80"].map(v => (
                              <button key={v} type="button" onClick={() => { setCgAge(v); setCgResult(null); }} className={`px-1.5 py-0.5 rounded text-[10px] ${isDarkMode ? "bg-slate-800 text-slate-300 hover:bg-slate-700" : "bg-slate-100 text-slate-800 hover:bg-slate-200"} font-mono`} id={`cg-age-preset-${v}`}>{v}y</button>
                            ))}
                          </div>
                        </div>

                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                          <div>
                            <label className={`text-[11px] font-semibold ${isDarkMode ? "text-slate-400" : "text-slate-700"} block mb-1`}>Weight (kg)</label>
                            <input 
                              type="number" 
                              value={cgWeight} 
                              onChange={(e) => { setCgWeight(e.target.value); setCgResult(null); }}
                              placeholder="e.g. 70" 
                              className={`w-full p-2.5 rounded-lg border bg-slate-900 border-slate-800 text-white`}
                            />
                          </div>
                          <div>
                            <label className={`text-[11px] font-semibold ${isDarkMode ? "text-slate-400" : "text-slate-700"} block mb-1`}>Height (cm) <span className="text-slate-600 font-normal">(opt)</span></label>
                            <input 
                              type="number" 
                              value={cgHeight} 
                              onChange={(e) => { setCgHeight(e.target.value); setCgResult(null); }}
                              placeholder="e.g. 170" 
                              className={`w-full p-2.5 rounded-lg border bg-slate-900 border-slate-800 text-white`}
                            />
                          </div>
                        </div>

                        <div>
                          <label className={`text-[11px] font-semibold ${isDarkMode ? "text-slate-400" : "text-slate-700"} block mb-1`}>Serum Creatinine (µmol/L)</label>
                          <input 
                            type="number" 
                            value={cgCreatinine} 
                            onChange={(e) => { setCgCreatinine(e.target.value); setCgResult(null); }}
                            placeholder="e.g. 110" 
                            className={`w-full p-2.5 rounded-lg border bg-slate-900 border-slate-800 text-white`}
                          />
                          <div className="flex gap-1 mt-1 flex-wrap">
                            {["80", "120", "200"].map(v => (
                              <button key={v} type="button" onClick={() => { setCgCreatinine(v); setCgResult(null); }} className={`px-1.5 py-0.5 rounded text-[10px] ${isDarkMode ? "bg-slate-800 text-slate-300 hover:bg-slate-700" : "bg-slate-100 text-slate-800 hover:bg-slate-200"} font-mono`} id={`cg-scr-preset-${v}`}>{v}</button>
                            ))}
                          </div>
                        </div>

                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                          <div>
                            <label className={`text-[11px] font-semibold ${isDarkMode ? "text-slate-400" : "text-slate-700"} block mb-1`}>Sex</label>
                            <select 
                              value={cgSex} 
                              onChange={(e) => { setCgSex(e.target.value as "male" | "female"); setCgResult(null); }}
                              className={`w-full p-2.5 rounded-lg border bg-slate-900 border-slate-800 text-white`}
                            >
                              <option value="male">Male</option>
                              <option value="female">Female</option>
                            </select>
                          </div>

                          {cgCalculatedWeights && (
                            <div>
                              <label className={`text-[11px] font-semibold ${isDarkMode ? "text-slate-400" : "text-slate-700"} block mb-1`}>Patient BMI</label>
                              <div className={`p-2.5 rounded-lg border text-center font-bold text-xs ${
                                cgCalculatedWeights.bmi >= 30 
                                  ? "bg-rose-500/10 text-rose-400 border-rose-500/20" 
                                  : "bg-teal-500/10 text-teal-400 border-teal-500/20"
                              }`}>
                                {cgCalculatedWeights.bmi} {cgCalculatedWeights.bmi >= 30 ? "Obese" : ""}
                              </div>
                            </div>
                          )}
                        </div>

                        {cgCalculatedWeights && (
                          <div className={`p-2.5 rounded-lg border ${isDarkMode ? "bg-slate-950/40 border-slate-800/80" : "bg-slate-50 border-slate-200"} space-y-2`}>
                            <span className={`block text-[10px] font-bold ${isDarkMode ? "text-slate-400" : "text-slate-700"} uppercase tracking-wider`}>Weight Selection (Clinical Safety)</span>
                            <div className={`text-[10px] ${isDarkMode ? "text-slate-400" : "text-slate-700"} leading-normal`}>
                              {cgCalculatedWeights.isObese ? (
                                <span className={`${isDarkMode ? "text-amber-400" : "text-amber-700"} font-semibold`}>⚠️ Patient is Obese. Recommend using Adjusted Body Weight (AjBW) to prevent dosage overestimation.</span>
                              ) : (
                                <span>Recommend using Actual Body Weight.</span>
                              )}
                            </div>
                            <div className="grid grid-cols-3 gap-1">
                              <button 
                                type="button" 
                                onClick={() => setCgWeightType("actual")}
                                className={`p-1.5 rounded border text-[10px] font-mono flex flex-col items-center justify-center transition-all ${
                                  cgWeightType === "actual" 
                                    ? "bg-teal-500/20 border-teal-500 text-teal-300 font-bold" 
                                    : "bg-slate-900/60 border-slate-800 text-slate-400 hover:bg-slate-800"
                                }`}
                              >
                                <span>Actual</span>
                                <span className="text-[9px] text-slate-600">{cgWeight}kg</span>
                              </button>
                              <button 
                                type="button" 
                                onClick={() => setCgWeightType("ideal")}
                                className={`p-1.5 rounded border text-[10px] font-mono flex flex-col items-center justify-center transition-all ${
                                  cgWeightType === "ideal" 
                                    ? "bg-teal-500/20 border-teal-500 text-teal-300 font-bold" 
                                    : "bg-slate-900/60 border-slate-800 text-slate-400 hover:bg-slate-800"
                                }`}
                              >
                                <span>Ideal (IBW)</span>
                                <span className="text-[9px] text-slate-600">{cgCalculatedWeights.ibw}kg</span>
                              </button>
                              <button 
                                type="button" 
                                onClick={() => setCgWeightType("adjusted")}
                                className={`p-1.5 rounded border text-[10px] font-mono flex flex-col items-center justify-center transition-all ${
                                  cgWeightType === "adjusted" 
                                    ? "bg-teal-500/20 border-teal-500 text-teal-300 font-bold" 
                                    : "bg-slate-900/60 border-slate-800 text-slate-400 hover:bg-slate-800"
                                }`}
                              >
                                <span>Adjusted</span>
                                <span className="text-[9px] text-slate-600">{cgCalculatedWeights.ajbw}kg</span>
                              </button>
                            </div>
                          </div>
                        )}

                        <button 
                          onClick={calculateCrCl}
                          className="w-full bg-teal-500 hover:bg-teal-600 text-slate-950 font-bold py-2 rounded-lg text-xs transition-all cursor-pointer uppercase tracking-wider"
                          id="btn-calculate-crcl"
                        >
                          Recalculate CrCl
                        </button>
                      </div>
                    </div>

                    {cgResult !== null && (
                      <div className="p-2.5 bg-teal-500/10 border border-teal-500/20 rounded-lg text-center mt-3">
                        <span className={`block text-[10px] ${isDarkMode ? "text-slate-400" : "text-slate-700"}`}>Calculated Clearance ({cgWeightType.toUpperCase()})</span>
                        <strong className={`${isDarkMode ? "text-teal-400" : "text-teal-700"} font-mono text-base block`}>{cgResult.toFixed(1)} ml/min</strong>
                        {cgCalculatedWeights && (
                          <span className="text-[9px] text-slate-600 font-mono mt-0.5 block">
                            Using weight: {cgWeightType === "actual" ? `${cgWeight}kg` : cgWeightType === "ideal" ? `${cgCalculatedWeights.ibw}kg (IBW)` : `${cgCalculatedWeights.ajbw}kg (AjBW)`}
                          </span>
                        )}
                      </div>
                    )}
                  </div>

                  {/* Corrected Calcium Calculator */}
                  <div className={`p-5 rounded-xl border flex flex-col justify-between ${
                    isDarkMode ? "bg-[#111827] border-slate-800" : "bg-white border-slate-200 shadow-sm"
                  }`}>
                    <div>
                      <div className="flex items-center gap-2.5 mb-4">
                        <div className={`p-2 rounded bg-teal-500/10 ${isDarkMode ? "text-teal-400" : "text-teal-700"}`}>
                          <Calculator className="h-4.5 w-4.5" />
                        </div>
                        <div>
                          <h3 className={`font-bold text-sm ${isDarkMode ? "text-slate-200" : "text-slate-700"}`}>Corrected Calcium</h3>
                          <p className={`text-[10px] ${isDarkMode ? "text-slate-400" : "text-slate-700"}`}>Albumin-Adjusted Calcium</p>
                        </div>
                      </div>

                      <div className="space-y-3.5 text-xs text-left">
                        <div>
                          <label className={`text-[11px] font-semibold ${isDarkMode ? "text-slate-400" : "text-slate-700"} block mb-1`}>Measured Calcium (mmol/L)</label>
                          <input 
                            type="number" 
                            step="0.01"
                            value={caMeasured} 
                            onChange={(e) => { setCaMeasured(e.target.value); setCaResult(null); }}
                            placeholder="e.g. 1.85" 
                            className={`w-full p-2.5 rounded-lg border bg-slate-900 border-slate-800 text-white`}
                          />
                          <div className="flex gap-1 mt-1 flex-wrap">
                            {["1.70", "1.90", "2.10"].map(v => (
                              <button key={v} type="button" onClick={() => { setCaMeasured(v); setCaResult(null); }} className={`px-1.5 py-0.5 rounded text-[10px] ${isDarkMode ? "bg-slate-800 text-slate-300 hover:bg-slate-700" : "bg-slate-100 text-slate-800 hover:bg-slate-200"} font-mono`} id={`ca-measured-preset-${v}`}>{v}</button>
                            ))}
                          </div>
                        </div>

                        <div>
                          <label className={`text-[11px] font-semibold ${isDarkMode ? "text-slate-400" : "text-slate-700"} block mb-1`}>Serum Albumin (g/L)</label>
                          <input 
                            type="number" 
                            value={caAlbumin} 
                            onChange={(e) => { setCaAlbumin(e.target.value); setCaResult(null); }}
                            placeholder="e.g. 25" 
                            className={`w-full p-2.5 rounded-lg border bg-slate-900 border-slate-800 text-white`}
                          />
                          <div className="flex gap-1 mt-1 flex-wrap">
                            {["20", "28", "35"].map(v => (
                              <button key={v} type="button" onClick={() => { setCaAlbumin(v); setCaResult(null); }} className={`px-1.5 py-0.5 rounded text-[10px] ${isDarkMode ? "bg-slate-800 text-slate-300 hover:bg-slate-700" : "bg-slate-100 text-slate-800 hover:bg-slate-200"} font-mono`} id={`ca-albumin-preset-${v}`}>{v}</button>
                            ))}
                          </div>
                        </div>

                        <button 
                          onClick={calculateCalcium}
                          className="w-full bg-teal-500 hover:bg-teal-600 text-slate-950 font-bold py-2.5 px-3 rounded-lg text-xs transition-all mt-6 cursor-pointer uppercase tracking-wider animate-pulse"
                          id="btn-calculate-calcium"
                        >
                          Correct Calcium
                        </button>
                      </div>
                    </div>

                    {caResult !== null && (
                      <div className="p-2.5 bg-teal-500/10 border border-teal-500/20 rounded-lg text-center mt-3">
                        <span className={`block text-[10px] ${isDarkMode ? "text-slate-400" : "text-slate-700"}`}>Corrected Calcium</span>
                        <strong className={`font-mono text-base block mt-0.5 ${caResult < 2.15 ? "text-rose-400 animate-pulse" : "text-teal-400"}`}>
                          {caResult.toFixed(2)} mmol/L
                        </strong>
                      </div>
                    )}
                  </div>

                  {/* Infusion Drip & Flow Rate Calculator */}
                  <div className={`p-5 rounded-xl border flex flex-col justify-between ${
                    isDarkMode ? "bg-[#111827] border-slate-800" : "bg-white border-slate-200 shadow-sm"
                  }`}>
                    <div>
                      <div className="flex items-center gap-2.5 mb-4">
                        <div className={`p-2 rounded bg-teal-500/10 ${isDarkMode ? "text-teal-400" : "text-teal-700"}`}>
                          <Calculator className="h-4.5 w-4.5" />
                        </div>
                        <div>
                          <h3 className={`font-bold text-sm ${isDarkMode ? "text-slate-200" : "text-slate-700"}`}>Infusion Flow Rate</h3>
                          <p className={`text-[10px] ${isDarkMode ? "text-slate-400" : "text-slate-700"}`}>mL/h & Drop Rate Converter</p>
                        </div>
                      </div>

                      <div className="space-y-3.5 text-xs text-left">
                        <div>
                          <label className={`text-[11px] font-semibold ${isDarkMode ? "text-slate-400" : "text-slate-700"} block mb-1`}>Total Volume (ml)</label>
                          <input 
                            type="number" 
                            value={infusionVol} 
                            onChange={(e) => { setInfusionVol(e.target.value); setInfusionResult(null); }}
                            placeholder="e.g. 500" 
                            className={`w-full p-2.5 rounded-lg border bg-slate-900 border-slate-800 text-white`}
                          />
                          <div className="flex gap-1 mt-1 flex-wrap">
                            {["100", "250", "500"].map(v => (
                              <button key={v} type="button" onClick={() => { setInfusionVol(v); setInfusionResult(null); }} className={`px-1.5 py-0.5 rounded text-[10px] ${isDarkMode ? "bg-slate-800 text-slate-300 hover:bg-slate-700" : "bg-slate-100 text-slate-800 hover:bg-slate-200"} font-mono`} id={`infusion-vol-preset-${v}`}>{v}</button>
                            ))}
                          </div>
                        </div>

                        <div>
                          <label className={`text-[11px] font-semibold ${isDarkMode ? "text-slate-400" : "text-slate-700"} block mb-1`}>Duration (hours)</label>
                          <input 
                            type="number" 
                            value={infusionDuration} 
                            onChange={(e) => { setInfusionVolDuration(e.target.value); setInfusionResult(null); }}
                            placeholder="e.g. 4" 
                            className={`w-full p-2.5 rounded-lg border bg-slate-900 border-slate-800 text-white`}
                          />
                          <div className="flex gap-1 mt-1 flex-wrap">
                            {["1", "4", "8", "12"].map(v => (
                              <button key={v} type="button" onClick={() => { setInfusionVolDuration(v); setInfusionResult(null); }} className={`px-1.5 py-0.5 rounded text-[10px] ${isDarkMode ? "bg-slate-800 text-slate-300 hover:bg-slate-700" : "bg-slate-100 text-slate-800 hover:bg-slate-200"} font-mono`} id={`infusion-dur-preset-${v}`}>{v}h</button>
                            ))}
                          </div>
                        </div>

                        <div>
                          <label className={`text-[11px] font-semibold ${isDarkMode ? "text-slate-400" : "text-slate-700"} block mb-1`}>Drop Factor (gtt/ml)</label>
                          <select 
                            value={infusionDropFactor} 
                            onChange={(e) => { setInfusionDropFactor(e.target.value); setInfusionResult(null); }}
                            className={`w-full p-2.5 rounded-lg border bg-slate-900 border-slate-800 text-white`}
                          >
                            <option value="20">20 gtt/ml (Standard Blood/IV Set)</option>
                            <option value="15">15 gtt/ml (Macro Set)</option>
                            <option value="60">60 gtt/ml (Microdrip Set)</option>
                          </select>
                        </div>

                        <button 
                          onClick={calculateInfusion}
                          className="w-full bg-teal-500 hover:bg-teal-600 text-slate-950 font-bold py-2.5 px-3 rounded-lg text-xs transition-all mt-2 cursor-pointer uppercase tracking-wider"
                          id="btn-calculate-infusion"
                        >
                          Calculate Rates
                        </button>
                      </div>
                    </div>

                    {infusionResult !== null && (
                      <div className="p-2.5 bg-teal-500/10 border border-teal-500/20 rounded-lg text-center mt-3 flex flex-col gap-1 text-[11px]">
                        <div className="flex justify-between items-center px-1">
                          <span className={`${isDarkMode ? "text-slate-400" : "text-slate-700"}`}>Flow Rate:</span>
                          <strong className={`${isDarkMode ? "text-teal-400" : "text-teal-700"} font-mono text-xs`}>{infusionResult.mlPerHour.toFixed(1)} ml/h</strong>
                        </div>
                        <div className="flex justify-between items-center border-t border-slate-800/45 px-1 pt-1 mt-1">
                          <span className={`${isDarkMode ? "text-slate-400" : "text-slate-700"}`}>Drip Rate:</span>
                          <strong className={`${isDarkMode ? "text-teal-400" : "text-teal-700"} font-mono text-xs`}>{infusionResult.dropsPerMin.toFixed(0)} drops/min</strong>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* SECTION B: CRITICAL CARE DRUG & INFUSION CONVERTER (Bidirectional) */}
              {calcSubTab === "infusion" && (() => {
                return (
                  <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
                    
                    {/* INPUT PANEL (5 cols) */}
                    <div className={`p-5 rounded-2xl border lg:col-span-5 space-y-4 ${
                      isDarkMode ? "bg-[#111827] border-slate-800" : "bg-white border-slate-200 shadow-sm"
                    }`}>
                      <h3 className="font-bold text-sm tracking-wide text-teal-400 flex items-center gap-2">
                        <span>⚙️</span> Infusion Configuration
                      </h3>

                      {/* Weight Input with Presets */}
                      <div>
                        <label className={`text-[11px] font-semibold ${isDarkMode ? "text-slate-400" : "text-slate-700"} block mb-1`}>
                          Patient Weight (kg)
                        </label>
                        <input 
                          type="number"
                          value={infWeight}
                          onChange={(e) => setInfWeight(e.target.value)}
                          className="w-full p-2.5 rounded-lg border bg-slate-900 border-slate-800 text-white font-mono text-sm"
                          placeholder="70"
                        />
                        <div className="flex gap-1 mt-2 flex-wrap">
                          {["50", "60", "70", "80", "90"].map((wVal) => (
                            <button
                              key={wVal}
                              onClick={() => setInfWeight(wVal)}
                              className={`px-2 py-1 rounded text-[10px] font-mono ${
                                infWeight === wVal
                                  ? "bg-teal-500/20 text-teal-400 border border-teal-500/40"
                                  : "bg-slate-800 hover:bg-slate-700 text-slate-300"
                              }`}
                            >
                              {wVal}kg
                            </button>
                          ))}
                        </div>
                      </div>

                      {/* Drug Selection */}
                      <div>
                        <label className={`text-[11px] font-semibold ${isDarkMode ? "text-slate-400" : "text-slate-700"} block mb-1`}>
                          Select Infusion Drug
                        </label>
                        <select
                          value={infDrug}
                          onChange={(e) => {
                            const selected = e.target.value as any;
                            setInfDrug(selected);
                            // Set defaults for selected drug to avoid blank calculations
                            if (selected === "noradrenaline") {
                              setInfPrep("single");
                              setInfTargetDose("0.1");
                              setInfMlPerHour("3.75");
                            } else if (selected === "adrenaline") {
                              setInfPrep("single");
                              setInfTargetDose("0.1");
                              setInfMlPerHour("5.0");
                            } else if (selected === "dopamine") {
                              setInfPrep("single");
                              setInfTargetDose("5");
                              setInfMlPerHour("5.25");
                            } else if (selected === "dobutamine") {
                              setInfPrep("single");
                              setInfTargetDose("5");
                              setInfMlPerHour("4.2");
                            } else if (selected === "insulin") {
                              setInfTargetDose("2");
                              setInfMlPerHour("2.0");
                            } else if (selected === "heparin") {
                              setInfTargetDose("1000");
                              setInfMlPerHour("2.0");
                            } else {
                              setInfCustomUnit("mcg/kg/min");
                              setInfCustomConc("1");
                            }
                          }}
                          className="w-full p-2.5 rounded-lg border bg-slate-900 border-slate-800 text-white font-semibold text-xs"
                          id="select-infusion-drug"
                        >
                          <option value="noradrenaline">Noradrenaline (Levophed)</option>
                          <option value="adrenaline">Adrenaline (Epinephrine)</option>
                          <option value="dopamine">Dopamine</option>
                          <option value="dobutamine">Dobutamine</option>
                          <option value="insulin">Actrapid Insulin</option>
                          <option value="heparin">Heparin (UFH)</option>
                          <option value="custom">Custom Infusion Profile</option>
                        </select>
                      </div>

                      {/* Preparation / Strength */}
                      {infDrug !== "insulin" && infDrug !== "heparin" && infDrug !== "custom" && (
                        <div>
                          <label className={`text-[11px] font-semibold ${isDarkMode ? "text-slate-400" : "text-slate-700"} block mb-1`}>
                            Dilution Prep Strength
                          </label>
                          <div className="grid grid-cols-3 gap-1.5">
                            {[
                              { id: "single", label: "Single" },
                              { id: "double", label: "Double" },
                              { id: "custom", label: "Custom" }
                            ].map((pOpt) => (
                              <button
                                key={pOpt.id}
                                onClick={() => setInfPrep(pOpt.id as any)}
                                className={`py-2 px-1 rounded-lg border text-xs font-bold transition-all ${
                                  infPrep === pOpt.id
                                    ? "bg-teal-500/20 text-teal-400 border-teal-500/50"
                                    : "bg-slate-900 border-slate-800 text-slate-400 hover:bg-slate-800"
                                }`}
                              >
                                {pOpt.label}
                              </button>
                            ))}
                          </div>
                        </div>
                      )}

                      {/* Custom Concentration (when Custom Prep or Custom Drug is selected) */}
                      {((infPrep === "custom" && infDrug !== "insulin" && infDrug !== "heparin") || infDrug === "custom") && (
                        <div>
                          <label className={`text-[11px] font-semibold ${isDarkMode ? "text-slate-400" : "text-slate-700"} block mb-1`}>
                            Syringe Concentration ({infDrug === "custom" ? "Custom Units" : "mcg"}/mL)
                          </label>
                          <input
                            type="number"
                            value={infCustomConc}
                            onChange={(e) => setInfCustomConc(e.target.value)}
                            className="w-full p-2.5 rounded-lg border bg-slate-900 border-slate-800 text-white font-mono text-xs"
                            placeholder="e.g. 80"
                          />
                        </div>
                      )}

                      {/* Custom Drug Dose Units */}
                      {infDrug === "custom" && (
                        <div>
                          <label className={`text-[11px] font-semibold ${isDarkMode ? "text-slate-400" : "text-slate-700"} block mb-1`}>
                            Target Dose Units
                          </label>
                          <select
                            value={infCustomUnit}
                            onChange={(e) => setInfCustomUnit(e.target.value as any)}
                            className="w-full p-2.5 rounded-lg border bg-slate-900 border-slate-800 text-white text-xs"
                          >
                            <option value="mcg/kg/min">mcg/kg/min (weight-based min)</option>
                            <option value="mcg/min">mcg/min (absolute min)</option>
                            <option value="units/hr">units/hour (absolute hr)</option>
                            <option value="mg/hr">mg/hour (absolute hr)</option>
                          </select>
                        </div>
                      )}

                      {/* Dilution guide card */}
                      <div className="p-3.5 rounded-xl bg-slate-950/40 border border-slate-800/80 text-[11px] space-y-1 text-left leading-relaxed">
                        <strong className="text-teal-400 uppercase tracking-wider block text-[10px]">Preparation Guide:</strong>
                        <p className={isDarkMode ? "text-slate-300" : "text-slate-800"}>{inf.preparationText}</p>
                        <div className="pt-1.5 border-t border-slate-800/40 text-[10px] text-slate-500 font-mono">
                          Computed Concentration: {inf.concentration} {inf.unit.includes("units") ? "units" : inf.unit.includes("mg") ? "mg" : "mcg"}/mL
                        </div>
                      </div>
                    </div>

                    {/* DUAL CALCULATOR INTERLOCK (7 cols) */}
                    <div className="lg:col-span-7 space-y-4">
                      
                      {/* Active Titrator Selector */}
                      <div className="flex border border-slate-800 bg-slate-950/20 p-1 rounded-xl">
                        <button
                          onClick={() => setInfCalcMode("doseToRate")}
                          className={`flex-1 py-2 text-xs font-bold rounded-lg transition-all ${
                            infCalcMode === "doseToRate"
                              ? "bg-teal-500 text-slate-950 shadow"
                              : "text-slate-400 hover:text-slate-200"
                          }`}
                        >
                          🎯 Set Target Dose ➔ Get Rate (mL/h)
                        </button>
                        <button
                          onClick={() => setInfCalcMode("rateToDose")}
                          className={`flex-1 py-2 text-xs font-bold rounded-lg transition-all ${
                            infCalcMode === "rateToDose"
                              ? "bg-teal-500 text-slate-950 shadow"
                              : "text-slate-400 hover:text-slate-200"
                          }`}
                          id="btn-mode-rate-to-dose"
                        >
                          📈 Set Pump Rate (mL/h) ➔ Get Dose
                        </button>
                      </div>

                      {/* CASE A: TARGET DOSE TO INFUSION RATE */}
                      {infCalcMode === "doseToRate" && (
                        <div className={`p-5 rounded-2xl border space-y-4 ${
                          isDarkMode ? "bg-[#111827] border-slate-800" : "bg-white border-slate-200 shadow-sm"
                        }`}>
                          <div className="flex justify-between items-center">
                            <span className="text-xs font-bold uppercase tracking-wider text-teal-400">Target Dose Titration</span>
                            <span className="text-[10px] text-slate-500 font-mono font-bold">ACTIVE CALCULATOR</span>
                          </div>

                          <div className="space-y-3">
                            <div>
                              <label className={`text-[11px] font-semibold ${isDarkMode ? "text-slate-400" : "text-slate-700"} block mb-1`}>
                                Target Infusion Dose ({inf.unit})
                              </label>
                              <div className="flex items-center gap-2">
                                <input
                                  type="number"
                                  step="0.01"
                                  value={infTargetDose}
                                  onChange={(e) => setInfTargetDose(e.target.value)}
                                  className="flex-1 p-3 rounded-xl border bg-slate-900 border-slate-800 text-white font-mono text-base font-bold outline-none focus:border-teal-400"
                                  id="input-target-dose"
                                />
                                <span className="text-xs font-bold text-slate-400 w-20 truncate">{inf.unit.split("/")[0]}</span>
                              </div>
                            </div>

                            {/* Preset titration buttons */}
                            <div>
                              <span className={`text-[10px] font-bold block ${isDarkMode ? "text-slate-500" : "text-slate-600"} mb-1.5 uppercase`}>
                                Titration Presets
                              </span>
                              <div className="flex gap-1.5 flex-wrap">
                                {inf.standardDoses.map((dPreset) => (
                                  <button
                                    key={dPreset}
                                    onClick={() => setInfTargetDose(dPreset.toString())}
                                    className={`px-2.5 py-1 rounded-md text-xs font-mono transition-all border ${
                                      parseFloat(infTargetDose) === dPreset
                                        ? "bg-teal-500/20 text-teal-400 border-teal-500/40"
                                        : "bg-slate-900 border-slate-800 text-slate-400 hover:bg-slate-800"
                                    }`}
                                  >
                                    {dPreset}
                                  </button>
                                ))}
                              </div>
                            </div>
                          </div>

                          {/* OUTPUT WINDOW (RATE) */}
                          <div className="p-4 rounded-xl bg-teal-500/5 border border-teal-500/20 text-center space-y-1">
                            <span className="text-[10px] uppercase font-bold text-slate-500 tracking-wider">Required Syringe Pump Flow Rate</span>
                            <div className="flex items-baseline justify-center gap-1.5">
                              <span className="text-3xl font-extrabold text-teal-400 font-mono tracking-tight" id="calc-rate-output">
                                {inf.calculatedRate}
                              </span>
                              <span className="text-sm font-bold text-slate-400">mL/hr</span>
                            </div>
                            <p className="text-[10px] text-slate-400 font-medium">
                              Set syringe driver flow speed exactly to <strong className="text-slate-200">{inf.calculatedRate} mL/h</strong> to deliver a dosage of <strong className="text-teal-400">{infTargetDose} {inf.unit}</strong>.
                            </p>
                          </div>
                        </div>
                      )}

                      {/* CASE B: INFUSION RATE TO CLINICAL DOSE */}
                      {infCalcMode === "rateToDose" && (
                        <div className={`p-5 rounded-2xl border space-y-4 ${
                          isDarkMode ? "bg-[#111827] border-slate-800" : "bg-white border-slate-200 shadow-sm"
                        }`}>
                          <div className="flex justify-between items-center">
                            <span className="text-xs font-bold uppercase tracking-wider text-teal-400">Syringe Driver Speed</span>
                            <span className="text-[10px] text-slate-500 font-mono font-bold">ACTIVE CALCULATOR</span>
                          </div>

                          <div className="space-y-3">
                            <div>
                              <label className={`text-[11px] font-semibold ${isDarkMode ? "text-slate-400" : "text-slate-700"} block mb-1`}>
                                Infusion Rate (mL/hr)
                              </label>
                              <div className="flex items-center gap-2">
                                <input
                                  type="number"
                                  step="0.1"
                                  value={infMlPerHour}
                                  onChange={(e) => setInfMlPerHour(e.target.value)}
                                  className="flex-1 p-3 rounded-xl border bg-slate-900 border-slate-800 text-white font-mono text-base font-bold outline-none focus:border-teal-400"
                                  id="input-ml-per-hour"
                                />
                                <span className="text-xs font-bold text-slate-400 w-20">mL/hour</span>
                              </div>
                            </div>

                            {/* Preset rate buttons */}
                            <div>
                              <span className={`text-[10px] font-bold block ${isDarkMode ? "text-slate-500" : "text-slate-600"} mb-1.5 uppercase`}>
                                Standard Flow Rates
                              </span>
                              <div className="flex gap-1.5 flex-wrap">
                                {["0.5", "1.0", "2.0", "4.0", "8.0", "12.0", "16.0"].map((rPreset) => (
                                  <button
                                    key={rPreset}
                                    onClick={() => setInfMlPerHour(rPreset)}
                                    className={`px-2.5 py-1 rounded-md text-xs font-mono transition-all border ${
                                      parseFloat(infMlPerHour) === parseFloat(rPreset)
                                        ? "bg-teal-500/20 text-teal-400 border-teal-500/40"
                                        : "bg-slate-900 border-slate-800 text-slate-400 hover:bg-slate-800"
                                    }`}
                                  >
                                    {rPreset} ml/h
                                  </button>
                                ))}
                              </div>
                            </div>
                          </div>

                          {/* OUTPUT WINDOW (DOSE) */}
                          <div className="p-4 rounded-xl bg-teal-500/5 border border-teal-500/20 text-center space-y-1">
                            <span className="text-[10px] uppercase font-bold text-slate-500 tracking-wider">Delivered Patient Dosage</span>
                            <div className="flex items-baseline justify-center gap-1.5">
                              <span className="text-3xl font-extrabold text-teal-400 font-mono tracking-tight" id="calc-dose-output">
                                {inf.calculatedDose}
                              </span>
                              <span className="text-xs font-bold text-slate-400 truncate">{inf.unit}</span>
                            </div>
                            <p className="text-[10px] text-slate-400 font-medium">
                              Running at <strong className="text-slate-200">{infMlPerHour} mL/h</strong> delivers a continuous blood dosage of <strong className="text-teal-400">{inf.calculatedDose} {inf.unit}</strong> to a {weight}kg patient.
                            </p>
                          </div>
                        </div>
                      )}

                      {/* Clinical Guidance/Alert Panel */}
                      <div className="p-4 rounded-xl border border-slate-800/80 bg-slate-900/40 space-y-2 text-left">
                        <div className="flex items-center gap-2 text-amber-400 text-xs font-bold">
                          <span>🛡️</span> Bedside Clinical Notes ({inf.drugName})
                        </div>
                        <p className={`text-xs leading-relaxed ${isDarkMode ? "text-slate-300" : "text-slate-700"}`}>
                          {clinicalNotes}
                        </p>
                      </div>

                    </div>

                  </div>
                );
              })()}

            </div>
          );
        })()}

      </main>

      {/* FOOTER */}
      <footer className={`border-t py-8 text-center text-xs ${
        isDarkMode ? "bg-[#0b0f19] border-slate-900 text-slate-600" : "bg-slate-100 border-slate-200 text-slate-800"
      }`}>
        <div className="max-w-3xl mx-auto px-4">
          <p className={`font-semibold ${isDarkMode ? "text-slate-400" : "text-slate-700"} text-sm`}>
            Copyright Dr FH Liew(2026)
          </p>
          <p className="max-w-2xl mx-auto mt-2 leading-relaxed text-[11px]">
            This initiative is undertaken on a free and voluntary basis, and the organizers disclaim any responsibility for errors, omissions, or legal consequences arising from participation. Always exercise professional clinical judgment at the bedside.
          </p>
        </div>
      </footer>

    </div>
  );
}
