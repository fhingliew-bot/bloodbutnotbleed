const fs = require('fs');

let code = fs.readFileSync('src/App.tsx', 'utf8');

// We want to replace all occurrences of `isDarkMode ? "text-slate-XXX" : "text-slate-YYY"` to make YYY darker.
// Specifically:
// text-slate-400 -> text-slate-600
// text-slate-500 -> text-slate-700
// text-slate-600 -> text-slate-800
// text-slate-700 -> text-slate-900

code = code.replace(/isDarkMode \? "([^"]+)" : "([^"]+)"/g, (match, dark, light) => {
    let newLight = light;
    newLight = newLight.replace(/\btext-slate-400\b/g, 'text-slate-600');
    newLight = newLight.replace(/\btext-slate-500\b/g, 'text-slate-700');
    newLight = newLight.replace(/\btext-slate-600\b/g, 'text-slate-800');
    // For backgrounds:
    // bg-slate-50 -> bg-slate-100 or keep it? bg-white is good enough, maybe text needs to be darker
    return `isDarkMode ? "${dark}" : "${newLight}"`;
});

// For span/text classes that don't use isDarkMode but might be static text-slate-500
// e.g. <span className="text-[11px] sm:text-xs text-slate-500 leading-normal">
// Should be text-slate-500 in light, maybe text-slate-600 is better
code = code.replace(/text-slate-500/g, 'text-slate-600');

fs.writeFileSync('src/App.tsx', code);
console.log('Fixed text contrast');
