const fs = require('fs');

let code = fs.readFileSync('src/data/labs.ts', 'utf8');

// I will parse the array and update/add elements.
// To safely update, we can find the specific strings and replace them with new blocks.

const replacements = [
  {
    find: `test: "ADAMTS-13 Activity & Inhibitor [Referred]",
    lab: "Ref: Haematology Lab, Hospital Ampang",
    container: "Trisodium Citrate tube (Blue cap) - Double spun & Frozen",
    specimen: "Platelet-poor plasma",
    volume: "2 tubes of 2.7 ml",
    ltat: "14 working days",
    remark: "FORM: Special Haematology Request Form (Hospital Ampang). Spin, separate, and freeze immediately. Do not test during acute thrombotic episode or while on oral anticoagulants.",
    ranges: "Protein C Activity: 70% - 140%, Protein S (Free): 60% - 130%, Antithrombin III: 80% - 120%."`,
    replace: `test: "ADAMTS TS-13 Activity/ Inhibitor [Referred]",
    lab: "Ref: Clinical Haematology Referral Laboratory, Hospital Ampang",
    container: "One (1) Trisodium Citrate 3.2% tube",
    specimen: "Blood (plasma)",
    volume: "1 tube x 2.7 ml",
    ltat: "6 WEEKS",
    remark: "HOSPITAL AMPANG SPECIAL HAEMATOLOGY REQUISITION FORM. Deliver tubes immediately to the laboratory at room temperature. OR Separate plasma from cells as soon as possible (double spin) within 4 hours from time of collection. Platelet count must be <10x10^9/L in plasma prior to freezing. Store frozen at -40°C and transport frozen plasma on dried ice. Requesting clinician must call Haematologist Hospital Ampang before sending the sample/s to HKL Lab.",
    ranges: "Refer to referring laboratory report."`
  },
  {
    find: `test: "Serum Erythropoietin (sEPO) [Referred]",
    lab: "Ref: Haematology Lab, Hospital Ampang",
    container: "Plain with gel (Yellow cap)",
    specimen: "Serum",
    volume: "4 ml",
    ltat: "14 working days",
    remark: "FORM: Special Haematology Request Form (Hospital Ampang). Spin and separate serum. Correlate with FBC and hematocrit levels. Do not use for athletes suspected of EPO abuse.",
    ranges: "4.3 - 29.0 mIU/mL."`,
    replace: `test: "Serum EPO (Erythropoietin) - ELISA [Referred]",
    lab: "Ref: Clinical Haematology Referral Laboratory, Hospital Ampang",
    container: "Four (4) Plain tubes",
    specimen: "Blood (serum)",
    volume: "4 tubes x 2.0 ml",
    ltat: "MDS : 8 WEEKS, MPN & PRV : 12 WEEKS",
    remark: "HOSPITAL AMPANG SPECIAL HAEMATOLOGY REQUISITION FORM. All request must be accompanied with recent FBC result. Deliver tubes immediately to the laboratory at room temperature. OR Separate serum from cells as soon as possible (Separated serum minimum 1.5 ml). Store frozen at -40°C and transport frozen serum on dried ice. Requesting clinician must call Haematologist Hospital Ampang before sending the sample/s to HKL Lab.",
    ranges: "Refer to referring laboratory report."`
  },
  {
    find: `test: "BCR-ABL1 Gene Rearrangement (RT-qPCR) [Referred]",
    lab: "Ref: Haematology Lab, Hospital Ampang",
    container: "EDTA tube (Purple cap)",
    specimen: "Whole Blood",
    volume: "4 ml",
    ltat: "10 to 14 working days",
    remark: "FORM: Special Haematology Request Form (Hospital Ampang). Diagnostic and therapeutic monitoring for Chronic Myeloid Leukemia (CML) and Ph+ ALL. Send immediately.",
    ranges: "Not detected. Major molecular response is BCR-ABL1/ABL1 ratio <= 0.1% on International Scale (IS)."`,
    replace: `test: "BCR-ABL1 (Qualitative & Quantitative) [Referred]",
    lab: "Ref: Clinical Haematology Referral Laboratory, Hospital Ampang",
    container: "Three to Five (3-5) EDTA tubes",
    specimen: "Whole Blood / Bone Marrow Aspirate",
    volume: "WB: 5 tubes x 2.0 ml (Min 10 ml), BMA: 1 tube x 2.0 ml (Min 1.0 - 2.0 ml)",
    ltat: "Qualitative: 4 WEEKS, Quantitative: 12 WEEKS",
    remark: "HOSPITAL AMPANG SPECIAL HAEMATOLOGY REQUISITION FORM. Transport samples without delay preferably within 24 hours at room temperature (20-24°C). DO NOT FREEZE specimens. Requesting clinician must call Haematologist Hospital Ampang before sending the sample/s to HKL Lab. Requesting clinician must get appointment from Haematology Lab HKL before sending sample/s to the lab.",
    ranges: "Refer to referring laboratory report."`
  },
  {
    find: `test: "JAK2 V617F Mutation Analysis [Referred]",
    lab: "Ref: Haematology Lab, Hospital Ampang",
    container: "EDTA tube (Purple cap)",
    specimen: "Whole Blood",
    volume: "4 ml",
    ltat: "14 to 21 working days",
    remark: "FORM: Special Haematology Request Form (Hospital Ampang). Screen for myeloproliferative neoplasms (PV, ET, PMF). Keep at room temperature.",
    ranges: "Negative for JAK2 V617F mutation."`,
    replace: `test: "JAK2/ CALR Calreticulin [Referred]",
    lab: "Ref: Clinical Haematology Referral Laboratory, Hospital Ampang",
    container: "Three to Five (3-5) EDTA tubes",
    specimen: "Whole Blood / Bone Marrow Aspirate",
    volume: "WB: 5 tubes x 2.0 ml (Min 10 ml), BMA: 1 tube x 2.0 ml (Min 1.0 - 2.0 ml)",
    ltat: "8 WEEKS",
    remark: "HOSPITAL AMPANG SPECIAL HAEMATOLOGY REQUISITION FORM. Transport samples without delay preferably within 24 hours at room temperature (20-24°C). DO NOT FREEZE specimens. Requesting clinician must call Haematologist Hospital Ampang before sending the sample/s to HKL Lab. Requesting clinician must get appointment from Haematology Lab HKL before sending sample/s to the lab.",
    ranges: "Refer to referring laboratory report."`
  },
  {
    find: `test: "Fluorescence In Situ Hybridization (FISH) [Referred]",
    lab: "Ref: Haematology Lab, Hospital Ampang",
    container: "Sodium Heparin tube (Green cap)",
    specimen: "Bone Marrow or Whole Blood",
    volume: "3 ml",
    ltat: "14 to 21 working days",
    remark: "FORM: Special Haematology Request Form (Hospital Ampang). Indicate specific FISH probes required (e.g. t(9;22), t(15;17), inv(16), del(5q), trisomy 8, 11q23). Send immediately at room temperature.",
    ranges: "Negative for targeted structural/numerical abnormalities."`,
    replace: `test: "Leukemia FISH Analysis (For MPN case) [Referred]",
    lab: "Ref: Clinical Haematology Referral Laboratory, Hospital Ampang",
    container: "Three (3) Sodium Heparin",
    specimen: "Whole Blood / Bone Marrow Aspirate",
    volume: "WB: 5 tubes x 2.0 ml (Min 10 ml), BMA: 1 tube x 2.0 ml (Min 2.0 ml)",
    ltat: "18 DAYS",
    remark: "HOSPITAL AMPANG SPECIAL HAEMATOLOGY REQUISITION FORM. Transport samples without delay preferably within 24 hours at room temperature (20-24°C). DO NOT FREEZE specimens. Requesting clinician must call Haematologist Hospital Ampang before sending the sample/s to HKL Lab.",
    ranges: "Refer to referring laboratory report."`
  }
];

let replaced = 0;
for (const replacement of replacements) {
  if (code.includes(replacement.find)) {
    code = code.replace(replacement.find, replacement.replace);
    replaced++;
  } else {
    console.log("Could not find:\\n" + replacement.find);
  }
}

// Add Anti PF4 and Minor BCR::ABL1
const newTests = `
  {
    test: "Anti PF4 Antibody Testing [Referred]",
    lab: "Ref: Clinical Haematology Referral Laboratory, Hospital Ampang",
    container: "Two (2) Plain tubes",
    specimen: "Blood (plasma)",
    volume: "2 tubes x 2.0 ml",
    ltat: "12-16 WEEKS",
    remark: "HOSPITAL AMPANG SPECIAL HAEMATOLOGY REQUISITION FORM. Deliver tubes immediately to the laboratory at room temperature. Requesting clinician must call Haematologist Hospital Ampang before sending the sample/s to HKL Lab.",
    ranges: "Refer to referring laboratory report."
  },
  {
    test: "Minor BCR::ABL1 (Quantitative) (Follow-up) [Referred]",
    lab: "Ref: Clinical Haematology Referral Laboratory, Hospital Ampang",
    container: "One (1) EDTA tube",
    specimen: "Bone Marrow Aspirate",
    volume: "1 tube x 2.0 ml (Min 1.0 - 2.0 ml)",
    ltat: "6 WEEKS",
    remark: "HOSPITAL AMPANG SPECIAL HAEMATOLOGY REQUISITION FORM. Transport samples without delay preferably within 24 hours at room temperature (20-24°C). DO NOT FREEZE specimens. Requesting clinician must call Haematologist Hospital Ampang before sending the sample/s to HKL Lab. Requesting clinician must get appointment from Haematology Lab HKL before sending sample/s to the lab.",
    ranges: "Refer to referring laboratory report."
  }
`;

const index = code.lastIndexOf('}');
if (index !== -1) {
  code = code.substring(0, index + 1) + ',' + newTests + '\n];';
  fs.writeFileSync('src/data/labs.ts', code);
  console.log('Successfully applied replacements and appended tests. Replaced: ' + replaced);
} else {
  console.log('Could not find the end of the array.');
}
