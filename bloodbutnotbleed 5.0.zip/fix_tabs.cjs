const fs = require('fs');

let code = fs.readFileSync('src/App.tsx', 'utf8');

// Change grid columns
code = code.replace(/className="grid grid-cols-1 md:grid-cols-3 gap-3 mb-6"/, 'className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-6"');

const newButton = `
            <button 
              onClick={() => { setActiveCategory("sos"); setActiveTab("checklists"); setSearchQuery(""); }}
              className={\`p-4 rounded-xl border flex flex-col items-start gap-1 transition-all text-left cursor-pointer group \${
                activeCategory === "sos"
                  ? "bg-rose-500/15 border-rose-500/50 text-rose-400 shadow-md ring-1 ring-rose-500/20"
                  : isDarkMode 
                    ? "bg-slate-900/40 border-slate-800/60 text-slate-400 hover:bg-slate-800/80 hover:text-slate-300"
                    : "bg-white border-slate-200 text-slate-600 hover:bg-slate-50 hover:border-slate-300 shadow-sm"
              }\`}
            >
              <div className="flex items-center gap-2 font-bold text-sm sm:text-base">
                <span className={\`transition-transform duration-300 \${activeCategory === "sos" ? "scale-110" : "group-hover:scale-110"}\`}>🚨</span> 
                SOS CHECKLISTS
              </div>
              <span className="text-[11px] sm:text-xs text-slate-600 leading-normal">
                Cognitive aids & critical protocols
              </span>
            </button>
`;

code = code.replace(/(<span className="text-\[11px\] sm:text-xs text-slate-600 leading-normal">\s*Cockcroft-Gault, Corrected Calcium, etc\.\s*<\/span>\s*<\/button>)/, '$1' + newButton);

fs.writeFileSync('src/App.tsx', code);
