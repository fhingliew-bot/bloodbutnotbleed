const fs = require('fs');

const testsToAdd = `
  {
    test: "Blood Lead [Referred]",
    lab: "Ref: Hospital Selayang",
    container: "EDTA Tube",
    specimen: "Blood",
    volume: "2 mL",
    ltat: "21 working days (Tuesday)",
    remark: "FORM: PER-PAT 301. Send to H. Selayang.",
    ranges: "Refer to referring laboratory report."
  },
  {
    test: "Serum Copper [Referred]",
    lab: "Ref: Hospital Selayang",
    container: "Plain tube without gel or EDTA Tube",
    specimen: "Serum",
    volume: "2 mL",
    ltat: "21 working days (Tuesday)",
    remark: "FORM: PER-PAT 301. Send to H. Selayang.",
    ranges: "Refer to referring laboratory report."
  },
  {
    test: "24hr Urine Copper [Referred]",
    lab: "Ref: Hospital Selayang",
    container: "24hr Urine Container (Without Preservative)",
    specimen: "24hr Urine",
    volume: "5 mL",
    ltat: "21 working days (Thursday)",
    remark: "FORM: PER-PAT 301. 24hr urine volume MUST be stated on the request form.",
    ranges: "Refer to referring laboratory report."
  },
  {
    test: "Coeliac Antibodies Panel [Referred]",
    lab: "Ref: IMR",
    container: "Plain gel tube",
    specimen: "Blood/ Serum",
    volume: "5ml",
    ltat: "21 working days (Mon-Fri)",
    remark: "Includes Anti-Endomysium, Anti-Deamidated Gliadin Peptide, Anti-Tissue Transglutaminase.",
    ranges: "Negative."
  },
  {
    test: "Paraneoplastic Neurological Syndrome (PNS) Panel [Referred]",
    lab: "Ref: IMR",
    container: "Plain gel tube",
    specimen: "Blood/ Serum",
    volume: "5ml",
    ltat: "14 working days (Mon-Fri)",
    remark: "Includes Anti-Amphiphysin, Anti-Ma, Anti-Yo, Anti-Ri, Anti-Hu, Anti-CV2, Anti-Tr, Anti-GAD65, Anti-Zic4, Anti-Titin, Anti-SOX1, Anti-Recoverin.",
    ranges: "Negative."
  },
  {
    test: "Specific Liver Antibodies (SLA) Panel [Referred]",
    lab: "Ref: IMR",
    container: "Plain gel tube",
    specimen: "Blood/ Serum",
    volume: "5ml",
    ltat: "14 working days (Mon-Fri)",
    remark: "Includes Anti-AMA-M2, M2 3E/BPO, Sp100, PML, gp210, LKM1, LC-1, SLA/LP, Ro-52. Must specify tissue antibody results (AMA, ASMA, LKM). Enclose screening test results along with this form.",
    ranges: "Negative."
  },
  {
    test: "Cytokine Test Panel: IL-1b, IL-6, IL-8 & TNF-a [Referred]",
    lab: "Ref: IMR",
    container: "Plain gel tube / cryovial tube",
    specimen: "Blood- 5 mls in plain tube, Serum- 2 mls in cryovial tube",
    volume: "5ml",
    ltat: "21 working days (Mon-Fri)",
    remark: "By appointment only.",
    ranges: "Refer to referring laboratory report."
  },
  {
    test: "Skin Antibodies Panel [Referred]",
    lab: "Ref: IMR",
    container: "Plain gel tube",
    specimen: "Blood/ Serum",
    volume: "5ml",
    ltat: "14 working days (Mon-Fri)",
    remark: "Includes Anti-BP 180, Anti BP-230, Anti-Desmoglein 1 & Anti-Desmoglein 3.",
    ranges: "Negative."
  },
  {
    test: "Anti - Ganglioside Antibodies (GA) Panel [Referred]",
    lab: "Ref: IMR",
    container: "Bijou bottle/Plain gel tube",
    specimen: "CSF/Serum",
    volume: "5ml",
    ltat: "14 working days (Mon-Fri)",
    remark: "Includes Anti GM1, Anti-GM2, Anti-GM3, Anti-GM4, Anti-GD1a, Anti-GD1b, Anti-GD2, Anti-GD3, Anti-GT 1a, Anti-GT 1b, Anti-GQ1b.",
    ranges: "Negative."
  }
`;

let code = fs.readFileSync('src/data/labs.ts', 'utf8');

const index = code.lastIndexOf('}');
if (index !== -1) {
  code = code.substring(0, index + 1) + ',' + testsToAdd + '\n];';
  fs.writeFileSync('src/data/labs.ts', code);
  console.log('Successfully appended lab tests.');
} else {
  console.log('Could not find the end of the array.');
}
