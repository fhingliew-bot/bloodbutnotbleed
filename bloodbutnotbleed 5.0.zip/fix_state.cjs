const fs = require('fs');

let code = fs.readFileSync('src/App.tsx', 'utf8');
code = code.replace(
  /const \[activeCategory, setActiveCategory\] = useState<"lab" \| "drug" \| "calc">/,
  'const [activeCategory, setActiveCategory] = useState<"lab" | "drug" | "calc" | "sos">'
);
code = code.replace(
  /const \[activeTab, setActiveTab\] = useState<"labs" \| "endocrine" \| "directory" \| "dilution" \| "renal" \| "emts">/,
  'const [activeTab, setActiveTab] = useState<"labs" | "endocrine" | "directory" | "dilution" | "renal" | "emts" | "checklists">'
);
fs.writeFileSync('src/App.tsx', code);
