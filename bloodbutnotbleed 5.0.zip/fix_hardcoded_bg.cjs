const fs = require('fs');

let code = fs.readFileSync('src/App.tsx', 'utf8');

// We have things like className="p-3 rounded-lg bg-slate-950/20 border border-slate-800"
// and className="mt-3 p-3 bg-slate-950/20 rounded-lg border border-slate-800/40"
// We want to turn them into className={`p-3 rounded-lg ${isDarkMode ? 'bg-slate-950/20 border-slate-800' : 'bg-slate-50 border-slate-200'} border`}

code = code.replace(/className="([^"]*(?:bg-slate-950\/(?:20|25|40)|bg-slate-500\/10)[^"]*)"/g, (match, classes) => {
    let newClasses = classes;
    if (newClasses.includes('bg-slate-500/10')) {
        newClasses = newClasses.replace('bg-slate-500/10', '${isDarkMode ? "bg-slate-500/10" : "bg-slate-100"}');
    }
    if (newClasses.includes('bg-slate-950/20')) {
        newClasses = newClasses.replace('bg-slate-950/20', '${isDarkMode ? "bg-slate-950/20 border-slate-800" : "bg-slate-50 border-slate-200"}');
        newClasses = newClasses.replace('border-slate-800', '');
    }
    if (newClasses.includes('bg-slate-950/25')) {
        newClasses = newClasses.replace('bg-slate-950/25', '${isDarkMode ? "bg-slate-950/25 border-slate-800/40" : "bg-slate-50 border-slate-200"}');
        newClasses = newClasses.replace('border-slate-800/40', '');
    }
    if (newClasses.includes('bg-slate-950/40')) {
        newClasses = newClasses.replace('bg-slate-950/40', '${isDarkMode ? "bg-slate-950/40 border-slate-800/80" : "bg-slate-50 border-slate-200"}');
        newClasses = newClasses.replace('border-slate-800/80', '');
    }
    // Clean up double spaces
    newClasses = newClasses.replace(/\s+/g, ' ').trim();
    return `className={\`${newClasses}\`}`;
});

fs.writeFileSync('src/App.tsx', code);
console.log('Fixed hardcoded bg classes');
