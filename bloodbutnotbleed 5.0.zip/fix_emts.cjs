const fs = require('fs');
let code = fs.readFileSync('src/data/emts.ts', 'utf8');

code = code.replace(/"Acute Ischemic Stroke: 10% of total dose administered as an IV bolus over 1 minute.\nMassive PE: 10mg IV bolus over 1-2 minutes."/, '"Acute Ischemic Stroke: 10% of total dose administered as an IV bolus over 1 minute.\\nMassive PE: 10mg IV bolus over 1-2 minutes."');

code = code.replace(/"Acute Ischemic Stroke: Total dose is 0.9 mg\/kg \(Maximum 90mg\). Remaining 90% infused over 60 minutes.\nMassive PE: Remaining 90mg infused over 2 hours."/, '"Acute Ischemic Stroke: Total dose is 0.9 mg/kg (Maximum 90mg). Remaining 90% infused over 60 minutes.\\nMassive PE: Remaining 90mg infused over 2 hours."');

fs.writeFileSync('src/data/emts.ts', code);
