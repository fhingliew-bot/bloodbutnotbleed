const fs = require('fs');

const testsToAdd = `
  {
    test: "Thiamine (Vitamin B1) [Referred]",
    lab: "Ref: Makmal Kesihatan Awam Kebangsaan (MKAK)",
    container: "EDTA tube (Purple cap)",
    specimen: "Whole Blood",
    volume: "4 ml",
    ltat: "14 - 30 working days",
    remark: "Use Borang Permohonan Ujian (Umum) MKAK.",
    ranges: "Refer to referring laboratory report."
  },
  {
    test: "Adenosine deaminase (ADA) [Referred]",
    lab: "Ref: Makmal Kesihatan Awam Kebangsaan (MKAK)",
    container: "Plain container (Red/Gold cap)",
    specimen: "Pleural fluid",
    volume: "3 ml",
    ltat: "14 - 30 working days",
    remark: "Use Borang Permohonan Ujian (Umum) MKAK.",
    ranges: "Refer to referring laboratory report."
  },
  {
    test: "Methanol Level [Referred]",
    lab: "Ref: Makmal Kesihatan Awam Kebangsaan (MKAK)",
    container: "Fluoride tube (Grey cap)",
    specimen: "Serum",
    volume: "3 ml",
    ltat: "Urgent/Routine based on request",
    remark: "For suspected methanol poisoning.",
    ranges: "Toxic levels >20 mg/dL. Normal is zero."
  },
  {
    test: "Beta-2 Microglobulin [Referred]",
    lab: "Ref: Hospital Ampang",
    container: "Plain with gel (Yellow cap)",
    specimen: "Blood",
    volume: "3 ml",
    ltat: "14 working days",
    remark: "Tumor marker for multiple myeloma and certain lymphomas.",
    ranges: "Refer to referring laboratory report."
  },
  {
    test: "Protein Electrophoresis (CSF) / Oligoclonal band [Referred]",
    lab: "Ref: Hospital Ampang",
    container: "Plain with gel (Yellow cap) AND Bijou bottle",
    specimen: "Serum & CSF",
    volume: "3 ml Blood, 2 ml CSF",
    ltat: "14 working days",
    remark: "MUST be send in pair (serum & CSF) at the same time.",
    ranges: "Negative for oligoclonal bands."
  },
  {
    test: "Progesterone, 17 Hydroxy [Referred]",
    lab: "Ref: Hospital Putrajaya",
    container: "Plain with gel (Yellow cap)",
    specimen: "Blood",
    volume: "3 ml",
    ltat: "14 working days",
    remark: "Used for evaluation of Congenital Adrenal Hyperplasia (CAH).",
    ranges: "Refer to referring laboratory report."
  },
  {
    test: "Insulin-like Growth Factor 1 (IGF-1) [Referred]",
    lab: "Ref: Hospital Putrajaya",
    container: "Plain with gel (Yellow cap)",
    specimen: "Blood",
    volume: "3 ml",
    ltat: "14 working days",
    remark: "Assessment of acromegaly or growth hormone deficiency.",
    ranges: "Age and sex-dependent. Refer to referring laboratory report."
  },
  {
    test: "Sex Hormone Binding Globulin (SHBG) [Referred]",
    lab: "Ref: Hospital Putrajaya",
    container: "Plain with gel (Yellow cap)",
    specimen: "Blood",
    volume: "3 ml",
    ltat: "14 working days",
    remark: "Useful for evaluating free testosterone status.",
    ranges: "Refer to referring laboratory report."
  },
  {
    test: "Sirolimus Level [Referred]",
    lab: "Ref: Hospital Tunku Azizah (HTA)",
    container: "Plain tube without gel (Red cap)",
    specimen: "Blood",
    volume: "3 ml",
    ltat: "14 working days",
    remark: "Use TDM form. Trough level is usually preferred.",
    ranges: "Refer to referring laboratory report."
  },
  {
    test: "Homocysteine Total [Referred]",
    lab: "Ref: National Institute of Health (NIH)",
    container: "EDTA tube (Purple cap)",
    specimen: "Blood",
    volume: "4 ml",
    ltat: "14 - 30 working days",
    remark: "Evaluate for hypercoagulable states or B12/Folate deficiency.",
    ranges: "Refer to referring laboratory report."
  },
  {
    test: "Porphyrins Urine (Qualitative) [Referred]",
    lab: "Ref: National Institute of Health (NIH)",
    container: "Universal container",
    specimen: "Urine",
    volume: "5 ml",
    ltat: "14 - 30 working days",
    remark: "Protect from light. Refer to NIH guidelines.",
    ranges: "Negative."
  },
  {
    test: "5-hydroxy-Indol-Acetic Acid (5 HIAA) 24Hr Urine [Referred]",
    lab: "Ref: National Institute of Health (NIH)",
    container: "24-hour urine container",
    specimen: "24-Hour Urine",
    volume: "5 ml aliquot",
    ltat: "14 - 30 working days",
    remark: "Screening for carcinoid tumors. Dietary restrictions apply (avoid bananas, avocados, pineapples, tomatoes, walnuts, etc. 48h prior).",
    ranges: "Refer to referring laboratory report."
  }
`;

let code = fs.readFileSync('src/data/labs.ts', 'utf8');

// The file ends with `];` or `}  ];`
// Find the last `  }` and insert the testsToAdd after a comma.
const index = code.lastIndexOf('}');
if (index !== -1) {
  code = code.substring(0, index + 1) + ',' + testsToAdd + '\n];';
  fs.writeFileSync('src/data/labs.ts', code);
  console.log('Successfully appended tests.');
} else {
  console.log('Could not find the end of the array.');
}
