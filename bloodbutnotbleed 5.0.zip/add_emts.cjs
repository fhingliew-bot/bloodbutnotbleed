const fs = require('fs');

let code = fs.readFileSync('src/data/emts.ts', 'utf8');

const newDrugs = `
  {
    drug: "Nicardipine 10mg/10ml",
    indication: "Hypertensive Crises, Acute Ischemic Stroke (to lower BP prior to thrombolysis), Acute Intracerebral Haemorrhage",
    category: "Hypertension",
    preparation: "Continuous Infusion: Dilute 50mg (5 ampoules) in 50ml NS or D5% (concentration: 1 mg/ml). Alternatively, dilute 20mg in 40ml or 50mg in 200ml depending on ward protocol.",
    bolus: "N/A (Do not give as IV bolus).",
    infusion: "Start at 2.5 - 5.0 mg/hour. Increase by 2.5 mg/hour every 5-15 minutes until target BP is achieved. Maximum dose: 15 mg/hour. Once target BP achieved, reduce dose to 3 mg/hour.",
    precautions: "Closely monitor BP continuously. Causes reflex tachycardia and headache. May induce phlebitis; change peripheral infusion site every 12 hours or use central line."
  },
  {
    drug: "Alteplase (rt-PA) 50mg/vial",
    indication: "Acute Ischemic Stroke (within 4.5 hours of onset), Massive Pulmonary Embolism, STEMI (if PCI unavailable)",
    category: "Resuscitation",
    preparation: "Reconstitute with provided sterile water (usually 50mg in 50ml) to a concentration of 1 mg/ml. Do not shake vigorously (swirl gently to avoid foaming).",
    bolus: "Acute Ischemic Stroke: 10% of total dose administered as an IV bolus over 1 minute.\nMassive PE: 10mg IV bolus over 1-2 minutes.",
    infusion: "Acute Ischemic Stroke: Total dose is 0.9 mg/kg (Maximum 90mg). Remaining 90% infused over 60 minutes.\nMassive PE: Remaining 90mg infused over 2 hours.",
    precautions: "Strictly adhere to inclusion/exclusion criteria for thrombolysis. Maintain BP <180/105 mmHg during and 24 hours post-infusion. Do not insert NGT, catheter, or perform arterial puncture during infusion. Monitor for intracranial/systemic bleeding."
  }
`;

const index = code.lastIndexOf('}');
if (index !== -1) {
  code = code.substring(0, index + 1) + ',' + newDrugs + '\n];';
  fs.writeFileSync('src/data/emts.ts', code);
  console.log('Successfully appended EMTS drugs.');
}
