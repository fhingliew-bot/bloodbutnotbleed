const fs = require('fs');
let code = fs.readFileSync('src/App.tsx', 'utf8');

const targetStr = `              <div className="flex gap-2">
                <span className={\`w-2 h-2 rounded-full \${breathingPhase === "Inhale" ? "bg-teal-400" : "bg-slate-700"}\`} />
                <span className={\`w-2 h-2 rounded-full \${breathingPhase === "Hold (Full)" ? "bg-teal-400" : "bg-slate-700"}\`} />
                <span className={\`w-2 h-2 rounded-full \${breathingPhase === "Exhale" ? "bg-teal-400" : "bg-slate-700"}\`} />
                <span className={\`w-2 h-2 rounded-full \${breathingPhase === "Hold (Empty)" ? "bg-teal-400" : "bg-slate-700"}\`} />
              </div>`;

const helpLine = `              <div className="mt-4 pt-4 border-t border-teal-500/20 w-full text-center space-y-3">
                <p className={\`text-[11px] \${isDarkMode ? "text-teal-300/80" : "text-teal-800/80"}\`}>
                  You are not alone. If you're feeling overwhelmed or burned out:
                </p>
                <div className="flex flex-col sm:flex-row justify-center gap-2">
                  <a href="tel:0340411140" className={\`text-[11px] px-3 py-1.5 rounded-full border \${isDarkMode ? "bg-slate-900 border-teal-900 text-teal-400 hover:bg-slate-800" : "bg-white border-teal-200 text-teal-700 hover:bg-teal-50"}\`}>
                    📞 MMA HelpDoc Hotline
                  </a>
                  <a href="tel:0376272929" className={\`text-[11px] px-3 py-1.5 rounded-full border \${isDarkMode ? "bg-slate-900 border-teal-900 text-teal-400 hover:bg-slate-800" : "bg-white border-teal-200 text-teal-700 hover:bg-teal-50"}\`}>
                    📞 Befrienders KL
                  </a>
                </div>
              </div>`;

code = code.replace(targetStr, targetStr + '\n' + helpLine);
fs.writeFileSync('src/App.tsx', code);
