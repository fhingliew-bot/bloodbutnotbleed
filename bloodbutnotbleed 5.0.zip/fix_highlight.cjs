const fs = require('fs');

let code = fs.readFileSync('src/App.tsx', 'utf8');

code = code.replace(/<mark key=\{i\} className="bg-amber-400\/30 text-amber-700 dark:bg-amber-400\/40 dark:text-amber-200 px-0\.5 rounded font-semibold">/g, '<mark key={i} className={`px-0.5 rounded font-semibold ${isDarkMode ? "bg-amber-400/40 text-amber-200" : "bg-amber-400/30 text-amber-900"}`}>');

fs.writeFileSync('src/App.tsx', code);
console.log('Fixed highlightMatch');
