const fs = require('fs');
let code = fs.readFileSync('src/App.tsx', 'utf8');

const helpLine = `
              <div className="mt-6 pt-4 border-t border-teal-500/20 w-full text-center space-y-2">
                <p className={\`text-[11px] \${isDarkMode ? "text-slate-400" : "text-slate-600"}\`}>
                  You are not alone. If you're feeling overwhelmed or burned out:
                </p>
                <div className="flex flex-col sm:flex-row justify-center gap-2">
                  <a href="tel:0340411140" className={\`text-[10px] px-3 py-1.5 rounded-full border \${isDarkMode ? "bg-slate-900 border-slate-700 text-teal-400 hover:bg-slate-800" : "bg-white border-slate-200 text-teal-700 hover:bg-teal-50"}\`}>
                    📞 MMA HelpDoc Hotline
                  </a>
                  <a href="tel:0376272929" className={\`text-[10px] px-3 py-1.5 rounded-full border \${isDarkMode ? "bg-slate-900 border-slate-700 text-teal-400 hover:bg-slate-800" : "bg-white border-slate-200 text-teal-700 hover:bg-teal-50"}\`}>
                    📞 Befrienders KL
                  </a>
                </div>
              </div>
`;

code = code.replace(/<p className=\{`text-xs \$\{isDarkMode \? "text-slate-400" : "text-slate-700"\} mt-1 max-w-sm mx-auto`\}>\n\s*Follow the circle to regulate your heart rate and reduce stress.\n\s*<\/p>\n\s*<\/div>/, '<p className={`text-xs ${isDarkMode ? "text-slate-400" : "text-slate-700"} mt-1 max-w-sm mx-auto`}>\n                Follow the circle to regulate your heart rate and reduce stress.\n              </p>\n            </div>' + helpLine);

fs.writeFileSync('src/App.tsx', code);
