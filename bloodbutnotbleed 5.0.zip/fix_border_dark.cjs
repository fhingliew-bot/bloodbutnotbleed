const fs = require('fs');
let code = fs.readFileSync('src/App.tsx', 'utf8');

code = code.replace(/isDarkMode \? "bg-slate-950\/20 " : "bg-slate-50 border-slate-200"/g, 'isDarkMode ? "bg-slate-950/20 border-slate-800" : "bg-slate-50 border-slate-200"');
code = code.replace(/isDarkMode \? "bg-slate-950\/25 " : "bg-slate-50 border-slate-200"/g, 'isDarkMode ? "bg-slate-950/25 border-slate-800/40" : "bg-slate-50 border-slate-200"');
code = code.replace(/isDarkMode \? "bg-slate-950\/40 " : "bg-slate-50 border-slate-200"/g, 'isDarkMode ? "bg-slate-950/40 border-slate-800/80" : "bg-slate-50 border-slate-200"');

fs.writeFileSync('src/App.tsx', code);
console.log('Fixed borders in dark mode');
