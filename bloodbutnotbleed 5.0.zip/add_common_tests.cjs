const fs = require('fs');

const testsToAdd = `
  {
    test: "Lipase",
    lab: "Chemical Pathology",
    container: "Plain / Gel tube (Yellow cap)",
    specimen: "Serum",
    volume: "3 ml",
    ltat: "2 hours",
    remark: "Highly specific for acute pancreatitis. Often rises earlier and stays elevated longer than Amylase.",
    ranges: "13 - 60 U/L."
  },
  {
    test: "Opiates / Morphine Screen (Urine)",
    lab: "Chemical Pathology",
    container: "Sterile urine container",
    specimen: "Urine",
    volume: "10 ml",
    ltat: "2 hours",
    remark: "Drugs of abuse screening. Usually requested together with Amphetamines and Benzodiazepines.",
    ranges: "Negative."
  },
  {
    test: "Vitamin D (25-OH Cholecalciferol)",
    lab: "Chemical Pathology",
    container: "Plain / Gel tube (Yellow cap)",
    specimen: "Serum",
    volume: "4 ml",
    ltat: "3 - 5 days",
    remark: "Assessment of Vitamin D deficiency or toxicity.",
    ranges: "Adequate: > 75 nmol/L, Insufficient: 50-75 nmol/L, Deficient: < 50 nmol/L."
  },
  {
    test: "Prolactin",
    lab: "Chemical Pathology",
    container: "Plain / Gel tube (Yellow cap)",
    specimen: "Serum",
    volume: "3 ml",
    ltat: "2 - 3 days",
    remark: "Patient should be resting for 30 mins prior to venepuncture. Evaluate pituitary adenoma, amenorrhea, galactorrhea.",
    ranges: "Male: 86-324 mIU/L, Female (Non-pregnant): 102-496 mIU/L."
  },
  {
    test: "TIBC & Transferrin",
    lab: "Chemical Pathology",
    container: "Plain / Gel tube (Yellow cap)",
    specimen: "Serum",
    volume: "3 ml",
    ltat: "2 - 3 days",
    remark: "Part of Iron Studies panel. Interpret together with Serum Iron and Ferritin.",
    ranges: "Transferrin: 2.0 - 3.6 g/L. TIBC: 45 - 80 umol/L."
  },
  {
    test: "CK-MB (Creatine Kinase-MB)",
    lab: "Chemical Pathology",
    container: "Plain / Gel tube (Yellow cap)",
    specimen: "Serum",
    volume: "3 ml",
    ltat: "2 hours",
    remark: "Cardiac biomarker. Usually requested for suspected re-infarction as it normalizes faster than Troponin.",
    ranges: "0 - 24 U/L."
  },
  {
    test: "ENA Profile (Extractable Nuclear Antigen) [Referred]",
    lab: "Ref: IMR / Hospital Kuala Lumpur",
    container: "Plain / Gel tube (Yellow cap)",
    specimen: "Serum",
    volume: "4 ml",
    ltat: "14 - 21 working days",
    remark: "Should only be requested if ANA is positive. Identifies specific autoantibodies (e.g. SSA/Ro, SSB/La, Sm, RNP, Scl-70, Jo-1).",
    ranges: "Negative."
  },
  {
    test: "Hepatitis A IgM (Anti-HAV IgM)",
    lab: "Microbiology / Serology",
    container: "Plain / Gel tube (Yellow cap)",
    specimen: "Serum",
    volume: "3 ml",
    ltat: "1 - 3 days",
    remark: "Used to diagnose acute Hepatitis A infection.",
    ranges: "Non-reactive."
  },
  {
    test: "Mycoplasma pneumoniae Serology",
    lab: "Microbiology / Serology",
    container: "Plain / Gel tube (Yellow cap)",
    specimen: "Serum",
    volume: "3 ml",
    ltat: "3 - 5 days",
    remark: "Atypical pneumonia screen. May include IgM/IgG or particle agglutination test.",
    ranges: "Negative / Titre < 1:40."
  }
`;

let code = fs.readFileSync('src/data/labs.ts', 'utf8');
const index = code.lastIndexOf('}');
if (index !== -1) {
  code = code.substring(0, index + 1) + ',' + testsToAdd + '\n];';
  fs.writeFileSync('src/data/labs.ts', code);
  console.log('Successfully appended common missing tests.');
} else {
  console.log('Could not find the end of the array.');
}
