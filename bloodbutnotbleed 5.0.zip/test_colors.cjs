const fs = require('fs');

let code = fs.readFileSync('src/App.tsx', 'utf8');

const regex = /isDarkMode \? "([^"]+)" : "([^"]+)"/g;
let match;
const pairs = new Set();
while ((match = regex.exec(code)) !== null) {
  pairs.add(`isDarkMode ? "${match[1]}" : "${match[2]}"`);
}

console.log(Array.from(pairs).join('\n'));
