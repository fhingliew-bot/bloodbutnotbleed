const fs = require('fs');

const testsToAdd = `
  {
    test: "EGFR Testing (Histopathology) [Referred]",
    lab: "Ref: Makmal Molekular Genetik, Hospital Tunku Azizah",
    container: "Unstained slides",
    specimen: "Unstained slides",
    volume: "As requested",
    ltat: "10 days",
    remark: "Request by Pathologist.",
    ranges: "Refer to referring laboratory report."
  },
  {
    test: "Fungal PCR (Histopathology) [Referred]",
    lab: "Ref: Molecular Mycology, National Institute of Health (NIH)",
    container: "Unstained slides",
    specimen: "Unstained slides",
    volume: "As requested",
    ltat: "10 days",
    remark: "Request by Pathologist.",
    ranges: "Refer to referring laboratory report."
  },
  {
    test: "Immunohistochemistry of Lymphoma markers [Referred]",
    lab: "Ref: Unit Hematopatologi, Hospital Ampang",
    container: "Unstained slides",
    specimen: "Unstained slides",
    volume: "As requested",
    ltat: "Within 10 days",
    remark: "Request by Pathologist. Perform stain without report/result.",
    ranges: "Stain results."
  }
`;

let code = fs.readFileSync('src/data/labs.ts', 'utf8');

// The file ends with `];` or `}  ];`
// Find the last `  }` and insert the testsToAdd after a comma.
const index = code.lastIndexOf('}');
if (index !== -1) {
  code = code.substring(0, index + 1) + ',' + testsToAdd + '\n];';
  fs.writeFileSync('src/data/labs.ts', code);
  console.log('Successfully appended tests.');
} else {
  console.log('Could not find the end of the array.');
}
