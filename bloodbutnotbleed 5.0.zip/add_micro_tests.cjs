const fs = require('fs');

const testsToAdd = `
  {
    test: "Bordetella pertussis PCR [Referred]",
    lab: "Ref: IMR",
    container: "Sterile container",
    specimen: "Nasopharyngeal aspirates / swabs",
    volume: "1-2 ml",
    ltat: "5 working days",
    remark: "Every working day (Mon-Fri).",
    ranges: "Negative."
  },
  {
    test: "Leptospiral PCR [Referred]",
    lab: "Ref: IMR",
    container: "Sterile container or EDTA tube",
    specimen: "Blood, CSF, Bronchial lavage, Tissue",
    volume: "2 ml",
    ltat: "5 working days",
    remark: "For ICU cases & after consultation only.",
    ranges: "Negative."
  },
  {
    test: "Carbapenemase genes detection (CRE) [Referred]",
    lab: "Ref: IMR",
    container: "Blood agar or nutrient slant",
    specimen: "Bacterial culture / Pure isolate",
    volume: "Pure isolate",
    ltat: "14 working days",
    remark: "Sample send from Microbiology Unit. Request through Sample Management.",
    ranges: "Negative."
  },
  {
    test: "Avian influenza Viruses (H5,H7, H9) qRT-PCR [Referred]",
    lab: "Ref: IMR",
    container: "Sterile plastic vial containing VTM",
    specimen: "Respiratory swabs / aspirate",
    volume: "As collected",
    ltat: "1 - 5 days",
    remark: "Requires consultation. Every working day (Mon-Fri).",
    ranges: "Negative."
  },
  {
    test: "SARS-CoV-2 Whole Genome Sequencing [Referred]",
    lab: "Ref: IMR",
    container: "VTM",
    specimen: "Respiratory samples",
    volume: "As collected",
    ltat: "1 - 5 days",
    remark: "Requires consultation.",
    ranges: "Refer to report."
  }
`;

let code = fs.readFileSync('src/data/labs.ts', 'utf8');

const index = code.lastIndexOf('}');
if (index !== -1) {
  code = code.substring(0, index + 1) + ',' + testsToAdd + '\n];';
  fs.writeFileSync('src/data/labs.ts', code);
  console.log('Successfully appended tests.');
} else {
  console.log('Could not find the end of the array.');
}
