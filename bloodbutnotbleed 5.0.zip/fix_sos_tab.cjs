const fs = require('fs');

let code = fs.readFileSync('src/App.tsx', 'utf8');

const sosState = `
  const [checkedItems, setCheckedItems] = useState<Record<string, boolean>>({});

  const toggleChecklist = (id: string) => {
    setCheckedItems(prev => ({...prev, [id]: !prev[id]}));
  };
`;

// Insert the state just before const isDarkMode
code = code.replace(/const isDarkMode = theme === "dark";/, sosState + '\n  const isDarkMode = theme === "dark";');

const sosView = `
        {/* TAB: SOS CHECKLISTS */}
        {activeCategory === "sos" && (
          <div className="space-y-6 animate-fade-in">
            <div className={\`p-5 rounded-xl border mb-6 \${
              isDarkMode ? "bg-[#111827] border-rose-500/10" : "bg-white border-rose-200 shadow-sm"
            }\`}>
              <h2 className={\`text-xl font-bold font-sans \${isDarkMode ? "text-rose-400" : "text-rose-700"} flex items-center gap-2\`}>
                <span>🚨</span> SOS Cognitive Aids & Checklists
              </h2>
              <p className={\`text-xs \${isDarkMode ? "text-slate-400" : "text-slate-700"} mt-2 max-w-3xl leading-relaxed\`}>
                During critical emergencies, cognitive overload can lead to missed steps. Use these evidence-based checklists to offload mental burden.
              </p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {dbChecklists.map((list) => (
                <div key={list.id} className={\`p-5 rounded-xl border flex flex-col \${
                  isDarkMode ? "bg-[#111827] border-slate-800" : "bg-white border-slate-200 shadow-sm"
                }\`}>
                  <div className="flex items-center gap-3 mb-2 border-b border-slate-800/40 pb-3">
                    <span className="text-2xl">{list.icon}</span>
                    <div>
                      <h3 className={\`font-bold text-base \${isDarkMode ? "text-rose-300" : "text-rose-800"}\`}>{list.title}</h3>
                      <p className={\`text-[11px] \${isDarkMode ? "text-slate-400" : "text-slate-600"}\`}>{list.description}</p>
                    </div>
                  </div>
                  
                  <div className="space-y-2.5 mt-3 flex-1">
                    {list.items.map(item => (
                      <div 
                        key={item.id}
                        onClick={() => toggleChecklist(item.id)}
                        className={\`flex items-start gap-3 p-2.5 rounded-lg cursor-pointer transition-all border \${
                          checkedItems[item.id]
                            ? isDarkMode ? "bg-emerald-500/10 border-emerald-500/20" : "bg-emerald-50 border-emerald-200"
                            : isDarkMode ? "bg-slate-900/50 border-slate-800 hover:border-slate-700" : "bg-slate-50 border-slate-200 hover:border-slate-300"
                        }\`}
                      >
                        <div className={\`mt-0.5 flex-shrink-0 w-4 h-4 rounded border flex items-center justify-center \${
                          checkedItems[item.id]
                            ? "bg-emerald-500 border-emerald-500 text-white"
                            : isDarkMode ? "border-slate-600" : "border-slate-400"
                        }\`}>
                          {checkedItems[item.id] && <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" /></svg>}
                        </div>
                        <span className={\`text-xs leading-relaxed \${
                          checkedItems[item.id]
                            ? isDarkMode ? "text-slate-500 line-through" : "text-slate-400 line-through"
                            : isDarkMode ? "text-slate-300" : "text-slate-700"
                        }\`}>
                          {item.text}
                        </span>
                      </div>
                    ))}
                  </div>
                  <div className="mt-4 pt-3 border-t border-slate-800/40 text-right">
                    <button 
                      onClick={(e) => {
                        e.stopPropagation();
                        // Clear all items for this list
                        const nextState = { ...checkedItems };
                        list.items.forEach(i => delete nextState[i.id]);
                        setCheckedItems(nextState);
                      }}
                      className={\`text-[10px] px-2 py-1 rounded \${
                        isDarkMode ? "bg-slate-800 text-slate-400 hover:bg-slate-700 hover:text-slate-200" : "bg-slate-100 text-slate-500 hover:bg-slate-200 hover:text-slate-800"
                      }\`}
                    >
                      Reset Checklist
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
`;

code = code.replace(/\{\/\* TAB: BEDSIDE CALCULATORS \(Active Category\) \*\/\}/, sosView + '\n\n        {/* TAB: BEDSIDE CALCULATORS (Active Category) */}');

fs.writeFileSync('src/App.tsx', code);
