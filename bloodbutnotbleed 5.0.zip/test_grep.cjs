const fs = require('fs');
let code = fs.readFileSync('src/App.tsx', 'utf8');
const lines = code.split('\n');
for (let i = 0; i < lines.length; i++) {
  if (lines[i].includes('activeCategory === "calc"')) {
    console.log(`Line ${i+1}: ${lines[i]}`);
  }
}
