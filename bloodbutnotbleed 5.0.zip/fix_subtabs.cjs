const fs = require('fs');
let code = fs.readFileSync('src/App.tsx', 'utf8');

code = code.replace(/\{activeCategory !== "calc" && \(/g, '{activeCategory !== "calc" && activeCategory !== "sos" && (');

fs.writeFileSync('src/App.tsx', code);
