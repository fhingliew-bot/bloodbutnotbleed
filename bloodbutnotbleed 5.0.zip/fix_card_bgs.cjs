const fs = require('fs');

let code = fs.readFileSync('src/App.tsx', 'utf8');

code = code.replace(/bg-slate-50 border-slate-300 text-slate-900/g, 'bg-white border-slate-200 text-slate-900 shadow-sm');

fs.writeFileSync('src/App.tsx', code);
console.log('Fixed card backgrounds');
