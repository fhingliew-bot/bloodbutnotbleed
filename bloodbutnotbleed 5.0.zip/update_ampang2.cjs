const fs = require('fs');

let code = fs.readFileSync('src/data/labs.ts', 'utf8');

// Replace ADAMTS
code = code.replace(/test: "ADAMTS-13 Activity & Inhibitor \[Referred\]"[\s\S]*?ranges: "[^"]*"/g, `test: "ADAMTS TS-13 Activity/ Inhibitor [Referred]",
    lab: "Ref: Clinical Haematology Referral Laboratory, Hospital Ampang",
    container: "One (1) Trisodium Citrate 3.2% tube",
    specimen: "Blood (plasma)",
    volume: "1 tube x 2.7 ml",
    ltat: "6 WEEKS",
    remark: "HOSPITAL AMPANG SPECIAL HAEMATOLOGY REQUISITION FORM. Deliver tubes immediately to the laboratory at room temperature. OR Separate plasma from cells as soon as possible (double spin) within 4 hours from time of collection. Platelet count must be <10x10^9/L in plasma prior to freezing. Store frozen at -40°C and transport frozen plasma on dried ice. Requesting clinician must call Haematologist Hospital Ampang before sending the sample/s to HKL Lab.",
    ranges: "Refer to referring laboratory report."`);

// Replace sEPO
code = code.replace(/test: "Serum Erythropoietin \(sEPO\) \[Referred\]"[\s\S]*?ranges: "[^"]*"/g, `test: "Serum EPO (Erythropoietin) - ELISA [Referred]",
    lab: "Ref: Clinical Haematology Referral Laboratory, Hospital Ampang",
    container: "Four (4) Plain tubes",
    specimen: "Blood (serum)",
    volume: "4 tubes x 2.0 ml",
    ltat: "MDS : 8 WEEKS, MPN & PRV : 12 WEEKS",
    remark: "HOSPITAL AMPANG SPECIAL HAEMATOLOGY REQUISITION FORM. All request must be accompanied with recent FBC result. Deliver tubes immediately to the laboratory at room temperature. OR Separate serum from cells as soon as possible (Separated serum minimum 1.5 ml). Store frozen at -40°C and transport frozen serum on dried ice. Requesting clinician must call Haematologist Hospital Ampang before sending the sample/s to HKL Lab.",
    ranges: "Refer to referring laboratory report."`);

// Replace FISH
code = code.replace(/test: "Fluorescence In Situ Hybridization \(FISH\) \[Referred\]"[\s\S]*?ranges: "[^"]*"/g, `test: "Leukemia FISH Analysis (For MPN case) [Referred]",
    lab: "Ref: Clinical Haematology Referral Laboratory, Hospital Ampang",
    container: "Three (3) Sodium Heparin",
    specimen: "Whole Blood / Bone Marrow Aspirate",
    volume: "WB: 5 tubes x 2.0 ml (Min 10 ml), BMA: 1 tube x 2.0 ml (Min 2.0 ml)",
    ltat: "18 DAYS",
    remark: "HOSPITAL AMPANG SPECIAL HAEMATOLOGY REQUISITION FORM. Transport samples without delay preferably within 24 hours at room temperature (20-24°C). DO NOT FREEZE specimens. Requesting clinician must call Haematologist Hospital Ampang before sending the sample/s to HKL Lab.",
    ranges: "Refer to referring laboratory report."`);


fs.writeFileSync('src/data/labs.ts', code);
console.log('Successfully replaced remaining tests.');

