const fs = require('fs');
const path = require('path');

const filePath = path.join(__dirname, 'src/data/labs.ts');
let content = fs.readFileSync(filePath, 'utf8');

const missingLabs = `,
  {
    "test": "Myositis Extended Panel [Referred]",
    "lab": "Ref: IMR Autoimmune Unit",
    "container": "Plain tube with gel (yellow cap)",
    "specimen": "Blood",
    "volume": "3 ml",
    "ltat": "14 to 30 working days",
    "remark": "FORM: PER-PAT 301. Evaluates for idiopathic inflammatory myopathies (e.g., polymyositis, dermatomyositis). Includes Mi-2, Ku, PM-Scl, SRP, Jo-1, PL-7, PL-12, EJ, OJ, Ro-52.",
    "ranges": "Negative."
  }
];`;

content = content.replace(/\];\s*$/, missingLabs);
fs.writeFileSync(filePath, content, 'utf8');
console.log('Added myositis panel');
