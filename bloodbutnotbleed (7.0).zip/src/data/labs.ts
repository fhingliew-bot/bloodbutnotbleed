import { LabTest } from "../types";

export const testDatabase: LabTest[] = [
  {
    "test": "Acetaminophen",
    "lab": "Core Lab",
    "container": "Plain tube without gel (red cap)",
    "specimen": "Blood",
    "volume": "4 ml",
    "ltat": "1 hour (Urgent), 1 day for external user",
    "remark": "Therapeutic Drug Monitoring (TDM) Request Form/PER-PAT 301 form (In-house)",
    "ranges": "Therapeutic profile: 10-30 mg/L. Toxic threshold: >150 mg/L at 4 hours post-ingestion."
  },
  {
    "test": "Adrenocorticotropic Hormone (ACTH)",
    "lab": "Special Chemical Pathology",
    "container": "EDTA tube",
    "specimen": "Plasma",
    "volume": "3 ml",
    "ltat": "5 working days",
    "remark": "Put in ice once blood drawed and send to the lab immediately. Use refrigerated centrifuge. Plasma stability: 10 weeks at -20°C",
    "ranges": "7.2 - 63.3 pg/mL (Diurnal variation: collection between 07:00-10:00 AM preferred)."
  },
  {
    "test": "Alanine transaminase (ALT)",
    "lab": "Core Lab SCACC Lab",
    "container": "Lithium heparin tube",
    "specimen": "Blood",
    "volume": "4 ml",
    "ltat": "1 hour (Urgent), 3 hours (Routine), 6 hours (SCACC-Routine), 3 working days external",
    "remark": "SCACC Lab for routine test only",
    "ranges": "Male: <50 U/L, Female: <35 U/L."
  },
  {
    "test": "Albumin",
    "lab": "Core Lab SCACC Lab",
    "container": "Lithium heparin tube",
    "specimen": "Blood",
    "volume": "4 ml",
    "ltat": "1 hour (Urgent), 3 hours (Routine), 6 hours (SCACC-Routine), 3 working days external",
    "remark": "SCACC Lab for routine test only",
    "ranges": "35 - 52 g/L."
  },
  {
    "test": "Albumin Creatinine Ratio, Urine",
    "lab": "Core Lab SCACC Lab",
    "container": "Sterile urine container",
    "specimen": "First morning urine (preferred). Random acceptable",
    "volume": "5 ml",
    "ltat": "1 working day, 6 hours (SCACC-Routine), 3 working days external",
    "remark": "SCACC Lab for routine test only",
    "ranges": "Normal: <2.5 mg/mmol (Male), <3.5 mg/mmol (Female). Microalbuminuria: 2.5-30 mg/mmol."
  },
  {
    "test": "Albumin, Fluid",
    "lab": "Core Lab",
    "container": "Plain container",
    "specimen": "Body Fluid",
    "volume": "2 ml",
    "ltat": "1 hour (Urgent), 3 hours (Routine), 3 working days external",
    "remark": "Send to the laboratory as soon as possible.",
    "ranges": "Used to compute Serum-Ascites Albumin Gradient (SAAG). SAAG >11 g/L suggests portal hypertension."
  },
  {
    "test": "Alkaline phosphatase (ALP)",
    "lab": "Core Lab SCACC Lab",
    "container": "Lithium heparin tube",
    "specimen": "Blood",
    "volume": "4 ml",
    "ltat": "1 hour (Urgent), 3 hours (Routine), 6 hours (SCACC-Routine), 3 working days external",
    "remark": "SCACC Lab for routine test only",
    "ranges": "Adults: 30 - 120 U/L (Significantly higher in pediatric & obstetric cohorts)."
  },
  {
    "test": "Alpha Feto-Protein (AFP)",
    "lab": "Core Lab",
    "container": "Blood: Plain tube with gel (yellow cap). CSF/Fluid: Sterile",
    "specimen": "Blood/CSF/Body Fluid",
    "volume": "3 ml (blood), 1 ml (fluid)",
    "ltat": "2 working days, 3 working days external",
    "remark": "",
    "ranges": "Normal adults: <10 ng/mL. Malignancy index: values >400 ng/mL highly suggestive of HCC."
  },
  {
    "test": "Alpha-1-Antitrypsin",
    "lab": "Core Lab",
    "container": "Plain tube with gel (yellow cap)",
    "specimen": "Blood",
    "volume": "3 ml",
    "ltat": "2 working days, 3 working days external",
    "remark": "",
    "ranges": "0.9 - 2.0 g/L."
  },
  {
    "test": "Amikacin",
    "lab": "Core Lab",
    "container": "Plain tube without gel (red cap)",
    "specimen": "Blood",
    "volume": "4 ml",
    "ltat": "6 hours (Urgent), 1 day (Routine & External)",
    "remark": "Therapeutic Drug Monitoring (TDM) Request Form",
    "ranges": "Peak target: 20-30 mg/L (draw 30 min post-infusion). Trough target: <5 mg/L (draw directly before next dose)."
  },
  {
    "test": "Ammonia",
    "lab": "Core Lab",
    "container": "EDTA tube",
    "specimen": "Blood",
    "volume": "2 ml",
    "ltat": "1 hour (Urgent), 1 day for external user",
    "remark": "Sample should be sent immediately in ice bath. Process within 60 minutes.",
    "ranges": "15 - 45 µmol/L (Avoid fist-clenching/tourniquet stasis during phlebotomy to prevent artificial elevation)."
  },
  {
    "test": "Amphetamine Type Stimulants",
    "lab": "Drug & Toxicology Lab",
    "container": "Sterile urine container",
    "specimen": "Urine",
    "volume": "30 ml",
    "ltat": "Medical Check-up (5 days), Medicolegal (60 days), Urgent Medicolegal (14 days), Clinical (6 weeks)",
    "remark": "UPD-1 (Pindaan 2020) form for Medico-legal/Checkup",
    "ranges": "Screening Cut-off: 500 ng/mL via immunoassay assay configuration."
  },
  {
    "test": "Amylase",
    "lab": "Core Lab",
    "container": "Lithium heparin tube",
    "specimen": "Blood",
    "volume": "4 ml",
    "ltat": "1 hour (Urgent), 3 hours (Routine), 3 working days external",
    "remark": "",
    "ranges": "28 - 100 U/L. Acute pancreatitis standard diagnostic marker at >3x upper limit of normal."
  },
  {
    "test": "Amylase, Fluid",
    "lab": "Core Lab",
    "container": "Plain container",
    "specimen": "Body Fluid",
    "volume": "2 ml",
    "ltat": "1 hour (Urgent), 3 hours (Routine), 3 working days external",
    "remark": "",
    "ranges": "Elevated concentrations matching or exceeding concurrent serum index indicate pancreatic ascites/fistula."
  },
  {
    "test": "Amylase, Urine",
    "lab": "Core Lab",
    "container": "Sterile urine container /24 hr container",
    "specimen": "Random/24 hr Urine",
    "volume": "5 ml / 24 hr collection",
    "ltat": "1 hour (Urgent), 3 hours (Routine), 3 working days external",
    "remark": "",
    "ranges": "Up to 450 U/24 hours."
  },
  {
    "test": "Anemia (Ferritin, Iron, UIBC/TIBC)",
    "lab": "Core Lab",
    "container": "Plain tube with gel (yellow cap)",
    "specimen": "Blood",
    "volume": "3 ml",
    "ltat": "2 working days, 3 working days external",
    "remark": "PER-PAT 301 form (Clinical). Medical checkup ONLY via OSH Clinic",
    "ranges": "Ferritin: 30-400 ng/mL (Male), 15-150 ng/mL (Female). Serum Iron: 10-30 µmol/L. Transferrin Saturation: 20-50%."
  },
  {
    "test": "Anterior Pituitary Hormone Panel",
    "lab": "Special Chemical Pathology / Core Lab / Endocrine",
    "container": "Yellow Cap (SST) + Purple Cap (EDTA for ACTH)",
    "specimen": "Serum + EDTA Plasma",
    "volume": "3 ml Serum + 3 ml Plasma",
    "ltat": "2 to 5 working days (ACTH varies)",
    "remark": "MOH/MEMS Protocol. Draw between 08:00 AM – 09:00 AM. Includes AM Cortisol, TFT (TSH/FT4), ACTH, FSH, LH, Testosterone, Prolactin. ACTH requires a pre-chilled EDTA tube on ice, centrifuged in a refrigerated centrifuge immediately.",
    "ranges": "AM Cortisol (>350 nmol/L normal, <100 AI). FT4 (11.5 - 22.7 pmol/L) + TSH (0.27 - 4.20 mIU/L). LH & FSH (cycle dependent). Prolactin (<500 mIU/L; >5000 prolactinoma)."
  },
  {
    "test": "Antifungal TDM (Flucytosine, Isavuconazole, etc.)",
    "lab": "Drug & Toxicology Lab (IUN)",
    "container": "Plain tube without gel (red cap)",
    "specimen": "Blood",
    "volume": "4 ml",
    "ltat": "6 hours (Working days), 1 day for external user",
    "remark": "Antifungal Therapeutic Drug Monitoring (TDM) Request Form",
    "ranges": "Flucytosine peak profile: 50-100 mg/L. Avoid prolonged toxic concentrations >100 mg/L."
  },
  {
    "test": "Anti-Mullerian Hormone (AMH) [Referred]",
    "lab": "Ref: IMR Endocrine",
    "container": "Plain tube without gel (red cap)",
    "specimen": "Separated Serum/Plasma",
    "volume": "1.0 - 2.5 ml",
    "ltat": "Varies",
    "remark": "FORM: ENDOCRINE REQUEST FORM. Requires specialist signature. Separate from RBC immediately. DO NOT send in gel tube. Transport at 2-8°C (ICE).",
    "ranges": "Ovarian reserve evaluation assessment metrics vary by age group bracket."
  },
  {
    "test": "Anti-Glutamic Acid Decarboxylase (GAD 65) [Referred]",
    "lab": "Ref: IMR Endocrine",
    "container": "Plain tube without gel (red cap)",
    "specimen": "Separated Serum/Plasma",
    "volume": "1.0 - 2.5 ml",
    "ltat": "Varies",
    "remark": "FORM: ENDOCRINE REQUEST FORM. Separate from RBC immediately. DO NOT send in gel tube. Transport at 2-8°C (ICE). Requested for neurological disorders or isolated diabetes checks.",
    "ranges": "<5.0 IU/mL (Elevated profiles distinguish autoimmune Type 1 DM / LADA from Type 2)."
  },
  {
    "test": "Diabetes Antibodies Panel (ICA, GAD65, IA2) [Referred]",
    "lab": "Ref: IMR Endocrine",
    "container": "Plain tube without gel (red cap)",
    "specimen": "Separated Serum/Plasma",
    "volume": "1.0 - 2.5 ml",
    "ltat": "Varies",
    "remark": "FORM: ENDOCRINE REQUEST FORM. Includes Anti-ICA, Anti-GAD65, Anti-IA2. Send in a SINGLE request form & SINGLE tube. Separate from RBC immediately. DO NOT send in gel tube. Transport at 2-8°C (ICE).",
    "ranges": "Used to classify Type 1 Diabetes Mellitus / LADA status."
  },
  {
    "test": "17-Hydroxyprogesterone (17-OHP) [Referred]",
    "lab": "Ref: IMR Endocrine",
    "container": "Plain tube without gel (red cap)",
    "specimen": "Separated Serum/Plasma",
    "volume": "1.0 - 2.5 ml per point",
    "ltat": "Varies",
    "remark": "FORM: ENDOCRINE REQUEST FORM. For Synacthen, include 0, 30, 60 min samples in a SINGLE request form. Separate from RBC immediately. DO NOT send in gel tube. Transport at 2-8°C (ICE).",
    "ranges": "Elevated baseline or exaggerated stimulated responses evaluate for Congenital Adrenal Hyperplasia (CAH)."
  },
  {
    "test": "Antithyroglobulin",
    "lab": "Special Chemical Pathology",
    "container": "Plain tube with gel (yellow cap)",
    "specimen": "Serum",
    "volume": "3 ml",
    "ltat": "10 working days",
    "remark": "Rejection criteria: Incomplete clinical history",
    "ranges": "<115 IU/mL."
  },
  {
    "test": "Anti-thyroid Specific Peroxidase",
    "lab": "Special Chemical Pathology",
    "container": "Plain tube with gel (yellow cap)",
    "specimen": "Serum",
    "volume": "3 ml",
    "ltat": "10 working days",
    "remark": "Rejection criteria: Incomplete clinical history",
    "ranges": "<34 IU/mL."
  },
  {
    "test": "Anti-thyroid Stimulating Hormone Receptor",
    "lab": "Special Chemical Pathology",
    "container": "Plain tube with gel (yellow cap)",
    "specimen": "Serum",
    "volume": "3 ml",
    "ltat": "10 working days",
    "remark": "Requires specialist approval. Rejection criteria: Incomplete clinical history",
    "ranges": "<1.75 IU/L (Diagnostic tracking reference parameter for Graves' orbitopathy / disease validation)."
  },
  {
    "test": "Aspartate Transaminase (AST)",
    "lab": "Core Lab SCACC Lab",
    "container": "Lithium heparin tube",
    "specimen": "Blood",
    "volume": "4 ml",
    "ltat": "1 hour (Urgent), 3 hours (Routine), 6 hours (SCACC-Routine), 3 working days external",
    "remark": "SCACC Lab for routine test only",
    "ranges": "<40 U/L."
  },
  {
    "test": "Benzodiazepines (Serum)",
    "lab": "Special Chemical Pathology",
    "container": "Plain tube without gel (red cap)",
    "specimen": "Serum",
    "volume": "3 ml",
    "ltat": "1 working day",
    "remark": "Therapeutic Drug Monitoring (TDM) Request Form",
    "ranges": "Dependent upon specific molecule administration index."
  },
  {
    "test": "Benzodiazepines (Urine)",
    "lab": "Drug & Toxicology Lab",
    "container": "Sterile urine container",
    "specimen": "Urine",
    "volume": "30 ml",
    "ltat": "Medicolegal (60 days), Urgent Medicolegal (14 days), Clinical (6 weeks)",
    "remark": "UPD-1 form (Medico-legal), PER-PAT 301 form (Clinical)",
    "ranges": "Immunoassay screening benchmark criteria: 200 ng/mL cut-off window."
  },
  {
    "test": "Beta Human Chorionic Gonadotrophin (B-hCG)",
    "lab": "Core Lab",
    "container": "Blood: Plain tube with gel (yellow cap). CSF/Fluid: Sterile",
    "specimen": "Blood/CSF/Body Fluid",
    "volume": "3 ml (blood), 1 ml (fluid)",
    "ltat": "1 hour (Urgent), 2 working days (Routine), 3 working days external",
    "remark": "Urgent request requires consultation from MO",
    "ranges": "Normal males/non-pregnant females: <5 mIU/mL. Ectopic pregnancy or gestational trophoblastic disease confirmation tracks quantitative dynamic acceleration."
  },
  {
    "test": "Bilirubin - Direct",
    "lab": "Core Lab SCACC Lab",
    "container": "Lithium heparin tube",
    "specimen": "Blood",
    "volume": "4 ml",
    "ltat": "1 hour (Urgent), 3 hours (Routine), 6 hours (SCACC-Routine), 3 working days external",
    "remark": "SCACC Lab for routine test only",
    "ranges": "<5 µmol/L (Significant index indicator for obstructive biliary pathway disorders)."
  },
  {
    "test": "Bilirubin - Total",
    "lab": "Core Lab SCACC Lab",
    "container": "Lithium heparin tube",
    "specimen": "Blood",
    "volume": "4 ml",
    "ltat": "1 hour (Urgent), 3 hours (Routine), 6 hours (SCACC-Routine), 3 working days external",
    "remark": "SCACC Lab for routine test only",
    "ranges": "5 - 21 µmol/L."
  },
  {
    "test": "Bilirubin, Fluid",
    "lab": "Core Lab",
    "container": "Plain container",
    "specimen": "Body Fluid",
    "volume": "2 ml",
    "ltat": "1 hour (Urgent), 3 hours (Routine), 3 working days external",
    "remark": "Send to the laboratory as soon as possible.",
    "ranges": "Fluid to serum concentration ratio >1.0 highly correlated with localized gall bladder/biliary structural compromise."
  },
  {
    "test": "Blood Gases (ABG/VBG)",
    "lab": "Core Lab SCACC Lab",
    "container": "Preheparinized syringe / Lithium heparin tube",
    "specimen": "Blood",
    "volume": "0.6 ml / 4 ml",
    "ltat": "1 hour (Urgent), 2 hours (SCACC-Routine)",
    "remark": "Click here for Instruction On Blood Gas Sample Collection. Send ASAP in ice bath.",
    "ranges": "ABG Targets: pH 7.35-7.45, pCO2 35-45 mmHg, pO2 80-100 mmHg, HCO3 22-26 mmol/L, Base Excess -2 to +2."
  },
  {
    "test": "Calcium",
    "lab": "Core Lab SCACC Lab",
    "container": "Lithium heparin tube",
    "specimen": "Blood",
    "volume": "4 ml",
    "ltat": "1 hour (Urgent), 3 hours (Routine), 6 hours (SCACC-Routine), 3 working days external",
    "remark": "SCACC Lab for routine test only",
    "ranges": "Total Calcium: 2.15 - 2.55 mmol/L. Note: Cross-evaluate with Albumin index for corrected calcium profile calculation."
  },
  {
    "test": "Calcium, Urine",
    "lab": "Core Lab SCACC Lab",
    "container": "Sterile urine container / 24 hr container",
    "specimen": "Random/24 hr urine",
    "volume": "5 ml / 24 hr collection",
    "ltat": "1 working day, 6 hours (SCACC-Routine), 3 working days external",
    "remark": "Discard first void. Keep refrigerated.",
    "ranges": "2.5 - 7.5 mmol/24 hours."
  },
  {
    "test": "Cancer Antigen 125 (CA 125)",
    "lab": "Core Lab",
    "container": "Plain tube with gel (yellow cap)",
    "specimen": "Blood",
    "volume": "3 ml",
    "ltat": "2 working days, 3 working days external",
    "remark": "Sample Stability: 8 hrs at 20-25°C, 5 days at 2-8°C, 24 weeks at -20°C",
    "ranges": "<35 U/mL (Ovarian malignancy clinical tracking baseline benchmark)."
  },
  {
    "test": "Cancer Antigen 15-3 (CA 15-3)",
    "lab": "Core Lab",
    "container": "Plain tube with gel (yellow cap)",
    "specimen": "Blood",
    "volume": "3 ml",
    "ltat": "2 working days, 3 working days external",
    "remark": "Sample Stability: 48 hrs at 20-25°C, 5 days at 2-8°C, 90 days at -20°C",
    "ranges": "<31 U/mL (Metastatic breast cancer therapy tracking tracking asset)."
  },
  {
    "test": "Cancer Antigen 19-9 (CA 19-9)",
    "lab": "Core Lab",
    "container": "Blood: Plain tube with gel. CSF/Fluid: Sterile",
    "specimen": "Blood/CSF/Body Fluid",
    "volume": "3 ml (blood), 1 ml (fluid)",
    "ltat": "2 working days, 3 working days external",
    "remark": "",
    "ranges": "<37 U/mL (Pancreatic/hepatobiliary diagnostic evaluation parameter)."
  },
  {
    "test": "Cannabinoids (THC)",
    "lab": "Drug & Toxicology Lab",
    "container": "Sterile urine container",
    "specimen": "Urine",
    "volume": "30 ml",
    "ltat": "Medical Check-up (5 days), Medicolegal (10 days), Clinical (6 weeks)",
    "remark": "UPD-1 form for medico-legal.",
    "ranges": "Immunoassay structural analysis target: 50 ng/mL validation threshold."
  },
  {
    "test": "Carbamazepine",
    "lab": "Core Lab",
    "container": "Plain tube without gel (red cap)",
    "specimen": "Blood",
    "volume": "4 ml",
    "ltat": "6 hours (Urgent), 1 day (Routine & External)",
    "remark": "Therapeutic Drug Monitoring (TDM) Request Form",
    "ranges": "Therapeutic standard matrix range: 4 - 12 mg/L (Draw trough index directly before next package delivery schedule)."
  },
  {
    "test": "Carcinoembryonic Antigen (CEA)",
    "lab": "Core Lab",
    "container": "Blood: Plain tube with gel. CSF/Fluid: Sterile",
    "specimen": "Blood/CSF/Body Fluid",
    "volume": "3 ml (blood), 1 ml (fluid)",
    "ltat": "2 working days, 3 working days external",
    "remark": "",
    "ranges": "Nonsmokers: <3.0 ng/mL. Smokers: <5.0 ng/mL. Tracking resource for colorectal carcinoma dynamics."
  },
  {
    "test": "Cathinones (Khat, Mephedrone)",
    "lab": "Drug & Toxicology Lab",
    "container": "Sterile urine container",
    "specimen": "Urine",
    "volume": "30 ml",
    "ltat": "Medicolegal (60 days), Clinical Cases (6 weeks)",
    "remark": "UPD-1 form (Medico-legal), PER-PAT 301 form (Clinical)",
    "ranges": "Qualitative clinical identification profiling parameters."
  },
  {
    "test": "Ceruloplasmin",
    "lab": "Core Lab",
    "container": "Plain tube with gel (yellow cap)",
    "specimen": "Blood",
    "volume": "3 ml",
    "ltat": "2 working days, 3 working days external",
    "remark": "",
    "ranges": "200 - 600 mg/L (Marked structural degradation tracks closely with Wilson's disease profile)."
  },
  {
    "test": "Chloride",
    "lab": "Core Lab SCACC Lab",
    "container": "Lithium heparin tube",
    "specimen": "Blood",
    "volume": "4 ml",
    "ltat": "1 hour (Urgent), 3 hours (Routine), 6 hours (SCACC-Routine), 3 working days external",
    "remark": "SCACC Lab for routine test only",
    "ranges": "98 - 107 mmol/L."
  },
  {
    "test": "Chloride, Fluid",
    "lab": "Core Lab",
    "container": "Plain container",
    "specimen": "Body Fluid",
    "volume": "2 ml",
    "ltat": "1 hour (Urgent), 3 hours (Routine), 3 working days external",
    "remark": "Send to the laboratory as soon as possible.",
    "ranges": "Interpreted via paired concurrent systemic metabolic structural arrays."
  },
  {
    "test": "Chloride, Urine",
    "lab": "Core Lab SCACC Lab",
    "container": "Sterile urine container / 24 hr container",
    "specimen": "Random/24 hr urine",
    "volume": "5 ml / 24 hr collection",
    "ltat": "1 hour (Urgent), 3 hours (Routine), 6 hours (SCACC-Routine), 3 working days external",
    "remark": "",
    "ranges": "110 - 250 mmol/24 hours (Highly dependent upon physical dietary inputs)."
  },
  {
    "test": "Cholesterol",
    "lab": "Core Lab SCACC Lab",
    "container": "Lithium heparin tube",
    "specimen": "Blood",
    "volume": "4 ml",
    "ltat": "1 hour (Urgent), 3 hours (Routine), 6 hours (SCACC-Routine), 3 working days external",
    "remark": "SCACC Lab for routine test only",
    "ranges": "Desirable concentration range: <5.2 mmol/L."
  },
  {
    "test": "Cholesterol, Fluid",
    "lab": "Core Lab",
    "container": "Plain container",
    "specimen": "Body Fluid",
    "volume": "2 ml",
    "ltat": "1 hour (Urgent), 3 hours (Routine), 3 working days external",
    "remark": "Send to the laboratory as soon as possible.",
    "ranges": "Fluid concentration >1.1 mmol/L differentiates exudative effusions from transudative baseline patterns."
  },
  {
    "test": "Cholinestrase",
    "lab": "Core Lab",
    "container": "Plain tube with gel (yellow cap)",
    "specimen": "Blood",
    "volume": "3 ml",
    "ltat": "1 working day, 3 working days external",
    "remark": "",
    "ranges": "5320 - 12920 U/L (Degraded levels note organophosphate insecticide toxicity exposure risks)."
  },
  {
    "test": "Complement C3",
    "lab": "Core Lab",
    "container": "Plain tube with gel (yellow cap)",
    "specimen": "Blood",
    "volume": "3 ml",
    "ltat": "2 working days, 3 working days external",
    "remark": "PER-PAT 301 form",
    "ranges": "0.9 - 1.8 g/L (Consumption drop signals acute post-streptococcal glomerulonephritis / lupus nephritis flares)."
  },
  {
    "test": "Complement C4",
    "lab": "Core Lab",
    "container": "Plain tube with gel (yellow cap)",
    "specimen": "Blood",
    "volume": "3 ml",
    "ltat": "2 working days, 3 working days external",
    "remark": "PER-PAT 301 form",
    "ranges": "0.1 - 0.4 g/L."
  },
  {
    "test": "Cooximetry Profile",
    "lab": "Core Lab",
    "container": "Pre-heparinized syringe",
    "specimen": "Blood",
    "volume": "1 ml",
    "ltat": "1 hour (Urgent)",
    "remark": "For HKL internal wards only. MetHb, COHb, O2Hb, HHb",
    "ranges": "Carboxyhemoglobin (COHb): <1.5% (nonsmokers), <9% (smokers). Methemoglobin (MetHb): <1.5%."
  },
  {
    "test": "Cortisol, serum",
    "lab": "Core Lab",
    "container": "Plain tube with gel (yellow cap)",
    "specimen": "Blood",
    "volume": "3 ml",
    "ltat": "2 working days, 3 working days external",
    "remark": "Morning: 6-10 am. Evening: 4-8 pm.",
    "ranges": "Morning (08:00 AM): 171 - 536 nmol/L. Evening (04:00 PM): 64 - 327 nmol/L. Stated collection timestamp is mandatory."
  },
  {
    "test": "C-Peptide",
    "lab": "Special Chemical Pathology",
    "container": "Plain tube with gel (yellow cap)",
    "specimen": "Serum",
    "volume": "3 ml",
    "ltat": "5 working days",
    "remark": "",
    "ranges": "1.1 - 4.4 ng/mL (Helhelps differentiate exogenous insulin administration toxicity from endogenous insulin production/insulinoma)."
  },
  {
    "test": "C-Reactive protein",
    "lab": "Core Lab",
    "container": "Plain tube with gel (yellow cap) / Lithium heparin tube",
    "specimen": "Blood",
    "volume": "3 ml",
    "ltat": "1 day, 3 working days external",
    "remark": "",
    "ranges": "Normal baseline: <5 mg/L. Acute inflammatory reaction states elevate index significantly."
  },
  {
    "test": "Creatine kinase",
    "lab": "Core Lab SCACC Lab",
    "container": "Lithium heparin tube",
    "specimen": "Blood",
    "volume": "4 ml",
    "ltat": "1 hour (Urgent), 3 hours (Routine), 6 hours (SCACC-Routine), 3 working days external",
    "remark": "SCACC Lab for routine test only",
    "ranges": "Male: 39 - 308 U/L. Female: 26 - 192 U/L. Striated muscle pathology shifts numbers radically."
  },
  {
    "test": "Creatinine",
    "lab": "Core Lab SCACC Lab",
    "container": "Lithium heparin tube",
    "specimen": "Blood",
    "volume": "4 ml",
    "ltat": "1 hour (Urgent), 3 hours (Routine), 6 hours (SCACC-Routine), 3 working days external",
    "remark": "SCACC Lab for routine test only",
    "ranges": "Male: 62 - 106 µmol/L. Female: 44 - 80 µmol/L."
  },
  {
    "test": "Creatinine clearance",
    "lab": "Core Lab SCACC Lab",
    "container": "24 hr Urine container & Lithium heparin tube",
    "specimen": "Blood & Urine",
    "volume": "4 ml (blood) & 24 hr Urine",
    "ltat": "1 hour (Urgent), 3 hours (Routine), 6 hours (SCACC-Routine), 3 working days external",
    "remark": "Requires 24-hr urine and blood sample drawn within 24 hr.",
    "ranges": "90 - 139 mL/min (Male), 80 - 125 mL/min (Female). Tracks explicit renal clearance patterns."
  },
  {
    "test": "Creatinine, Fluid",
    "lab": "Core Lab",
    "container": "Plain container",
    "specimen": "Body Fluid",
    "volume": "2 ml",
    "ltat": "1 hour (Urgent), 3 hours (Routine), 3 working days external",
    "remark": "Send to the laboratory as soon as possible.",
    "ranges": "Used to confirm suspected local anatomical structural leakage (urinary extravasation vs ascites fluid accumulation)."
  },
  {
    "test": "Creatinine, Urine",
    "lab": "Core Lab SCACC Lab",
    "container": "Sterile urine container / 24 hr container",
    "specimen": "Random/24 hr urine",
    "volume": "5 ml / 24 hr collection",
    "ltat": "1 working day, 3 working days external",
    "remark": "",
    "ranges": "9 - 19 mmol/24 hours."
  },
  {
    "test": "CSF Biochemistry (Glucose, Protein, Appearance)",
    "lab": "Core Lab",
    "container": "Fluoride tube/Sterile Bijou bottle",
    "specimen": "CSF",
    "volume": "1 ml",
    "ltat": "1 hour (Urgent)",
    "remark": "Send to the laboratory as soon as possible.",
    "ranges": "Protein: 0.15-0.45 g/L. Glucose: 2.2-4.2 mmol/L (or >60% of paired peripheral blood glucose index). Appearance: Clear and colorless."
  },
  {
    "test": "Dehydroepiandrosterone Sulfate (DHEA-S)",
    "lab": "Special Chemical Pathology",
    "container": "Plain tube with gel (yellow cap)",
    "specimen": "Serum",
    "volume": "3 ml",
    "ltat": "5 working days",
    "remark": "Serum stability: 5 days at 20-25°C, 14 days at 2-8°C, 12 months at -20°C",
    "ranges": "Highly stratified by age demographics and biological sexes."
  },
  {
    "test": "Digoxin",
    "lab": "Core Lab",
    "container": "Plain tube without gel (red cap)",
    "specimen": "Blood",
    "volume": "4 ml",
    "ltat": "6 hours (Urgent), 1 day (Routine & External)",
    "remark": "Therapeutic Drug Monitoring (TDM) Request Form",
    "ranges": "Therapeutic baseline limit target: 0.5 - 2.0 µg/L. Collect sample minimum 6-8 hours post-dose administration to avoid tracking initial redistribution artifacts."
  },
  {
    "test": "Estradiol (Oestradiol/E2)",
    "lab": "Core Lab",
    "container": "Plain tube with gel (yellow cap)",
    "specimen": "Blood",
    "volume": "3 ml",
    "ltat": "2 working days, 3 working days external",
    "remark": "Blood taking at Day 2 to Day 5 menses",
    "ranges": "Follicular phase baseline: 73 - 551 pmol/L. Luteal phase shifts: 131 - 1655 pmol/L. Postmenopausal: <184 pmol/L."
  },
  {
    "test": "Ethanol",
    "lab": "Core Lab",
    "container": "Plain tube without gel (red cap)",
    "specimen": "Blood",
    "volume": "4 ml",
    "ltat": "1 hour (Urgent), 1 day for external user",
    "remark": "Therapeutic Drug Monitoring (TDM) Request Form",
    "ranges": "Toxic impairment baseline marker threshold: >80 mg/dL (>17.4 mmol/L). Note: Avoid alcohol swab decontamination for puncture site preparation."
  },
  {
    "test": "Fasting Serum Lipid (FSL)",
    "lab": "Core Lab SCACC Lab",
    "container": "Lithium heparin tube",
    "specimen": "Blood",
    "volume": "4 ml",
    "ltat": "1 hour (Urgent), 3 hours (Routine), 6 hours (SCACC-Routine), 3 working days external",
    "remark": "Non-fasting acceptable for routine screening unless fasting specifically requested. Otherwise, fast 8-12 hours.",
    "ranges": "Triglycerides: <1.7 mmol/L. HDL: >1.0 mmol/L (Male), >1.2 mmol/L (Female). LDL target tracking calibrated via overall cardiovascular disease classification risk scales."
  },
  {
    "test": "Ferritin",
    "lab": "Core Lab",
    "container": "Plain tube with gel (yellow cap)",
    "specimen": "Blood",
    "volume": "3 ml",
    "ltat": "2 working days, 3 working days external",
    "remark": "",
    "ranges": "30 - 400 ng/mL (Male), 15 - 150 ng/mL (Female). Acute phase reactant behavior can obscure underlying iron stores deficiency dynamics during active inflammatory phases."
  },
  {
    "test": "Fertility Test (FSH, LH, E2, Progesterone, Prolactin, Testo)",
    "lab": "Core Lab",
    "container": "Plain tube with gel (yellow cap)",
    "specimen": "Blood",
    "volume": "3 ml",
    "ltat": "2 working days, 3 working days external",
    "remark": "Progesterone at day 21. FSH, LH, E2 at day 2 to 5 of menses.",
    "ranges": "Interpretation strictly requires clinical cross-matching with concurrent menstrual tracking diary entries."
  },
  {
    "test": "Fluid Biochemistry (Glucose, Protein, LDH, pH)",
    "lab": "Core Lab",
    "container": "Plain container",
    "specimen": "Body Fluid",
    "volume": "2 ml",
    "ltat": "1 hour (Urgent), 2 working days, 3 working days external",
    "remark": "Send to the laboratory as soon as possible.",
    "ranges": "Evaluated using Light's Criteria framework for pleural exudate validation (Fluid/Serum Protein ratio >0.5, Fluid/Serum LDH ratio >0.6)."
  },
  {
    "test": "Folate",
    "lab": "Core Lab",
    "container": "Plain tube with gel (yellow cap)",
    "specimen": "Blood",
    "volume": "3 ml",
    "ltat": "2 working days, 3 working days external",
    "remark": "",
    "ranges": "Normal concentration index: >10 nmol/L."
  },
  {
    "test": "Follicle Stimulating Hormone (FSH)",
    "lab": "Core Lab",
    "container": "Plain tube with gel (yellow cap)",
    "specimen": "Blood",
    "volume": "3 ml",
    "ltat": "2 working days, 3 working days external",
    "remark": "",
    "ranges": "Follicular phase: 3.5 - 12.5 IU/L. Postmenopausal transition elevation: >25.8 IU/L."
  },
  {
    "test": "Free Thyroxine (FT4)",
    "lab": "Core Lab",
    "container": "Plain tube with gel (yellow cap)",
    "specimen": "Blood",
    "volume": "3 ml",
    "ltat": "2 working days, 3 working days external",
    "remark": "",
    "ranges": "12.0 - 22.0 pmol/L."
  },
  {
    "test": "Free Triiodothyronine (FT3)",
    "lab": "Core Lab",
    "container": "Plain tube with gel (yellow cap)",
    "specimen": "Blood",
    "volume": "3 ml",
    "ltat": "2 working days, 3 working days external",
    "remark": "",
    "ranges": "3.1 - 6.8 pmol/L."
  },
  {
    "test": "Gamma-glutamyltransferase (GGT)",
    "lab": "Core Lab",
    "container": "Plain tube with gel (yellow cap)",
    "specimen": "Blood",
    "volume": "3 ml",
    "ltat": "2 working days, 3 working days external",
    "remark": "",
    "ranges": "<60 U/L (Male), <40 U/L (Female). High specificity for hepatic tract etiology during concurrent alkaline phosphatase elevation phases."
  },
  {
    "test": "Gentamicin",
    "lab": "Core Lab",
    "container": "Plain tube without gel (red cap)",
    "specimen": "Blood",
    "volume": "4 ml",
    "ltat": "6 hours (Urgent), 1 day (Routine & External)",
    "remark": "Therapeutic Drug Monitoring (TDM) Request Form",
    "ranges": "Traditional dosing trough: <2 mg/L. Peak: 5-10 mg/L. Pulse high-dose configuration models track trough parameter exclusion values <0.5 mg/L."
  },
  {
    "test": "Glucose (FBS, 2HPP, RBS)",
    "lab": "Core Lab SCACC Lab",
    "container": "Fluoride tube",
    "specimen": "Blood",
    "volume": "2 ml",
    "ltat": "1 hour (Urgent), 3 hours (Routine), 6 hours (SCACC-Routine), 3 working days external",
    "remark": "FBS requires 8-12 hours fasting. Water allowed.",
    "ranges": "Fasting Blood Glucose target index: 3.9 - 5.5 mmol/L. Impaired fasting glucose spectrum: 5.6 - 6.9 mmol/L. Diabetes Mellitus threshold validation: Fasting index ≥7.0 mmol/L or Random index ≥11.1 mmol/L alongside canonical clinical features."
  },
  {
    "test": "Glucose, CSF",
    "lab": "Core Lab",
    "container": "Fluoride tube/Sterile Bijou bottle",
    "specimen": "CSF",
    "volume": "1 ml",
    "ltat": "1 hour (Urgent)",
    "remark": "Send to the laboratory as soon as possible.",
    "ranges": "2.2 - 4.2 mmol/L. Pathological drop below 0.4 CSF-to-peripheral serum glucose ratio correlates heavily with acute purulent bacterial meningitis structures."
  },
  {
    "test": "Haemoglobin A1c (HbA1c)",
    "lab": "Special Chemical Pathology",
    "container": "EDTA tube",
    "specimen": "Whole blood",
    "volume": "3 ml",
    "ltat": "3 working days",
    "remark": "Rejection criteria: Request less than 3 months (12 weeks) from previous.",
    "ranges": "Normal matrix range: <5.7%. High-risk/Prediabetes target: 5.7 - 6.4%. Diagnostic diabetes verification index: ≥6.5%. "
  },
  {
    "test": "Immunosuppressants TDM (Cyclosporin, Everolimus, Tacrolimus)",
    "lab": "Drug & Toxicology Lab (IUN)",
    "container": "EDTA tube",
    "specimen": "Blood",
    "volume": "2 ml",
    "ltat": "Results issued on same day",
    "remark": "Therapeutic Drug Monitoring (TDM) Request Form",
    "ranges": "Target concentration matrix parameters scale dynamically on timeline context relative to organ transplantation procedures."
  },
  {
    "test": "Insulin",
    "lab": "Special Chemical Pathology",
    "container": "Plain tube with gel (yellow cap)",
    "specimen": "Serum",
    "volume": "3 ml",
    "ltat": "5 working days",
    "remark": "Serum stability: 4 hrs at 20-25°C, 2 days at 2-8°C, 6 months at -20°C",
    "ranges": "Fasting concentration parameters: 2.6 - 24.9 µIU/mL."
  },
  {
    "test": "Iron (Fe)",
    "lab": "Core Lab",
    "container": "Plain tube with gel (yellow cap)",
    "specimen": "Blood",
    "volume": "3 ml",
    "ltat": "2 working days, 3 working days external",
    "remark": "",
    "ranges": "10 - 30 µmol/L (Clear diurnal fluctuation tracking requires early morning phlebotomy context for reliable tracking)."
  },
  {
    "test": "Ketamine / Norketamine",
    "lab": "Drug & Toxicology Lab",
    "container": "Sterile urine container",
    "specimen": "Urine",
    "volume": "30 ml",
    "ltat": "Medicolegal cases (60 days), Urgent (14 days), Clinical (6 weeks)",
    "remark": "UPD-1 form (Medico-legal), PER-PAT 301 form (Clinical)",
    "ranges": "Qualitative verification profiling tracking parameters."
  },
  {
    "test": "Lactate",
    "lab": "Core Lab",
    "container": "Fluoride tube",
    "specimen": "Blood",
    "volume": "2 ml",
    "ltat": "1 hour (Urgent)",
    "remark": "Send immediately in ice bath. Process within 15 mins.",
    "ranges": "0.5 - 2.2 mmol/L. Critical hyperlactatemia values >4.0 mmol/L flag peripheral hypoperfusion during sepsis resuscitation tracking phases."
  },
  {
    "test": "Lactate Dehydrogenase (LDH)",
    "lab": "Core Lab SCACC Lab",
    "container": "Lithium heparin tube",
    "specimen": "Blood",
    "volume": "4 ml",
    "ltat": "1 hour (Urgent), 3 hours (Routine), 6 hours (SCACC-Routine), 3 working days external",
    "remark": "SCACC Lab for routine test only",
    "ranges": "135 - 225 U/L (Nonspecific intracellular enzyme marker; highly susceptible to false-positive shifts from structural erythrocyte hemolysis in transit)."
  },
  {
    "test": "Liver Function Test (LFT)",
    "lab": "Core Lab SCACC Lab",
    "container": "Lithium heparin tube",
    "specimen": "Blood",
    "volume": "4 ml",
    "ltat": "1 hour (Urgent), 3 hours (Routine), 6 hours (SCACC-Routine), 3 working days external",
    "remark": "Includes TP, Alb, Bilirubin, ALP, ALT, Globulin, A/G Ratio",
    "ranges": "Integrated comprehensive assessment of absolute synthesis and clearance function arrays."
  },
  {
    "test": "Luteinising Hormone (LH)",
    "lab": "Core Lab",
    "container": "Plain tube with gel (yellow cap)",
    "specimen": "Blood",
    "volume": "3 ml",
    "ltat": "2 working days, 3 working days external",
    "remark": "Blood taking at Day 2 to Day 5 menses",
    "ranges": "Follicular profile: 2.4 - 12.6 IU/L. Ovulatory surge tracking metrics escalate rapidly to 14.0 - 95.6 IU/L."
  },
  {
    "test": "Magnesium",
    "lab": "Core Lab SCACC Lab",
    "container": "Lithium heparin tube",
    "specimen": "Blood",
    "volume": "4 ml",
    "ltat": "1 hour (Urgent), 3 hours (Routine), 6 hours (SCACC-Routine), 3 working days external",
    "remark": "SCACC Lab for routine test only",
    "ranges": "0.66 - 1.07 mmol/L (Cross-check explicitly during intractable structural hypokalemia tracking maneuvers)."
  },
  {
    "test": "Mitragynine (Ketum)",
    "lab": "Drug & Toxicology Lab",
    "container": "Sterile urine container",
    "specimen": "Urine",
    "volume": "30 ml",
    "ltat": "Medicolegal cases (60 days), Clinical (6 weeks)",
    "remark": "UPD-1 form (Medico-legal), PER-PAT 301 form (Clinical)",
    "ranges": "Forensic screening array configurations."
  },
  {
    "test": "Occult Blood",
    "lab": "Core Lab",
    "container": "Stool container",
    "specimen": "Stool",
    "volume": "1g",
    "ltat": "1 hour (Urgent), 3 hours (Routine), 3 working days external",
    "remark": "",
    "ranges": "Negative target result threshold."
  },
  {
    "test": "Opioids (Methadone, Buprenorphine, Fentanyl, etc.)",
    "lab": "Drug & Toxicology Lab",
    "container": "Sterile urine container",
    "specimen": "Urine",
    "volume": "30 ml",
    "ltat": "Medicolegal (60 days), Clinical Cases (6 weeks)",
    "remark": "UPD-1 form (Medico-legal), PER-PAT 301 form (Clinical)",
    "ranges": "Qualitative toxicological asset parameters."
  },
  {
    "test": "Opioids (Morphine, Codeine, Tramadol)",
    "lab": "Drug & Toxicology Lab",
    "container": "Sterile urine container",
    "specimen": "Urine",
    "volume": "30 ml",
    "ltat": "Medical Check-up (5 days), Medicolegal (10 days), Clinical (6 weeks)",
    "remark": "UPD-1 form for medico-legal",
    "ranges": "Standard immunoassay screening baseline target validation tracking configuration: 300 ng/mL validation threshold."
  },
  {
    "test": "Paraquat, Urine",
    "lab": "Core Lab",
    "container": "Sterile urine container",
    "specimen": "Urine",
    "volume": "10 ml",
    "ltat": "1 hour (Urgent)",
    "remark": "Available 24 hrs, PER-PAT 301 form",
    "ranges": "Dithionite test validation deployment: Color change tracking determines qualitative presence indices directly."
  },
  {
    "test": "Phenytoin",
    "lab": "Core Lab",
    "container": "Plain tube without gel (red cap)",
    "specimen": "Blood",
    "volume": "4 ml",
    "ltat": "6 hours (Urgent), 1 day (Routine & External)",
    "remark": "Therapeutic Drug Monitoring (TDM) Request Form",
    "ranges": "Total therapeutic target profile: 10 - 20 mg/L (Note: Strongly bound to serum albumin structural components; normalize metrics explicitly during concurrent uremic or severe hypoalbuminemia phases)."
  },
  {
    "test": "Phosphate",
    "lab": "Core Lab SCACC Lab",
    "container": "Lithium heparin tube",
    "specimen": "Blood",
    "volume": "4 ml",
    "ltat": "1 hour (Urgent), 3 hours (Routine), 6 hours (SCACC-Routine), 3 working days external",
    "remark": "SCACC Lab for routine test only",
    "ranges": "0.74 - 1.52 mmol/L."
  },
  {
    "test": "Potassium",
    "lab": "Core Lab SCACC Lab",
    "container": "Lithium heparin tube",
    "specimen": "Blood",
    "volume": "4 ml",
    "ltat": "1 hour (Urgent), 3 hours (Routine), 6 hours (SCACC-Routine), 3 working days external",
    "remark": "SCACC Lab for routine test only",
    "ranges": "3.5 - 5.0 mmol/L. Note: Critical pathology indicators flag risks at indices <3.0 mmol/L or >6.0 mmol/L due to dangerous cardiac conduction arrhythmias."
  },
  {
    "test": "Procalcitonin",
    "lab": "Core Lab",
    "container": "Plain tube with gel (yellow cap)",
    "specimen": "Blood",
    "volume": "3 ml",
    "ltat": "1 day",
    "remark": "",
    "ranges": "<0.05 ng/mL. Systemic septic shock threat markers track values crossing structural thresholds >2.0 ng/mL."
  },
  {
    "test": "Protein, CSF",
    "lab": "Core Lab",
    "container": "Fluoride tube/Sterile Bijou bottle",
    "specimen": "CSF",
    "volume": "1 ml",
    "ltat": "1 hour (Urgent)",
    "remark": "Send to the laboratory as soon as possible.",
    "ranges": "0.15 - 0.45 g/L (Marked structural accumulation flags bacterial etiology or albuminocytologic dissociation pathways)."
  },
  {
    "test": "Protein, Total",
    "lab": "Core Lab SCACC Lab",
    "container": "Lithium heparin tube",
    "specimen": "Blood",
    "volume": "4 ml",
    "ltat": "1 hour (Urgent), 3 hours (Routine), 6 hours (SCACC-Routine), 3 working days external",
    "remark": "SCACC Lab for routine test only",
    "ranges": "64 - 83 g/L."
  },
  {
    "test": "Protein, Urine",
    "lab": "Core Lab SCACC Lab",
    "container": "Sterile urine container / 24 hr container",
    "specimen": "Random/24 hr urine",
    "volume": "5 ml / 24 hr collection",
    "ltat": "1 working day, 6 hours (SCACC-Routine), 3 working days external",
    "remark": "",
    "ranges": "<150 mg/24 hours. Nephrotic range proteinuria definitions lock in parameters crossing >3.5g/24 hours."
  },
  {
    "test": "Renal Profile (RP)",
    "lab": "Core Lab SCACC Lab",
    "container": "Lithium heparin tube",
    "specimen": "Blood",
    "volume": "4 ml",
    "ltat": "1 hour (Urgent), 3 hours (Routine), 6 hours (SCACC-Routine), 3 working days external",
    "remark": "Urea, Creatinine, Chloride, Potassium, Sodium, eGFR",
    "ranges": "Comprehensive tracking configuration matching basic metabolic maintenance systems."
  },
  {
    "test": "Rheumatoid Factor",
    "lab": "Special Chemical Pathology",
    "container": "Plain tube with gel (yellow cap)",
    "specimen": "Serum",
    "volume": "3 ml",
    "ltat": "5 working days",
    "remark": "",
    "ranges": "<14 IU/mL."
  },
  {
    "test": "Salicylate",
    "lab": "Core Lab",
    "container": "Plain tube without gel (red cap)",
    "specimen": "Blood",
    "volume": "4 ml",
    "ltat": "1 hour (Urgent), 1 day for external user",
    "remark": "Therapeutic Drug Monitoring (TDM) Request Form",
    "ranges": "Therapeutic analgesic spectrum baseline: 30-100 mg/L. Severe systemic acid-base metabolic toxic shock states occur at values exceeding >300 mg/L."
  },
  {
    "test": "Serum Bilirubin (Total, Direct, Indirect)",
    "lab": "Core Lab",
    "container": "Lithium heparin tube",
    "specimen": "Blood",
    "volume": "4 ml",
    "ltat": "1 hour (Urgent), 3 hours (Routine), 3 working days external",
    "remark": "SCACC Lab for routine test only",
    "ranges": "Clinical jaundice indexes manifest physically when total bilirubin targets cross past >34-50 µmol/L boundaries."
  },
  {
    "test": "Sodium",
    "lab": "Core Lab SCACC Lab",
    "container": "Lithium heparin tube",
    "specimen": "Blood",
    "volume": "4 ml",
    "ltat": "1 hour (Urgent), 3 hours (Routine), 6 hours (SCACC-Routine), 3 working days external",
    "remark": "SCACC Lab for routine test only",
    "ranges": "135 - 145 mmol/L. Severe neuro-structural danger indexes track closely when parameters drop <120 mmol/L or push past >160 mmol/L."
  },
  {
    "test": "Testosterone",
    "lab": "Core Lab",
    "container": "Plain tube with gel (yellow cap)",
    "specimen": "Blood",
    "volume": "3 ml",
    "ltat": "2 working days, 3 working days external",
    "remark": "",
    "ranges": "Adult Male: 8.6 - 29.0 nmol/L. Adult Female: 0.3 - 1.7 nmol/L."
  },
  {
    "test": "Thyroid Function Test (TSH, FT4)",
    "lab": "Core Lab",
    "container": "Plain tube with gel (yellow cap)",
    "specimen": "Blood",
    "volume": "3 ml",
    "ltat": "2 working days, 3 working days external",
    "remark": "",
    "ranges": "TSH: 0.27 - 4.20 mIU/L. Paired alongside Free T4 parameters to accurately isolate primary vs central thyroid tracking axes."
  },
  {
    "test": "Triglycerides",
    "lab": "Core Lab SCACC Lab",
    "container": "Lithium heparin tube",
    "specimen": "Blood",
    "volume": "4 ml",
    "ltat": "1 hour (Urgent), 3 hours (Routine), 6 hours (SCACC-Routine), 3 working days external",
    "remark": "SCACC Lab for routine test only",
    "ranges": "<1.7 mmol/L. Values exceeding >5.6 mmol/L present acute high-risk secondary triggers for clinical pancreatitis development."
  },
  {
    "test": "Troponin T high sensitive",
    "lab": "Core Lab",
    "container": "Lithium heparin tube / Plain tube",
    "specimen": "Blood",
    "volume": "3 ml",
    "ltat": "1 hour (Urgent)",
    "remark": "Send to the laboratory as soon as possible. Essential diagnostic marker for acute heart failure pathway.",
    "ranges": "<14 ng/L. Serial delta changes tracking over a 1-3 hour window determine acute myocardial infarction kinetics."
  },
  {
    "test": "Urea",
    "lab": "Core Lab SCACC Lab",
    "container": "Lithium heparin tube",
    "specimen": "Blood",
    "volume": "4 ml",
    "ltat": "1 hour (Urgent), 3 hours (Routine), 6 hours (SCACC-Routine), 3 working days external",
    "remark": "SCACC Lab for routine test only",
    "ranges": "1.7 - 8.3 mmol/L."
  },
  {
    "test": "Uric Acid",
    "lab": "Core Lab SCACC Lab",
    "container": "Lithium heparin tube",
    "specimen": "Blood",
    "volume": "4 ml",
    "ltat": "1 hour (Urgent), 3 hours (Routine), 6 hours (SCACC-Routine), 3 working days external",
    "remark": "SCACC Lab for routine test only",
    "ranges": "Male: 200 - 420 µmol/L. Female: 140 - 340 µmol/L."
  },
  {
    "test": "Urine Biochemistry & Microscopic exam",
    "lab": "Core Lab SCACC Lab",
    "container": "Sterile urine container",
    "specimen": "Urine",
    "volume": "4 ml",
    "ltat": "1 hour (Urgent), 3 hours (Routine)",
    "remark": "SCACC Lab for routine test only",
    "ranges": "Leukocytes, nitrites, protein, and micro-erythrocyte diagnostic validation arrays."
  },
  {
    "test": "Urine Pregnancy Test",
    "lab": "Core Lab SCACC Lab",
    "container": "Sterile urine container",
    "specimen": "Fresh morning urine",
    "volume": "2 ml",
    "ltat": "1 hour (Urgent), 3 hours (Routine), 6 hours (SCACC-Routine), 3 working days external",
    "remark": "SCACC Lab for routine test only",
    "ranges": "Qualitative positive/negative matrix outputs calibrated via minimal structural detection constraints (commonly 20-25 mIU/mL)."
  },
  {
    "test": "Valproic acid",
    "lab": "Core Lab",
    "container": "Plain tube without gel (red cap)",
    "specimen": "Blood",
    "volume": "4 ml",
    "ltat": "6 hours (Urgent), 1 day (Routine & External)",
    "remark": "Therapeutic Drug Monitoring (TDM) Request Form",
    "ranges": "Therapeutic targeted concentration limit matrix: 50 - 100 mg/L (phlebotomy requires explicit pre-dose trough collection context)."
  },
  {
    "test": "Vancomycin",
    "lab": "Core Lab",
    "container": "Plain tube without gel (red cap)",
    "specimen": "Blood",
    "volume": "4 ml",
    "ltat": "6 hours (Urgent), 1 day (Routine & External)",
    "remark": "Therapeutic Drug Monitoring (TDM) Request Form",
    "ranges": "Target therapeutic trough index: 15-20 mg/L for complex configurations (MRSA bacteremia/endocarditis), 10-15 mg/L for simpler tracking contexts. Pull immediately preceding subsequent dose application cycle."
  },
  {
    "test": "Vitamin B12",
    "lab": "Core Lab",
    "container": "Plain tube with gel (yellow cap)",
    "specimen": "Blood",
    "volume": "3 ml",
    "ltat": "2 working days, 3 working days external",
    "remark": "",
    "ranges": "150 - 700 pmol/L."
  },
  {
    "test": "Activated Partial Thrombin Time (APTT)",
    "lab": "Core Lab",
    "container": "Sodium citrate tube",
    "specimen": "Blood",
    "volume": "To fill line",
    "ltat": "1 hour (Urgent), 3 hours (Routine), 3 working days external",
    "remark": "Send within 2 hours of sample collection. Must be filled EXACTLY to the line (1:9 ratio). Do not underfill.",
    "ranges": "28 - 40 seconds (Target ranges scale to 1.5-2.5x base values during clinical unfractionated heparin therapy deployment)."
  },
  {
    "test": "Coagulation Test (PT, INR, APTT, Ratio)",
    "lab": "Core Lab",
    "container": "Sodium citrate tube",
    "specimen": "Blood",
    "volume": "To fill line",
    "ltat": "1 hour (Urgent), 3 hours (Routine), 3 working days external",
    "remark": "Send within 2 hours of sample collection. Must be filled EXACTLY to the line (1:9 ratio). Do not underfill.",
    "ranges": "PT: 11 - 14 seconds. Normal target INR baseline: 0.8 - 1.2. Therapeutic warfarin targets map parameters to 2.0 - 3.0 windows."
  },
  {
    "test": "D-Dimer",
    "lab": "Core Lab",
    "container": "Sodium citrate tube",
    "specimen": "Blood",
    "volume": "To fill line",
    "ltat": "1 hour (Urgent), 3 hours (Routine), 3 working days external",
    "remark": "Send within 2 hours of sample collection. Must be filled EXACTLY to the line (1:9 ratio). Do not underfill.",
    "ranges": "Exclusion target baseline: <0.50 mg/L FEU. Used extensively as a high negative predictive tool for acute VTE/PE diagnostic workup routines."
  },
  {
    "test": "DIVC Screening",
    "lab": "Core Lab",
    "container": "Sodium citrate tube & EDTA tube",
    "specimen": "Blood",
    "volume": "Citrate to line, EDTA 2ml",
    "ltat": "90 mins (Urgent), 3 hours (Routine), 3 working days external",
    "remark": "Send within 2 hours of sample collection. Must be filled EXACTLY to the line (1:9 ratio). Do not underfill.",
    "ranges": "Tracks coordinated drop in platelets & fibrinogen index matched alongside prolonged PT/APTT patterns and rising D-Dimer values."
  },
  {
    "test": "Erythrocyte Sedimentation Rate (ESR)",
    "lab": "Core Lab",
    "container": "EDTA tube",
    "specimen": "Blood",
    "volume": "2 ml",
    "ltat": "1 hour (Urgent), 3 hours (Routine), 3 working days external",
    "remark": "Send to the laboratory as soon as possible.",
    "ranges": "Male: <15 mm/hr. Female: <20 mm/hr (Physiologically scales upward inside elderly cohorts)."
  },
  {
    "test": "Fibrinogen",
    "lab": "Core Lab",
    "container": "Sodium citrate tube",
    "specimen": "Blood",
    "volume": "To fill line",
    "ltat": "1 hour (Urgent), 3 hours (Routine), 3 working days external",
    "remark": "Send within 2 hours of sample collection. Must be filled EXACTLY to the line (1:9 ratio). Do not underfill.",
    "ranges": "1.5 - 4.0 g/L (Severe consumption alerts flag risk levels dipping <1.0 g/L during active DIC processing crises)."
  },
  {
    "test": "Full Blood Count (FBC)",
    "lab": "Core Lab SCACC Lab",
    "container": "EDTA tube",
    "specimen": "Whole Blood",
    "volume": "2 ml",
    "ltat": "45 mins (Urgent), 3 hours (Routine), 3 hours (SCACC-Routine)",
    "remark": "SCACC Lab for routine test only",
    "ranges": "Hb: 130-170 g/L (M), 120-150 g/L (F). WBC: 4.0-11.0 x10^9/L. Platelets: 150-400 x10^9/L."
  },
  {
    "test": "Full Blood Picture (routine)",
    "lab": "Haematology",
    "container": "EDTA tube",
    "specimen": "Blood",
    "volume": "2 ml",
    "ltat": "14 days",
    "remark": "Send within 4 hours of sample collection.",
    "ranges": "Qualitative evaluation of cellular architecture configurations (blasts, schistocytes, dysplastic morphologic variants)."
  },
  {
    "test": "Full Blood Picture (urgent)",
    "lab": "Haematology",
    "container": "EDTA tube",
    "specimen": "Blood",
    "volume": "2 ml",
    "ltat": "3 days",
    "remark": "Send within 4 hours. Call ext 6374/6549 or MO on-call to request urgent.",
    "ranges": "Critical verification array configuration for acute leukemia or microangiopathic hemolytic anemia exclusion processing pathways."
  },
  {
    "test": "Mixing Test",
    "lab": "Core Lab",
    "container": "Sodium citrate tube",
    "specimen": "Blood",
    "volume": "2 tubes (fill line)",
    "ltat": "1 working day. Urgent upon consultation",
    "remark": "Send within 2 hours of sample collection.",
    "ranges": "Correction of prolonged clotting profiles highlights single/multiple factor deficiencies; failure to correct confirms internal circulatory inhibitor presence (e.g. Lupus Anticoagulant)."
  },
  {
    "test": "Prothrombin Time (PT) & INR",
    "lab": "Core Lab",
    "container": "Sodium citrate tube",
    "specimen": "Blood",
    "volume": "To fill line",
    "ltat": "1 hour (Urgent), 3 hours (Routine), 3 working days external",
    "remark": "Send within 2 hours of sample collection. Must be filled EXACTLY to the line (1:9 ratio). Do not underfill.",
    "ranges": "PT standard window: 11-14 seconds. Baseline diagnostic validation parameter."
  },
  {
    "test": "Reticulocyte count",
    "lab": "Core Lab",
    "container": "EDTA tube",
    "specimen": "Blood",
    "volume": "2 ml",
    "ltat": "1 hour (Urgent), 3 hours (Routine), 3 working days external",
    "remark": "Send to the laboratory as soon as possible.",
    "ranges": "0.5% - 2.0% of total RBC tracking index (Indicates kinetic bone marrow production response capability during active hemolytic anemia drops)."
  },
  {
    "test": "Group, Screen and Hold (GSH)",
    "lab": "Blood Bank",
    "container": "EDTA tube (Pink/Purple cap)",
    "specimen": "Blood",
    "volume": "4 ml",
    "ltat": "1 hour (Urgent), 3 hours (Routine)",
    "remark": "Strict labeling required. Signature of phlebotomist/doctor on tube and Blood Bank Request Form is MANDATORY. Do NOT use addressograph on tube in some centers.",
    "ranges": "Validates core ABO blood group identity parameters and rules out unexpected red cell antibody profiles."
  },
  {
    "test": "Group and Crossmatch (GXM)",
    "lab": "Blood Bank",
    "container": "EDTA tube (Pink/Purple cap)",
    "specimen": "Blood",
    "volume": "4 ml",
    "ltat": "1 hour (Urgent), 3 hours (Routine)",
    "remark": "State number of pints/components needed. Strict labeling required. Blood Bank Request Form and tube must be signed by the person drawing blood.",
    "ranges": "Direct matching setup ensuring explicit unit-to-patient compatibility checks before product issue confirmation loops."
  },
  {
    "test": "Direct Antiglobulin Test (DAT / Direct Coombs)",
    "lab": "Blood Bank",
    "container": "EDTA tube",
    "specimen": "Blood",
    "volume": "4 ml",
    "ltat": "1 hour (Urgent), 1 working day",
    "remark": "Investigate autoimmune hemolytic anemia (AIHA), HDFN, or transfusion reaction. Blood Bank Request Form required.",
    "ranges": "Negative target threshold indicator."
  },
  {
    "test": "Indirect Antiglobulin Test (IAT / Indirect Coombs)",
    "lab": "Blood Bank",
    "container": "EDTA tube",
    "specimen": "Blood",
    "volume": "4 ml",
    "ltat": "1 working day",
    "remark": "Antibody screening for antenatal or pre-transfusion. Blood Bank Request Form required.",
    "ranges": "Negative target threshold index validation loop."
  },
  {
    "test": "Cold Agglutinin Titre",
    "lab": "Blood Bank",
    "container": "Plain tube without gel (red cap)",
    "specimen": "Blood",
    "volume": "4 ml",
    "ltat": "3-5 working days",
    "remark": "Maintain at 37°C immediately after collection (use warm water bath/thermos) and transport immediately to lab. DO NOT refrigerate.",
    "ranges": "Normal baseline target: <1:32 titer configuration metrics."
  },
  {
    "test": "Kleihauer-Betke Test",
    "lab": "Blood Bank",
    "container": "EDTA tube",
    "specimen": "Blood",
    "volume": "2 ml",
    "ltat": "1 working day",
    "remark": "Maternal blood to check for fetal-maternal hemorrhage. Send immediately. Blood Bank Request Form required.",
    "ranges": "Calculates fractional proportion of fetal erythrocytes inside systemic maternal circulation to determine required RhIG rescue dosing."
  },
  {
    "test": "AFB Direct Smear",
    "lab": "Microbiology",
    "container": "Sterile container",
    "specimen": "Sputum, BAL, aspirate",
    "volume": "1 ml",
    "ltat": "1 day",
    "remark": "TBIS 20C Form",
    "ranges": "Reported qualitatively using standardized slide review density metrics (1+ to 3+ acid-fast bacilli observed)."
  },
  {
    "test": "Blood culture & sensitivity (aerobic)",
    "lab": "Microbiology",
    "container": "Aerobic Blood Culture Bottle",
    "specimen": "Blood",
    "volume": "8-10 ml (Adults)",
    "ltat": "7 days",
    "remark": "Preliminary report available",
    "ranges": "Negative baseline validation goal tracking target status loops."
  },
  {
    "test": "Blood culture & sensitivity (anaerobic)",
    "lab": "Microbiology",
    "container": "Anaerobic Blood Culture Bottle",
    "specimen": "Blood",
    "volume": "8-10 ml (Adults)",
    "ltat": "7 days",
    "remark": "Preliminary report available",
    "ranges": "Negative baseline validation target verification processing paths."
  },
  {
    "test": "Cerebrospinal fluid culture & sensitivity",
    "lab": "Microbiology",
    "container": "Sterile container",
    "specimen": "CSF",
    "volume": "3 ml",
    "ltat": "5 days",
    "remark": "Preliminary report available pending validation",
    "ranges": "Sterile pathogen tracking index baseline status loop definitions."
  },
  {
    "test": "Dengue Serology IgG FIA / High Titer ELISA",
    "lab": "Microbiology",
    "container": "Plain tube",
    "specimen": "Blood",
    "volume": "3 ml",
    "ltat": "2 - 3 days",
    "remark": "Cut off receive sample 8.00am for same day test",
    "ranges": "Positive index confirms past localized secondary exposure or remote clinical infection phases."
  },
  {
    "test": "Dengue Serology - IgM / NS1 Antigen FIA",
    "lab": "Microbiology",
    "container": "Plain tube",
    "specimen": "Blood",
    "volume": "3 ml",
    "ltat": "2 days",
    "remark": "Cut off receive sample 8.00am for same day test",
    "ranges": "NS1 presence flags early viremic phase (Days 1-5 from onset); IgM switches confirm active acute phase tracking vectors (Day 5+)."
  },
  {
    "test": "Full Examination Microscopy Exam (FEME)",
    "lab": "Microbiology",
    "container": "Peritoneal fluid/dialysis",
    "specimen": "Fluid",
    "volume": "3 ml",
    "ltat": "1 day",
    "remark": "",
    "ranges": "Dialysate white cell criteria tracking counts >100/µL with >50% polymorphonuclear cells confirms structural peritonitis pathogenesis."
  },
  {
    "test": "Gonococcal culture & sensitivity",
    "lab": "Microbiology",
    "container": "Amies transport media/culture",
    "specimen": "Swab/culture plate",
    "volume": "NA",
    "ltat": "5 days",
    "remark": "Send to the lab as soon as possible (ASAP)",
    "ranges": "Target search parameters track explicit isolation of Neisseria gonorrhoeae structures."
  },
  {
    "test": "HBe Ag / HBs Ab Quantitative Immunoassay",
    "lab": "Microbiology",
    "container": "Plain tube",
    "specimen": "Blood",
    "volume": "3 ml",
    "ltat": "5 days",
    "remark": "",
    "ranges": "HBsAb concentrations ≥10 mIU/mL validate active, protective immunization tracking protection scales."
  },
  {
    "test": "HBsAg (Confirmatory / Screening)",
    "lab": "Microbiology",
    "container": "Plain tube",
    "specimen": "Blood/Serum",
    "volume": "1-3 ml",
    "ltat": "5 days",
    "remark": "",
    "ranges": "Positive parameter confirms active, structural Hepatitis B viral carriage."
  },
  {
    "test": "HCV-RNA PCR Viral Load (Quantitative)",
    "lab": "Microbiology",
    "container": "EDTA tube",
    "specimen": "Plasma",
    "volume": "2 ml x 2",
    "ltat": "14 days",
    "remark": "Transport in ice. Specialist signature required. Follow CPG.",
    "ranges": "Quantified tracking indices determine baseline values before launching DAAA therapy configurations."
  },
  {
    "test": "Hepatitis B Virus - DNA PCR Viral Load",
    "lab": "Microbiology",
    "container": "EDTA tube",
    "specimen": "Plasma",
    "volume": "2ml x 2",
    "ltat": "14 days",
    "remark": "Transport in ice. Specialist signature required. Follow CPG.",
    "ranges": "Expressed explicitly in IU/mL to determine operational antiviral thresholds tracking replication speeds."
  },
  {
    "test": "Hepatitis C Virus (HCV) - Ab (Screening)",
    "lab": "Microbiology",
    "container": "Plain tube",
    "specimen": "Blood",
    "volume": "3 ml",
    "ltat": "5 days",
    "remark": "",
    "ranges": "Non-reactive target tracking validation baseline threshold parameters."
  },
  {
    "test": "HIV 1/2 Ab/Ag Combo (Screening)",
    "lab": "Microbiology",
    "container": "Plain tube",
    "specimen": "Blood",
    "volume": "5 ml",
    "ltat": "5 days",
    "remark": "",
    "ranges": "Tracks p24 antigen structures alongside HIV antibodies simultaneously for reduced screening window times."
  },
  {
    "test": "HIV-1 RNA PCR Viral Load (Quantitative)",
    "lab": "Microbiology",
    "container": "EDTA tube",
    "specimen": "Plasma",
    "volume": "2 ml x 2",
    "ltat": "14 days",
    "remark": "Transport in ice. Specialist signature required. Follow CPG.",
    "ranges": "Clinical management therapeutic maintenance goal: Complete suppression to undetected concentration status (<20-40 copies/mL)."
  },
  {
    "test": "Influenza PCR (Flu A, B & H1N1)",
    "lab": "Microbiology",
    "container": "Swab UTM / Sterile container",
    "specimen": "Respiratory Specimen",
    "volume": "1-2 ml",
    "ltat": "4-7 days",
    "remark": "Transport in ice. Specialist signature required. Not for URTI.",
    "ranges": "Qualitative verification profiling diagnostic checks."
  },
  {
    "test": "Pus culture & sensitivity",
    "lab": "Microbiology",
    "container": "Amies transport media/sterile",
    "specimen": "Swab/pus aspirate",
    "volume": "3 ml",
    "ltat": "5 days",
    "remark": "",
    "ranges": "Identifies localized bacterial pathogens matched directly against targeted antibiotic resistance profiling arrays."
  },
  {
    "test": "QIAstatDx - Meningitis Panel",
    "lab": "Microbiology",
    "container": "Sterile container",
    "specimen": "CSF",
    "volume": "0.5 ml",
    "ltat": "1 day",
    "remark": "Transport immediately. Do not refrigerate.",
    "ranges": "Multiplex molecular amplification targets key structural viral, bacterial, and fungal meningeal targets simultaneously."
  },
  {
    "test": "QIAstatDx - Respiratory Panel",
    "lab": "Microbiology",
    "container": "Swab UTM / VTM",
    "specimen": "Nasopharyngeal / Oropharyngeal swab",
    "volume": "1-3 ml",
    "ltat": "1 day",
    "remark": "Transport immediately in cold chain (2-8°C). Used for rapid multiplex detection of respiratory pathogens.",
    "ranges": "Multiplex PCR detecting common viral and bacterial respiratory pathogens."
  },
  {
    "test": "QIAstatDx - Gastrointestinal Panel",
    "lab": "Microbiology",
    "container": "Sterile container",
    "specimen": "Stool",
    "volume": "2-5 g (walnut size)",
    "ltat": "1 day",
    "remark": "Transport immediately. Used for rapid multiplex detection of gastrointestinal pathogens.",
    "ranges": "Multiplex PCR detecting common viral, bacterial, and parasitic GI pathogens."
  },
  {
    "test": "Rapid Respiratory Antigen (RTK) Flu/RSV/Adeno",
    "lab": "Microbiology",
    "container": "FLOQ swab / Sterile",
    "specimen": "Swab / Aspirate",
    "volume": "NA",
    "ltat": "1 day",
    "remark": "Transport in ice",
    "ranges": "Point-of-care rapid confirmation checking infrastructure loops."
  },
  {
    "test": "Respiratory culture & sensitivity",
    "lab": "Microbiology",
    "container": "Sterile container",
    "specimen": "Aspirate, Sputum, BAL",
    "volume": "NA",
    "ltat": "5 days",
    "remark": "",
    "ranges": "Tracks pathologically relevant deep tissue lower airway microbial presence markers."
  },
  {
    "test": "SARS-CoV-2 Antigen RTK",
    "lab": "Microbiology",
    "container": "Dacron swab",
    "specimen": "Nasopharyngeal swab",
    "volume": "NA",
    "ltat": "4 hours",
    "remark": "Triple packaging and transport in ice.",
    "ranges": "Qualitative structural diagnostics checking pathways."
  },
  {
    "test": "SARS-CoV-2 RT-PCR",
    "lab": "Microbiology",
    "container": "Sterile container / VTM",
    "specimen": "Respiratory sample",
    "volume": "1-2 ml",
    "ltat": "2 days",
    "remark": "Triple packaging, ice. Specialist signature required.",
    "ranges": "Tracks baseline viral gene extraction presence evaluated across numeric Cycle Threshold (Ct) scales directly."
  },
  {
    "test": "Stool culture & sensitivity",
    "lab": "Microbiology",
    "container": "Sterile container",
    "specimen": "Stool",
    "volume": "3 ml",
    "ltat": "5 days",
    "remark": "",
    "ranges": "Screens explicitly for enteric pathogen colonies (Salmonella, Shigella, Campylobacter, Vibrio isolates)."
  },
  {
    "test": "Syphilis - Rapid Plasma Reagin / TPPA / Anti",
    "lab": "Microbiology",
    "container": "Plain tube",
    "specimen": "Blood",
    "volume": "5 ml",
    "ltat": "4 days",
    "remark": "",
    "ranges": "RPR non-reactive baseline status. Positive non-treponemal checks require reflex TPPA confirmation setups to rule out false-positive biologic noise."
  },
  {
    "test": "Urine culture and sensitivity",
    "lab": "Microbiology",
    "container": "Sterile urine container",
    "specimen": "Urine",
    "volume": "5 ml",
    "ltat": "5 days",
    "remark": "Send immediately to Microbiology Lab",
    "ranges": "Standard diagnostic validation benchmark: Colony counts crossing ≥10^5 CFU/mL signify established UTI pathology metrics."
  },
  {
    "test": "Cytology: Non-gynaecology",
    "lab": "Anatomic Pathology-Cytology",
    "container": "Universal / sterile container",
    "specimen": "Body Fluid, Washing, Urine",
    "volume": "20mL-200mL",
    "ltat": "3 days (Urgent), 14 days (Routine)",
    "remark": "After office hour: Kaunter Utama Jabatan Patologi",
    "ranges": "Microscopic review checks explicitly for malignant cell configurations or atypia flags."
  },
  {
    "test": "Histopathology: Frozen Section",
    "lab": "Anatomic Pathology-Histopathology",
    "container": "Universal container",
    "specimen": "Fresh tissue",
    "volume": "NA",
    "ltat": "45 minutes",
    "remark": "Send immediately. Fill request form. Appointment 1 day earlier.",
    "ranges": "Intraoperative rapid diagnostic validation checking margin clearance metrics during active surgical procedures."
  },
  {
    "test": "Histopathology: HPE/Surgical Specimen-Other",
    "lab": "Anatomic Pathology-Histopathology",
    "container": "Tissue in 10% formalin",
    "specimen": "Tissue",
    "volume": "NA",
    "ltat": "14 days (70% cases)",
    "remark": "PER-PAT 301 form",
    "ranges": "Formal structural tissue pathology assessment reporting loops."
  },
  {
    "test": "Thiamine (Vitamin B1) [Referred]",
    "lab": "Ref: MKAK",
    "container": "EDTA tube",
    "specimen": "Whole Blood",
    "volume": "4 ml",
    "ltat": "Varies",
    "remark": "Use Borang Permohonan Ujian (Umum) MKAK",
    "ranges": "70 - 180 nmol/L."
  },
  {
    "test": "Adenosine deaminase (ADA) [Referred]",
    "lab": "Ref: MKAK",
    "container": "Plain container (Red/Gold cap)",
    "specimen": "Pleural fluid",
    "volume": "3 ml",
    "ltat": "Varies",
    "remark": "Use Borang Permohonan Ujian (Umum) MKAK",
    "ranges": "Concentration marks exceeding >30-40 U/L inside pleural effusions display high diagnostic specificity for tuberculous pleuritis profiles."
  },
  {
    "test": "Protein Electrophoresis (CSF)/ Oligoclonal band [Referred]",
    "lab": "Ref: Hosp Ampang",
    "container": "Plain Gel Tube & Bijou bottle",
    "specimen": "Blood & CSF",
    "volume": "3 ml (Blood), 2 ml (CSF)",
    "ltat": "Varies",
    "remark": "MUST be send in pair (serum & CSF)",
    "ranges": "The localized presence of unique oligoclonal band pairings in CSF (absent in peripheral serum matches) supports Multiple Sclerosis verification indices."
  },
  {
    "test": "Insulin-like Growth Factor 1 (IGF-1) [Referred]",
    "lab": "Ref: H. Putrajaya",
    "container": "Plain tube with gel (yellow cap)",
    "specimen": "Blood",
    "volume": "3 ml",
    "ltat": "Varies",
    "remark": "",
    "ranges": "Highly stratified by age category profiles; used as a non-fluctuating growth hormone screening tool asset."
  },
  {
    "test": "Homocystine Urine (Quantitative) [Referred]",
    "lab": "Ref: H. Tunku Azizah (HTA)",
    "container": "Universal container",
    "specimen": "Urine",
    "volume": "5 ml",
    "ltat": "Varies",
    "remark": "",
    "ranges": "<15 µmol/g creatinine tracking benchmark parameters."
  },
  {
    "test": "Homocysteine Total [Referred]",
    "lab": "Ref: NIH / IMR",
    "container": "EDTA tube",
    "specimen": "Blood",
    "volume": "4 ml",
    "ltat": "Varies",
    "remark": "Refer to IMR test list",
    "ranges": "<15 µmol/L."
  },
  {
    "test": "Anti Xa Assay (for LMWH) [Referred]",
    "lab": "Ref: H. Tunku Azizah (HTA)",
    "container": "Sodium citrate tube",
    "specimen": "Blood (plasma)",
    "volume": "2.7 ml",
    "ltat": "36 hrs (Urgent), 7 days (Routine)",
    "remark": "PER-PAT 301. Send immed at Room Temp. Require discussion with Pathologist prior.",
    "ranges": "Therapeutic target tracking for twice-daily LMWH dosing setups: 0.5 - 1.0 IU/mL (Pull sample precisely 4 hours post-subcutaneous injection)."
  },
  {
    "test": "Factor VIII Assay/Inhibitor [Referred]",
    "lab": "Ref: H. Tunku Azizah (HTA)",
    "container": "Sodium citrate tube",
    "specimen": "Blood (plasma)",
    "volume": "2.7 ml",
    "ltat": "3 days (Urgent), 14 days (Routine)",
    "remark": "PER-PAT 301. Send immed at Room Temp. Require discussion with Pathologist.",
    "ranges": "50% - 150% functional standard activity limits. Depressed metrics determine Hemophilia A status indicators directly."
  },
  {
    "test": "Factor IX Assay/Inhibitor [Referred]",
    "lab": "Ref: H. Tunku Azizah (HTA)",
    "container": "Sodium citrate tube",
    "specimen": "Blood (plasma)",
    "volume": "2.7 ml",
    "ltat": "3 days (Urgent), 14 days (Routine)",
    "remark": "PER-PAT 301. Send immed at Room Temp. Require discussion with Pathologist.",
    "ranges": "50% - 150% standard activity boundaries. Deficiencies track Hemophilia B markers explicitly."
  },
  {
    "test": "Lupus Anticoagulant Antibody [Referred]",
    "lab": "Ref: H. Tunku Azizah (HTA)",
    "container": "3x Sodium citrate tube",
    "specimen": "Blood (plasma)",
    "volume": "3 x 2.7 ml",
    "ltat": "30 days",
    "remark": "PER-PAT 301. Send immed at Room Temp. Require discussion with Pathologist.",
    "ranges": "Multi-stage screening and confirmation profiling arrays (DRVVT testing cascades)."
  },
  {
    "test": "Rare Coagulation Factor Activity Assays [Referred]",
    "lab": "Ref: H. Tunku Azizah (HTA)",
    "container": "Sodium citrate tube",
    "specimen": "Blood (plasma)",
    "volume": "2.7 ml",
    "ltat": "30 days",
    "remark": "PER-PAT 301. Includes FII, FV, FVII, FX, FXI, FXII, FXIII. Call Pathologist.",
    "ranges": "Explicit functional activity mapping percentages unique to single isolated factor components."
  },
  {
    "test": "Von Willebrand Factor Profile [Referred]",
    "lab": "Ref: H. Tunku Azizah (HTA)",
    "container": "3x Sodium citrate tube",
    "specimen": "Blood (plasma)",
    "volume": "3 x 2.7 ml",
    "ltat": "30 days",
    "remark": "PER-PAT 301. Send immed at Room Temp. Require discussion with Pathologist.",
    "ranges": "Measures vWF Antigen indices, Ristocetin Cofactor activity levels, and Factor VIII pairing metrics simultaneously."
  },
  {
    "test": "Haemato-Oncology Conventional Cytogenetics [Referred]",
    "lab": "Ref: H. Tunku Azizah (HTA)",
    "container": "2x Sodium Heparin tubes",
    "specimen": "Whole Blood / Bone Marrow",
    "volume": "2 x 2.0 ml",
    "ltat": "20 days (Urgent), 90 days (Routine)",
    "remark": "Ice-packed container within 24hr. Requested by specialist only.",
    "ranges": "Karyotyping matrix tracking analysis for chromosomal deletions, duplications, or complex translocation architectures."
  },
  {
    "test": "G6PD screening (Fluorescent spot test) [Referred]",
    "lab": "Ref: H. Tunku Azizah (HTA)",
    "container": "Filter paper OR EDTA tube",
    "specimen": "Dried/Whole blood",
    "volume": "2.0 ml",
    "ltat": "24 hours",
    "remark": "PER-PAT 301. Send immed at Room Temp. Avoid direct contact with ice.",
    "ranges": "Qualitative screen (Normal vs Deficient). Note: False-negative normal screens can follow acute hemolytic crises due to elevated youthful reticulocyte presence scales."
  },
  {
    "test": "G6PD Assay (Quantitative) [Referred]",
    "lab": "Ref: H. Tunku Azizah (HTA)",
    "container": "EDTA tube",
    "specimen": "Whole blood",
    "volume": "2.0 ml",
    "ltat": "14 days",
    "remark": "By appointment only. Call Haematology Lab. Immediate transport.",
    "ranges": "Absolute numeric enzyme activity values calculated relative to hemoglobin mass constraints directly."
  },
  {
    "test": "CD4/CD8 Enumeration [Referred]",
    "lab": "Ref: H. Tunku Azizah (HTA)",
    "container": "EDTA tube",
    "specimen": "Whole blood",
    "volume": "2.0 ml",
    "ltat": "7 days",
    "remark": "PER-PAT 301. Send immed at Room Temp. Mon-Thu only.",
    "ranges": "Absolute CD4 immune metric targets: 500 - 1500 cells/µL. Opportunistic infection vectors compound rapidly if indices drop <200 cells/µL."
  },
  {
    "test": "CD20 Enumeration [Referred]",
    "lab": "Ref: H. Tunku Azizah (HTA)",
    "container": "EDTA tube",
    "specimen": "Whole blood",
    "volume": "2.0 ml",
    "ltat": "21 days",
    "remark": "PER-PAT 301. Send immed at Room Temp. Mon-Thu only.",
    "ranges": "Flow cytometry tracking index parameters."
  },
  {
    "test": "Immunophenotyping for Leukaemia & Lymphoma [Referred]",
    "lab": "Ref: H. Tunku Azizah (HTA)",
    "container": "2x EDTA tubes",
    "specimen": "Whole Blood / Bone Marrow",
    "volume": "2 x 2.0 ml",
    "ltat": "36 hrs (verbal), 21 days (formal)",
    "remark": "Transport immediately at Room Temp. Mon-Thu only. BMA needs unstained slide.",
    "ranges": "Isolates and validates explicit cluster of differentiation (CD) lineage patterns to determine clonal blast classification sets."
  },
  {
    "test": "Leukaemia Translocation Study [Referred]",
    "lab": "Ref: H. Tunku Azizah (HTA)",
    "container": "2x EDTA tubes",
    "specimen": "Whole Blood / Bone Marrow",
    "volume": "2 x 2.0 ml",
    "ltat": "21 days",
    "remark": "PER-PAT 301. Pack in ice (2-8°C). Avoid direct contact. By appointment.",
    "ranges": "Identifies diagnostic fusion genes via molecular tracking configurations."
  },
  {
    "test": "Molecular BCR-ABL1 (Qualitative) [Referred]",
    "lab": "Ref: H. Tunku Azizah (HTA)",
    "container": "2x EDTA tubes",
    "specimen": "Whole Blood / Bone Marrow",
    "volume": "2 x 2.0 ml",
    "ltat": "21 days",
    "remark": "PER-PAT 301 & Special Haematology Form. Pack in ice (2-8°C). Avoid direct contact. By appointment.",
    "ranges": "Detects presence of t(9;22) Philadelphia chromosome genetic rearrangements qualitatively."
  },
  {
    "test": "Molecular BCR-ABL1 (Quantitative) [Referred]",
    "lab": "Ref: H. Tunku Azizah (HTA)",
    "container": "3x EDTA tubes",
    "specimen": "Whole blood",
    "volume": "3 x 2.0 ml",
    "ltat": "9 days",
    "remark": "PER-PAT 301 & Special Haematology Form. Pack in ice (2-8°C). Last test not <6 months.",
    "ranges": "Monitors minimal residual disease tracking deep molecular response parameters across explicit international standardized percentage scales."
  },
  {
    "test": "Inherited Thrombophilia Tests (Protein C/S/Antithrombin/APCR) [Referred]",
    "lab": "Ref: H. Tunku Azizah (HTA)",
    "container": "4x Sodium citrate tube",
    "specimen": "Blood (plasma)",
    "volume": "4 x 2.7 ml",
    "ltat": "6 weeks",
    "remark": "PER-PAT 301. Send immed at Room Temp. Require discussion with Pathologist.",
    "ranges": "Functional baseline tracking index values. Note: Acute thrombotic events or active anticoagulant therapies heavily distort results; screen safely 6 weeks post-event context."
  },
  {
    "test": "AML Mutation Panel (FLT3-ITD, NGS) [Referred]",
    "lab": "Ref: IMR",
    "container": "2x EDTA tubes",
    "specimen": "Whole Blood / Bone Marrow",
    "volume": "2 x 2.0 ml",
    "ltat": "14 to 45 working days",
    "remark": "Refrigerated (2-8°C). Do NOT freeze.",
    "ranges": "Identifies actionable molecular prognostic drivers to guide advanced target induction protocols."
  },
  {
    "test": "Confirmation For Haemoglobinopathy/Variant [Referred]",
    "lab": "Ref: IMR",
    "container": "2x EDTA tubes",
    "specimen": "Whole blood",
    "volume": "2 x 2.0 ml",
    "ltat": "120 working days",
    "remark": "Refrigerated (2-8°C). Do NOT freeze. Need FBC/Hb analysis copies.",
    "ranges": "Definitive structural genetic molecular mapping isolating thalassemia variants and abnormal hemoglobin expressions explicitly."
  },
  {
    "test": "Haemophilia Genetic Testing A & B [Referred]",
    "lab": "Ref: IMR",
    "container": "2x EDTA tubes",
    "specimen": "Whole blood",
    "volume": "2 x 2.0 ml",
    "ltat": "30 to 60 working days",
    "remark": "Refrigerated (2-8°C). Do NOT freeze.",
    "ranges": "Confirms hereditary gene mutation patterns tracking explicit factor coding sequence errors."
  },
  {
    "test": "BCR-ABL1 (Qualitative / Quantitative) [Referred]",
    "lab": "Ref: Hosp Ampang",
    "container": "5x EDTA tubes",
    "specimen": "Whole blood / Bone Marrow",
    "volume": "5 x 2.0 ml",
    "ltat": "4 to 12 weeks",
    "remark": "PER-PAT 301 & Special Haematology Form. Transport at Room Temp. DO NOT freeze. Call Haematologist Hosp Ampang.",
    "ranges": "Advanced therapeutic transcription tracking loops tracking CML response milestones."
  },
  {
    "test": "JAK2/CALR Calreticulin [Referred]",
    "lab": "Ref: Hosp Ampang",
    "container": "5x EDTA tubes",
    "specimen": "Whole blood / Bone Marrow",
    "volume": "5 x 2.0 ml",
    "ltat": "8 weeks",
    "remark": "PER-PAT 301 & Special Haematology Form. Transport at Room Temp. DO NOT freeze. Call Haematologist Hosp Ampang.",
    "ranges": "Identifies diagnostic driver mutations confirming underlying Myeloproliferative Neoplasm (MPN) status (PV, ET, PMF)."
  },
  {
    "test": "Leukemia FISH Analysis (MPN) [Referred]",
    "lab": "Ref: Hosp Ampang",
    "container": "3x Sodium Heparin tubes",
    "specimen": "Whole blood / Bone Marrow",
    "volume": "3 x 2.0 ml",
    "ltat": "18 days",
    "remark": "PER-PAT 301 & Special Haematology Form. Transport at Room Temp. DO NOT freeze. Call Haematologist Hosp Ampang.",
    "ranges": "Targeted cytogenetic fluorescence tracking to isolate structural rearrangements rapidly without waiting on formal culture growth loops."
  },
  {
    "test": "EGFR Testing [Referred]",
    "lab": "Ref: H. Tunku Azizah (HTA)",
    "container": "Unstained slides",
    "specimen": "Paraffin Section",
    "volume": "NA",
    "ltat": "10 days",
    "remark": "Request by Pathologist",
    "ranges": "Identifies actionable somatic mutations within tissue blocks to confirm eligibility for tyrosine kinase inhibitor (TKI) therapies."
  },
  {
    "test": "Fungal PCR [Referred]",
    "lab": "Ref: IMR / NIH",
    "container": "Unstained slides",
    "specimen": "Paraffin Section / Body fluid",
    "volume": "NA",
    "ltat": "5 to 10 days",
    "remark": "Request by Pathologist",
    "ranges": "Molecular validation amplifying unique fungal ribosomal DNA sequencing profiles directly."
  },
  {
    "test": "Histopathology Second Opinion [Referred]",
    "lab": "Ref: Various (H. Selayang/HSA/NIH/etc)",
    "container": "Paraffin block and slides",
    "specimen": "Tissue",
    "volume": "NA",
    "ltat": "Within 30 days",
    "remark": "Request by Pathologist",
    "ranges": "Expert advisory diagnostic cross-checks on challenging architectural tissue morphology slices."
  },
  {
    "test": "Bordetella pertussis PCR [Referred]",
    "lab": "Ref: IMR",
    "container": "Sterile container",
    "specimen": "Nasopharyngeal aspirates/swabs",
    "volume": "1 - 2 ml",
    "ltat": "5 working days",
    "remark": "",
    "ranges": "Target molecular tracking identifying active whooping cough infection indices quickly."
  },
  {
    "test": "Brucella PCR [Referred]",
    "lab": "Ref: IMR",
    "container": "EDTA tube",
    "specimen": "Blood",
    "volume": "5 ml",
    "ltat": "5 working days",
    "remark": "",
    "ranges": "Isolates and validates explicit Brucella species genomic structures."
  },
  {
    "test": "Leptospiral PCR [Referred]",
    "lab": "Ref: IMR / MKAK",
    "container": "EDTA tube",
    "specimen": "Blood",
    "volume": "2 ml",
    "ltat": "5 working days",
    "remark": "For ICU cases & after consultation only",
    "ranges": "High diagnostic accuracy tool in early acute phase (Days 1-7 from symptom onset) before systemic antibody emergence manifests loops."
  },
  {
    "test": "MTB PCR [Referred]",
    "lab": "Ref: MKAK",
    "container": "Sterile container",
    "specimen": "Sputum, pus, tissue, CSF",
    "volume": "1 - 3 ml",
    "ltat": "5 working days",
    "remark": "Tue & Thu only",
    "ranges": "Amplifies insertion sequence IS6110 to confirm Mycobacterium tuberculosis presence with high operational sensitivity parameters."
  },
  {
    "test": "MTB culture and sensitivity [Referred]",
    "lab": "Ref: MKAK",
    "container": "Sterile container",
    "specimen": "Sputum, bronchial aspirate",
    "volume": "5 - 10 ml",
    "ltat": "9 weeks",
    "remark": "Tue & Thu only. Form TBIS 20C.",
    "ranges": "Gold-standard verification track mapping absolute mycobacterial isolation and definitive first/second-line drug resistance patterns."
  },
  {
    "test": "Carbapenemase genes detection (CRE) [Referred]",
    "lab": "Ref: IMR",
    "container": "Blood agar",
    "specimen": "Pure isolate",
    "volume": "NA",
    "ltat": "14 working days",
    "remark": "",
    "ranges": "Identifies explicit resistance genes molecularly (e.g. blaNDM, blaOXA-48, blaKPC) inside multi-drug resistant Gram-negative isolates."
  },
  {
    "test": "Pneumocystis jirovecii Genome Detection (PCR) [Referred]",
    "lab": "Ref: Hosp Sg. Buloh",
    "container": "Sterile container",
    "specimen": "BAL / Induced sputum",
    "volume": "5 ml",
    "ltat": "2 to 5 working days",
    "remark": "Tue & Thu only.",
    "ranges": "Isolates opportunistic fungal sequences to confirm PJP pneumonia profiles inside deeply immunocompromised groups rapidly."
  },
  {
    "test": "MTB/Rif GeneXpert (IPR) [Referred]",
    "lab": "Ref: IPR",
    "container": "Sterile container",
    "specimen": "Non Respiratory samples",
    "volume": "NA",
    "ltat": "24 hours",
    "remark": "Consultation with IPR physician prior submission.",
    "ranges": "Simultaneously reports structural MTB presence alongside molecular markers validating explicit Rifampicin drug resistance boundaries."
  },
  {
    "test": "Mycobacterium leprae Culture & PCR [Referred]",
    "lab": "Ref: MKAK",
    "container": "Sterile plain container",
    "specimen": "Skin Incision / Punch Biopsy",
    "volume": "5 mm biopsy",
    "ltat": "7 days to 18 mths",
    "remark": "Tue & Thu only.",
    "ranges": "Confirms Hansen's disease pathology molecularly directly from target structural skin slit setups."
  },
  {
    "test": "Borrelia burgdorferi IgM/IgG [Referred]",
    "lab": "Ref: Hosp Sg Buloh",
    "container": "Plain tube",
    "specimen": "Serum",
    "volume": "3 - 5 ml",
    "ltat": "2 to 3 working days",
    "remark": "Tue & Thu only.",
    "ranges": "Serologic evaluation profiling targeting Lyme disease exposure vectors."
  },
  {
    "test": "Coxiella burnetti IgM/IgG [Referred]",
    "lab": "Ref: Hosp Sg Buloh",
    "container": "Plain tube",
    "specimen": "Serum",
    "volume": "3 - 5 ml",
    "ltat": "2 to 3 working days",
    "remark": "Tue & Thu only.",
    "ranges": "Confirms specific immunologic antibody footprints indicating exposure tracking for Q Fever diagnostics."
  },
  {
    "test": "Leptospiral MAT [Referred]",
    "lab": "Ref: MKAK Sg Buloh",
    "container": "Plain tube",
    "specimen": "Serum",
    "volume": "3 ml",
    "ltat": "7 working days",
    "remark": "Tue & Thu only.",
    "ranges": "Microscopic Agglutination Test tracking; diagnostic confirmation requires a 4-fold tier rise across serial paired tracking parameters."
  },
  {
    "test": "Burkholderia pseudomallei IgM (Meliodosis) [Referred]",
    "lab": "Ref: IMR",
    "container": "Plain tube",
    "specimen": "Serum",
    "volume": "2 - 3 ml",
    "ltat": "5 working days",
    "remark": "",
    "ranges": "Specific serologic indicator flagging localized exposure risks inside endemic regions during active workup processing."
  },
  {
    "test": "Brucella Serology (ELISA) [Referred]",
    "lab": "Ref: IMR",
    "container": "Plain tube",
    "specimen": "Serum (Transport at 2-8°C)",
    "volume": "2 ml",
    "ltat": "10 working days",
    "remark": "",
    "ranges": "Evaluates systemic antibody presence patterns targeting chronic brucellosis exposure indices."
  },
  {
    "test": "Rickettsia PCR [Referred]",
    "lab": "Ref: IMR",
    "container": "EDTA tube / Sterile container",
    "specimen": "Blood / Tissue",
    "volume": "5 ml",
    "ltat": "5 working days",
    "remark": "",
    "ranges": "Molecular confirmation for scrub/murine typhus syndromes during early undifferentiated febrile tracking windows."
  },
  {
    "test": "Tryptase [Referred]",
    "lab": "Ref: IMR",
    "container": "Plain tube with gel (yellow cap)",
    "specimen": "Blood / Serum",
    "volume": "3 ml",
    "ltat": "Varies",
    "remark": "Every working day (Mon-Fri)",
    "ranges": "<11.4 µg/L. Serial transient spikes pulling samples 1-2 hours post-event help confirm severe systemic anaphylactic mast cell degranulation pathways."
  },
  {
    "test": "Chikungunya Serology [Referred]",
    "lab": "Ref: MKAK",
    "container": "Plain tube with gel (yellow cap)",
    "specimen": "Serum (Kept in 2-8°C)",
    "volume": "1 - 3 ml",
    "ltat": "3 days",
    "remark": "Tue & Thu only.",
    "ranges": "Specific viral antibody detection setups tracking concurrent alphavirus infection dynamics."
  },
  {
    "test": "Japanese Encephalitis / Measles Serology [Referred]",
    "lab": "Ref: MKAK",
    "container": "Plain tube with gel (yellow cap)",
    "specimen": "Serum",
    "volume": "2 - 4 ml",
    "ltat": "3 to 7 days",
    "remark": "Tue & Thu only.",
    "ranges": "Targeted viral antibody diagnostic screens mapping localized acute central nervous tracking markers."
  },
  {
    "test": "Nipah Virus Antibody [Referred]",
    "lab": "Ref: IMR",
    "container": "Plain tube / EDTA / Sterile",
    "specimen": "Serum, Plasma, CSF",
    "volume": "1 - 3 ml",
    "ltat": "5 to 14 days",
    "remark": "",
    "ranges": "High-containment serological tracking mapping specialized biosecurity diagnostics explicitly."
  },
  {
    "test": "Adenovirus qRT-PCR [Referred]",
    "lab": "Ref: IMR",
    "container": "Sterile container with VTM",
    "specimen": "Nasopharyngeal swab / BAL",
    "volume": "1 - 3 ml",
    "ltat": "14 to 28 days",
    "remark": "",
    "ranges": "Molecular quantification profiling tracking explicit respiratory or ocular viral loads."
  },
  {
    "test": "Dengue virus serotyping qRT-PCR [Referred]",
    "lab": "Ref: MKAK",
    "container": "Plain tube / Sterile container",
    "specimen": "Serum, CSF",
    "volume": "1 - 3 ml",
    "ltat": "1 to 10 days",
    "remark": "Tue & Thu only.",
    "ranges": "Isolates and validates explicit circulating serotype strands (DENV 1-4) for epidemiological surveillance control matrices."
  },
  {
    "test": "Enterovirus qRT-PCR (EV71, CA16) [Referred]",
    "lab": "Ref: IMR",
    "container": "Sterile container with VTM / Swab",
    "specimen": "Nasopharyngeal swab, Rectal swab, Stool",
    "volume": "1 - 3 ml / >5g",
    "ltat": "1 to 10 days",
    "remark": "",
    "ranges": "Isolates virulent molecular fragments to manage HFMD institutional outbreak vectors safely."
  },
  {
    "test": "SARS-CoV-2 RT-PCR (Other than respiratory) [Referred]",
    "lab": "Ref: IMR",
    "container": "Sterile container",
    "specimen": "Non-respiratory sample",
    "volume": "NA",
    "ltat": "1 to 5 days",
    "remark": "Requires consultation",
    "ranges": "Investigates atypical extra-pulmonary systemic carriage parameters molecularly directly."
  },
  {
    "test": "Blood Lead [Referred]",
    "lab": "Ref: H. Selayang",
    "container": "EDTA tube",
    "specimen": "Blood",
    "volume": "2 ml",
    "ltat": "21 working days",
    "remark": "FORM: PER-PAT 301. Send on Tuesday.",
    "ranges": "Children: <50 µg/L. Adults: <100 µg/L. Occupational protection management triggers are lower than acute heavy metal clinical toxicity thresholds."
  },
  {
    "test": "Serum Copper [Referred]",
    "lab": "Ref: H. Selayang",
    "container": "Plain tube without gel / EDTA",
    "specimen": "Serum",
    "volume": "2 ml",
    "ltat": "21 working days",
    "remark": "FORM: PER-PAT 301. Send on Tuesday.",
    "ranges": "11.0 - 24.0 µmol/L (Cross-evaluate carefully against concurrent total ceruloplasmin levels to calculate accurate free unbound copper fractions)."
  },
  {
    "test": "24hr Urine Copper [Referred]",
    "lab": "Ref: H. Selayang",
    "container": "24 hr Urine container",
    "specimen": "24hr Urine",
    "volume": "5 ml",
    "ltat": "21 working days",
    "remark": "FORM: PER-PAT 301. Send on Thursday. 24hr urine volume MUST be stated on request.",
    "ranges": "<0.60 µmol/24 hours. Excretory values scaling >1.6 µmol/24 hours support clinical Wilson's disease tracking loops directly."
  },
  {
    "test": "Paroxysmal Nocturnal Hemoglobinuria (PNH) [Referred]",
    "lab": "Ref: Hosp Ampang",
    "container": "2x EDTA tubes",
    "specimen": "Fresh venous blood",
    "volume": "2.5 - 3.0 ml",
    "ltat": "3 weeks",
    "remark": "Received preferably within 24 hours of draw and transported at 2°C to 8°C. Form: PER-PAT 301 & Special Haematology Form.",
    "ranges": "Flow cytometry tracking evaluates specific anchors (CD55/CD59 expression profile loss on peripheral erythrocytes and granulocyte populations)."
  },
  {
    "test": "ADAMTS-13 Assay [Referred]",
    "lab": "Ref: Hosp Ampang",
    "container": "5x Sodium citrate tube",
    "specimen": "Fresh venous blood",
    "volume": "5 x 2.7 ml",
    "ltat": "8 weeks",
    "remark": "Requires consultation with Hematologist. Form: PER-PAT 301 & Special Haematology Form.",
    "ranges": "Functional activity indices dropping severe limits <10% confirm Thrombotic Thrombocytopenic Purpura (TTP) pathogenetic processing paths directly."
  },
  {
    "test": "Serum Erythropoietin (EPO) ELISA [Referred]",
    "lab": "Ref: Hosp Ampang",
    "container": "Plain tube without gel",
    "specimen": "Serum",
    "volume": "3.5 ml",
    "ltat": "8 to 14 weeks",
    "remark": "Separate serum (min 1.5ml) ASAP. Store frozen at -40°C. Transport frozen on dry ice. Form: Special Haematology Form.",
    "ranges": "4.3 - 29.0 mIU/mL (Suppressed levels matching erythrocytosis flag primary Polycythemia Vera drivers directly)."
  },
  {
    "test": "PML-RARa Quantitative Assay [Referred]",
    "lab": "Ref: Hosp Ampang",
    "container": "EDTA tube",
    "specimen": "Whole Blood / Bone Marrow",
    "volume": "10 ml (Blood), 1-2 ml (BMA)",
    "ltat": "8 to 10 weeks",
    "remark": "Transport at 2°C to 8°C within 24 hours. DO NOT freeze. Form: PER-PAT 301 & Special Haematology Form.",
    "ranges": "Molecular validation for t(15;17) genetic targets confirming Acute Promyelocytic Leukemia (APL / AML M3) structural profiles."
  },
  {
    "test": "Beta-2-Microglobulin, Serum [Referred]",
    "lab": "Ref: Hosp Ampang",
    "container": "Plain tube",
    "specimen": "Blood",
    "volume": "4 ml",
    "ltat": "14 working days",
    "remark": "Specialist counter-signed is a MUST. Form: PER-PAT 301 & Special Haematology Form.",
    "ranges": "0.7 - 1.8 mg/L (Critical independent prognostic staging evaluation parameter for Multiple Myeloma development layouts)."
  },
  {
    "test": "Free Light Chain, Serum [Referred]",
    "lab": "Ref: Hosp Ampang",
    "container": "Plain tube",
    "specimen": "Blood",
    "volume": "4 ml",
    "ltat": "28 working days",
    "remark": "Specialist counter-signed is a MUST. Form: PER-PAT 301 & Special Haematology Form.",
    "ranges": "Free Kappa: 3.3-19.4 mg/L. Free Lambda: 5.7-26.3 mg/L. Kappa/Lambda ratio target: 0.26-1.65. Shifts outside these boundaries flag monoclonal plasma cell dyscrasias."
  },
  {
    "test": "Anti-Acetylcholine Receptor (AChR) Antibody [Referred]",
    "lab": "Ref: IMR",
    "container": "Plain tube with gel (yellow cap)",
    "specimen": "Blood",
    "volume": "3-5 ml",
    "ltat": "3 to 4 weeks",
    "remark": "FORM: AUTOIMMUNE REQUEST FORM (Version 4.0). Spin for serum immediately. Transport in ICE (2-8°C). 1 tube & 1 form per test. Primary diagnostic verification tool for generalized and ocular Myasthenia Gravis.",
    "ranges": "<0.40 nmol/L (Negative). Diagnostic indicator threshold validation: values ≥0.40 nmol/L confirm autoimmune neuromuscular junction pathology."
  },
  {
    "test": "Anti-Muscle-Specific Tyrosine Kinase (MuSK) Antibody [Referred]",
    "lab": "Ref: IMR / External",
    "container": "Plain tube with gel (yellow cap)",
    "specimen": "Blood",
    "volume": "3-5 ml",
    "ltat": "4 weeks",
    "remark": "FORM: AUTOIMMUNE REQUEST FORM (Version 4.0). Spin for serum immediately. Transport in ICE (2-8°C). 1 tube & 1 form per test. Indicated if patient exhibits typical clinical Myasthenia Gravis presentation but demonstrates seronegative AChR profile results.",
    "ranges": "Negative baseline metric standard profile configuration context."
  },
  {
    "test": "Anti-Aquaporin 4 (AQP4 / AQ4) Antibody (Serum) [Referred]",
    "lab": "Ref: IMR",
    "container": "Plain tube with gel (yellow cap)",
    "specimen": "Blood",
    "volume": "3-5 ml",
    "ltat": "3 to 4 weeks",
    "remark": "FORM: AUTOIMMUNE REQUEST FORM (Version 4.0). Spin for serum immediately. Transport in ICE (2-8°C). 1 tube & 1 form per test. Hallmark serological biomarker for Neuromyelitis Optica Spectrum Disorder (NMOSD).",
    "ranges": "Negative target threshold index confirmation array setup validation."
  },
  {
    "test": "Anti-Aquaporin 4 (AQP4 / AQ4) Antibody (CSF) [Referred]",
    "lab": "Ref: IMR",
    "container": "Sterile container (Bijou bottle)",
    "specimen": "CSF",
    "volume": "2 ml",
    "ltat": "3 to 4 weeks",
    "remark": "FORM: AUTOIMMUNE REQUEST FORM (Version 4.0). Transport in ICE (2-8°C). Typically requested as a paired simultaneous evaluation array with serum tracking metrics.",
    "ranges": "Negative baseline reference framework paths."
  },
  {
    "test": "Anti-Myelin Oligodendrocyte Glycoprotein (MOG) Antibody [Referred]",
    "lab": "Ref: IMR / External",
    "container": "Plain tube with gel (yellow cap)",
    "specimen": "Blood",
    "volume": "3-5 ml",
    "ltat": "4 weeks",
    "remark": "FORM: AUTOIMMUNE REQUEST FORM (Version 4.0). Spin for serum immediately. Transport in ICE (2-8°C). 1 tube & 1 form per test. Useful diagnostic differentiator for MOGAD syndromes.",
    "ranges": "Negative screening output validation threshold profiles."
  },
  {
    "test": "Autoimmune Encephalitis Panel (CSF) [Referred]",
    "lab": "Ref: IMR / HTA",
    "container": "Sterile container (Bijou bottle)",
    "specimen": "CSF",
    "volume": "2 ml",
    "ltat": "3 to 4 weeks",
    "remark": "FORM: PER-PAT 301. Multiplex screen tracking functional cell-surface targets (Anti-NMDAR, Anti-LGI1, Anti-CASPR2, Anti-AMPA 1/2, Anti-GABA-B). Keep cool.",
    "ranges": "Negative detection standard output. Positive matching confirms specific limbic or autoimmune-mediated brain inflammation architectures."
  },
  {
    "test": "Autoimmune Encephalitis Panel (Serum) [Referred]",
    "lab": "Ref: IMR / HTA",
    "container": "Plain tube with gel (yellow cap)",
    "specimen": "Blood",
    "volume": "5 ml",
    "ltat": "3 to 4 weeks",
    "remark": "FORM: PER-PAT 301. Optimal protocols dictate paired drawing with concurrent CSF collection to achieve maximum screening sensitivity yield thresholds.",
    "ranges": "Negative qualitative screening metrics configuration window."
  },
  {
    "test": "Paraneoplastic Neurological Syndrome Panel [Referred]",
    "lab": "Ref: IMR",
    "container": "Plain tube with gel (yellow cap)",
    "specimen": "Blood",
    "volume": "3-5 ml",
    "ltat": "4 weeks",
    "remark": "FORM: AUTOIMMUNE REQUEST FORM (Version 4.0). Spin for serum immediately. Transport in ICE (2-8°C). 1 tube & 1 form per test. Evaluates intracellular onconeural antibodies (Anti-Tr, GAD65, Zic4, Titin, SOX1, Recoverin, Amphiphysin, Ma2/Ta, Yo, Ri, Hu, CV2).",
    "ranges": "Negative tracking configuration benchmark baseline verification parameters."
  },
  {
    "test": "CSF 14-3-3 Protein [Referred]",
    "lab": "Ref: MKAK Sg Buloh",
    "container": "Sterile container (Bijou bottle)",
    "specimen": "CSF",
    "volume": "2 ml",
    "ltat": "4 weeks",
    "remark": "Requires explicit specialist clinician consultation prior to request. Absolute rejection rule applies if specimen exhibits macroscopic blood/erythrocyte tracking contamination.",
    "ranges": "Negative verification profile. Positive marker indices strongly indicate rapid, catastrophic structural neuronal decomposition (Creutzfeldt-Jakob Disease confirmation setup)."
  },
  {
    "test": "CSF VDRL / TPPA (Neurosyphilis Screening)",
    "lab": "Microbiology",
    "container": "Sterile container (Bijou bottle)",
    "specimen": "CSF",
    "volume": "2 ml",
    "ltat": "3 working days",
    "remark": "Standard Microbiology Lab Form. Cross-check systematically against paired concurrent peripheral blood serology tracking values to rule out passive serum transfer artifacts.",
    "ranges": "Non-reactive target baseline validation loop parameters."
  },
  {
    "test": "Short Synacthen Test (ACTH Stimulation)",
    "lab": "Core Lab",
    "container": "Plain tube with gel (yellow cap)",
    "specimen": "Blood",
    "volume": "3 ml per point",
    "ltat": "2 working days",
    "remark": "MOH/MEMS Protocol. Baseline (0 min) drawn, administer Synacthen 250 µg IV/IM, then pull timed cortisol points at exactly 30 and 60 minutes. Evaluates primary/secondary adrenal insufficiency.",
    "ranges": "Normal response: Stimulated peak serum cortisol must exceed >420 nmol/L (or >500 nmol/L depending on assay kit metrics) to confirm intact adrenal reserve."
  },
  {
    "test": "Overnight Dexamethasone Suppression Test (ODST)",
    "lab": "Core Lab",
    "container": "Plain tube with gel (yellow cap)",
    "specimen": "Blood",
    "volume": "3 ml",
    "ltat": "2 working days",
    "remark": "MOH/MEMS Protocol. Instruct patient to ingest exactly 1 mg oral Dexamethasone between 11:00 PM and midnight. Draw single cortisol sample the next morning at 8:00 AM. Screening benchmark for Cushing's syndrome.",
    "ranges": "Normal exclusion limit: Post-dexamethasone morning serum cortisol compresses safely to <50 nmol/L (<1.8 µg/dL)."
  },
  {
    "test": "Growth Hormone Suppression Test (OGTT-GH)",
    "lab": "Special Chemical Pathology",
    "container": "Plain tube with gel (yellow cap) & Fluoride tube (grey cap)",
    "specimen": "Blood",
    "volume": "3 ml + 2 ml per point",
    "ltat": "5 working days",
    "remark": "MOH/MEMS Protocol. Administer standard 75g oral glucose load. Draw synchronized pairs of GH and Glucose at 0, 30, 60, 90, and 120 minutes. Gold standard confirmatory study for suspected Acromegaly.",
    "ranges": "Normal evaluation: Hyperglycemia suppresses Growth Hormone to <1.0 µg/L (high-sensitivity assays check suppression limits down to <0.4 µg/L). Failure to suppress confirms Acromegaly."
  },
  {
    "test": "Water Deprivation Test (WDT)",
    "lab": "Core Lab",
    "container": "Plain tube with gel (yellow cap) & Sterile urine container",
    "specimen": "Blood & Urine",
    "volume": "3 ml + 5 ml hourly",
    "ltat": "1 working day",
    "remark": "MOH/MEMS Protocol. Differentiates Cranial DI vs Nephrogenic DI vs Primary Polydipsia. Hourly checks on body weight, urine volume, urine osmolality, and serum osmolality/sodium.",
    "ranges": "Normal/Polydipsia: Urine osmolality concentrates safely above >600 mOsm/kg. Diabetes Insipidus: Urine fails to concentrate despite rising serum metrics. Cranial DI shows >50% rise in urine osmolality post-desmopressin injection."
  },
  {
    "test": "Insulin Tolerance Test (ITT)",
    "lab": "Special Chemical Pathology",
    "container": "Plain tube with gel (yellow cap) & Fluoride tube (grey cap)",
    "specimen": "Blood",
    "volume": "3 ml + 2 ml per point",
    "ltat": "5 working days",
    "remark": "MOH/MEMS Protocol. CRITICAL: Absolute, continuous physical presence of an MO/Endocrinologist is mandatory. Inject IV insulin to safely force severe hypoglycemia (target glucose <2.2 mmol/L). Pull timed points for Cortisol and GH at -15, 0, 15, 30, 45, 60, and 90 minutes. Absolute contraindication: Epilepsy or Ischemic Heart Disease.",
    "ranges": "Adequate physiological axis stress reserve: Stimulated peak cortisol must cross >500 nmol/L, and Growth Hormone must surge past >5 µg/L during proven neuroglycopenia."
  },
  {
    "test": "Aldosterone-Renin Ratio (ARR) Screening",
    "lab": "Special Chemical Pathology",
    "container": "EDTA tube (purple cap)",
    "specimen": "Plasma",
    "volume": "4 ml",
    "ltat": "7 to 10 working days",
    "remark": "FORM: PER-PAT 301. Crucial screen for Primary Aldosteronism. Patient must sit quietly/upright for 2 hours prior to venipuncture. Must correct clinical hypokalemia prior to draw, and stop mineralocorticoid receptor antagonists (e.g., spironolactone) for a minimum of 4 weeks.",
    "ranges": "Screening threshold index: An ARR >35 (with PAC in pmol/L and DRC in mU/L) flags a positive screening trace. PA can be confidently excluded if absolute PAC remains <170 pmol/L."
  },
  {
    "test": "Metanephrines, 24-Hour Urine",
    "lab": "Special Chemical Pathology",
    "container": "24-hr Urine bottle with 10ml 32% HCl acid preservative",
    "specimen": "Urine",
    "volume": "Total 24h collection",
    "ltat": "14 working days",
    "remark": "FORM: PER-PAT 301. Must secure specialized brown container from lab pre-loaded with HCl acid preservative to maintain pH <2. Instruct patient to restrict caffeine, vanilla, nicotine, and intense stress over collection span. Diagnostic sweep for Pheochromocytoma.",
    "ranges": "Elevated excretion markers matching or exceeding >2-3 times the upper threshold limits of normal validate autonomous catecholamine hypersecretion."
  },
  {
    "test": "NT-proBNP",
    "lab": "Core Lab",
    "container": "Lithium heparin tube / Plain tube",
    "specimen": "Blood",
    "volume": "3 ml",
    "ltat": "1 hour (Urgent)",
    "remark": "Send to the laboratory as soon as possible. Essential diagnostic marker for acute heart failure pathway.",
    "ranges": "<300 pg/mL rules out acute heart failure. Rule-in cut-offs are heavily age-dependent (>450, >900, >1800 pg/mL)."
  },
  {
    "test": "Osmolality, Serum",
    "lab": "Core Lab",
    "container": "Plain tube with gel (yellow cap)",
    "specimen": "Serum",
    "volume": "3 ml",
    "ltat": "1 hour (Urgent), 3 hours (Routine)",
    "remark": "Always cross-evaluate with paired concurrent urine osmolality when tracking hyponatremia/SIADH dynamics.",
    "ranges": "275 - 295 mOsm/kg."
  },
  {
    "test": "Osmolality, Urine",
    "lab": "Core Lab",
    "container": "Sterile urine container",
    "specimen": "Urine",
    "volume": "5 ml",
    "ltat": "1 hour (Urgent), 3 hours (Routine)",
    "remark": "Requires paired concurrent serum osmolality drawn within a similar timeframe for accurate clinical interpretation.",
    "ranges": "50 - 1200 mOsm/kg (Highly dependent upon systemic hydration and ADH axis status)."
  },
  {
    "test": "Anti-Nuclear Antibody (ANA) [Referred]",
    "lab": "Ref: IMR Autoimmune Unit",
    "container": "Plain tube with gel (yellow cap)",
    "specimen": "Serum",
    "volume": "3 ml",
    "ltat": "14 to 30 working days",
    "remark": "FORM: PER-PAT 301. The IMR Autoimmune Unit serves as the national referral centre for autoimmune diagnostic services. Fundamental screening test for SLE and systemic autoimmune rheumatic diseases.",
    "ranges": "Reported as Titers (e.g., <1:80 Negative). Positive structural patterns (Speckled, Homogeneous, Nucleolar) strictly require clinical correlation."
  },
  {
    "test": "Anti-Neutrophil Cytoplasmic Antibody (ANCA) [Referred]",
    "lab": "Ref: IMR Autoimmune Unit",
    "container": "Plain tube with gel (yellow cap)",
    "specimen": "Serum",
    "volume": "3 ml",
    "ltat": "14 to 30 working days",
    "remark": "FORM: PER-PAT 301. Evaluates systemic vasculitis frameworks (GPA, MPA) and acute rapid progressive glomerulonephritis.",
    "ranges": "Negative baseline screening. Positive immunofluorescence screens usually reflex explicitly to targeted MPO and PR3 antigen tracking."
  },
  {
    "test": "Lithium",
    "lab": "Core Lab",
    "container": "Plain tube without gel (red cap)",
    "specimen": "Blood",
    "volume": "4 ml",
    "ltat": "1 working day",
    "remark": "Therapeutic Drug Monitoring (TDM) Request Form. CRITICAL: DO NOT use Lithium Heparin tube (green cap) as it induces severe artificial false-positive toxicity levels. Pull 12 hours post-dose.",
    "ranges": "Therapeutic steady state tracking limit: 0.6 - 1.2 mmol/L. Systemic toxicity risks escalate rapidly past >1.5 mmol/L."
  },
  {
    "test": "Prostate-Specific Antigen (PSA)",
    "lab": "Core Lab",
    "container": "Plain tube with gel (yellow cap)",
    "specimen": "Blood",
    "volume": "3 ml",
    "ltat": "2 working days, 3 working days external",
    "remark": "Avoid digital rectal exam (DRE), urinary catheterization, or vigorous cycling 48 hours prior to phlebotomy to prevent transient structural false elevations.",
    "ranges": "<4.0 ng/mL (Reference bounds scale upwards physiologically across advancing older male demographics)."
  },
  {
    "test": "Hepatitis A (Anti-HAV IgM)",
    "lab": "Microbiology",
    "container": "Plain tube",
    "specimen": "Blood",
    "volume": "3 ml",
    "ltat": "5 days",
    "remark": "Essential parameter for acute uncharacterized jaundice diagnostic workups.",
    "ranges": "Non-reactive target tracking validation baseline."
  },
  {
    "test": "Mycoplasma Serology (IgM/IgG) [Referred]",
    "lab": "Ref: IMR",
    "container": "Plain tube with gel (yellow cap)",
    "specimen": "Serum",
    "volume": "3 ml",
    "ltat": "5 to 10 working days",
    "remark": "FORM: PER-PAT 301. Deployed heavily for atypical respiratory pneumonia syndrome investigations.",
    "ranges": "Negative qualitative verification profile."
  },
  {
    "test": "Blood Film for Malaria Parasites (BFMP)",
    "lab": "Microbiology / Parasitology",
    "container": "EDTA tube / Glass slides",
    "specimen": "Whole Blood",
    "volume": "2 ml",
    "ltat": "Urgent: < 2 hours",
    "remark": "Send immediately. Essential for undifferentiated fever, especially with travel history.",
    "ranges": "No malaria parasites seen."
  },
  {
    "test": "H. pylori Stool Antigen",
    "lab": "Microbiology",
    "container": "Sterile container",
    "specimen": "Stool",
    "volume": "Pea-sized / 5 ml",
    "ltat": "3-5 working days",
    "remark": "Patients should be off PPIs for at least 2 weeks before testing to avoid false negatives.",
    "ranges": "Negative."
  },
  {
    "test": "Anti-dsDNA Antibody [Referred]",
    "lab": "Ref: IMR Autoimmune Unit",
    "container": "Plain tube with gel (yellow cap)",
    "specimen": "Serum",
    "volume": "3 ml",
    "ltat": "14 to 30 working days",
    "remark": "FORM: PER-PAT 301. Essential for SLE diagnosis and monitoring disease activity.",
    "ranges": "Reported as Titers or IU/mL. Positive indicates high specificity for SLE."
  },
  {
    "test": "Anti-Cyclic Citrullinated Peptide (Anti-CCP) [Referred]",
    "lab": "Ref: IMR Autoimmune Unit",
    "container": "Plain tube with gel (yellow cap)",
    "specimen": "Serum",
    "volume": "3 ml",
    "ltat": "14 to 30 working days",
    "remark": "FORM: PER-PAT 301. Highly specific early marker for Rheumatoid Arthritis.",
    "ranges": "< 20 U/mL (Negative)."
  },
  {
    "test": "Immunoglobulins (IgG, IgA, IgM)",
    "lab": "Core Lab / Special Chemical Pathology",
    "container": "Plain tube with gel (yellow cap)",
    "specimen": "Serum",
    "volume": "3 ml",
    "ltat": "3 to 5 working days",
    "remark": "Workup for recurrent infections or suspected immunodeficiencies.",
    "ranges": "IgG: 7.0-16.0 g/L, IgA: 0.7-4.0 g/L, IgM: 0.4-2.3 g/L (adult reference)."
  },
  {
    "test": "Serum Protein Electrophoresis (SPEP)",
    "lab": "Special Chemical Pathology",
    "container": "Plain tube with gel (yellow cap)",
    "specimen": "Serum",
    "volume": "3 ml",
    "ltat": "7 to 14 working days",
    "remark": "Primary screening for monoclonal gammopathies (Multiple Myeloma).",
    "ranges": "No paraprotein/monoclonal band detected."
  },
  {
    "test": "Urine Protein Electrophoresis (UPEP)",
    "lab": "Special Chemical Pathology",
    "container": "Sterile urine container",
    "specimen": "Early morning urine or 24h urine",
    "volume": "10 ml",
    "ltat": "7 to 14 working days",
    "remark": "Must be sent alongside SPEP for complete Multiple Myeloma workup (Bence Jones Protein).",
    "ranges": "No monoclonal free light chains detected."
  },
  {
    "test": "Hb Analysis (Thalassemia Screening)",
    "lab": "Haematology",
    "container": "EDTA tube",
    "specimen": "Whole Blood",
    "volume": "2 ml",
    "ltat": "14 working days",
    "remark": "Include FBC results and clinical history (family history, ethnicity).",
    "ranges": "Normal adult hemoglobin pattern (HbA >95%, HbA2 <3.5%, HbF <1%)."
  },
  {
    "test": "Intact Parathyroid Hormone (iPTH)",
    "lab": "Special Chemical Pathology",
    "container": "EDTA tube",
    "specimen": "Plasma",
    "volume": "3 ml",
    "ltat": "2 to 5 working days",
    "remark": "Send IN ICE immediately. Separated and frozen if delayed. Cross-check with concurrent serum Calcium.",
    "ranges": "1.6 - 6.9 pmol/L (Depends heavily on CKD staging)."
  },
  {
    "test": "Urine Phase Contrast (Dysmorphic RBC)",
    "lab": "Core Lab / Nephrology",
    "container": "Sterile urine container",
    "specimen": "Fresh mid-stream urine",
    "volume": "10 ml",
    "ltat": "1 working day",
    "remark": "Urine must be very fresh (< 1 hour). Used to differentiate glomerular vs non-glomerular hematuria.",
    "ranges": ">80% dysmorphic RBCs strongly suggests glomerular bleeding."
  },
  {
    "test": "Methotrexate Level",
    "lab": "Core Lab / Drug & Tox",
    "container": "Plain tube without gel (red cap) / Protect from light",
    "specimen": "Serum",
    "volume": "4 ml",
    "ltat": "1 working day (Urgent for toxicity)",
    "remark": "TDM Form. Wrap tube in aluminum foil (light-sensitive). Note exact time of last dose and infusion duration.",
    "ranges": "Toxicity threshold depends on time post-infusion (e.g., > 1.0 µmol/L at 48 hours requires folinic acid rescue)."
  },
  {
    "test": "Anti-Glomrular Basement Membrane (GBM) [Referred]",
    "lab": "Ref: IMR",
    "container": "Plain tube with gel (yellow cap)",
    "specimen": "Blood",
    "volume": "3-5 ml",
    "ltat": "14 to 30 working days",
    "remark": "FORM: AUTOIMMUNE REQUEST FORM (Version 4.0). Spin for serum immediately. Transport in ICE (2-8°C). 1 tube & 1 form per test.",
    "ranges": "Negative baseline screening."
  },
  {
    "test": "Anti-Ganglioside Antibodies (GA) Panel [Referred]",
    "lab": "Ref: IMR",
    "container": "Plain tube with gel (yellow cap)",
    "specimen": "Blood",
    "volume": "3-5 ml",
    "ltat": "14 to 30 working days",
    "remark": "FORM: AUTOIMMUNE REQUEST FORM (Version 4.0). Includes Anti-GM1, GM2, GM3, GM4, GD1a, GD1b, GD2, GD3, GT1a, GT1b, GQ1b. Spin for serum immediately. Transport in ICE (2-8°C). 1 tube & 1 form per test.",
    "ranges": "Negative baseline screening."
  },
  {
    "test": "Anti-N-Methyl-D-Aspartate Receptor (NMDAR) [Referred]",
    "lab": "Ref: IMR",
    "container": "Plain tube with gel (yellow cap)",
    "specimen": "Blood",
    "volume": "3-5 ml",
    "ltat": "3 to 4 weeks",
    "remark": "FORM: AUTOIMMUNE REQUEST FORM (Version 4.0). Spin for serum immediately. Transport in ICE (2-8°C). 1 tube & 1 form per test.",
    "ranges": "Negative baseline screening."
  },
  {
    "test": "Coeliac Antibodies Panel [Referred]",
    "lab": "Ref: IMR",
    "container": "Plain tube with gel (yellow cap)",
    "specimen": "Blood",
    "volume": "3-5 ml",
    "ltat": "14 to 30 working days",
    "remark": "FORM: AUTOIMMUNE REQUEST FORM (Version 4.0). Includes Anti-Endomysium, Anti-Deamidated Gliadin Peptide, Anti-Tissue Transglutaminase. Spin for serum immediately. Transport in ICE (2-8°C).",
    "ranges": "Negative baseline screening."
  },
  {
    "test": "Cytokine Test Panel [Referred]",
    "lab": "Ref: IMR",
    "container": "Plain tube with gel (yellow cap)",
    "specimen": "Blood",
    "volume": "3-5 ml",
    "ltat": "Varies",
    "remark": "FORM: AUTOIMMUNE REQUEST FORM (Version 4.0). Includes IL-1b, IL-6, IL-8 & TNF-a. BY APPOINTMENT ONLY. Spin for serum immediately. Transport in ICE (2-8°C).",
    "ranges": "Clinical correlation required."
  },
  {
    "test": "Phospholipase A2 Receptor antibody (PLA2R) [Referred]",
    "lab": "Ref: IMR",
    "container": "Plain tube with gel (yellow cap)",
    "specimen": "Blood",
    "volume": "3-5 ml",
    "ltat": "14 to 30 working days",
    "remark": "FORM: AUTOIMMUNE REQUEST FORM (Version 4.0). Spin for serum immediately. Transport in ICE (2-8°C).",
    "ranges": "Negative baseline screening."
  },
  {
    "test": "Skin Antibodies Panel [Referred]",
    "lab": "Ref: IMR",
    "container": "Plain tube with gel (yellow cap)",
    "specimen": "Blood",
    "volume": "3-5 ml",
    "ltat": "14 to 30 working days",
    "remark": "FORM: AUTOIMMUNE REQUEST FORM (Version 4.0). Includes Anti-BP 180, Anti BP-230, Anti-Desmoglein 1 & 3. Spin for serum immediately. Transport in ICE (2-8°C).",
    "ranges": "Negative baseline screening."
  },
  {
    "test": "Specific Liver Antibodies (SLA) Panel [Referred]",
    "lab": "Ref: IMR",
    "container": "Plain tube with gel (yellow cap)",
    "specimen": "Blood",
    "volume": "3-5 ml",
    "ltat": "14 to 30 working days",
    "remark": "FORM: AUTOIMMUNE REQUEST FORM (Version 4.0). COMPULSORY: Must enclose/specify screening results for AMA, ASMA, LKM. Spin for serum immediately. Transport in ICE (2-8°C).",
    "ranges": "Negative baseline screening."
  },
  {
    "test": "Antistreptolysin O Titre (ASOT)",
    "lab": "Core Lab / Serology",
    "container": "Plain tube with gel (yellow cap)",
    "specimen": "Blood",
    "volume": "3 ml",
    "ltat": "2 working days",
    "remark": "Clinical screening for post-streptococcal complications (Rheumatic Fever, GN).",
    "ranges": "Normal: <200 IU/mL."
  },
  {
    "test": "Vitamin D (25-OH Vitamin D)",
    "lab": "Special Chemical Pathology",
    "container": "Plain tube with gel (yellow cap)",
    "specimen": "Blood",
    "volume": "3 ml",
    "ltat": "10 working days",
    "remark": "Requires PER-PAT 301 form. Assessment of total body Vitamin D stores.",
    "ranges": "Deficient: <30 nmol/L. Insufficient: 30 - 50 nmol/L. Sufficient: >50 nmol/L."
  },
  {
    "test": "Anticardiolipin Antibodies (ACL)",
    "lab": "Core Lab / Serology",
    "container": "Plain tube with gel (yellow cap)",
    "specimen": "Blood",
    "volume": "3 ml",
    "ltat": "7 to 10 working days",
    "remark": "Clinical screening for APS/SLE.",
    "ranges": "Normal: <10 GPL/MPL U/mL."
  },
  {
    "test": "Anti-dsDNA",
    "lab": "Core Lab / Serology",
    "container": "Plain tube with gel (yellow cap)",
    "specimen": "Blood",
    "volume": "3 ml",
    "ltat": "2 to 4 working days",
    "remark": "Clinical screening for SLE.",
    "ranges": "Normal: <20 IU/mL."
  },
  {
    "test": "Lupus Anticoagulant",
    "lab": "Core Lab / Haematology",
    "container": "Blue cap (Citrate)",
    "specimen": "Blood",
    "volume": "2.7 ml",
    "ltat": "3 to 5 working days",
    "remark": "Clinical screening for APS.",
    "ranges": "Negative."
  },
  {
    "test": "Beta-2 Glycoprotein 1 Antibodies (IgG/IgM)",
    "lab": "Core Lab / Serology",
    "container": "Plain tube with gel (yellow cap)",
    "specimen": "Blood",
    "volume": "3 ml",
    "ltat": "7 to 10 working days",
    "remark": "Part of the antiphospholipid syndrome (APS) diagnostic triad alongside Anticardiolipin and Lupus Anticoagulant.",
    "ranges": "Normal: <10 U/mL (Negative)."
  },
  {
    "test": "Anti-Neutrophil Cytoplasmic Antibodies (ANCA IFA, MPO, PR3)",
    "lab": "Special Immunology / Referred",
    "container": "Plain tube with gel (yellow cap)",
    "specimen": "Blood",
    "volume": "3 ml",
    "ltat": "10 to 14 working days",
    "remark": "Investigation of systemic vasculitis (GPA, MPA, EGPA) and crescentic glomerulonephritis.",
    "ranges": "Negative."
  },
  {
    "test": "Anti-Cyclic Citrullinated Peptide (Anti-CCP) Antibody",
    "lab": "Core Lab / Serology",
    "container": "Plain tube with gel (yellow cap)",
    "specimen": "Blood",
    "volume": "3 ml",
    "ltat": "5 to 7 working days",
    "remark": "Highly specific clinical marker for Rheumatoid Arthritis (RA) diagnosis.",
    "ranges": "Normal: <20 U/mL (Negative)."
  },
  {
    "test": "HLA-B27 Antigen Typing [Referred]",
    "lab": "Referred Lab / Molecular Genetics",
    "container": "EDTA (Purple cap)",
    "specimen": "Blood",
    "volume": "3 ml",
    "ltat": "14 to 21 working days",
    "remark": "Clinical screening/investigation for Spondyloarthropathies (Ankylosing Spondylitis, Reactive Arthritis, Psoriatic Arthritis). Compulsory to enclose clinical request form.",
    "ranges": "Negative."
  },
  {
    "test": "HLA-B*58:01 Genotyping (Allopurinol SCAR Screening) [Referred]",
    "lab": "Referred Lab / Molecular Diagnostics",
    "container": "EDTA (Purple cap)",
    "specimen": "Blood",
    "volume": "3 ml",
    "ltat": "7 to 14 working days",
    "remark": "Highly recommended screening before starting Allopurinol to prevent drug-induced Severe Cutaneous Adverse Reactions (SCAR) like Stevens-Johnson Syndrome (SJS)/TEN, especially in Asian patients with CKD.",
    "ranges": "Negative."
  },
  {
    "test": "Serum Galactomannan Antigen",
    "lab": "Microbiology / Mycology Lab",
    "container": "Plain tube with gel (yellow cap)",
    "specimen": "Blood",
    "volume": "3 ml",
    "ltat": "3 to 5 working days",
    "remark": "Diagnostic biomarker for Invasive Aspergillosis. Crucial for febrile neutropenic/immunocompromised patients.",
    "ranges": "Normal: Index < 0.5 (Negative)."
  },
  {
    "test": "Serum Beta-D-Glucan (BDG) [Referred]",
    "lab": "Microbiology / Referred Lab",
    "container": "Plain tube with gel (yellow cap)",
    "specimen": "Blood",
    "volume": "3 ml",
    "ltat": "5 to 7 working days",
    "remark": "Pan-fungal biomarker for invasive fungal infections (Pneumocystis jirovecii, Candida, Aspergillus). Does NOT detect Mucorales or Cryptococcus.",
    "ranges": "Normal: < 80 pg/mL (Negative)."
  },
  {
    "test": "QuantiFERON-TB Gold Plus (IGRA)",
    "lab": "Special Immunology / Referred Lab",
    "container": "4 QuantiFERON Blood Collection Tubes (Nil: Grey, TB1: Green, TB2: Yellow, Mitogen: Purple)",
    "specimen": "Blood",
    "volume": "Exactly 1 ml per tube",
    "ltat": "5 to 7 working days",
    "remark": "Interferon-Gamma Release Assay for latent tuberculosis. CRITICAL: Draw exactly to the 1ml black line. Shake vigorously 10 times immediately after drawing to solubilize antigens. Do not refrigerate. Send to lab within 16 hours.",
    "ranges": "Negative."
  }
,
  {
    "test": "Urine FEME (Full Examination & Microscopic Examination)",
    "lab": "Pathology",
    "container": "Sterile container",
    "specimen": "Urine (Mid-stream)",
    "volume": "10 - 20 ml",
    "ltat": "4 hours",
    "remark": "Transport immediately to prevent cellular degradation. Used for screening UTI, hematuria, proteinuria, and kidney disease.",
    "ranges": "pH: 4.5 - 8.0, SG: 1.005 - 1.030. Negative for protein, glucose, ketones, bilirubin, blood, leukocyte esterase, and nitrites."
  },
  {
    "test": "Lipase",
    "lab": "Biochemistry",
    "container": "Plain tube (Red) / SST (Yellow)",
    "specimen": "Blood",
    "volume": "3 ml",
    "ltat": "4 hours",
    "remark": "More specific and sensitive than amylase for acute pancreatitis. Levels remain elevated longer than amylase.",
    "ranges": "13 - 60 U/L (Assay dependent). Acute pancreatitis suspected if > 3x upper limit of normal."
  },
  {
    "test": "Creatine Kinase-MB (CK-MB)",
    "lab": "Biochemistry",
    "container": "Plain tube (Red) / SST (Yellow)",
    "specimen": "Blood",
    "volume": "3 ml",
    "ltat": "4 hours",
    "remark": "Used for suspected myocardial infarction or re-infarction, though High Sensitivity Troponin is preferred.",
    "ranges": "0 - 24 U/L. If total CK is elevated, CK-MB index (CK-MB/Total CK) > 5% suggests cardiac source."
  }
,
  {
    "test": "Extractable Nuclear Antigen (ENA) Antibodies Panel",
    "lab": "Ref: IMR Autoimmune Unit",
    "container": "Plain tube with gel (yellow cap)",
    "specimen": "Blood",
    "volume": "3 ml",
    "ltat": "14 to 30 working days",
    "remark": "FORM: PER-PAT 301. Usually ordered after a positive ANA. Includes Anti-Sm, Anti-RNP, Anti-SSA/Ro, Anti-SSB/La, Anti-Scl-70, and Anti-Jo-1.",
    "ranges": "Negative."
  },
  {
    "test": "Anti-Mitochondrial Antibody (AMA)",
    "lab": "Ref: IMR Autoimmune Unit",
    "container": "Plain tube with gel (yellow cap)",
    "specimen": "Blood",
    "volume": "3 ml",
    "ltat": "14 to 30 working days",
    "remark": "FORM: PER-PAT 301. Primary marker for Primary Biliary Cholangitis (PBC).",
    "ranges": "Negative. Titers >= 1:40 are considered clinically significant."
  },
  {
    "test": "Anti-Smooth Muscle Antibody (ASMA)",
    "lab": "Ref: IMR Autoimmune Unit",
    "container": "Plain tube with gel (yellow cap)",
    "specimen": "Blood",
    "volume": "3 ml",
    "ltat": "14 to 30 working days",
    "remark": "FORM: PER-PAT 301. Used in the evaluation of Autoimmune Hepatitis (Type 1).",
    "ranges": "Negative."
  },
  {
    "test": "Liver Kidney Microsomal Type 1 (LKM-1) Antibody",
    "lab": "Ref: IMR Autoimmune Unit",
    "container": "Plain tube with gel (yellow cap)",
    "specimen": "Blood",
    "volume": "3 ml",
    "ltat": "14 to 30 working days",
    "remark": "FORM: PER-PAT 301. Used in the evaluation of Autoimmune Hepatitis (Type 2).",
    "ranges": "Negative."
  },
  {
    "test": "Anti-Glomerular Basement Membrane (Anti-GBM) Antibody",
    "lab": "Ref: IMR Autoimmune Unit",
    "container": "Plain tube with gel (yellow cap)",
    "specimen": "Blood",
    "volume": "3 ml",
    "ltat": "7 to 14 working days",
    "remark": "FORM: PER-PAT 301. Crucial for diagnosing Goodpasture syndrome (Anti-GBM disease).",
    "ranges": "Negative."
  }
,
  {
    "test": "Myositis Extended Panel [Referred]",
    "lab": "Ref: IMR Autoimmune Unit",
    "container": "Plain tube with gel (yellow cap)",
    "specimen": "Blood",
    "volume": "3 ml",
    "ltat": "14 to 30 working days",
    "remark": "FORM: PER-PAT 301. Evaluates for idiopathic inflammatory myopathies (e.g., polymyositis, dermatomyositis). Includes Mi-2, Ku, PM-Scl, SRP, Jo-1, PL-7, PL-12, EJ, OJ, Ro-52.",
    "ranges": "Negative."
  }
];