import { DilutionDrug, RenalStableDrug, RenalICUDrug, EnteralDrug } from "../types";

export const dbDilution: DilutionDrug[] = [
  {
    "drug": "Cefepime 1g",
    "reconstitution": "Reconstitute 1 vial with 10ml of WFI",
    "dilution": "Further dilute to 100ml of NS or D5. Maximum of 2 vials (2 gram) in 100ml of NS. Diluted solution stable for 48 hours under refrigeration (2-8°C).",
    "infusion": "IV infusion over 30 minutes"
  },
  {
    "drug": "Cloxacillin 500mg",
    "reconstitution": "Reconstitute 1 vial with 5ml of WFI",
    "dilution": "Further dilute to 100ml of NS or D5. Maximum of 4 Vials (2 Gram) to 100ml of NS.",
    "infusion": "IV infusion over 60 minutes"
  },
  {
    "drug": "Ertapenem 1g",
    "reconstitution": "Reconstitute 1 vial with 10ml of NS",
    "dilution": "Further dilute to 50 or 100ml NS. Diluted solution may be stored at RT (25°c) and used within 6 hours or Stored for 24 hours under refrigeration (5°c) and used within 4 hours after removal from refrigerator.",
    "infusion": "IV infusion over 30 minutes"
  },
  {
    "drug": "Imipenem/Cilastatin 500mg/500mg",
    "reconstitution": "Reconstitute 1 vial with 20ml NS",
    "dilution": "Further dilute to 100ml NS or D5. Reconstituted/ diluted solution stable for 4 hours at RT (30°c) and 24 hours in refrigerator (5° C).",
    "infusion": "IV infusion over 4 hours"
  },
  {
    "drug": "Meropenem 1g",
    "reconstitution": "Reconstitute 1 vial with 20ml WFI",
    "dilution": "Further dilute to 100ml NS or D5. Diluted solution stable for 8 hours at RT (25°c) and 48 hours in refrigerator (4 C). Diluted solution with D5 stable for 3 hours at RT (25°c) and 14 hours in refrigerator (4 C).",
    "infusion": "IV infusion over 4 hours (NS). IV infusion over 3 hours (if dilute in D5)."
  },
  {
    "drug": "Piperacillin / tazobactam 4g/0.5g",
    "reconstitution": "Reconstitute 1 vial with 20ml of WFI. Reconstituted solution stable for 24 hours in refrigerator (2-8 C).",
    "dilution": "Further dilute to 100ml NS or D5.",
    "infusion": "IV infusion over 30 minutes."
  },
  {
    "drug": "Vancomycin 500mg",
    "reconstitution": "Reconstitute 1 vial with 10ml of WFI.",
    "dilution": "Final concentration 5 mg/ml (eg: 500mg in 100ml over 1 hour, 1000mg in 200ml over 2 hours). Max concentration is 10mg/ml for fluid restriction.",
    "infusion": "Maximum infusion rate 10mg/min."
  },
  {
    "drug": "Acetylcysteine 5g/25ml",
    "reconstitution": "N/A",
    "dilution": "Preferably D5 as the diluent. NS may be used if D5 is not suitable. The diluted solution is stable for 24 hours when stored at RT (25°C).",
    "infusion": "First Dose: 150 mg/kg in 200ml D5 over 1 hour. Second Dose: 50 mg/kg in 500ml D5 over 4 hours. Third Dose: 100 mg/kg in 1000ml D5 over 16 hours."
  },
  {
    "drug": "Adrenaline 1mg/ml",
    "reconstitution": "Single Strength: Adrenaline 3mg in 50ml NS (60 mcg/ml). Double Strength: Adrenaline 6mg in 50ml NS (120 mcg/ml).",
    "dilution": "Single: Add 3 ampoules of 1 mg/ml Adrenaline to 47ml of NS. Double: Add 6 ampoules of 1 mg/ml Adrenaline to 44ml of NS.",
    "infusion": "0.1 - 0.5 mcg/kg/min via pump."
  },
  {
    "drug": "Aminophylline 250mg/10ml",
    "reconstitution": "N/A",
    "dilution": "Loading ≤250mg: Dilute in 50ml NS or D5. Loading 251-500mg: Dilute in 100ml NS or D5. Maintenance: 1 to 2 ampoules diluted to 250-500ml NS or D5 (Up to 1 mg/ml).",
    "infusion": "Loading: Run over 30 minutes. Maintenance: 24 Hours. Should not exceed 21 mg/hour in patients with cor pulmonale, cardiac decompensation, hepatic impairment, or > 60 years old."
  },
  {
    "drug": "Digoxin 500mcg/2ml",
    "reconstitution": "N/A",
    "dilution": "Loading: Dilute to 50 ml NS or D5. Maintenance: Dilute to 100ml NS or D5 (Max concentration: 62.5mcg/ml). Solution stable for 48 hours under RT.",
    "infusion": "Loading: Run for 15 minutes. Maintenance: Minimum Infusion time: over 10-20 minutes."
  },
  {
    "drug": "Dobutamine 250mg/20ml",
    "reconstitution": "Single Strength: 250mg in 50ml NS (5000 mcg/ml). Double Strength: 500mg in 50ml NS (10000 mcg/ml).",
    "dilution": "Single: Add 1 ampoule to 30ml of NS. Double: Add 2 ampoules to 10ml of NS. Stable for 24 hours at RT.",
    "infusion": "Usual Dose: 2.5-20mcg/kg/min."
  },
  {
    "drug": "Dopamine 200mg/5ml",
    "reconstitution": "Single Strength: 200mg in 50ml NS (4000 mcg/ml). Double Strength: 400mg in 50ml NS (8000 mcg/ml).",
    "dilution": "Single: Add 1 ampoule to 45ml of NS. Double: Add 2 ampoules to 40ml of NS. Stable for 24 hours at RT.",
    "infusion": "Usual Dose: 0.5-20mcg/kg/min."
  },
  {
    "drug": "Esomeprazole 40mg",
    "reconstitution": "IV INFUSION (8MG/H): 5ML NS PER 40MG VIAL",
    "dilution": "Reconstitute 2 VIALS (80MG) and further dilute to 20mL NS (Final: 4mg/mL). Stable for 12 hours in NS under RT (<30°C).",
    "infusion": "2ML/HOUR"
  },
  {
    "drug": "Frusemide 20mg/2ml",
    "reconstitution": "N/A",
    "dilution": "IV Bolus: Use undiluted. IV Infusion: Use Undiluted (100mg/10ml).",
    "infusion": "IV Bolus over 1-2 minutes. IV Infusion: Maximum infusion rate: 4mg/min (240mg/hr)."
  },
  {
    "drug": "Glyceryl Trinitrate 50mg/10ml",
    "reconstitution": "N/A",
    "dilution": "Add 6ml Glyceryl Trinitrate to 44ml of NS or D5 (600 mcg/ml). Stable for 24 hours after dilution at RT (25°C).",
    "infusion": "Max dose: 400mcg/minute."
  },
  {
    "drug": "Isosorbide Dinitrate 10mg/10ml",
    "reconstitution": "N/A",
    "dilution": "Dilute 1 ampoule up to 50ml NS or D5 (0.2mg/ml). 24 Hours at RT.",
    "infusion": "Dose: 2-12mg/hr may increase to 20mg/hr."
  },
  {
    "drug": "Labetalol 25mg/5ml",
    "reconstitution": "N/A",
    "dilution": "Dilute 4 ampoules (100mg) up to 50ml NS or D5 (2mg/ml). 24 Hours at 25°C.",
    "infusion": "Dose: 0.5-2mg/min (Total maximum dose: 300mg/day)."
  },
  {
    "drug": "Lytic Cocktail",
    "reconstitution": "N/A",
    "dilution": "N/A",
    "infusion": "STEP 1: 10ml IV Calcium Gluconate 10% undiluted over 10 minutes. STEP 2: 10 units IV Insulin (Actrapid) undiluted. STEP 3: 50ml IV Dextrose 50% undiluted over 15-30 minutes. In DKA patients or blood glucose level >14mmol/L, OMIT dextrose & monitor blood glucose."
  },
  {
    "drug": "Magnesium Sulfate 2.47g/5ml (10mmol/5ml)",
    "reconstitution": "N/A",
    "dilution": "Acute Asthma / ROF: 1 ampoule in 20ml NS or D5. Non-ROF: 1 ampoule in 100ml NS or D5. Diluted solution stable for 24 hours when stored below 25°C (RT).",
    "infusion": "Acute Asthma / ROF: 20 minutes. Non-ROF: 1 hour. Max daily dose for adults is 30g - 40g."
  },
  {
    "drug": "Noradrenaline 4mg/4ml",
    "reconstitution": "Single Strength: 4mg in 50ml D5% (80 mcg/ml). Double Strength: 8mg in 50ml D5% (160 mcg/ml).",
    "dilution": "Single: Add 1 ampoule to 46ml of D5%. Double: Add 2 ampoules to 42ml of D5%. Stable for 24 hours at 25°C (RT).",
    "infusion": "0.01 to 3 mcg/kg/minute."
  },
  {
    "drug": "Octreotide 0.05mg/ml or 0.1mg/ml",
    "reconstitution": "N/A",
    "dilution": "0.05mg/ml: Dilute 10 ampoules to 50ml of NS. 0.1mg/ml: Dilute 5 ampoules to 50ml of NS. Diluted solution stable for 24 hours below 25°C (RT).",
    "infusion": "Dose 25mcg/H: IVI 2.5ml/H. Dose 50 mcg/H: IVI 5 ml/H."
  },
  {
    "drug": "Pantoprazole 40mg",
    "reconstitution": "10ML NS PER 40MG VIAL",
    "dilution": "IV INFUSION (8MG/H): Reconstitute 2 VIALS (80MG) and add together (Final: 4mg/mL). Stability is 12 hours under RT (<30°C).",
    "infusion": "2ML/HOUR"
  },
  {
    "drug": "Phenytoin Sodium 250mg/5ml",
    "reconstitution": "N/A",
    "dilution": "IV Infusion: Dilute in 100ml of NS. IV Loading: Dilute to 50-100ml NS (Max concentration to 10mg/ml).",
    "infusion": "IV Infusion: Run over 1 hour. Max infusion rate: 50mg/minute. IV Loading: 1 Hour."
  },
  {
    "drug": "Potassium Chloride 10% (1g/10ml)",
    "reconstitution": "N/A",
    "dilution": "Fast Correction: 1g of KCL add to 100mL NS. Continuous: Add 1-1.5g to 500mL NS.",
    "infusion": "Fast: run over 1 hour. Max concentration: 40mmol/L or 1.5g KCL per pint. Max daily dose: 3mmol/kg/day."
  },
  {
    "drug": "Potassium Dihydrogen Phosphate",
    "reconstitution": "N/A",
    "dilution": "Dilute to 100ml NS or D5.",
    "infusion": "4-6 hours. Maximum total daily dose: 20 mmol PO4- (2 ampoules)."
  }
];

export const dbRenalStable: RenalStableDrug[] = [
  {
    "drug": "Amoxicillin (PO)",
    "dose": "250-1000mg TDS",
    "cr3050": "500mg BD",
    "cr1030": "500mg OD-BD",
    "cr10": "500mg OD",
    "rrt": "<strong>HD:</strong> 500mg OD, post-HD<br><strong>PD:</strong> 500mg BD"
  },
  {
    "drug": "Amoxicillin/Clavulanate (IV)",
    "dose": "1.2g TDS. In serious infection, can increase frequency up to QID",
    "cr3050": "1.2g BD",
    "cr1030": "1.2g OD",
    "cr10": "1.2g OD",
    "rrt": "<strong>HD:</strong> 1.2g OD<br><strong>PD:</strong> 1.2g OD"
  },
  {
    "drug": "Amoxicillin/Clavulanate (PO)",
    "dose": "625mg TDS. H. pylori eradication therapy: 1g BD",
    "cr3050": "usual dose BD",
    "cr1030": "usual dose OD",
    "cr10": "usual dose OD",
    "rrt": "<strong>HD:</strong> usual dose OD, additional dose after HD<br><strong>PD:</strong> usual dose OD"
  },
  {
    "drug": "Ampicillin (IV)",
    "dose": "1-2g QID / 2g 4H",
    "cr3050": "1-2g TDS (or 2g QID)",
    "cr1030": "1-2g BD (or 2g TDS)",
    "cr10": "1-2g OD (or 2g BD)",
    "rrt": "<strong>HD:</strong> post HD on HD day<br><strong>PD:</strong> 1-2g OD (or 2g BD)"
  },
  {
    "drug": "Ampicillin/sulbactam (IV)",
    "dose": "1.5-3g TDS or QID. Acinetobacter sp MDR: 9g TDS",
    "cr3050": "1.5-3g BD",
    "cr1030": "1.5-3g OD",
    "cr10": "1.5-3g OD",
    "rrt": "<strong>HD:</strong> 1.5-3g OD-BD, serve post HD on HD day<br><strong>PD:</strong> 1.5g BD, or 3g OD"
  },
  {
    "drug": "Ampicillin/sulbactam (PO)",
    "dose": "375mg - 750mg BD",
    "cr3050": "No renal dose adjustment",
    "cr1030": "No renal dose adjustment",
    "cr10": "Caution: use with caution",
    "rrt": "Caution: use with caution"
  },
  {
    "drug": "Azithromycin (IV/PO)",
    "dose": "500mg OD",
    "cr3050": "No renal dose adjustment",
    "cr1030": "No renal dose adjustment",
    "cr10": "No renal dose adjustment",
    "rrt": "<strong>HD:</strong> no supplemental dose necessary"
  },
  {
    "drug": "Benzathine penicillin (IM)",
    "dose": "2.4MU IM stat or weekly for 3 weeks",
    "cr3050": "No renal dose adjustment",
    "cr1030": "No renal dose adjustment",
    "cr10": "No renal dose adjustment",
    "rrt": "No renal dose adjustment"
  },
  {
    "drug": "Benzylpenicillin / Penicillin G (IV)",
    "dose": "2-4 MU 4H - QID",
    "cr3050": "75% of usual dose",
    "cr1030": "75% of usual dose",
    "cr10": "20-50% of usual dose",
    "rrt": "<strong>HD:</strong> 50-100% of usual dose BD-TDS, serve post HD on HD day<br><strong>PD:</strong> 20-50% of usual dose"
  },
  {
    "drug": "Cefazolin (IV)",
    "dose": "1-2g TDS",
    "cr3050": "1-2g BD-TDS",
    "cr1030": "500mg - 1g BD",
    "cr10": "500mg-1g OD",
    "rrt": "<strong>HD:</strong> 1g OD (serve post HD on HD day) or 2g EOD post HD (thrice weekly post HD)<br><strong>PD:</strong> 500mg BD or 1g OD"
  },
  {
    "drug": "Cefepime (IV) 1g BD / 1g QID",
    "dose": "1g BD / 1g QID",
    "cr3050": "1g OD (for 1g BD dose), 1g TDS (for 1g QID dose)",
    "cr1030": "500mg OD (for 1g BD dose), 1g BD (for 1g QID dose)",
    "cr10": "250mg OD (for 1g BD dose), 1g OD (for 1g QID dose)",
    "rrt": "<strong>HD/PD:</strong> 1g OD"
  },
  {
    "drug": "Cefepime (IV) 2g BD / 2g TDS",
    "dose": "2g BD / 2g TDS",
    "cr3050": "1g BD (for 2g BD dose), 2g BD (for 2g TDS dose)",
    "cr1030": "1g OD (for 2g BD dose), 2g OD or 1g BD (for 2g TDS dose)",
    "cr10": "500mg OD (for 2g BD dose), 1g OD (for 2g TDS dose)",
    "rrt": "<strong>HD/PD:</strong> 1g OD"
  },
  {
    "drug": "Cefoperazone (IV)",
    "dose": "1-2g BD",
    "cr3050": "No adjustment",
    "cr1030": "No adjustment",
    "cr10": "No adjustment",
    "rrt": "<strong>HD:</strong> serve post HD"
  },
  {
    "drug": "Cefoperazone/Sulbactam (IV)",
    "dose": "Acinetobacter sp MDR: 4g QID",
    "cr3050": "3g QID",
    "cr1030": "2g QID",
    "cr10": "2g QID",
    "rrt": "<strong>HD:</strong> 2g QID"
  },
  {
    "drug": "Cefotaxime (IV)",
    "dose": "2g TDS",
    "cr3050": "2g BD",
    "cr1030": "2g BD",
    "cr10": "2g OD",
    "rrt": "<strong>HD:</strong> 2g OD<br><strong>PD:</strong> 2g OD"
  },
  {
    "drug": "Cetaroline (IV)",
    "dose": "600mg BD (TDS if involved bloodstream infection)",
    "cr3050": "400mg BD-TDS",
    "cr1030": "300mg BD-TDS",
    "cr10": "200mg BD-TDS",
    "rrt": "<strong>PD/HD:</strong> 200mg BD-TDS"
  },
  {
    "drug": "Ceftazidime (IV)",
    "dose": "Non Meliodosis: 1-2g TDS",
    "cr3050": "1-2g BD",
    "cr1030": "1-2g OD",
    "cr10": "500mg - 1g OD",
    "rrt": "<strong>HD:</strong> 1g OD (serve post HD on HD day) or 2g EOD post HD<br><strong>PD:</strong> 1g OD"
  },
  {
    "drug": "Ceftazidime (IV) Meliodosis intensive therapy",
    "dose": "100-120 mg/kg/day. Wt >60kg: 2g TDS. Wt <60kg: 1g TDS.",
    "cr3050": "Wt >60kg: 2g BD, Wt <60kg: 1g BD",
    "cr1030": "Wt >60kg: 2g OD, Wt <60kg: 1g OD",
    "cr10": "Wt >60kg: 2g OD, Wt <60kg: 1g OD",
    "rrt": "<strong>HD/CAPD:</strong> As per CrCl <15, serve post HD"
  },
  {
    "drug": "Ceftriaxone (IV)",
    "dose": "1-2g OD",
    "cr3050": "No renal dose adjustment",
    "cr1030": "No renal dose adjustment",
    "cr10": "No renal dose adjustment",
    "rrt": "No renal dose adjustment"
  },
  {
    "drug": "Cefuroxime (IV)",
    "dose": "750mg-1.5g TDS",
    "cr3050": "750mg-1.5g BD",
    "cr1030": "750mg-1.5g OD",
    "cr10": "750mg-1.5g OD",
    "rrt": "<strong>HD:</strong> 750mg-1.5g OD, serve post HD on HD day<br><strong>PD:</strong> 750mg-1.5g OD"
  },
  {
    "drug": "Cefuroxime (PO)",
    "dose": "250-500mg BD",
    "cr3050": "250-500mg BD",
    "cr1030": "500mg OD",
    "cr10": "500mg OD",
    "rrt": "<strong>HD:</strong> 500mg OD, serve post HD on HD day<br><strong>PD:</strong> 500mg OD"
  },
  {
    "drug": "Cephalexin (PO)",
    "dose": "Prophylaxis for recurrent urinary tract infection: 250mg ON",
    "cr3050": "No renal dose adjustment",
    "cr1030": "No renal dose adjustment",
    "cr10": "No renal dose adjustment",
    "rrt": "No renal dose adjustment"
  },
  {
    "drug": "Ciprofloxacin (IV)",
    "dose": "250mg-1g QID or 500mg BD (maximum dose: 4g/day)",
    "cr3050": "250-500mg BD-TDS",
    "cr1030": "250-500mg OD-BD",
    "cr10": "250-500mg OD-BD",
    "rrt": "<strong>HD/PD:</strong> 250-500mg OD-BD, serve post HD on HD day"
  },
  {
    "drug": "Ciprofloxacin (PO)",
    "dose": "400mg BD-TDS or 500-750mg BD",
    "cr3050": "250-500mg BD",
    "cr1030": "500mg OD",
    "cr10": "500mg OD",
    "rrt": "<strong>HD/PD:</strong> 250-500mg OD, serve post HD"
  },
  {
    "drug": "Clarithromycin (PO)",
    "dose": "250-500mg BD",
    "cr3050": "500mg OD-BD",
    "cr1030": "500mg OD",
    "cr10": "500mg OD",
    "rrt": "<strong>HD:</strong> 500mg OD, serve post HD on HD day"
  },
  {
    "drug": "Clindamycin (IV/PO)",
    "dose": "Various depend on indication. H. pylori eradication therapy: 500mg BD",
    "cr3050": "No renal dose adjustment",
    "cr1030": "No renal dose adjustment",
    "cr10": "No renal dose adjustment",
    "rrt": "<strong>H. pylori:</strong> 250mg BD"
  },
  {
    "drug": "Cloxacillin (IV/PO) / Doxycycline (PO) / Erythromycin (IV/PO) / Fusidic acid (PO)",
    "dose": "Various (Doxycycline 100mg BD, Fusidic acid 500mg TDS)",
    "cr3050": "No renal dose adjustment",
    "cr1030": "No renal dose adjustment",
    "cr10": "No renal dose adjustment",
    "rrt": "No renal dose adjustment"
  },
  {
    "drug": "Imipenem/Cilastatin (IV)",
    "dose": "500mg QID / 1g TDS / 1g QID (Dosing based on Imipenem component)",
    "cr3050": "Adjusted",
    "cr1030": "Adjusted",
    "cr10": "Adjusted",
    "rrt": "<strong>HD/PD:</strong> 250-500mg BD"
  },
  {
    "drug": "Levofloxacin (IV/PO)",
    "dose": "500mg OD / 750mg OD",
    "cr3050": "Adjusted",
    "cr1030": "Adjusted",
    "cr10": "Adjusted",
    "rrt": "<strong>HD:</strong> 500mg Q48H"
  },
  {
    "drug": "Linezolid (IV/PO)",
    "dose": "600mg BD",
    "cr3050": "No renal dose adjustment",
    "cr1030": "No renal dose adjustment",
    "cr10": "No renal dose adjustment",
    "rrt": "<strong>HD:</strong> serve post HD on HD day"
  },
  {
    "drug": "Meropenem (IV)",
    "dose": "1-2g TDS",
    "cr3050": "Usual dose BD",
    "cr1030": "50% usual dose BD",
    "cr10": "50% usual dose OD",
    "rrt": "<strong>HD:</strong> 50% usual dose OD (post HD)<br><strong>PD:</strong> 50% usual dose OD"
  },
  {
    "drug": "Meropenem (IV) Meliodosis",
    "dose": "If normal dose 1g TDS",
    "cr3050": "1g BD",
    "cr1030": "1g OD",
    "cr10": "1g OD",
    "rrt": "<strong>HD/PD:</strong> 1g OD"
  },
  {
    "drug": "Metronidazole (IV/PO) / Moxifloxacin (PO) / Phenoxymethyl penicillin (PO)",
    "dose": "Various / 400mg OD / Various",
    "cr3050": "No renal dose adjustment",
    "cr1030": "No renal dose adjustment",
    "cr10": "No renal dose adjustment",
    "rrt": "<strong>HD:</strong> consider supplemental dose"
  },
  {
    "drug": "Minocycline (PO)",
    "dose": "100mg BD",
    "cr3050": "Do not exceed 200mg/day",
    "cr1030": "Do not exceed 200mg/day",
    "cr10": "Do not exceed 200mg/day",
    "rrt": "Do not exceed 200mg/day"
  },
  {
    "drug": "Nitrofurantoin (PO)",
    "dose": "50-100mg ON to QID depend on indication",
    "cr3050": "Do not use",
    "cr1030": "Do not use",
    "cr10": "Do not use",
    "rrt": "Do not use"
  },
  {
    "drug": "Ofloxacin (PO)",
    "dose": "TB Treatment: 400mg BD",
    "cr3050": "600mg-800mg, 3x/wk",
    "cr1030": "600mg-800mg, 3x/wk",
    "cr10": "600mg-800mg, 3x/wk",
    "rrt": "<strong>HD:</strong> 600mg-800mg, 3x/wk"
  },
  {
    "drug": "Piperacillin/Tazobactam (IV)",
    "dose": "4.5g QID",
    "cr3050": "4.5g TDS",
    "cr1030": "4.5g BD",
    "cr10": "4.5g BD",
    "rrt": "<strong>HD/PD:</strong> 4.5g BD"
  },
  {
    "drug": "Polymyxin E (Colistin) IV",
    "dose": "LD: 9 MU STAT (usual) or weight-based (6-9 MU). MD: 4.5 MU BD",
    "cr3050": "3 MU BD",
    "cr1030": "2.5 MU BD",
    "cr10": "2 MU BD",
    "rrt": "<strong>HD:</strong> 2 MU BD + 1.5 MU AD"
  },
  {
    "drug": "Polymyxin B (IV)",
    "dose": "LD: 25,000u/kg. MD: 15,000u/kg BD",
    "cr3050": "No renal dose adjustment",
    "cr1030": "No renal dose adjustment",
    "cr10": "No renal dose adjustment",
    "rrt": "No renal dose adjustment"
  },
  {
    "drug": "Streptomycin (IM)",
    "dose": "Tuberculosis: 15mg/kg OD",
    "cr3050": "No renal dose adjustments",
    "cr1030": "No renal dose adjustments",
    "cr10": "No renal dose adjustments",
    "rrt": "No renal dose adjustments"
  },
  {
    "drug": "Tetracycline (PO)",
    "dose": "H. pylori eradication therapy: 500mg QID",
    "cr3050": "250-500mg OD-BD",
    "cr1030": "250-500mg OD",
    "cr10": "250-500mg OD",
    "rrt": "<strong>HD/CAPD:</strong> 250-500mg OD"
  },
  {
    "drug": "Tigecycline (IV)",
    "dose": "100mg LD, then 50mg BD",
    "cr3050": "No renal dose adjustment",
    "cr1030": "No renal dose adjustment",
    "cr10": "No renal dose adjustment",
    "rrt": "No renal dose adjustment"
  },
  {
    "drug": "Trimethoprim / Sulfamethoxazole / Bactrim (IV/PO)",
    "dose": "15-20 mg/kg/day, in 2-4 divided doses OR 8-12 mg/kg/day in 2 divided doses. PO: 2 tab BD / 1 tab OD",
    "cr3050": "Adjusted",
    "cr1030": "Adjusted",
    "cr10": "Adjusted",
    "rrt": "<strong>PD/HD:</strong> Adjusted"
  },
  {
    "drug": "Trimethoprim / Sulfamethoxazole Meliodosis Therapy",
    "dose": "PO (1 tab = 400mg SMX/80mg TMP)",
    "cr3050": "Adjusted",
    "cr1030": "Adjusted",
    "cr10": "Adjusted",
    "rrt": "<strong>HD/CAPD:</strong> Adjusted"
  },
  {
    "drug": "Anidulafungin (IV) / Micafungin (IV)",
    "dose": "200mg stat, 100mg OD / 100mg OD",
    "cr3050": "No dosage adjustment",
    "cr1030": "No dosage adjustment",
    "cr10": "No dosage adjustment",
    "rrt": "<strong>HD:</strong> supplemental dose is not necessary"
  },
  {
    "drug": "Fluconazole (IV/PO)",
    "dose": "100-800mg/day depend on indication",
    "cr3050": "50% of usual MD",
    "cr1030": "50% of usual MD",
    "cr10": "50% of usual MD",
    "rrt": "<strong>HD:</strong> 50% of usual MD, serve post HD on HD day"
  },
  {
    "drug": "Griseofulvin (PO) / Itraconazole (PO) / Nystatin (PO) / Terbinafine (PO) / Voriconazole (PO)",
    "dose": "Various depend on indication",
    "cr3050": "No dosage adjustment",
    "cr1030": "No dosage adjustment",
    "cr10": "No dosage adjustment",
    "rrt": "No dosage adjustment"
  },
  {
    "drug": "Acyclovir (PO)",
    "dose": "400mg BD / 200mg 5x/day / 800mg 5x/day",
    "cr3050": "Adjusted",
    "cr1030": "Adjusted",
    "cr10": "Adjusted",
    "rrt": "<strong>PD/HD:</strong> Adjusted"
  },
  {
    "drug": "Acyclovir (IV)",
    "dose": "5mg/kg/dose TDS / 10mg/kg/dose TDS",
    "cr3050": "Adjusted",
    "cr1030": "Adjusted",
    "cr10": "Adjusted",
    "rrt": "<strong>PD/HD:</strong> Adjusted"
  },
  {
    "drug": "Ganciclovir (IV)",
    "dose": "5mg/kg BD / 5mg/kg OD",
    "cr3050": "Adjusted",
    "cr1030": "Adjusted",
    "cr10": "Adjusted",
    "rrt": "<strong>PD/HD:</strong> Adjusted"
  },
  {
    "drug": "Oseltamivir (PO)",
    "dose": "Treatment dose: 75mg BD",
    "cr3050": "Adjusted",
    "cr1030": "Adjusted",
    "cr10": "Adjusted",
    "rrt": "<strong>HD:</strong> Adjusted<br><strong>PD:</strong> Adjusted"
  },
  {
    "drug": "Valganciclovir (PO)",
    "dose": "900mg BD / 900mg OD",
    "cr3050": "Adjusted",
    "cr1030": "Adjusted",
    "cr10": "Adjusted",
    "rrt": "<strong>PD/HD:</strong> Adjusted"
  }
];


export const dbRenalICU: RenalICUDrug[] = [
  {
    "drug": "Acyclovir",
    "dose": "10 mg/kg/dose q8h",
    "cr3050": "10 mg/kg/dose q24hr",
    "cr1030": "10 mg/kg/dose q12h",
    "cr10": "5 mg/kg/dose q24h",
    "rrt": "<strong>HD:</strong> 5 mg/kg q24h<br><strong>CVVH:</strong> 10 mg/kg q24h<br><strong>CVVHD/CVVHDF:</strong> 10 mg/kg q12h<br><strong>CAPD:</strong> 2.5-6.25 mg/kg q24h"
  },
  {
    "drug": "Amoxicillin/Clavulanate",
    "dose": "1.2 g q8h",
    "cr3050": "1.2 g q8h",
    "cr1030": "1.2 g q12h",
    "cr10": "1.2 g q24h",
    "rrt": "<strong>HD:</strong> 1.2 g q24h + 600 mg AD<br><strong>CVVH:</strong> 1.2 g q12h"
  },
  {
    "drug": "Amphotericin",
    "dose": "0.3-1 mg/kg q24h",
    "cr3050": "Refer Appendix 4",
    "cr1030": "Refer Appendix 4",
    "cr10": "Refer Appendix 4",
    "rrt": "Refer Appendix 4"
  },
  {
    "drug": "Ampicillin/Sulbactam",
    "dose": "3 g q6h",
    "cr3050": "3 g q8h",
    "cr1030": "3 g q12h",
    "cr10": "3 g q24h",
    "rrt": "<strong>HD:</strong> 3 g q24h<br><strong>CVVH:</strong> 3 g q8h-q12h<br><strong>CVVHD:</strong> 3 g q8h<br><strong>CVVHDF:</strong> 3 g q6h-q8h<br><strong>CAPD:</strong> 3 g q24h"
  },
  {
    "drug": "Ampicillin/Sulbactam (Acinetobacter sp MDR)",
    "dose": "9 g q8h",
    "cr3050": "6 g q8h (CrCl 20-50)",
    "cr1030": "6 g q12h (CrCl &lt;20)",
    "cr10": "6 g q12h (CrCl &lt;20)",
    "rrt": "<strong>HD:</strong> 6 g q12h<br><strong>CVVH/CVVHD/CVVHDF:</strong> 9 g q8h"
  },
  {
    "drug": "Ampicillin",
    "dose": "2 g q4h - q6h*",
    "cr3050": "2 g q6h-q12h",
    "cr1030": "2 g q6h-q12h",
    "cr10": "2 g q12h-q24h",
    "rrt": "<strong>HD:</strong> 2 g q12h<br><strong>CVVH:</strong> 2 g q8h - q12h<br><strong>CVVHD:</strong> 2 g q8h<br><strong>CVVHDF:</strong> 2 g q6h - q8h<br><strong>CAPD:</strong> 0.5-1 g q12h"
  },
  {
    "drug": "Anidulafungin",
    "dose": "200 mg STAT, then 100 mg q24h",
    "cr3050": "Unchanged",
    "cr1030": "Unchanged",
    "cr10": "Unchanged",
    "rrt": "Unchanged"
  },
  {
    "drug": "Benzylpenicillin",
    "dose": "4 MU q4-6h",
    "cr3050": "1.5-3 MU q4-q6h",
    "cr1030": "1.5-3 MU q4-q6h",
    "cr10": "1-2 MU q4-q6h",
    "rrt": "<strong>HD:</strong> 1-2 MU q4h-q6h<br><strong>CVVH:</strong> 2 MU q4h-q6h<br><strong>CVVHD:</strong> 2-3 MU q4h-q6h<br><strong>CVVHDF:</strong> 2-4 MU q4h-q6h<br><strong>CAPD:</strong> 4 MU q12h"
  },
  {
    "drug": "Cefazolin",
    "dose": "2 g q8h",
    "cr3050": "2 g q12h",
    "cr1030": "2 g q24h",
    "cr10": "1 g q24h",
    "rrt": "<strong>HD:</strong> 1 g q24h<br><strong>CVVH/CVVHD/CVVHDF:</strong> 1 g q8h or 2 g q12h<br><strong>CAPD:</strong> 500 mg q12h"
  },
  {
    "drug": "Cefepime",
    "dose": "2 g q8h - q12h",
    "cr3050": "2 g q12h",
    "cr1030": "1 g q24h",
    "cr10": "1 g q24h",
    "rrt": "<strong>HD:</strong> 1 g q24h +1 g AD<br><strong>CVVH/CVVHD/CVVHDF:</strong> 2 g q8h-q12h<br><strong>CAPD:</strong> 2 g q48h"
  },
  {
    "drug": "Cefoperazone",
    "dose": "1-2 g q12h",
    "cr3050": "Renal impairment: no adjustment",
    "cr1030": "Renal impairment: no adjustment",
    "cr10": "Renal impairment: no adjustment",
    "rrt": "<strong>HD:</strong> serve AD"
  },
  {
    "drug": "Cefotaxime",
    "dose": "2 g q4-8h",
    "cr3050": "2 g q8h-q12h",
    "cr1030": "2 g q12h",
    "cr10": "2 g q24h",
    "rrt": "<strong>HD:</strong> 1 g-2 g q24h<br><strong>CVVH/CVVHD/CVVHDF:</strong> 2 g q12h-q24h<br><strong>CAPD:</strong> 1 g q24h"
  },
  {
    "drug": "Ceftazidime",
    "dose": "2 g q8h",
    "cr3050": "2 g q8h-q12h",
    "cr1030": "2 g q24h",
    "cr10": "1 g q24h",
    "rrt": "<strong>HD:</strong> 2 g q24h + 1 g AD<br><strong>CVVH:</strong> 2 g q12h<br><strong>CVVHD/CVVHDF:</strong> 2 g q8h-q12h<br><strong>CAPD:</strong> 1 g q24h"
  },
  {
    "drug": "Ceftazidime (Meliodosis)",
    "dose": "2 g q6h",
    "cr3050": "Wt &lt; 60kg: 1 g q8h<br>Wt &gt;= 60kg: 2 g q12h (CrCl 31-50)",
    "cr1030": "Wt &lt; 60kg: 1 g q12h<br>Wt &gt;= 60kg: 2 g q24h (CrCl 15-30)",
    "cr10": "Wt &lt; 60kg: 1 g q24h<br>Wt &gt;= 60kg: 1 g q24h (CrCl &lt; 15)",
    "rrt": "<strong>HD/CAPD:</strong> As per CrCl &lt;15, serve post HD"
  },
  {
    "drug": "Ceftriaxone",
    "dose": "2 g stat then 1g q12h",
    "cr3050": "2 g q8h",
    "cr1030": "Unchanged",
    "cr10": "2 g q12h",
    "rrt": "<strong>Unchanged</strong>"
  },
  {
    "drug": "Cefuroxime",
    "dose": "1.5 g q8h",
    "cr3050": "1.5 g q8h",
    "cr1030": "1.5 g q12h",
    "cr10": "1.5 g q24h",
    "rrt": "<strong>HD:</strong> 1.5 g q24h<br><strong>CVVH:</strong> 1.5 g q8-12h<br><strong>CAPD:</strong> 0.75-1.5 g q24h"
  },
  {
    "drug": "Ciprofloxacin",
    "dose": "400 mg LD then 400 mg q8-12h",
    "cr3050": "Unchanged",
    "cr1030": "400 mg q12-24h",
    "cr10": "400 mg q24h",
    "rrt": "<strong>HD:</strong> 400 mg q24h<br><strong>CVVH:</strong> 200 mg-400 mg q12h<br><strong>CVVHD/CVVHDF:</strong> 400 mg q12h<br><strong>CAPD:</strong> 400 mg q24h"
  },
  {
    "drug": "Clindamycin / Cloxacillin / Micafungin",
    "dose": "Depend on indication / 2 g q4-6h / 100 mg q24h",
    "cr3050": "Unchanged",
    "cr1030": "Unchanged",
    "cr10": "Unchanged",
    "rrt": "<strong>Unchanged</strong>"
  },
  {
    "drug": "Fluconazole",
    "dose": "800 mg stat then 400-800 mg q24h",
    "cr3050": "200-400 mg q24h",
    "cr1030": "200-400 mg q24h",
    "cr10": "200-400 mg q24h",
    "rrt": "<strong>HD:</strong> 200-400 mg q24h<br><strong>CVVH:</strong> 400 mg q24h<br><strong>CVVHD/CVVHDF:</strong> 400-800 mg q24h<br><strong>CAPD:</strong> 200 mg q24h"
  },
  {
    "drug": "Imipenem",
    "dose": "1 g q8h",
    "cr3050": "500 mg q6h",
    "cr1030": "500 mg q8h",
    "cr10": "500 mg q12h",
    "rrt": "<strong>HD:</strong> 500 mg q12h<br><strong>CVVH:</strong> 500 mg q8h<br><strong>CVVHD/CVVHDF:</strong> 500 mg q6h<br><strong>CAPD:</strong> 250 mg q12h"
  },
  {
    "drug": "Levofloxacin",
    "dose": "750 mg q24h",
    "cr3050": "750 mg q48h",
    "cr1030": "500 mg q48h",
    "cr10": "500 mg q48h",
    "rrt": "<strong>HD:</strong> 500 mg q48h<br><strong>CVVH:</strong> 250 mg q24h<br><strong>CVVHD:</strong> 500 mg q24h<br><strong>CVVHDF:</strong> 750 mg q24h<br><strong>CAPD:</strong> 500 mg q48h"
  },
  {
    "drug": "Linezolid",
    "dose": "600 mg q12h",
    "cr3050": "Unchanged",
    "cr1030": "Unchanged",
    "cr10": "Unchanged",
    "rrt": "<strong>HD:</strong> serve post HD on HD day"
  },
  {
    "drug": "Meropenem",
    "dose": "1-2 g q8h",
    "cr3050": "1-2 g q12h",
    "cr1030": "500 mg -1 g q12h",
    "cr10": "500 mg q12-24h",
    "rrt": "<strong>HD:</strong> 500 mg -1 g q24h + 250-500 mg AD<br><strong>CVVH/CVVHD/CVVHDF:</strong> 1-2 g q12h<br><strong>CAPD:</strong> 500 mg q24h"
  },
  {
    "drug": "Metronidazole",
    "dose": "500 mg q8h",
    "cr3050": "Unchanged",
    "cr1030": "Unchanged",
    "cr10": "Unchanged",
    "rrt": "<strong>HD/CAPD:</strong> 500 mg q8h<br><strong>CVVH/CVVHD/CVVHDF:</strong> 500 mg q8h"
  },
  {
    "drug": "Oseltamivir",
    "dose": "75 mg q12h",
    "cr3050": "75 mg q24h",
    "cr1030": "75 mg q24h",
    "cr10": "30mg q48h",
    "rrt": "<strong>HD:</strong> 75 mg q24h<br><strong>CVVH/CVVHD/CVVHDF:</strong> 75 mg q12h"
  },
  {
    "drug": "Piperacillin/Tazobactam",
    "dose": "4.5 g q6h",
    "cr3050": "4.5 g q6h",
    "cr1030": "4.5 g q8h",
    "cr10": "2.25 g q6h",
    "rrt": "<strong>HD:</strong> 2.25 g q6h<br><strong>CVVH:</strong> 2.25 g q6h<br><strong>CVVHD/CVVHDF:</strong> 4.5 g q8h<br><strong>CAPD:</strong> 2.25 g q8h"
  },
  {
    "drug": "Tigecycline",
    "dose": "100 mg LD then 50 mg q12h",
    "cr3050": "Unchanged",
    "cr1030": "Unchanged",
    "cr10": "Unchanged",
    "rrt": "Unchanged"
  },
  {
    "drug": "Trimethoprim/Sulfamethoxazole (TMP Content)",
    "dose": "5 mg/kg q6-8h",
    "cr3050": "5 mg/kg q8h",
    "cr1030": "5 mg/kg q12h",
    "cr10": "5-10 mg/kg q24h",
    "rrt": "<strong>HD/CAPD:</strong> 5-10 mg/kg q24h<br><strong>CVVH/CVVHD:</strong> 5 mg/kg q12h<br><strong>CVVHDF:</strong> 10 mg/kg q12h"
  },
  {
    "drug": "Trimethoprim/Sulfamethoxazole (Melioidosis)",
    "dose": "4 mg/kg q12h",
    "cr3050": "4 mg/kg q12h",
    "cr1030": "4 mg/kg q24h",
    "cr10": "4 mg/kg q24h",
    "rrt": "<strong>HD:</strong> 4 mg/kg q24h<br><strong>CVVH/CVVHD/CVVHDF:</strong> 4 mg/kg q12h<br><strong>CAPD:</strong> 4 mg/kg q24h"
  },
  {
    "drug": "Polymyxin E (Colistin)",
    "dose": "LD: 9 MU STAT (usual) or by weight",
    "cr3050": "3 MU BD",
    "cr1030": "2.5 MU BD",
    "cr10": "2 MU BD",
    "rrt": "<strong>CVVH/CWHDF:</strong> 4 MU TDS<br><strong>HD:</strong> 2 MU BD + 1.5 MU AD<br><strong>SLED 4h:</strong> 2 MU BD + 1.5 MU after SLED<br><strong>SLED 6h:</strong> 2 MU BD + 2.5 MU after SLED"
  },
  {
    "drug": "Polymyxin B",
    "dose": "LD: 25,000u/kg (Max 2MU/day)",
    "cr3050": "Unchanged",
    "cr1030": "Unchanged",
    "cr10": "Unchanged",
    "rrt": "<strong>Unchanged</strong>"
  }
];

export const dbRenalCommon: RenalStableDrug[] = [
  {
    "drug": "Metoclopramide",
    "dose": "10mg TDS (PO/IV)",
    "cr3050": "10mg TDS (100%)",
    "cr1030": "10mg BD-TDS (75-100%)",
    "cr10": "5mg BD to TDS (50%)",
    "rrt": "<strong>HD:</strong> 5mg BD-TDS, no supplemental dose needed<br><strong>PD:</strong> 5mg BD-TDS"
  },
  {
    "drug": "Famotidine",
    "dose": "20mg BD or 40mg ON (PO/IV)",
    "cr3050": "20mg OD or 20mg BD",
    "cr1030": "20mg OD",
    "cr10": "20mg EOD",
    "rrt": "<strong>HD:</strong> 20mg EOD, post-HD<br><strong>PD:</strong> 20mg EOD"
  },
  {
    "drug": "Gabapentin",
    "dose": "300mg TDS up to 600mg TDS (PO)",
    "cr3050": "300mg BD",
    "cr1030": "300mg OD",
    "cr10": "100-300mg EOD",
    "rrt": "<strong>HD:</strong> 100-300mg post-HD thrice weekly<br><strong>PD:</strong> 100-300mg EOD"
  },
  {
    "drug": "Allopurinol",
    "dose": "100-300mg OD (PO)",
    "cr3050": "100-200mg OD",
    "cr1030": "50-100mg OD (or 100mg EOD)",
    "cr10": "50mg OD or 100mg twice weekly",
    "rrt": "<strong>HD:</strong> 50mg OD or 100mg post-HD<br><strong>PD:</strong> 50mg OD"
  },
  {
    "drug": "Spironolactone",
    "dose": "25-100mg OD (PO)",
    "cr3050": "10-25mg OD (Monitor K+ closely)",
    "cr1030": "12.5mg EOD to 25mg EOD (Use with extreme caution)",
    "cr10": "Avoid (High risk of hyperkalemia)",
    "rrt": "<strong>HD/PD:</strong> Avoid if possible; otherwise monitor potassium and renal function daily"
  },
  {
    "drug": "Digoxin",
    "dose": "125-250mcg OD (PO/IV)",
    "cr3050": "125mcg OD or 62.5-125mcg OD",
    "cr1030": "62.5mcg OD or EOD",
    "cr10": "62.5mcg EOD or 3x/week",
    "rrt": "<strong>HD/PD:</strong> 62.5mcg EOD or 3x/week (Not cleared by dialysis, monitor levels closely)"
  },
  {
    "drug": "Ranitidine",
    "dose": "150mg BD (PO) or 50mg TDS (IV)",
    "cr3050": "150mg OD (PO) or 50mg BD (IV)",
    "cr1030": "150mg OD (PO) or 50mg BD (IV)",
    "cr10": "150mg EOD (PO) or 50mg OD (IV)",
    "rrt": "<strong>HD:</strong> 150mg EOD (PO), post-HD<br><strong>PD:</strong> 150mg EOD (PO)"
  },
  {
    "drug": "Enoxaparin",
    "dose": "Treatment: 1mg/kg BD or 1.5mg/kg OD (SC). Prophylaxis: 40mg OD",
    "cr3050": "Treatment: Standard dose. Prophylaxis: 40mg OD",
    "cr1030": "Treatment: 1mg/kg OD (SC). Prophylaxis: 20mg OD (SC)",
    "cr10": "Treatment: 1mg/kg OD (SC). Prophylaxis: 20mg OD (SC)",
    "rrt": "<strong>HD/PD:</strong> Treatment: Avoid if possible; use UFH. Prophylaxis: 20mg OD"
  },
  {
    "drug": "Morphine",
    "dose": "Titrated (IV/SC/PO)",
    "cr3050": "50-75% of normal dose, titrate slowly",
    "cr1030": "50% of normal dose, increase dosing interval (e.g. Q6-8H)",
    "cr10": "Avoid if possible (active neurotoxic metabolites accumulate)",
    "rrt": "<strong>HD/PD:</strong> Avoid if possible; use Fentanyl or Methadone. If essential, use at 25-50% dose with long intervals"
  },
  {
    "drug": "Colchicine",
    "dose": "500mcg BD to QID for acute gout (PO)",
    "cr3050": "Max 500mcg-1mg daily during acute flare. Prophylaxis: Max 500mcg daily",
    "cr1030": "Acute flare: 500mcg stat, do not repeat for 3 days. Prophylaxis: 500mcg EOD or avoid",
    "cr10": "Avoid / Contraindicated",
    "rrt": "<strong>HD/PD:</strong> Contraindicated. High risk of fatal neuromyopathy and bone marrow toxicity"
  },
  {
    "drug": "Metformin",
    "dose": "500mg - 1000mg BD/TDS (PO) [Max: 3g/day]",
    "cr3050": "Maximum 1000mg/day (500mg BD or 1000mg OD). Monitor renal function every 3-6 months.",
    "cr1030": "CrCl 30-45: Max 1000mg/day. CrCl <30: Avoid / Contraindicated.",
    "cr10": "Avoid / Contraindicated",
    "rrt": "<strong>HD/PD:</strong> Contraindicated due to high risk of lactic acidosis."
  },
  {
    "drug": "Pregabalin",
    "dose": "75mg BD to 300mg BD (PO) [Max: 600mg/day]",
    "cr3050": "75mg OD to 150mg BD (Max 300mg/day)",
    "cr1030": "25mg OD to 75mg BD (Max 150mg/day)",
    "cr10": "25mg EOD to 75mg OD (Max 75mg/day)",
    "rrt": "<strong>HD:</strong> 25-75mg OD + 25-75mg supplemental single dose post-HD session<br><strong>PD:</strong> 25-75mg EOD"
  },
  {
    "drug": "Tramadol",
    "dose": "50mg - 100mg Q6-8H (PO/IV) [Max: 400mg/day]",
    "cr3050": "Standard dosing (titrate cautiously)",
    "cr1030": "50mg - 100mg Q12H (Max 200mg/day)",
    "cr10": "50mg Q12H (Use with extreme caution; avoid if possible)",
    "rrt": "<strong>HD/PD:</strong> 50mg Q12H (Not dialyzable, active metabolite accumulates, monitor closely for seizure/sedation)"
  },
  {
    "drug": "Atenolol",
    "dose": "50mg - 100mg OD (PO)",
    "cr3050": "Max 50mg daily or 100mg every other day (EOD)",
    "cr1030": "Max 50mg EOD or 25mg daily",
    "cr10": "Max 25mg EOD or twice weekly",
    "rrt": "<strong>HD:</strong> 25-50mg post-HD thrice weekly (Highly dialyzable)<br><strong>PD:</strong> 25-50mg twice weekly"
  },
  {
    "drug": "Baclofen",
    "dose": "5mg TDS up to 20mg TDS (PO)",
    "cr3050": "Reduce standard dose by 33-50% (e.g. 5mg BD-TDS)",
    "cr1030": "Reduce standard dose by 50-75% (e.g. 5mg OD-BD)",
    "cr10": "Avoid or use 2.5mg OD with extreme vigilance",
    "rrt": "<strong>HD/PD:</strong> Avoid if possible (Extreme risk of Baclofen-induced encephalopathy, confusion, and coma due to non-clearance)"
  },
  {
    "drug": "Sitagliptin",
    "dose": "100mg OD (PO)",
    "cr3050": "50mg OD (CrCl 30-45)",
    "cr1030": "25mg OD (CrCl <30)",
    "cr10": "25mg OD",
    "rrt": "<strong>HD/PD:</strong> 25mg OD (Administered without regard to dialysis timing)"
  },
  {
    "drug": "Vildagliptin",
    "dose": "50mg BD (PO)",
    "cr3050": "50mg OD (CrCl 30-50)",
    "cr1030": "50mg OD (CrCl <30)",
    "cr10": "50mg OD",
    "rrt": "<strong>HD/PD:</strong> 50mg OD (Take dose post-HD on dialysis days)"
  },
  {
    "drug": "SGLT2 inhibitors (Empagliflozin / Dapagliflozin)",
    "dose": "Empagliflozin 10-25mg OD / Dapagliflozin 10mg OD (PO)",
    "cr3050": "Standard dose. Glycemic efficacy is reduced, but cardiorenal benefits persist.",
    "cr1030": "eGFR 20-30: Standard dose can be continued for CKD/HFrEF benefits. Do not initiate if eGFR <30.",
    "cr10": "eGFR <20: Avoid initiation. Discontinue therapy.",
    "rrt": "<strong>HD/PD:</strong> Contraindicated. Discontinue."
  },
  {
    "drug": "Dabigatran",
    "dose": "150mg BD or 110mg BD (PO)",
    "cr3050": "150mg BD or 110mg BD (use 110mg BD if bleeding risk high)",
    "cr1030": "CrCl 15-30: 75mg BD or avoid. CrCl <15: Avoid / Contraindicated.",
    "cr10": "Avoid / Contraindicated",
    "rrt": "<strong>HD/PD:</strong> Avoid / Contraindicated."
  },
  {
    "drug": "Rivaroxaban",
    "dose": "20mg OD (PO) [15mg BD for initial DVT/PE treatment]",
    "cr3050": "15mg OD (Stroke prevention in AF)",
    "cr1030": "CrCl 15-29: 15mg OD (Use with caution). CrCl <15: Avoid / Contraindicated.",
    "cr10": "Avoid / Contraindicated",
    "rrt": "<strong>HD/PD:</strong> Avoid / Contraindicated."
  },
  {
    "drug": "Apixaban",
    "dose": "5mg BD (PO)",
    "cr3050": "5mg BD (Reduce to 2.5mg BD if meeting ≥2 of: Age ≥80, Weight ≤60kg, Creatinine ≥133 μmol/L)",
    "cr1030": "CrCl 15-29: 2.5mg BD. CrCl <15: Avoid / Contraindicated.",
    "cr10": "Avoid / Contraindicated",
    "rrt": "<strong>HD/PD:</strong> Avoid / Contraindicated."
  },
  {
    "drug": "Edoxaban",
    "dose": "60mg OD (PO)",
    "cr3050": "30mg OD",
    "cr1030": "CrCl 15-29: 30mg OD. CrCl <15: Avoid / Contraindicated.",
    "cr10": "Avoid / Contraindicated",
    "rrt": "<strong>HD/PD:</strong> Avoid / Contraindicated."
  },
  {
    "drug": "Enalapril",
    "dose": "5-20mg OD",
    "cr3050": "50% of usual dose",
    "cr1030": "25-50% of usual dose",
    "cr10": "Avoid or 25% dose",
    "rrt": "50% dose"
  },
  {
    "drug": "Lisinopril",
    "dose": "10-40mg OD",
    "cr3050": "5-10mg OD",
    "cr1030": "2.5-5mg OD",
    "cr10": "2.5mg OD",
    "rrt": "2.5mg OD"
  },
  {
    "drug": "Losartan",
    "dose": "25-100mg OD",
    "cr3050": "No renal dose adjustment",
    "cr1030": "No renal dose adjustment",
    "cr10": "25-50mg OD",
    "rrt": "25-50mg OD"
  },
  {
    "drug": "Valsartan",
    "dose": "80-320mg OD",
    "cr3050": "No renal dose adjustment",
    "cr1030": "No renal dose adjustment",
    "cr10": "Use with caution",
    "rrt": "Use with caution"
  }
];

export const dbEnteral: EnteralDrug[] = [
  // CARDIOVASCULAR
  {
    drug: "Aspirin (Plain / Dispersible)",
    category: "Cardiovascular",
    canCrush: "Yes",
    instructions: "Crush and disperse in 15-30mL of water. Dispersible form is highly preferred.",
    alternative: "Dispersible tablet"
  },
  {
    drug: "Aspirin EC (Enteric Coated)",
    category: "Cardiovascular",
    canCrush: "No",
    instructions: "Do NOT crush enteric-coated tablets. The coating protects the gastric mucosa and prevents acid degradation. Crushing destroys this protection.",
    alternative: "Switch to plain or dispersible Aspirin tablet."
  },
  {
    drug: "Clopidogrel",
    category: "Cardiovascular",
    canCrush: "Yes",
    instructions: "Crush and disperse standard tablet in 15-30mL of water.",
    alternative: "None"
  },
  {
    drug: "Atorvastatin",
    category: "Cardiovascular",
    canCrush: "Yes",
    instructions: "Crush film-coated tablet and disperse in 15-30mL of water.",
    alternative: "None"
  },
  {
    drug: "Metoprolol Tartrate (Immediate Release)",
    category: "Cardiovascular",
    canCrush: "Yes",
    instructions: "Crush tablet and disperse in 15-30mL of water.",
    alternative: "None"
  },
  {
    drug: "Metoprolol Succinate (Controlled Release / ZOK)",
    category: "Cardiovascular",
    canCrush: "No",
    instructions: "Do NOT crush controlled/extended-release tablets as it causes dose dumping (rapid release of entire dose), leading to profound bradycardia or hypotension.",
    alternative: "Switch to Metoprolol Tartrate (Immediate Release) given twice daily."
  },
  {
    drug: "Amlodipine",
    category: "Cardiovascular",
    canCrush: "Yes",
    instructions: "Crush tablet and disperse in 15-30mL of water.",
    alternative: "Amlodipine suspension"
  },
  {
    drug: "Enalapril",
    category: "Cardiovascular",
    canCrush: "Yes",
    instructions: "Crush tablet and disperse in 15-30mL of water.",
    alternative: "None"
  },
  {
    drug: "Lisinopril",
    category: "Cardiovascular",
    canCrush: "Yes",
    instructions: "Crush tablet and disperse in 15-30mL of water.",
    alternative: "None"
  },
  {
    drug: "Valsartan",
    category: "Cardiovascular",
    canCrush: "Yes",
    instructions: "Crush tablet and disperse in 15-30mL of water.",
    alternative: "None"
  },
  {
    drug: "Warfarin",
    category: "Cardiovascular",
    canCrush: "Yes",
    instructions: "Crush tablet and disperse immediately in 15-30mL of water. Flush the tube thoroughly before and after to ensure full dose delivery due to narrow therapeutic index.",
    alternative: "None"
  },
  {
    drug: "Digoxin",
    category: "Cardiovascular",
    canCrush: "Yes",
    instructions: "Crush tablet and disperse in 15-30mL of water.",
    alternative: "Digoxin pediatric elixir (0.05mg/mL)"
  },
  {
    drug: "Nifedipine Retard / LA / XL",
    category: "Cardiovascular",
    canCrush: "No",
    instructions: "Do NOT crush sustained-release formulations. Crushing causes immediate dose dumping, resulting in dangerous severe hypotension and reflex tachycardia.",
    alternative: "Switch to Amlodipine or immediate-release Nifedipine (if absolutely necessary, but generally amlodipine is safer)."
  },
  {
    drug: "Clonidine",
    category: "Cardiovascular",
    canCrush: "Yes",
    instructions: "Crush tablet and disperse in 15-30mL of water.",
    alternative: "None"
  },
  {
    drug: "Frusemide (Furosemide)",
    category: "Cardiovascular",
    canCrush: "Yes",
    instructions: "Crush tablet and disperse in 15-30mL of water.",
    alternative: "Frusemide oral liquid (10mg/mL) or IV route"
  },
  {
    drug: "Spironolactone",
    category: "Cardiovascular",
    canCrush: "Yes",
    instructions: "Crush tablet and disperse in 15-30mL of water. Has a very strong, unpleasant odor.",
    alternative: "Spironolactone suspension"
  },
  {
    drug: "Felodipine (Extended Release)",
    category: "Cardiovascular",
    canCrush: "No",
    instructions: "Do NOT crush extended-release felodipine tablets (e.g., Felodipine ER / Plendil). Crushing destroys the extended-release membrane or matrix, causing rapid release of the entire dose (dose dumping) which risks severe vasodilation, profound hypotension, and reflex tachycardia.",
    alternative: "Switch to Amlodipine (immediate-release / crushable tablet)."
  },
  {
    drug: "Rivaroxaban (NOAC / Xarelto)",
    category: "Cardiovascular",
    canCrush: "Yes",
    instructions: "Standard tablets (10mg, 15mg, 20mg) can be crushed and suspended in 15-30mL of water. Crush immediately before administration and flush thoroughly. It is stable in water for up to 4 hours. Administration into a gastric/nasogastric tube is highly preferred as jejunal (J-tube) administration can significantly reduce absorption.",
    alternative: "None. If jejunal administration is required, seek hematology advice or switch to Parenteral Low Molecular Weight Heparin (e.g., Enoxaparin)."
  },
  {
    drug: "Apixaban (NOAC / Eliquis)",
    category: "Cardiovascular",
    canCrush: "Yes",
    instructions: "Standard tablets (2.5mg, 5mg) can be crushed and suspended in 15-30mL of water. Stable in water. Can be administered with or without enteral feeds into the gastric/NG tube. Flush the tube thoroughly before and after.",
    alternative: "None"
  },
  {
    drug: "Dabigatran (NOAC / Pradaxa)",
    category: "Cardiovascular",
    canCrush: "No",
    instructions: "Do NOT open the capsules, crush, or chew the pellets inside. Opening the capsule increases oral bioavailability by 75% due to altered systemic absorption, which severely increases the risk of major bleeding. The pellets also contain a tartaric acid core that is essential for absorption and will cause severe mucosal irritation if exposed directly to the esophagus or gastric lining.",
    alternative: "Switch to a crushable oral anticoagulant (e.g., Rivaroxaban, Apixaban, or Warfarin) or Parenteral Low Molecular Weight Heparin (e.g., Enoxaparin)."
  },
  {
    drug: "Isosorbide Mononitrate (SR / Imdur)",
    category: "Cardiovascular",
    canCrush: "No",
    instructions: "Do NOT crush sustained-release formulations. Crushing causes immediate dose dumping, resulting in rapid drug absorption, severe headaches, and profound hypotension.",
    alternative: "Switch to immediate-release Isosorbide Dinitrate (crushed) or Isosorbide Mononitrate immediate-release standard tablets."
  },
  {
    drug: "Carvedilol",
    category: "Cardiovascular",
    canCrush: "Yes",
    instructions: "Crush standard tablet and disperse in 15-30mL of water. Highly lipophilic and is absorbed better with food/feeds.",
    alternative: "None"
  },
  {
    drug: "Amiodarone",
    category: "Cardiovascular",
    canCrush: "Yes",
    instructions: "Crush tablet and disperse in 15-30mL of water. Highly lipophilic and can adsorb to PVC tubing, so flush the feeding tube very thoroughly with water before and after.",
    alternative: "None"
  },
  {
    drug: "Bisoprolol",
    category: "Cardiovascular",
    canCrush: "Yes",
    instructions: "Crush standard tablet and disperse in 15-30mL of water. Highly soluble and well absorbed.",
    alternative: "None"
  },
  {
    drug: "Perindopril",
    category: "Cardiovascular",
    canCrush: "Yes",
    instructions: "Crush standard tablet and disperse in 15-30mL of water. Disperses very quickly.",
    alternative: "Perindopril arginine dispersible forms or alternate ACE inhibitors."
  },
  {
    drug: "Doxazosin Standard",
    category: "Cardiovascular",
    canCrush: "Yes",
    instructions: "Crush standard immediate-release tablet and disperse in 15-30mL of water.",
    alternative: "None"
  },
  {
    drug: "Doxazosin GITS / Cardura XL (Extended Release)",
    category: "Cardiovascular",
    canCrush: "No",
    instructions: "Do NOT crush, split, or chew extended-release GITS tablets (Cardura XL). The tablet uses an osmotic push-pull system (GITS) that will be destroyed, leading to sudden dose dumping, severe hypotension, and syncope.",
    alternative: "Switch to standard immediate-release Doxazosin tablets (given in divided doses)."
  },

  // INFECTIOUS DISEASE / ANTIBIOTICS
  {
    drug: "Amoxicillin",
    category: "Infectious Disease",
    canCrush: "Yes",
    instructions: "Open capsules and disperse powder in 15-30mL of water. Flush thoroughly.",
    alternative: "Amoxicillin oral suspension (preferred)"
  },
  {
    drug: "Ciprofloxacin",
    category: "Infectious Disease",
    canCrush: "Caution",
    instructions: "Crush standard tablet and disperse. Enteral nutrition significantly reduces Ciprofloxacin bioavailability (by 30-50%). Hold feeds 1-2 hours before and 1-2 hours after. Flush tube with at least 30mL of water. Do NOT use Ciprofloxacin oral suspension as it clogs feeding tubes due to oil-based microcapsules.",
    alternative: "Switch to IV Ciprofloxacin if enteral feeds cannot be held."
  },
  {
    drug: "Azithromycin",
    category: "Infectious Disease",
    canCrush: "Yes",
    instructions: "Crush tablet and disperse in 15-30mL of water. Flush well.",
    alternative: "Azithromycin oral suspension"
  },
  {
    drug: "Metronidazole",
    category: "Infectious Disease",
    canCrush: "Yes",
    instructions: "Crush standard or film-coated tablet and disperse in 15-30mL of water. Extremely bitter, but safe for enteral administration.",
    alternative: "Metronidazole suspension or IV Metronidazole"
  },
  {
    drug: "Cefuroxime Axetil",
    category: "Infectious Disease",
    canCrush: "Yes",
    instructions: "Crush tablet and disperse in 15-30mL of water. Extremely bitter taste when crushed. Flush very thoroughly.",
    alternative: "Cefuroxime oral suspension"
  },

  // ENDOCRINE / DIABETES
  {
    drug: "Metformin (Standard / Immediate Release)",
    category: "Endocrine",
    canCrush: "Yes",
    instructions: "Crush tablet and disperse in 15-30mL of water.",
    alternative: "Metformin oral solution"
  },
  {
    drug: "Metformin XR (Extended Release)",
    category: "Endocrine",
    canCrush: "No",
    instructions: "Do NOT crush extended-release tablets. Crushing destroys the polymer matrix, causing rapid release of the entire dose and increasing gastrointestinal toxicity.",
    alternative: "Switch to standard immediate-release Metformin tablets (given in divided doses)."
  },
  {
    drug: "Gliclazide (Standard)",
    category: "Endocrine",
    canCrush: "Yes",
    instructions: "Crush tablet and disperse in 15-30mL of water.",
    alternative: "None"
  },
  {
    drug: "Gliclazide MR (Modified Release)",
    category: "Endocrine",
    canCrush: "No",
    instructions: "Do NOT crush Gliclazide MR tablets (e.g., Diamicron MR). The gel-forming matrix will be destroyed, leading to dose dumping and risk of severe hypoglycemia.",
    alternative: "Switch to standard immediate-release Gliclazide."
  },
  {
    drug: "Sitagliptin",
    category: "Endocrine",
    canCrush: "Yes",
    instructions: "Crush tablet and disperse in 15-30mL of water.",
    alternative: "None"
  },
  {
    drug: "Levothyroxine",
    category: "Endocrine",
    canCrush: "Caution",
    instructions: "Crush tablet and disperse in 15-30mL of water. Enteral feeding formula binds levothyroxine, greatly reducing absorption. Hold feeding for at least 1 hour before and 1 hour after administration. Monitor TSH levels closely.",
    alternative: "None"
  },
  {
    drug: "Prednisolone",
    category: "Endocrine",
    canCrush: "Yes",
    instructions: "Crush tablet and disperse in 15-30mL of water. Soluble tablets are highly preferred and disperse easily.",
    alternative: "Prednisolone syrup or dispersible tablets"
  },
  {
    drug: "Carbimazole",
    category: "Endocrine",
    canCrush: "Yes",
    instructions: "Crush tablet and disperse in 15-30mL of water. Stable in water.",
    alternative: "None"
  },
  {
    drug: "Propylthiouracil (PTU)",
    category: "Endocrine",
    canCrush: "Yes",
    instructions: "Crush tablet and disperse in 15-30mL of water.",
    alternative: "None"
  },

  // NEUROLOGY / PSYCHIATRY
  {
    drug: "Sodium Valproate (Standard)",
    category: "Neurology",
    canCrush: "Yes",
    instructions: "Crush tablet and disperse in 15-30mL of water.",
    alternative: "Sodium Valproate syrup (preferred)"
  },
  {
    drug: "Sodium Valproate Chrono / CR (Epilim Chrono)",
    category: "Neurology",
    canCrush: "No",
    instructions: "Do NOT crush controlled-release tablets. Crushing destroys the slow-release mechanism, leading to fluctuating anticonvulsant levels and potential breakthrough seizures.",
    alternative: "Switch to Epilim syrup or standard immediate-release tablets."
  },
  {
    drug: "Carbamazepine CR (Tegretol CR)",
    category: "Neurology",
    canCrush: "No",
    instructions: "Do NOT crush controlled-release tablets. Crushing leads to dose dumping and toxicity (ataxia, nystagmus, lethargy).",
    alternative: "Switch to immediate-release Carbamazepine tablets (crushed) or Carbamazepine suspension (diluted with equal water)."
  },
  {
    drug: "Gabapentin",
    category: "Neurology",
    canCrush: "Yes",
    instructions: "Open capsule and disperse powder in 15-30mL of water. Flush the tube thoroughly.",
    alternative: "Gabapentin oral solution"
  },
  {
    drug: "Phenytoin Sodium",
    category: "Neurology",
    canCrush: "Caution",
    instructions: "Open capsule or crush tablet and disperse. Phenytoin is highly adsorbed by enteral feeding formulas, causing subtherapeutic serum levels. Hold feeds 2 hours before and 2 hours after dosing. Flush tube with 30-50mL of water. Monitor blood levels closely.",
    alternative: "Phenytoin suspension (dilute with equal volume of water before flush)"
  },
  {
    drug: "Levetiracetam (Keppra)",
    category: "Neurology",
    canCrush: "Yes",
    instructions: "Crush tablet and disperse in 15-30mL of water. Highly soluble.",
    alternative: "Levetiracetam oral solution"
  },
  {
    drug: "Pregabalin (Lyrica)",
    category: "Neurology",
    canCrush: "Yes",
    instructions: "Open capsule and disperse the white powder in 15-30mL of water. Highly water-soluble and stable.",
    alternative: "Pregabalin oral solution (20mg/mL)"
  },
  {
    drug: "Levodopa / Carbidopa (Sinemet / Madopar)",
    category: "Neurology",
    canCrush: "Yes",
    instructions: "Standard immediate-release tablets can be crushed and dispersed in 15-30mL of water. Administer immediately as levodopa degrades upon exposure to light and air. Do NOT crush CR/retard forms.",
    alternative: "Avoid CR/retard forms; switch to immediate-release form for crushing."
  },

  // GASTROINTESTINAL
  {
    drug: "Omeprazole Capsule (Enteric Coated Granules)",
    category: "Gastrointestinal",
    canCrush: "No",
    instructions: "Do NOT crush enteric-coated pellets/granules inside the capsule. Crushing inactivates the drug in stomach acid. Open the capsule, mix intact pellets with an acidic juice (e.g., orange/apple juice) or 8.4% Sodium Bicarbonate (as buffer), flush immediately through a sufficiently large tube (>14Fr) to prevent clogging. Do NOT mix with plain water or alkaline feeds.",
    alternative: "Switch to IV Omeprazole or Esomeprazole dispersible tablets (Nexium)."
  },
  {
    drug: "Pantoprazole",
    category: "Gastrointestinal",
    canCrush: "No",
    instructions: "Do NOT crush enteric-coated tablets. Acid-labile drug will be immediately destroyed by gastric juice.",
    alternative: "Switch to IV Pantoprazole, or Esomeprazole dispersible tablets (Nexium)."
  },
  {
    drug: "Metoclopramide",
    category: "Gastrointestinal",
    canCrush: "Yes",
    instructions: "Crush tablet and disperse in 15-30mL of water.",
    alternative: "Metoclopramide oral liquid or IV route"
  },
  {
    drug: "Lactulose",
    category: "Gastrointestinal",
    canCrush: "Yes",
    instructions: "Liquid formulation. Extremely viscous and has high osmolarity. MUST dilute with an equal volume of water before administration to prevent tube occlusion and reduce the risk of osmotic diarrhea.",
    alternative: "None"
  },
  {
    drug: "Esomeprazole (Nexium MUPS)",
    category: "Gastrointestinal",
    canCrush: "No",
    instructions: "Do NOT crush the tablet. This is a Multiple Unit Pellet System (MUPS). Place the tablet in 15-30mL of non-carbonated water. Wait 2-3 minutes for the tablet to disperse into hundreds of tiny enteric-coated microgranules. Gently swirl and flush immediately through a tube >=14Fr. Flush thoroughly with water to ensure no microgranules remain in the tube.",
    alternative: "Esomeprazole dispersible tablets or IV Esomeprazole"
  },
  {
    drug: "Domperidone",
    category: "Gastrointestinal",
    canCrush: "Yes",
    instructions: "Crush standard tablet and disperse in 15-30mL of water. Highly stable and disperses well.",
    alternative: "Domperidone oral suspension / liquid"
  },

  // OTHERS / RESPIRATORY / PAIN
  {
    drug: "Paracetamol (Acetaminophen)",
    category: "Others",
    canCrush: "Yes",
    instructions: "Crush tablet and disperse in 15-30mL of water. Dispersible / soluble formulations are highly preferred.",
    alternative: "Paracetamol syrup or suspension"
  },
  {
    drug: "Morphine SR (MST Continus)",
    category: "Others",
    canCrush: "No",
    instructions: "Do NOT crush, break, or chew sustained-release tablets (e.g., MST Continus, OxyContin). Crushing destroys the release matrix, causing immediate release of the entire dose (dose dumping) which risks fatal respiratory depression.",
    alternative: "Switch to immediate-release Morphine oral solution (preferred) or Parenteral/Subcutaneous route."
  },
  {
    drug: "Allopurinol",
    category: "Others",
    canCrush: "Yes",
    instructions: "Crush tablet and disperse in 15-30mL of water.",
    alternative: "None"
  },
  {
    drug: "Potassium Chloride SR (KSR)",
    category: "Others",
    canCrush: "No",
    instructions: "Do NOT crush sustained-release Potassium Chloride tablets (KSR). Crushing can cause severe localized mucosal irritation, ulceration, or necrosis in the GI tract due to rapid potassium release, and will clog the tube.",
    alternative: "Switch to liquid Potassium Chloride elixir or effervescent potassium tablets."
  },
  {
    drug: "Calcium Carbonate",
    category: "Others",
    canCrush: "Yes",
    instructions: "Crush tablet and disperse in 15-30mL of water. Disperses poorly and tends to settle quickly. Mix thoroughly and flush the tube immediately and vigorously with water to prevent clogging.",
    alternative: "None"
  },
  {
    drug: "Ferrous Sulfate (Iron)",
    category: "Others",
    canCrush: "Yes",
    instructions: "Crush tablet and disperse in water. Note that iron can cause tube clogging and staining. Flush very thoroughly.",
    alternative: "Iron syrup / liquid drops"
  },
  {
    drug: "Mycophenolate Mofetil (CellCept)",
    category: "Others",
    canCrush: "No",
    instructions: "Do NOT crush standard film-coated tablets or open capsules. Mycophenolate has potent teratogenic and mutagenic properties. Crushing or opening capsules releases fine powder aerosols, posing severe inhalation and contact hazard to healthcare personnel. If necessary, use liquid formulation or handle with full PPE / cytotoxic safety hood.",
    alternative: "Mycophenolate oral suspension (prepared in pharmacy with hazardous drug containment)."
  }
];

