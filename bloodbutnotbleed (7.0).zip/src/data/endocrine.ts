export interface EndocrineProtocol {
  id: string;
  category: "dynamic" | "pituitary" | "biopsy";
  title: string;
  cap?: string; // e.g. "Yellow Cap", "Purple Cap (EDTA)"
  timeline?: string;
  interpretation?: string | string[];
  safety?: string;
  components?: string;
  critical?: string;
  preBiopsy?: string;
  prep?: string;
  stability?: string;
  coresRequired?: string;
  warning?: string;
}

export const endocrineProtocols: EndocrineProtocol[] = [
  // 1. Dynamic Endocrinology
  {
    id: "synacthen",
    category: "dynamic",
    title: "Short Synacthen Test (ACTH Stimulation)",
    timeline: "Draw baseline cortisol (T=0). Inject Synacthen 250 µg IV or IM. Draw cortisol at exactly 30 mins and 60 mins.",
    interpretation: "Stimulated peak cortisol must cross >420 nmol/L (or >500 nmol/L depending on assay kit) to rule out primary adrenal insufficiency."
  },
  {
    id: "odst",
    category: "dynamic",
    title: "Overnight Dexamethasone Suppression (ODST)",
    timeline: "Patient ingests 1 mg oral Dexamethasone at 11:00 PM - midnight. Draw single serum cortisol the next morning at 8:00 AM.",
    interpretation: "Normal axis response suppresses serum cortisol safely to <50 nmol/L (<1.8 µg/dL). Failure to suppress suggests Cushing's syndrome."
  },
  {
    id: "ogtt_gh",
    category: "dynamic",
    title: "Growth Hormone Suppression Test (OGTT-GH)",
    timeline: "Administer standard 75g oral glucose load. Draw synchronized pairs of Growth Hormone and Glucose at 0, 30, 60, 90, and 120 minutes.",
    interpretation: "Glucose suppresses normal Growth Hormone to <1.0 µg/L. Failure to suppress confirms Acromegaly."
  },
  {
    id: "water_dep",
    category: "dynamic",
    title: "Water Deprivation Test (Fluid Deprivation)",
    timeline: "Restrict all fluids from 07:30 AM. Collect baseline weight, BP, serum & urine osmolality, and serum Na+. Measure these parameters hourly. Once serum osmolality >295 mOsm/kg or serum Na+ >145 mmol/L (with urine remaining dilute), administer 2 µg Desmopressin (DDAVP) SC/IM. Measure urine osmolality at 1 hour and 2 hours post-DDAVP.",
    safety: "Stop immediately if body weight loss exceeds 3% (risk of severe dehydration/vascular collapse), or if the patient becomes hypotensive or distressed.",
    interpretation: [
      "Normal / Primary Polydipsia: Urine concentrates well (>600 mOsm/kg) during fluid deprivation; DDAVP produces <10% further rise.",
      "Cranial (Central) DI: Urine remains dilute (<300 mOsm/kg) during deprivation, but rises significantly (>50% increase) after DDAVP.",
      "Nephrogenic DI: Urine remains dilute (<300 mOsm/kg) during deprivation, and fails to concentrate (<50% increase) after DDAVP."
    ]
  },

  // 2. Anterior Pituitary Hormone Panel
  {
    id: "am_cortisol",
    category: "pituitary",
    title: "AM Cortisol (Adrenal Axis)",
    cap: "Yellow Cap",
    timeline: "Draw at 08:00 AM. Avoid stress or exogenous glucocorticoids prior to the blood draw.",
    interpretation: [
      "AM Cortisol <100 nmol/L strongly indicates adrenal insufficiency.",
      "AM Cortisol >350–400 nmol/L usually rules out adrenal insufficiency.",
      "In-between grey values (100–350 nmol/L) require a Short Synacthen Test."
    ]
  },
  {
    id: "tft_axis",
    category: "pituitary",
    title: "Thyroid Function Test / TFT (Thyroid Axis)",
    cap: "Yellow Cap",
    components: "Free T4 (FT4) + TSH.",
    interpretation: "Central/secondary hypothyroidism is diagnosed by a low or inappropriately normal TSH paired with a low Free T4. Do not rely on TSH alone!"
  },
  {
    id: "plasma_acth",
    category: "pituitary",
    title: "Plasma ACTH (Corticotropic)",
    cap: "Purple Cap (EDTA)",
    critical: "Draw into a pre-chilled EDTA tube, place immediately in crushed ice, and transport to the laboratory within 15 minutes. Centrifuge inside a refrigerated centrifuge.",
    interpretation: "Paired with morning cortisol. Low cortisol with a low/normal ACTH points to secondary/pituitary insufficiency."
  },
  {
    id: "gonadotropins",
    category: "pituitary",
    title: "Gonadotropins (FSH & LH) & Sex Hormones",
    cap: "Yellow Cap",
    components: "Follicle-Stimulating Hormone (FSH), Luteinizing Hormone (LH) paired with Testosterone (males) or Estradiol (females).",
    interpretation: "Low/normal gonadotropins (FSH/LH) with low Testosterone (<8.4 nmol/L in men) or low Estradiol with amenorrhea/oligomenorrhea in women suggests hypogonadotropic hypogonadism."
  },
  {
    id: "prolactin",
    category: "pituitary",
    title: "Serum Prolactin (Lactotropic)",
    cap: "Yellow Cap",
    timeline: "Collect at least 2 hours after waking. Minimize venipuncture stress. Avoid breast exams, food, or exercise prior to testing.",
    interpretation: "Prolactin >5,000 mIU/L strongly correlates with prolactinoma. Mild elevation (1,000-3,000 mIU/L) may be due to stalk compression, drugs (e.g., dopamine antagonists), or stress."
  },

  // 3. Specialty Biopsy Protocols
  {
    id: "muscle_biopsy",
    category: "biopsy",
    title: "Muscle Biopsy (Myopathy/Neuromuscular)",
    preBiopsy: "Contact MLT concerned (ext 5605) at least 24h before. Deliver fresh. Do not stretch or tie the muscle cylinder.",
    prep: "Wrap tissue in aluminium foil, place in a dry clean container, and pack in a larger container with gel ice for transport immediately.",
    stability: "Must reach Histopathology Lab (Pintu 6) within 4-6 hours of excision."
  },
  {
    id: "renal_biopsy",
    category: "biopsy",
    title: "Renal Biopsy (Glomerulonephritis/Nephrotic)",
    preBiopsy: "Always notify the duty Pathologist for urgent or immunofluorescence evaluations.",
    coresRequired: "Two tissue cores recommended: 1) Formalin-fixed for ordinary light microscopy (H&E), and 2) Fresh tissue core in phosphate buffer for immunofluorescence.",
    warning: "Do NOT place fresh immunofluorescence samples on dry gauze as it absorbs the solution and degrades the core tissue."
  }
];
