export type NAGCategory = {
  id: string;
  name: string;
  description?: string;
  conditions: NAGCondition[];
};

export type NAGCondition = {
  id: string;
  name: string;
  pathogens?: string[];
  firstLine: string[];
  secondLine: string[];
  duration: string;
  remarks: string[];
};

export const nagData: NAGCategory[] = [
  {
    id: "sepsis",
    name: "Sepsis & Severe Systemic Infections",
    description: "Empirical antibiotic recommendations for septic patients and blood stream infections.",
    conditions: [
      {
        id: "sepsis-unknown",
        name: "Sepsis of Unknown Origin (Adult)",
        pathogens: ["E. coli", "Klebsiella spp.", "S. aureus", "S. pneumoniae", "P. aeruginosa"],
        firstLine: ["IV Piperacillin/Tazobactam 4.5g q6h OR", "IV Cefepime 2g q8h OR", "IV Ceftazidime 2g q8h"],
        secondLine: ["IV Meropenem 1g q8h (if ESBL or septic shock) OR", "IV Ceftriaxone 2g q24h + IV Metronidazole 500mg q8h"],
        duration: "7-10 days (tailor according to source control and clinical response)",
        remarks: [
          "Initiate empiric therapy within 1 hour of sepsis identification.",
          "Obtain 2 sets of blood cultures prior to starting antibiotics.",
          "De-escalate to narrower-spectrum agents once culture results are available."
        ]
      },
      {
        id: "neutropenic-sepsis",
        name: "Febrile Neutropenia (High-Risk Inpatient)",
        pathogens: ["P. aeruginosa", "Enterobacteriaceae", "S. aureus", "Coagulase-negative Staphylococci"],
        firstLine: ["IV Piperacillin/Tazobactam 4.5g q6h monotherapy OR", "IV Cefepime 2g q8h monotherapy OR", "IV Ceftazidime 2g q8h monotherapy"],
        secondLine: ["IV Meropenem 1g q8h OR", "IV Imipenem/Cilastatin 500mg q6h", "Add IV Vancomycin if MRSA, catheter-related infection, or soft tissue infection suspected"],
        duration: "Continue until ANC > 0.5 x 10^9/L and patient is afebrile for at least 48 hours",
        remarks: [
          "High risk defined as: anticipated prolonged neutropenia (>7 days) OR MASCC score < 21 OR significant medical co-morbidities.",
          "Avoid aminoglycosides as monotherapy."
        ]
      }
    ]
  },
  {
    id: "resp",
    name: "Respiratory Tract Infections",
    description: "Infections of the upper and lower respiratory tracts.",
    conditions: [
      {
        id: "cap-mild",
        name: "Community-Acquired Pneumonia (Mild/Moderate) - Outpatient",
        pathogens: ["S. pneumoniae", "M. pneumoniae", "C. pneumoniae", "H. influenzae"],
        firstLine: ["Amoxicillin 500mg to 1g TDS PO OR", "Macrolide (e.g. Azithromycin 500mg OD or Erythromycin 400mg QID) if atypical suspected"],
        secondLine: ["Amoxicillin/Clavulanate 625mg to 1g BD PO OR", "Cefuroxime axetil 500mg BD PO"],
        duration: "5-7 days",
        remarks: [
          "Assess severity using CURB-65 or CRB-65 score.",
          "Consider comorbidities (diabetes, renal failure, heart disease) when choosing amoxicillin/clavulanate."
        ]
      },
      {
        id: "cap-severe",
        name: "Community-Acquired Pneumonia (Severe) - Inpatient",
        pathogens: ["S. pneumoniae", "Legionella spp.", "Gram-negative bacilli", "S. aureus"],
        firstLine: ["IV Amoxicillin/Clavulanate 1.2g TDS + IV/PO Macrolide (Azithromycin 500mg OD) OR", "IV Cefuroxime 1.5g TDS + IV/PO Macrolide"],
        secondLine: ["IV Ceftriaxone 1g-2g OD + IV/PO Macrolide OR", "IV Levofloxacin 750mg OD monotherapy"],
        duration: "7-10 days (extend to 14 days if Legionella, S. aureus or Gram-negative bacilli confirmed)",
        remarks: [
          "Switch to oral therapy once clinically stable (afebrile < 37.8°C, hemodynamically stable, tolerating oral intake).",
          "If risk factors for Pseudomonas aeruginosa (e.g. bronchiectasis, recurrent COPD steroid use), use IV Piperacillin/Tazobactam or IV Cefepime."
        ]
      },
      {
        id: "aecb",
        name: "Acute Exacerbation of COPD",
        pathogens: ["H. influenzae", "S. pneumoniae", "M. catarrhalis"],
        firstLine: ["Amoxicillin 500mg TDS PO OR", "Amoxicillin/Clavulanate 625mg BD PO OR", "Doxycycline 100mg BD PO"],
        secondLine: ["Cefuroxime axetil 250-500mg BD PO OR", "Levofloxacin 500mg OD PO (if risk factors for Pseudomonas or treatment failure)"],
        duration: "5 days",
        remarks: [
          "Antibiotics are indicated if patient has at least two of the three cardinal symptoms: increased dyspnoea, increased sputum volume, and increased sputum purulence (Anthonisen criteria)."
        ]
      },
      {
        id: "hap",
        name: "Hospital-Acquired Pneumonia (HAP) / VAP",
        pathogens: ["P. aeruginosa", "K. pneumoniae", "Acinetobacter spp.", "S. aureus (MSSA/MRSA)"],
        firstLine: ["IV Piperacillin/Tazobactam 4.5g q6h OR", "IV Cefepime 2g q8h OR", "IV Ceftazidime 2g q8h"],
        secondLine: ["IV Meropenem 1g q8h OR", "IV Levofloxacin 750mg q24h", "Add IV Vancomycin (loading 20-25mg/kg, then 15mg/kg q12h) if MRSA risk present"],
        duration: "7-8 days (longer if immunocompromised, multidrug resistant pathogens, or necrotizing pneumonia)",
        remarks: [
          "Defined as pneumonia occurring >= 48 hours after admission and not incubating at time of admission.",
          "Obtain sputum, tracheal aspirate or bronchoalveolar lavage (BAL) culture before changing therapy."
        ]
      }
    ]
  },
  {
    id: "uti",
    name: "Urinary Tract Infections",
    description: "Infections of the lower and upper urinary tract.",
    conditions: [
      {
        id: "cystitis-uncomplicated",
        name: "Uncomplicated Cystitis (Acute, Female)",
        pathogens: ["E. coli", "Staphylococcus saprophyticus", "Proteus mirabilis", "Klebsiella spp."],
        firstLine: ["Nitrofurantoin (Macrobid) 100mg BD PO (or 50mg QID PO) OR", "Cephalexin 500mg BD PO"],
        secondLine: ["Fosfomycin trometamol 3g PO (Single Dose) OR", "Amoxicillin/Clavulanate 625mg BD PO"],
        duration: "Nitrofurantoin: 5 days | Cephalexin/Augmentin: 3-5 days | Fosfomycin: 1 day",
        remarks: [
          "Avoid Nitrofurantoin if estimated CrCl < 30 ml/min or in pyelonephritis (has poor tissue penetration).",
          "Fluoroquinolones (e.g. Ciprofloxacin) should be reserved for more serious infections."
        ]
      },
      {
        id: "pyelonephritis-mild",
        name: "Pyelonephritis (Mild/Moderate) - Outpatient",
        pathogens: ["E. coli", "Klebsiella pneumoniae", "Proteus spp."],
        firstLine: ["Cefuroxime axetil 500mg BD PO OR", "Amoxicillin/Clavulanate 1g BD PO"],
        secondLine: ["Ciprofloxacin 500mg BD PO OR", "Ceftriaxone 1g IV daily (as outpatient/daycare)"],
        duration: "10-14 days (7-10 days for fluoroquinolones)",
        remarks: [
          "Always perform urine microscopic analysis and culture.",
          "Give first dose parenterally (e.g. IM/IV Ceftriaxone 1g) if vomiting or compliance is questionable."
        ]
      },
      {
        id: "pyelonephritis-severe",
        name: "Pyelonephritis (Severe/Inpatient)",
        pathogens: ["E. coli (including ESBL)", "Klebsiella spp.", "Pseudomonas aeruginosa"],
        firstLine: ["IV Ceftriaxone 1g-2g q24h OR", "IV Amoxicillin/Clavulanate 1.2g q8h"],
        secondLine: ["IV Piperacillin/Tazobactam 4.5g q6h OR", "IV Cefepime 2g q8h OR", "IV Meropenem 1g q8h (if septic shock or known ESBL)"],
        duration: "10-14 days",
        remarks: [
          "Review clinical progress after 48-72 hours of therapy.",
          "De-escalate to PO agents based on antimicrobial susceptibility profiles."
        ]
      }
    ]
  },
  {
    id: "ssti",
    name: "Skin, Soft Tissue & Bone/Joint Infections",
    description: "Infections ranging from superficial cellulitis to deep bone and joint infections.",
    conditions: [
      {
        id: "cellulitis",
        name: "Cellulitis / Erysipelas (Non-purulent)",
        pathogens: ["Streptococcus pyogenes (Group A)", "Staphylococcus aureus (MSSA)"],
        firstLine: ["Cloxacillin 500mg QID PO (Mild) OR IV Cloxacillin 1g-2g q6h (Moderate/Severe) OR", "Cephalexin 500mg QID PO OR IV Cefazolin 1g-2g q8h"],
        secondLine: ["PO Clindamycin 300mg-450mg TDS (if Penicillin allergy) OR IV Clindamycin 600mg q8h OR", "PO Erythromycin stearate 400mg QID"],
        duration: "5-7 days (extend up to 14 days if slow clinical resolution)",
        remarks: [
          "Elevate the affected limb.",
          "Mark the cellulitis border with a pen to monitor treatment progress.",
          "If purulent or MRSA suspected, treat with Trimethoprim/Sulfamethoxazole or Doxycycline."
        ]
      },
      {
        id: "abscess",
        name: "Abscess / Purulent SSTI",
        pathogens: ["S. aureus (including MRSA)"],
        firstLine: ["Incision & Drainage (Primary Therapy) OR", "PO Cloxacillin 500mg QID (if systemic signs, immunocompromised, or multiple abscesses)"],
        secondLine: ["PO Trimethoprim/Sulfamethoxazole 160/800mg (1-2 tabs) BD OR", "PO Doxycycline 100mg BD OR", "IV Vancomycin (if severe / hospitalized / suspected systemic MRSA)"],
        duration: "5-7 days",
        remarks: [
          "Incision and drainage is the definitive treatment for uncomplicated abscesses.",
          "Antibiotics are NOT routinely required after successful drainage of single, localized, small (<2 cm) abscesses in healthy patients."
        ]
      },
      {
        id: "diabetic-foot",
        name: "Diabetic Foot Infection (Moderate/Severe)",
        pathogens: ["Polymicrobial: Gram-positives (Streptococci, S. aureus), Gram-negatives (E. coli, Klebsiella, Pseudomonas), Anaerobes"],
        firstLine: ["IV Amoxicillin/Clavulanate 1.2g q8h OR", "IV Ampicillin/Sulbactam 1.5g-3g q6h"],
        secondLine: ["IV Piperacillin/Tazobactam 4.5g q6h OR", "IV Ceftriaxone 2g q24h + IV Metronidazole 500mg q8h OR", "IV Ciprofloxacin 400mg q12h + IV Clindamycin 600mg q8h (if severe penicillin allergy)"],
        duration: "1-2 weeks for soft tissue infection; 4-6 weeks if osteomyelitis present",
        remarks: [
          "Requires multidisciplinary care, including wound debridement, pressure offloading, and strict glycemic control.",
          "Assess peripheral vascular disease status."
        ]
      },
      {
        id: "osteomyelitis",
        name: "Acute Osteomyelitis (Adult)",
        pathogens: ["S. aureus", "Streptococcus spp.", "Gram-negative bacilli (particularly in diabetics/elderly)"],
        firstLine: ["IV Cloxacillin 2g q6h OR", "IV Cefazolin 2g q8h"],
        secondLine: ["IV Ceftriaxone 2g q24h OR", "IV Clindamycin 600mg q8h OR", "IV Vancomycin (if MRSA risk)"],
        duration: "4-6 weeks (at least 2-3 weeks of IV therapy, followed by PO if highly compliant and markers are improving)",
        remarks: [
          "Obtain bone biopsy/cultures if possible before initiating therapy.",
          "Monitor ESR/CRP and clinical healing parameters."
        ]
      },
      {
        id: "septic-arthritis",
        name: "Septic Arthritis (Empirical, Adult)",
        pathogens: ["S. aureus", "Streptococcus spp.", "N. gonorrhoeae (young adults)", "Gram-negative bacilli"],
        firstLine: ["IV Cloxacillin 2g q6h OR", "IV Cefazolin 2g q8h"],
        secondLine: ["IV Ceftriaxone 2g q24h (if Gram-negative diplococci seen or suspected ESBL/Gonococcus) OR", "IV Vancomycin (if high risk for MRSA)"],
        duration: "3-4 weeks (longer for Pseudomonas or S. aureus; requires initial IV therapy)",
        remarks: [
          "Perform joint aspiration for Gram stain, cell count, and culture before giving antibiotics.",
          "Joint drainage (via arthroscopy or repeated needle aspiration) is essential."
        ]
      }
    ]
  },
  {
    id: "gi",
    name: "Gastrointestinal & Intra-abdominal",
    description: "Infections of the GI lumen and peritoneal cavity.",
    conditions: [
      {
        id: "gastroenteritis",
        name: "Acute Gastroenteritis (Severe/Invasive)",
        pathogens: ["Salmonella spp.", "Campylobacter spp.", "Shigella spp.", "Vibrio cholerae"],
        firstLine: ["Rehydration and Supportive Therapy (No antibiotics for mild cases)"],
        secondLine: ["PO Ciprofloxacin 500mg BD OR", "PO Azithromycin 500mg OD OR", "IV/PO Ceftriaxone 1g-2g OD (if systemic features/bacteremia)"],
        duration: "3-5 days",
        remarks: [
          "Antibiotics are NOT indicated in uncomplicated gastroenteritis as they may prolong carrier states (especially Salmonella).",
          "Antibiotics are reserved for: severe dysentery, high fever, systemic toxicity, immunocompromised, or elderly patients."
        ]
      },
      {
        id: "c-difficile",
        name: "Clostridioides difficile Infection (CDI)",
        pathogens: ["Clostridioides difficile"],
        firstLine: ["PO Vancomycin 125mg QID OR", "PO Fidaxomicin 200mg BD (if available)"],
        secondLine: ["PO Metronidazole 500mg TDS (only if Vancomycin is unavailable and infection is mild) OR", "PO Vancomycin 500mg QID + IV Metronidazole 500mg q8h (for Fulminant/Severe complicated CDI)"],
        duration: "10 days",
        remarks: [
          "Discontinue any triggering non-CDI antibiotics.",
          "Avoid anti-motility agents (e.g. Loperamide) as they increase toxin retention.",
          "Note: IV Vancomycin is NOT effective for CDI (does not reach therapeutic levels in the colon lumen)."
        ]
      },
      {
        id: "intra-abdominal",
        name: "Intra-abdominal Infections (Appendicitis, Cholecystitis, Peritonitis)",
        pathogens: ["Enterobacteriaceae (E. coli, Klebsiella), Anaerobes (B. fragilis), Enterococci"],
        firstLine: ["IV Amoxicillin/Clavulanate 1.2g q8h OR", "IV Cefuroxime 1.5g q8h + IV Metronidazole 500mg q8h"],
        secondLine: ["IV Ceftriaxone 1g-2g q24h + IV Metronidazole 500mg q8h OR", "IV Piperacillin/Tazobactam 4.5g q6h (Severe/Healthcare-associated)"],
        duration: "4-7 days (provided source control is achieved)",
        remarks: [
          "Prompt surgical intervention or percutaneous drainage (source control) is the cornerstone of therapy.",
          "Stop antibiotics within 24 hours if source control is complete for simple acute cholecystitis or localized appendicitis."
        ]
      }
    ]
  },
  {
    id: "cns",
    name: "Central Nervous System Infections",
    description: "Meningitis and other brain-related bacterial infections.",
    conditions: [
      {
        id: "meningitis-adult",
        name: "Bacterial Meningitis (Adult 18-50 years)",
        pathogens: ["S. pneumoniae", "N. meningitidis", "H. influenzae"],
        firstLine: ["IV Ceftriaxone 2g q12h OR", "IV Cefotaxime 2g q4-6h"],
        secondLine: ["IV Meropenem 2g q8h OR", "Add IV Vancomycin (loading 20-25mg/kg, then 15-20mg/kg q8-12h) if cephalosporin-resistant S. pneumoniae suspected"],
        duration: "10-14 days (S. pneumoniae: 10-14d, N. meningitidis: 7d, H. influenzae: 7d)",
        remarks: [
          "Administer IV Dexamethasone 10mg immediately before or with the first dose of antibiotics. Continue 10mg q6h for 4 days.",
          "Do not delay antibiotic administration for lumbar puncture if the patient is unstable or requires imaging first."
        ]
      },
      {
        id: "meningitis-older",
        name: "Bacterial Meningitis (Adult >50 years or Immunocompromised)",
        pathogens: ["S. pneumoniae", "N. meningitidis", "Listeria monocytogenes", "Gram-negative bacilli"],
        firstLine: ["IV Ceftriaxone 2g q12h + IV Ampicillin 2g q4h"],
        secondLine: ["IV Meropenem 2g q8h + IV Ampicillin 2g q4h OR", "IV Vancomycin + IV Ampicillin + IV Ceftriaxone"],
        duration: "14-21 days (extended to 21 days for Listeria)",
        remarks: [
          "Ampicillin is crucial in these populations to cover Listeria monocytogenes.",
          "Dexamethasone is recommended in pneumococcal meningitis but should be stopped if Listeria is identified."
        ]
      }
    ]
  },
  {
    id: "obgyn",
    name: "Obstetrics & Gynaecology",
    description: "Guidelines for pelvic infections, chorioamnionitis, and postpartum infections.",
    conditions: [
      {
        id: "pid-outpatient",
        name: "Pelvic Inflammatory Disease (PID) - Outpatient",
        pathogens: ["N. gonorrhoeae", "C. trachomatis", "Mycoplasma genitalium", "Vaginal anaerobes"],
        firstLine: ["Single IM Ceftriaxone 500mg + PO Doxycycline 100mg BD + PO Metronidazole 400mg BD"],
        secondLine: ["Single IM Ofloxacin 400mg + PO Metronidazole 400mg BD OR", "PO Azithromycin 1g weekly for 2 weeks + PO Metronidazole 400mg BD"],
        duration: "14 days",
        remarks: [
          "Screen and treat sexual partners to prevent reinfection.",
          "Advise abstinence from intercourse until both patient and partner have completed treatment."
        ]
      },
      {
        id: "pid-inpatient",
        name: "Pelvic Inflammatory Disease (PID) - Inpatient",
        pathogens: ["N. gonorrhoeae", "C. trachomatis", "Anaerobes", "Gram-negative bacilli"],
        firstLine: ["IV Ceftriaxone 2g daily + PO/IV Doxycycline 100mg BD + PO/IV Metronidazole 500mg TDS"],
        secondLine: ["IV Ampicillin/Sulbactam 3g q6h + PO/IV Doxycycline 100mg BD OR", "IV Clindamycin 900mg q8h + IV Gentamicin 5-7mg/kg daily"],
        duration: "14 days (can step down to PO Doxycycline + Metronidazole once clinically improving after 24-48 hours of IV therapy)",
        remarks: [
          "Criteria for hospitalization: pregnant, failed outpatient therapy, severe nausea/vomiting, high fever, or presence of tubo-ovarian abscess (TOA)."
        ]
      },
      {
        id: "chorioamnionitis",
        name: "Chorioamnionitis (Intra-amniotic Infection)",
        pathogens: ["Polymicrobial: Group B Streptococcus (GBS), E. coli, Anaerobes, Mycoplasma spp."],
        firstLine: ["IV Ampicillin 2g q6h + IV Gentamicin 5mg/kg OD", "Add IV Metronidazole 500mg q8h or IV Clindamycin 900mg q8h if undergoing Caesarean Section"],
        secondLine: ["IV Amoxicillin/Clavulanate 1.2g q8h OR", "IV Cefuroxime 1.5g q8h + IV Metronidazole 500mg q8h"],
        duration: "Until delivery is complete and patient is afebrile and asymptomatic for 24 hours",
        remarks: [
          "Prompt delivery of the fetus is the primary management alongside systemic antimicrobial therapy.",
          "Continue antibiotics postpartum only if risk factors for endometritis are present."
        ]
      },
      {
        id: "endometritis",
        name: "Postpartum Endometritis",
        pathogens: ["GBS", "E. coli", "Enterococcus spp.", "Bacteroides spp.", "Peptostreptococcus spp."],
        firstLine: ["IV Clindamycin 900mg q8h + IV Gentamicin 5mg/kg OD"],
        secondLine: ["IV Ampicillin/Sulbactam 3g q6h OR", "IV Amoxicillin/Clavulanate 1.2g q8h + IV Gentamicin 5mg/kg OD"],
        duration: "Continue IV until patient is afebrile and asymptomatic for 24-48 hours (Oral step-down is usually unnecessary)",
        remarks: [
          "Frequently occurs following emergency Caesarean section.",
          "Gentamicin dose should be adjusted based on renal function."
        ]
      }
    ]
  },
  {
    id: "ent-eye",
    name: "Otorhinolaryngology & Ophthalmology",
    description: "Infections of the ear, nose, throat, and eyes.",
    conditions: [
      {
        id: "strep-throat",
        name: "Acute Pharyngitis / Tonsillitis (Group A Strep)",
        pathogens: ["Streptococcus pyogenes (Group A Beta-hemolytic Streptococcus)"],
        firstLine: ["PO Phenoxymethylpenicillin (Penicillin V) 500mg QID OR", "PO Amoxicillin 500mg TDS"],
        secondLine: ["PO Erythromycin ethylsuccinate 800mg BD OR", "PO Azithromycin 500mg OD OR", "PO Cephalexin 500mg BD"],
        duration: "10 days (Azithromycin: 3-5 days)",
        remarks: [
          "Most sore throats are viral. Confirm bacterial etiology via Centor Score (fever, tonsillar exudate, tender cervical adenopathy, absence of cough) or rapid antigen test.",
          "The primary goal of antibiotic treatment is to prevent Acute Rheumatic Fever (ARF)."
        ]
      },
      {
        id: "otitis-media",
        name: "Acute Otitis Media (AOM - Adult)",
        pathogens: ["S. pneumoniae", "H. influenzae", "M. catarrhalis"],
        firstLine: ["PO Amoxicillin 1g TDS PO"],
        secondLine: ["PO Amoxicillin/Clavulanate 625mg to 1g BD PO OR", "PO Cefuroxime axetil 500mg BD PO"],
        duration: "5-7 days (10 days if severe or recurrent)",
        remarks: [
          "In mild/moderate unilateral cases in children, a watch-and-wait approach for 48-72h can be considered.",
          "High-dose amoxicillin is preferred to overcome intermediate penicillin resistance in S. pneumoniae."
        ]
      },
      {
        id: "sinusitis",
        name: "Acute Rhinosinusitis (Bacterial)",
        pathogens: ["S. pneumoniae", "H. influenzae", "M. catarrhalis"],
        firstLine: ["PO Amoxicillin/Clavulanate 625mg BD PO OR", "PO Amoxicillin 500mg-1g TDS PO"],
        secondLine: ["PO Doxycycline 100mg BD PO OR", "PO Levofloxacin 500mg OD PO"],
        duration: "5-7 days",
        remarks: [
          "Antibiotics are indicated only if symptoms are severe (fever > 39°C, facial pain), last > 10 days without improvement, or 'double-sickening' occurs (worsening after initial improvement)."
        ]
      },
      {
        id: "orbital-cellulitis",
        name: "Orbital Cellulitis",
        pathogens: ["S. pneumoniae", "S. aureus", "S. pyogenes", "Haemophilus spp."],
        firstLine: ["IV Amoxicillin/Clavulanate 1.2g q8h OR", "IV Ceftriaxone 2g daily + IV Cloxacillin 2g q6h"],
        secondLine: ["IV Cefotaxime 2g q8h + IV Cloxacillin 2g q6h OR", "IV Vancomycin + IV Piperacillin/Tazobactam"],
        duration: "10-14 days (until resolution of ocular signs; complete with PO therapy)",
        remarks: [
          "This is a medical emergency requiring urgent ophthalmology and ENT referral.",
          "Obtain CT scan of the orbits/paranasal sinuses to rule out subperiosteal or orbital abscess which may require surgical decompression."
        ]
      }
    ]
  },
  {
    id: "prophylaxis",
    name: "Surgical Antibiotic Prophylaxis",
    description: "Antibiotics given prior to surgical procedures to prevent surgical site infections (SSI).",
    conditions: [
      {
        id: "c-section-proph",
        name: "Caesarean Section Prophylaxis",
        pathogens: ["Skin flora (S. aureus, CoNS)", "Gram-negatives", "Vaginal flora"],
        firstLine: ["IV Cefazolin 2g (Single Dose) given IV 15-60 minutes before skin incision"],
        secondLine: ["IV Clindamycin 600mg-900mg (Single Dose) + IV Gentamicin 1.5mg/kg (if severe penicillin allergy)"],
        duration: "Single Dose (routine post-operative doses are not recommended)",
        remarks: [
          "Cefazolin should be administered prior to skin incision (not after cord clamping, as per modern guidelines).",
          "If the patient's weight is >120 kg, increase Cefazolin dose to 3g.",
          "Add Azithromycin 500mg IV infusion if emergency Caesarean section is performed after labor/ruptured membranes."
        ]
      },
      {
        id: "appendectomy-proph",
        name: "Appendectomy Prophylaxis",
        pathogens: ["Enterobacteriaceae (E. coli)", "Anaerobes (Bacteroides fragilis)"],
        firstLine: ["IV Cefazolin 2g + IV Metronidazole 500mg IV (Single Dose) OR", "IV Amoxicillin/Clavulanate 1.2g (Single Dose)"],
        secondLine: ["IV Cefuroxime 1.5g + IV Metronidazole 500mg (Single Dose) OR", "IV Gentamicin 1.5mg/kg + IV Clindamycin 600mg (if penicillin allergy)"],
        duration: "Single Dose (Extend to treatment course only if gangrenous or perforated appendicitis)",
        remarks: [
          "Administered 15-60 minutes before skin incision.",
          "Repeat dose if procedure lasts > 3-4 hours or if blood loss exceeds 1.5L."
        ]
      },
      {
        id: "colorectal-proph",
        name: "Colorectal Surgery Prophylaxis",
        pathogens: ["Gram-negative bacilli", "Anaerobes (B. fragilis, Clostridia)"],
        firstLine: ["IV Cefazolin 2g + IV Metronidazole 500mg OR", "IV Amoxicillin/Clavulanate 1.2g IV"],
        secondLine: ["IV Cefuroxime 1.5g + IV Metronidazole 500mg OR", "IV Gentamicin 1.5mg/kg + IV Metronidazole 500mg (if severe penicillin allergy)"],
        duration: "Single Dose",
        remarks: [
          "Combine intravenous prophylaxis with mechanical bowel preparation and oral antibiotics (Neomycin + Erythromycin or Metronidazole) where appropriate.",
          "Administer within 60 minutes before incision."
        ]
      },
      {
        id: "clean-surgery-proph",
        name: "Clean Surgery with Prosthesis (Herniorrhaphy, Orthopaedic Joint Replacement)",
        pathogens: ["Skin flora (S. aureus, S. epidermidis)"],
        firstLine: ["IV Cefazolin 2g (Single Dose)"],
        secondLine: ["IV Vancomycin 1g-1.5g IV infusion (start 60-120 mins before incision to complete infusion before incision) OR", "IV Clindamycin 600mg-900mg IV"],
        duration: "Single Dose",
        remarks: [
          "Prophylaxis is indicated because the insertion of foreign materials/prostheses increases the severity of any potential infection.",
          "Not required for simple clean surgeries without implants/prostheses."
        ]
      }
    ]
  },
  {
    id: "gram-pos-pathogens",
    name: "Gram-Positive Pathogens (Quick Guide)",
    description: "Empirical pathogen-antimicrobial matches.",
    conditions: [
      { id: "mssa", name: "MSSA", pathogens: ["MSSA"], firstLine: ["IV: Cloxacillin / Cefazolin"], secondLine: ["PO: Cephalexin / Cloxacillin"], duration: "N/A", remarks: [] },
      { id: "mrsa", name: "MRSA", pathogens: ["MRSA"], firstLine: ["IV: Vancomycin", "PO: Bactrim / Rifampicin + Fusidic Acid"], secondLine: ["IV: Linezolid / Ceftaroline / Tigecycline", "PO: Linezolid"], duration: "N/A", remarks: [] },
      { id: "ca-mrsa", name: "CA-MRSA", pathogens: ["CA-MRSA"], firstLine: ["IV/PO: Bactrim / Clindamycin", "PO: Fusidic Acid + Rifampicin / Linezolid"], secondLine: ["PO: Doxycycline"], duration: "N/A", remarks: [] },
      { id: "ent-faecalis", name: "Enterococcus faecalis", pathogens: ["Enterococcus faecalis"], firstLine: ["Ampicillin"], secondLine: ["Vancomycin / Linezolid (VRE)"], duration: "N/A", remarks: [] },
      { id: "ent-faecium", name: "Enterococcus faecium", pathogens: ["Enterococcus faecium"], firstLine: ["Vancomycin"], secondLine: ["Linezolid"], duration: "N/A", remarks: [] },
      { id: "strep-ab", name: "Strep. pyogenes (Group A) / Strep. agalactiae (Group B)", pathogens: ["Strep. pyogenes", "Strep. agalactiae"], firstLine: ["Penicillin"], secondLine: ["Augmentin / Unasyn / Clindamycin"], duration: "N/A", remarks: [] },
      { id: "strep-pneumo", name: "Strep. pneumoniae / Viridans gp.", pathogens: ["Strep. pneumoniae", "Viridans gp."], firstLine: ["Penicillin / Augmentin / Unasyn"], secondLine: ["Ceftriaxone / Cefotaxime"], duration: "N/A", remarks: [] }
    ]
  },
  {
    id: "gram-neg-pathogens",
    name: "Gram-Negative Pathogens (Quick Guide)",
    description: "Empirical pathogen-antimicrobial matches.",
    conditions: [
      { id: "ecoli-kleb", name: "E. coli / Klebsiella pneumoniae", pathogens: ["E. coli", "Klebsiella pneumoniae"], firstLine: ["IV: Augmentin / Unasyn / Cefuroxime", "PO: Cephalexin / Cefuroxime / Augmentin / Bactrim"], secondLine: ["IV: Ceftriaxone / Tazocin / Cefepime", "PO: Ciprofloxacin"], duration: "N/A", remarks: [] },
      { id: "esbl", name: "ESBL", pathogens: ["ESBL"], firstLine: ["IV: Ertapenem / Meropenem / Imipenem"], secondLine: [], duration: "N/A", remarks: [] },
      { id: "pseudomonas", name: "Pseudomonas aeruginosa", pathogens: ["Pseudomonas aeruginosa"], firstLine: ["IV: Tazocin / Ceftazidime / Cefepime", "PO: Ciprofloxacin (for definitive therapy only)"], secondLine: ["IV: Ciprofloxacin / Sulperazone / Meropenem / Imipenem"], duration: "N/A", remarks: ["MDR/DTR refer to ID"] },
      { id: "ampc", name: "Significant AmpC-producing organisms: (CEK)", pathogens: ["Citrobacter freundii", "Enterobacter cloacae", "Klebsiella aerogenes"], firstLine: ["If Cefepime MIC <= 2: IV Cefepime", "If Cefepime MIC 4-8: IV Cefepime (non-severe) / IV Carbapenem (severe infection)", "If Cefepime MIC > 8: IV Carbapenem"], secondLine: ["Refer to Treatment Algorithm of Resistant GNR"], duration: "N/A", remarks: [] },
      { id: "acineto-pan", name: "Pan-sensitive (wild-type) Acinetobacter baumannii", pathogens: ["Acinetobacter baumannii"], firstLine: ["IV: Unasyn (Sulbactam Component)"], secondLine: [], duration: "N/A", remarks: [] },
      { id: "crab", name: "Carbapenem-resistant Acinetobacter baumannii (CRAB)", pathogens: ["Acinetobacter baumannii"], firstLine: ["IV: High dose Unasyn / High dose Sulperazone / Polymyxin B / Colistin (for UTI only)", "IV/PO: Minocycline"], secondLine: ["Refer to Treatment Algorithm of Resistant GNR"], duration: "N/A", remarks: ["Combination therapy may be preferred"] },
      { id: "burkholderia", name: "Burkholderia pseudomallei (Melioidosis)", pathogens: ["Burkholderia pseudomallei"], firstLine: ["IV: Ceftazidime / Meropenem [± Bactrim]", "PO (Maintenance): Bactrim"], secondLine: ["IV: Sulperazone / Imipenem [± Bactrim]", "PO (Maintenance): Augmentin"], duration: "N/A", remarks: [] },
      { id: "stenotrophomonas", name: "Stenotrophomonas maltophilia", pathogens: ["Stenotrophomonas maltophilia"], firstLine: ["IV: Bactrim", "PO: Bactrim"], secondLine: ["IV: Levofloxacin ± Minocycline / [Ceftazidime/Avibactam + Aztreonam]", "PO: Levofloxacin ± Minocycline"], duration: "N/A", remarks: [] },
      { id: "leptospira", name: "Leptospira sp. (Leptospirosis)", pathogens: ["Leptospira sp."], firstLine: ["IV: Penicillin / Ceftriaxone", "PO: Doxycycline / Azithromycin"], secondLine: [], duration: "N/A", remarks: [] },
      { id: "salmonella-nt", name: "Salmonella non-typhi (Salmonellosis)", pathogens: ["Salmonella non-typhi"], firstLine: ["IV: Ceftriaxone / Bactrim / Ampicillin", "PO: Bactrim / Ciprofloxacin"], secondLine: [], duration: "N/A", remarks: [] },
      { id: "typhoid", name: "Salmonella enterica serovar Typhi (Typhoid fever)", pathogens: ["Salmonella enterica serovar Typhi"], firstLine: ["IV: Ceftriaxone", "PO: Ciprofloxacin"], secondLine: ["PO: Bactrim"], duration: "N/A", remarks: [] },
      { id: "cre", name: "Carbapenem-resistant Enterobacterales (CRE)", pathogens: ["CRE"], firstLine: ["Refer to ID"], secondLine: [], duration: "N/A", remarks: [] },
      { id: "spm", name: "SPM: Serratia marcescens, Morganella morganii, Providencia spp", pathogens: ["Serratia marcescens", "Morganella morganii", "Providencia spp"], firstLine: ["Refer to ID"], secondLine: [], duration: "N/A", remarks: [] }
    ]
  },
  {
    id: "misc-pathogens",
    name: "Miscellaneous Pathogens (Quick Guide)",
    description: "Empirical pathogen-antimicrobial matches.",
    conditions: [
      { id: "atypicals", name: "Atypicals (Mycoplasma, Chlamydia, Legionella)", pathogens: ["Mycoplasma", "Chlamydia", "Legionella"], firstLine: ["Macrolide (eg: Azithromycin)"], secondLine: ["Doxycycline / Fluoroquinolones (eg: Levofloxacin)"], duration: "N/A", remarks: [] },
      { id: "anaerobes", name: "Anaerobes", pathogens: ["Anaerobes"], firstLine: ["IV: Metronidazole / Clindamycin / Augmentin / Unasyn / Tazocin / Sulperazone", "PO: Metronidazole / Clindamycin / Augmentin / Unasyn"], secondLine: [], duration: "N/A", remarks: [] },
      { id: "syphilis", name: "Treponema pallidum (Syphilis)", pathogens: ["Treponema pallidum"], firstLine: ["IV: Penicillin (Benzylpenicillin) or IM: Benzathine Penicillin"], secondLine: ["IV: Ceftriaxone", "PO: Doxycycline"], duration: "N/A", remarks: [] },
      { id: "cdi", name: "Clostridium difficile (CDI)", pathogens: ["Clostridium difficile"], firstLine: ["PO: Vancomycin / Metronidazole"], secondLine: [], duration: "N/A", remarks: [] },
      { id: "candida-alb", name: "Candida albicans / tropicalis / parapsilosis", pathogens: ["Candida albicans", "Candida tropicalis", "Candida parapsilosis"], firstLine: ["IV/PO: Fluconazole"], secondLine: ["IV: Ampho B / Micafungin"], duration: "N/A", remarks: [] },
      { id: "candida-glab", name: "Candida glabrata", pathogens: ["Candida glabrata"], firstLine: ["IV: Ampho B / Micafungin"], secondLine: ["IV: Fluconazole (Susceptible-dose dependent)"], duration: "N/A", remarks: [] },
      { id: "candida-krusei", name: "Candida krusei", pathogens: ["Candida krusei"], firstLine: ["IV: Ampho B / Micafungin"], secondLine: [], duration: "N/A", remarks: [] },
      { id: "candida-auris", name: "Candida auris", pathogens: ["Candida auris"], firstLine: ["IV: Micafungin"], secondLine: ["IV: Ampho B / Fluconazole (MIC Guided)"], duration: "N/A", remarks: [] },
      { id: "aspergillus", name: "Aspergillus sp.", pathogens: ["Aspergillus sp."], firstLine: ["IV: Ampho B / Voriconazole", "PO: Voriconazole"], secondLine: [], duration: "N/A", remarks: [] },
      { id: "hsv", name: "HSV/ HZV/ VZV (Chickenpox)", pathogens: ["HSV", "HZV", "VZV"], firstLine: ["IV/PO: Acyclovir"], secondLine: [], duration: "N/A", remarks: [] },
      { id: "cmv", name: "CMV (Cytomegalovirus)", pathogens: ["CMV"], firstLine: ["IV: Ganciclovir", "PO: Valganciclovir"], secondLine: [], duration: "N/A", remarks: [] }
    ]
  }
];
