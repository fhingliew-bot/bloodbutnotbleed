import React, { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  Zap, 
  Activity, 
  Info, 
  CheckCircle2, 
  AlertCircle, 
  Eye, 
  ShieldAlert,
  ArrowRight,
  ChevronDown,
  ChevronUp
} from "lucide-react";

interface EcgRhythm {
  id: string;
  name: string;
  classification: "shockable" | "non-shockable";
  path: string;
  rate: string;
  qrs: string;
  pwave: string;
  clinicalNote: string;
  action: string;
  color: string;
}

interface EcgGalleryProps {
  isDarkMode: boolean;
}

export default function EcgGallery({ isDarkMode }: EcgGalleryProps) {
  const [filter, setFilter] = useState<"all" | "shockable" | "non-shockable">("all");
  const [selectedRhythm, setSelectedRhythm] = useState<string | null>(null);
  const [isExpanded, setIsExpanded] = useState(false);

  const rhythms: EcgRhythm[] = [
    {
      id: "vf_coarse",
      name: "Coarse Ventricular Fibrillation (VF)",
      classification: "shockable",
      path: "M 0 50 L 8 38 L 16 58 L 24 20 L 32 75 L 40 10 L 48 85 L 56 30 L 64 68 L 72 25 L 80 78 L 88 40 L 96 60 L 104 15 L 112 82 L 120 35 L 128 72 L 136 28 L 144 65 L 152 48 L 160 52 L 168 20 L 176 80 L 184 15 L 192 75 L 200 35 L 208 68 L 216 28 L 224 82 L 232 40 L 240 60 L 248 18 L 256 78 L 264 30 L 272 72 L 280 25 L 288 65 L 296 48 L 304 55 L 312 15 L 320 85 L 328 32 L 336 70 L 344 25 L 352 65 L 360 40 L 368 55 L 376 18 L 384 82 L 392 35 L 400 50",
      rate: "Indeterminate (extremely rapid & chaotic)",
      qrs: "None discernible (chaotic waves)",
      pwave: "None present",
      clinicalNote: "No organized electrical activity. Ventricles merely quiver, resulting in zero cardiac output and immediate collapse. Primary cause of sudden cardiac death.",
      action: "Immediate high-quality CPR and Defibrillation (200J Biphasic). Do not delay for drugs.",
      color: "text-rose-500 hover:border-rose-500/30"
    },
    {
      id: "vt_monomorphic",
      name: "Pulseless Ventricular Tachycardia (VT)",
      classification: "shockable",
      path: "M 0 50 L 8 50 L 14 15 L 24 80 L 32 50 L 42 50 L 48 15 L 58 80 L 66 50 L 76 50 L 82 15 L 92 80 L 100 50 L 110 50 L 116 15 L 126 80 L 134 50 L 144 50 L 150 15 L 160 80 L 168 50 L 178 50 L 184 15 L 194 80 L 202 50 L 212 50 L 218 15 L 228 80 L 236 50 L 246 50 L 252 15 L 262 80 L 270 50 L 280 50 L 286 15 L 296 80 L 304 50 L 314 50 L 320 15 L 330 80 L 338 50 L 348 50 L 354 15 L 364 80 L 372 50 L 382 50 L 388 15 L 398 80 L 400 50",
      rate: "150 to 250 bpm",
      qrs: "Wide (> 0.12s), bizarre and regular monomorphic shape",
      pwave: "Absent or dissociated (buried within QRS)",
      clinicalNote: "Rapid, coordinated ventricular firing. If patient has no palpable central pulse, manage strictly as a shockable cardiac arrest identical to VF.",
      action: "Deliver 1st shock (200J) immediately if pulseless. Resume chest compressions without pulse check.",
      color: "text-rose-400 hover:border-rose-400/30"
    },
    {
      id: "torsades",
      name: "Polymorphic VT / Torsades de Pointes",
      classification: "shockable",
      path: "M 0 50 L 10 40 L 20 60 L 30 30 L 40 70 L 50 20 L 60 80 L 70 15 L 80 85 L 90 20 L 100 80 L 110 30 L 120 70 L 130 40 L 140 60 L 150 48 L 160 52 L 170 48 L 180 52 L 190 40 L 200 60 L 210 30 L 220 70 L 230 20 L 240 80 L 250 15 L 260 85 L 270 20 L 280 80 L 290 30 L 300 70 L 310 40 L 320 60 L 330 48 L 340 52 L 350 48 L 360 40 L 370 60 L 380 30 L 390 70 L 400 50",
      rate: "150 to 300 bpm",
      qrs: "Wide, changing amplitude, peaks twist around the baseline",
      pwave: "None visible",
      clinicalNote: "Characterized by QRS complexes rotating around the isoelectric baseline. Often triggered by prolonged QT interval, hypokalemia, or drug toxicities.",
      action: "Immediate defibrillation if pulseless. Give Magnesium Sulfate 2g IV/IO slow push, correct underlying electrolytes.",
      color: "text-pink-500 hover:border-pink-500/30"
    },
    {
      id: "pea_sinus",
      name: "Pulseless Electrical Activity (PEA)",
      classification: "non-shockable",
      path: "M 0 50 L 15 50 Q 20 44, 25 50 L 35 50 L 38 52 L 41 12 L 44 68 L 47 50 L 55 50 Q 65 42, 75 50 L 115 50 Q 120 44, 125 50 L 135 50 L 138 52 L 141 12 L 144 68 L 147 50 L 155 50 Q 165 42, 175 50 L 215 50 Q 220 44, 225 50 L 235 50 L 238 52 L 241 12 L 244 68 L 247 50 L 255 50 Q 265 42, 275 50 L 315 50 Q 320 44, 325 50 L 335 50 L 338 52 L 341 12 L 344 68 L 347 50 L 355 50 Q 365 42, 375 50 L 400 50",
      rate: "Typically regular (varies; here 60 bpm)",
      qrs: "Organized, narrow/wide complexes present on monitor",
      pwave: "Normal or abnormal sinus activity",
      clinicalNote: "The monitor shows an organized rhythm that should produce a pulse, but clinically the patient has NO palpable pulse. Heart is electrically intact but mechanically inactive.",
      action: "Adrenaline 1mg IV/IO IMMEDIATELY. High quality CPR. Systematically troubleshoot the H's and T's (e.g. Hypovolemia, Tamponade). Do NOT shock.",
      color: "text-amber-500 hover:border-amber-500/30"
    },
    {
      id: "asystole",
      name: "Asystole / Flatline",
      classification: "non-shockable",
      path: "M 0 50 L 15 50 Q 30 49, 45 50 L 60 51 L 80 50 Q 100 50, 115 49 L 130 50 L 150 50 Q 170 51, 185 50 L 200 49 L 220 50 L 245 50 Q 260 51, 275 50 L 290 50 L 315 49 L 330 51 Q 350 50, 365 50 L 380 49 L 400 50",
      rate: "0 bpm",
      qrs: "None present",
      pwave: "None present",
      clinicalNote: "Total cessation of all electrical and mechanical activity in the heart. Always confirm lead connections, gains, and that electrodes are attached when flatline is observed.",
      action: "Immediate continuous chest compressions. Secure IV/IO access and deliver Adrenaline 1mg immediately. Seek reversible causes.",
      color: "text-teal-500 hover:border-teal-500/30"
    }
  ];

  const filteredRhythms = rhythms.filter(
    (r) => filter === "all" || r.classification === filter
  );

  const selectedItem = rhythms.find((r) => r.id === selectedRhythm);

  return (
    <div className={`p-5 rounded-2xl border ${
      isDarkMode ? "bg-slate-950/40 border-slate-800/80" : "bg-white border-slate-200 shadow-sm"
    } space-y-5`} id="ecg-reference-gallery-section">
      
      {/* Section Header */}
      <div 
        className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-100 dark:border-slate-800/60 cursor-pointer group"
        onClick={() => setIsExpanded(!isExpanded)}
      >
        <div className="flex items-start justify-between w-full sm:w-auto">
          <div>
            <h4 className={`font-extrabold text-sm flex items-center gap-2 ${
              isDarkMode ? "text-slate-200" : "text-slate-800"
            }`}>
              <Activity className="w-4 h-4 text-teal-500 animate-pulse" />
              ECG Rhythm strip reference gallery
            </h4>
            <p className="text-[11px] text-slate-500 mt-0.5">
              Vector ECG strips for shockable vs non-shockable triage. Click to view full clinical details.
            </p>
          </div>
          <button className={`sm:hidden p-1.5 rounded-lg border ${
            isDarkMode ? "border-slate-800 text-slate-400" : "border-slate-200 text-slate-500"
          }`}>
            {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
          </button>
        </div>

        {/* Filters & Toggle */}
        <div className="flex items-center gap-3 self-start sm:self-center w-full sm:w-auto justify-between sm:justify-end">
          <div className="flex bg-slate-100 dark:bg-slate-900 p-1 rounded-xl border border-slate-200 dark:border-slate-800/80">
            {[
              { id: "all", label: "All" },
              { id: "shockable", label: "Shockable" },
              { id: "non-shockable", label: "Non-Shockable" }
            ].map((opt) => (
              <button
                key={opt.id}
                onClick={(e) => {
                  e.stopPropagation();
                  setFilter(opt.id as any);
                  setIsExpanded(true);
                }}
                className={`px-3 py-1 rounded-lg text-[10px] font-bold transition-all cursor-pointer ${
                  filter === opt.id
                    ? "bg-teal-500 text-slate-950 shadow-sm"
                    : "text-slate-500 hover:text-slate-800 dark:hover:text-slate-200"
                }`}
              >
                {opt.label}
              </button>
            ))}
          </div>
          <button className={`hidden sm:flex p-1.5 rounded-lg border transition-all ${
            isDarkMode ? "border-slate-800 text-slate-400 hover:bg-slate-800" : "border-slate-200 text-slate-500 hover:bg-slate-100"
          }`}>
            {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
          </button>
        </div>
      </div>

      <AnimatePresence>
        {isExpanded && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="overflow-hidden space-y-5"
          >
            {/* Rhythm strip Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filteredRhythms.map((r) => (
          <div
            key={r.id}
            onClick={() => setSelectedRhythm(selectedRhythm === r.id ? null : r.id)}
            id={`ecg-strip-card-${r.id}`}
            className={`border rounded-xl overflow-hidden transition-all duration-200 cursor-pointer group flex flex-col ${
              selectedRhythm === r.id
                ? "ring-2 ring-teal-500 border-teal-500/40"
                : isDarkMode
                  ? "border-slate-800 bg-slate-900/30 hover:bg-slate-900/60 hover:border-slate-700"
                  : "border-slate-200 bg-slate-50/50 hover:bg-slate-100/50 hover:border-slate-300 shadow-xs"
            }`}
          >
            {/* Strip Header */}
            <div className={`px-3.5 py-2.5 flex justify-between items-center border-b ${
              isDarkMode ? "border-slate-800/60 bg-slate-950/40" : "border-slate-200 bg-slate-50"
            }`}>
              <div className="flex items-center gap-1.5">
                <span className={`text-xs font-bold ${isDarkMode ? "text-slate-200" : "text-slate-800"}`}>
                  {r.name}
                </span>
              </div>
              <span className={`text-[9px] font-extrabold uppercase px-1.5 py-0.5 rounded border tracking-wider font-mono ${
                r.classification === "shockable"
                  ? "bg-rose-500/15 border-rose-500/30 text-rose-500 dark:text-rose-400"
                  : "bg-amber-500/15 border-amber-500/30 text-amber-600 dark:text-amber-400"
              }`}>
                {r.classification === "shockable" ? "Shockable" : "Non-Shockable"}
              </span>
            </div>

            {/* Simulated ECG Paper background with SVG Trace */}
            <div className="relative h-28 w-full bg-[#fde8e8] dark:bg-[#1c0d0d] flex items-center overflow-hidden border-b border-slate-200/50 dark:border-slate-800/50">
              
              {/* Millimeter Grid Pattern */}
              <svg className="absolute inset-0 w-full h-full text-rose-200/50 dark:text-rose-900/40" xmlns="http://www.w3.org/2000/svg">
                <defs>
                  {/* Minor 1mm grids */}
                  <pattern id={`grid-minor-${r.id}`} width="8" height="8" patternUnits="userSpaceOnUse">
                    <path d="M 8 0 L 0 0 0 8" fill="none" stroke="currentColor" strokeWidth="0.5" />
                  </pattern>
                  {/* Major 5mm grids */}
                  <pattern id={`grid-major-${r.id}`} width="40" height="40" patternUnits="userSpaceOnUse">
                    <rect width="40" height="40" fill={`url(#grid-minor-${r.id})`} />
                    <path d="M 40 0 L 0 0 0 40" fill="none" stroke="currentColor" strokeWidth="1.2" />
                  </pattern>
                </defs>
                <rect width="100%" height="100%" fill={`url(#grid-major-${r.id})`} />
              </svg>

              {/* Glowing Dynamic Waveform SVG */}
              <svg 
                viewBox="0 0 400 100" 
                preserveAspectRatio="none" 
                className="absolute inset-0 w-full h-full z-10"
              >
                {/* Glow filter */}
                <defs>
                  <filter id={`glow-${r.id}`} x="-20%" y="-20%" width="140%" height="140%">
                    <feGaussianBlur stdDeviation="1.5" result="blur" />
                    <feMerge>
                      <feMergeNode in="blur" />
                      <feMergeNode in="SourceGraphic" />
                    </feMerge>
                  </filter>
                </defs>

                {/* Animated sweep background indicator if selected */}
                {selectedRhythm === r.id && (
                  <motion.rect
                    initial={{ x: -100 }}
                    animate={{ x: 400 }}
                    transition={{ repeat: Infinity, duration: 2, ease: "linear" }}
                    width="40"
                    height="100"
                    fill="url(#sweep-grad)"
                    className="opacity-20"
                  />
                )}

                {/* Main trace line */}
                <path
                  d={r.path}
                  fill="none"
                  stroke={r.classification === "shockable" ? "#ef4444" : "#10b981"}
                  strokeWidth="2.5"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  filter={`url(#glow-${r.id})`}
                  className="animate-pulse"
                />
              </svg>

              <div className="absolute bottom-1 right-2 z-20 bg-slate-900/60 text-white font-mono text-[8px] px-1.5 py-0.5 rounded flex items-center gap-1">
                <Eye className="w-2.5 h-2.5" /> Click to Analyze
              </div>
            </div>

            {/* Interactive Preview Details */}
            <div className={`p-3 text-[11px] leading-relaxed flex-1 flex flex-col justify-between ${
              isDarkMode ? "text-slate-400" : "text-slate-600"
            }`}>
              <div className="space-y-1">
                <div className="flex justify-between">
                  <span><strong>Rate:</strong> {r.rate}</span>
                  <span><strong>QRS:</strong> {r.qrs}</span>
                </div>
                <p className="line-clamp-2 italic">{r.clinicalNote}</p>
              </div>

              <div className={`mt-2 pt-2 border-t flex items-center justify-between text-[10px] font-bold ${
                r.classification === "shockable" ? "text-rose-500" : "text-teal-600 dark:text-teal-400"
              }`}>
                <span className="flex items-center gap-1 uppercase">
                  {r.classification === "shockable" ? (
                    <Zap className="w-3 h-3 text-rose-500" />
                  ) : (
                    <Activity className="w-3 h-3 text-teal-500" />
                  )}
                  {r.classification === "shockable" ? "Action: Defibrillate" : "Action: CPR & Drugs"}
                </span>
                <span className="group-hover:translate-x-0.5 transition-transform flex items-center gap-0.5 text-teal-600 dark:text-teal-400">
                  Analyze details <ArrowRight className="w-3 h-3" />
                </span>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* SVG Gradient helper for scanning line */}
      <svg className="hidden">
        <defs>
          <linearGradient id="sweep-grad" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="#2dd4bf" stopOpacity="0" />
            <stop offset="50%" stopColor="#2dd4bf" stopOpacity="1" />
            <stop offset="100%" stopColor="#2dd4bf" stopOpacity="0" />
          </linearGradient>
        </defs>
      </svg>

      {/* EXPANDED FULL-SCREEN CLINICAL PANEL */}
      <AnimatePresence>
        {selectedItem && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            id="ecg-analysis-panel"
            className={`p-4 rounded-xl border ${
              isDarkMode 
                ? "bg-slate-900/60 border-slate-800 text-slate-300" 
                : "bg-teal-50/40 border-teal-200 text-slate-700 shadow-inner"
            } space-y-3`}
          >
            <div className="flex items-start justify-between border-b pb-2 dark:border-slate-800">
              <div className="flex items-center gap-2">
                <ShieldAlert className={`w-4 h-4 ${selectedItem.classification === "shockable" ? "text-rose-500" : "text-amber-500"}`} />
                <h5 className="font-bold text-xs md:text-sm">
                  Clinical Electrocardiographic Analysis: {selectedItem.name}
                </h5>
              </div>
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  setSelectedRhythm(null);
                }}
                className="text-[10px] underline hover:no-underline text-slate-500 cursor-pointer"
              >
                Close Analysis
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
              <div className="p-3 rounded-lg bg-slate-950/20 border dark:border-slate-850 space-y-1.5">
                <span className="font-bold text-teal-400 block uppercase tracking-wider text-[9px]">AHA / MOH ECG Criteria</span>
                <ul className="space-y-1 text-slate-400">
                  <li>• <strong>Ventricular Rate:</strong> {selectedItem.rate}</li>
                  <li>• <strong>P Wave:</strong> {selectedItem.pwave}</li>
                  <li>• <strong>QRS Complex:</strong> {selectedItem.qrs}</li>
                </ul>
              </div>

              <div className="p-3 rounded-lg bg-slate-950/20 border dark:border-slate-850 space-y-1">
                <span className="font-bold text-teal-400 block uppercase tracking-wider text-[9px]">Hemodynamic Significance</span>
                <p className="text-slate-400 leading-relaxed text-[11px]">{selectedItem.clinicalNote}</p>
              </div>

              <div className="p-3 rounded-lg bg-slate-950/20 border dark:border-slate-850 space-y-1.5">
                <span className="font-bold text-rose-500 dark:text-rose-400 block uppercase tracking-wider text-[9px]">Critical Bedside Directive</span>
                <p className="font-bold leading-normal text-rose-600 dark:text-rose-400 text-[11px]">{selectedItem.action}</p>
                <div className="text-[10px] text-slate-500 mt-1 italic">
                  Always verify mechanical state! A pulse check is MANDATORY when an organized PEA rhythm is noted.
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
