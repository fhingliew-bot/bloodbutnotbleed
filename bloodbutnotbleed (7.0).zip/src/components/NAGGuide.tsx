import { useState } from "react";
import { ShieldAlert, Search, ArrowRight, CheckCircle2, ChevronDown, ChevronUp, AlertTriangle } from "lucide-react";
import { nagData, NAGCategory, NAGCondition } from "../data/nag";

export default function NAGGuide({ isDarkMode }: { isDarkMode: boolean }) {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<string>("All");
  const [expandedCondition, setExpandedCondition] = useState<string | null>(null);

  const filteredCategories = nagData.map(category => {
    if (selectedCategory !== "All" && category.id !== selectedCategory) {
      return null;
    }

    const filteredConditions = category.conditions.filter(condition => {
      const q = searchQuery.toLowerCase();
      if (!q) return true;
      return condition.name.toLowerCase().includes(q) || 
             condition.firstLine.some(d => d.toLowerCase().includes(q)) ||
             condition.pathogens?.some(p => p.toLowerCase().includes(q));
    });

    if (filteredConditions.length === 0) return null;

    return {
      ...category,
      conditions: filteredConditions
    };
  }).filter(Boolean) as NAGCategory[];

  return (
    <div className="space-y-4 animate-fade-in">
      <div className={`p-4 rounded-xl border ${
        isDarkMode ? "bg-[#111827] border-slate-800" : "bg-white border-slate-200 shadow-sm"
      }`}>
        <div className="flex flex-col gap-3">
          <div>
            <h2 className={`text-lg font-bold font-sans ${isDarkMode ? "text-teal-400" : "text-teal-700"} flex items-center gap-2`}>
              <ShieldAlert className="w-5 h-5" /> AMS / NAG (Antibiotic Stewardship)
            </h2>
          </div>
          <div className="flex items-center gap-2">
             <div className="relative flex-1">
              <Search className={`absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 ${isDarkMode ? "text-slate-500" : "text-slate-400"}`} />
              <input
                type="text"
                placeholder="Search..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className={`w-full pl-9 pr-4 py-2 rounded-lg text-sm border focus:outline-none focus:ring-2 focus:ring-teal-500/50 ${
                  isDarkMode 
                    ? "bg-slate-900 border-slate-700 text-slate-200" 
                    : "bg-white border-slate-300 text-slate-800"
                }`}
              />
            </div>
            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              className={`py-2 px-3 rounded-lg text-sm font-medium border appearance-none ${
                isDarkMode 
                  ? "bg-slate-900 border-slate-700 text-slate-300" 
                  : "bg-white border-slate-300 text-slate-700"
              }`}
            >
              <option value="All">All Systems</option>
              {nagData.map(cat => (
                <option key={cat.id} value={cat.id}>{cat.name}</option>
              ))}
            </select>
          </div>
        </div>
      </div>

      <div className="space-y-4">
        {filteredCategories.length > 0 ? (
          filteredCategories.map(category => (
            <div key={category.id} className="space-y-2">
              <h3 className={`text-xs font-bold uppercase tracking-wider pl-2 border-l-2 border-teal-500 ${isDarkMode ? "text-slate-300" : "text-slate-700"}`}>
                {category.name}
              </h3>
              
              <div className="grid grid-cols-1 gap-2">
                {category.conditions.map(condition => {
                  const isExpanded = expandedCondition === condition.id;
                  
                  return (
                    <div 
                      key={condition.id}
                      className={`border rounded-lg overflow-hidden transition-colors ${
                        isDarkMode 
                          ? isExpanded ? "bg-slate-800/80 border-teal-500/30" : "bg-slate-900/50 border-slate-800" 
                          : isExpanded ? "bg-white border-teal-500/30 shadow-sm" : "bg-white border-slate-200"
                      }`}
                    >
                      <div 
                        className="p-3 cursor-pointer flex items-center justify-between"
                        onClick={() => setExpandedCondition(isExpanded ? null : condition.id)}
                      >
                        <h4 className={`font-semibold text-sm ${isDarkMode ? "text-teal-400" : "text-teal-700"}`}>
                          {condition.name}
                        </h4>
                        {isExpanded ? <ChevronUp className="w-4 h-4 text-slate-400" /> : <ChevronDown className="w-4 h-4 text-slate-400" />}
                      </div>

                      {isExpanded && (
                        <div className={`p-3 pt-0 border-t ${isDarkMode ? "border-slate-800" : "border-slate-100"}`}>
                          <div className="grid grid-cols-1 gap-3 mt-2">
                            <div className="space-y-1">
                              <h5 className={`text-[10px] font-bold uppercase flex items-center gap-1.5 ${isDarkMode ? "text-emerald-400" : "text-emerald-700"}`}>
                                <CheckCircle2 className="w-3 h-3" /> First-Line
                              </h5>
                              <ul className="space-y-0.5">
                                {condition.firstLine.map((drug, idx) => (
                                  <li key={idx} className={`text-xs p-1.5 rounded ${isDarkMode ? "bg-slate-900 text-slate-300" : "bg-slate-50 text-slate-700"}`}>
                                    {drug}
                                  </li>
                                ))}
                              </ul>
                            </div>
                            {condition.secondLine.length > 0 && (
                                <div className="space-y-1">
                                    <h5 className={`text-[10px] font-bold uppercase flex items-center gap-1.5 ${isDarkMode ? "text-amber-400" : "text-amber-700"}`}>
                                        <ArrowRight className="w-3 h-3" /> Alternative
                                    </h5>
                                    <ul className="space-y-0.5">
                                        {condition.secondLine.map((drug, idx) => (
                                        <li key={idx} className={`text-xs p-1.5 rounded ${isDarkMode ? "bg-slate-900 text-slate-300" : "bg-slate-50 text-slate-700"}`}>
                                            {drug}
                                        </li>
                                        ))}
                                    </ul>
                                </div>
                            )}
                          </div>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          ))
        ) : (
          <div className={`p-6 text-center rounded-xl border border-dashed ${isDarkMode ? "border-slate-700 text-slate-500" : "border-slate-300 text-slate-400"}`}>
            <p className="text-sm">No guidelines found.</p>
          </div>
        )}
      </div>
    </div>
  );
}

