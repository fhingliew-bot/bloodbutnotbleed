import React, { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  X, 
  Zap, 
  Activity, 
  ShieldAlert, 
  Heart, 
  Syringe, 
  Info, 
  Clock, 
  CheckCircle2, 
  ChevronRight, 
  PlusCircle, 
  Wind,
  Layers,
  Sparkles
} from "lucide-react";

interface AclsAlgorithmModalProps {
  isOpen: boolean;
  onClose: () => void;
  isDarkMode: boolean;
}

export default function AclsAlgorithmModal({ isOpen, onClose, isDarkMode }: AclsAlgorithmModalProps) {
  const [activeTab, setActiveTab] = useState<"combined" | "shockable" | "non-shockable" | "parameters">("combined");

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 overflow-y-auto">
        {/* Backdrop overlay */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
          className="fixed inset-0 bg-black/60 backdrop-blur-xs"
        />

        {/* Modal Content Card */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 15 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 15 }}
          transition={{ duration: 0.2 }}
          className={`relative w-full max-w-5xl rounded-2xl border shadow-2xl flex flex-col max-h-[90vh] overflow-hidden ${
            isDarkMode 
              ? "bg-[#0b0f19] border-slate-800 text-slate-100" 
              : "bg-white border-slate-200 text-slate-800"
          }`}
        >
          {/* Header */}
          <div className={`p-5 border-b flex justify-between items-start gap-4 ${
            isDarkMode ? "border-slate-800/80 bg-slate-900/40" : "border-slate-150 bg-slate-50"
          }`}>
            <div className="flex gap-3">
              <div className="p-2 rounded-xl bg-rose-500 text-white shadow-lg shadow-rose-500/20">
                <Heart className="w-5 h-5 animate-pulse" />
              </div>
              <div>
                <h3 className="font-bold text-base md:text-lg tracking-tight flex items-center gap-2">
                  ACLS Cardiac Arrest Algorithm Reference
                  <span className={`text-[9px] font-mono px-1.5 py-0.5 rounded border ${
                    isDarkMode ? "bg-slate-950 border-slate-800 text-slate-400" : "bg-white border-slate-200 text-slate-500"
                  }`}>
                    AHA Guidelines
                  </span>
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  Standardized bedside reference for high-performance shockable and non-shockable resuscitation pathways.
                </p>
              </div>
            </div>
            
            <button
              onClick={onClose}
              id="close-acls-modal-btn"
              className={`p-1.5 rounded-lg border transition-all ${
                isDarkMode 
                  ? "border-slate-800 bg-slate-950 text-slate-400 hover:text-slate-200 hover:bg-slate-900" 
                  : "border-slate-200 bg-white text-slate-500 hover:text-slate-800 hover:bg-slate-50 shadow-xs"
              }`}
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Tab Navigation */}
          <div className={`px-4 pt-3 pb-0 border-b flex gap-1 overflow-x-auto scrollbar-none ${
            isDarkMode ? "border-slate-800/60 bg-[#0e1424]" : "border-slate-150 bg-slate-50/50"
          }`}>
            {[
              { id: "combined", label: "Combined Flowchart", icon: <Layers className="w-3.5 h-3.5" /> },
              { id: "shockable", label: "Shockable (VF/pVT)", icon: <Zap className="w-3.5 h-3.5 text-rose-500" /> },
              { id: "non-shockable", label: "Non-Shockable (PEA/Asystole)", icon: <Activity className="w-3.5 h-3.5 text-amber-500" /> },
              { id: "parameters", label: "Critical Care Parameters", icon: <ShieldAlert className="w-3.5 h-3.5 text-teal-500" /> }
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`px-4 py-2 text-xs font-bold transition-all border-b-2 flex items-center gap-1.5 whitespace-nowrap -mb-px ${
                  activeTab === tab.id
                    ? isDarkMode 
                      ? "border-teal-500 text-teal-400 bg-teal-500/5" 
                      : "border-teal-600 text-teal-700 bg-teal-50"
                    : "border-transparent text-slate-400 hover:text-slate-600 dark:hover:text-slate-300"
                }`}
              >
                {tab.icon}
                {tab.label}
              </button>
            ))}
          </div>

          {/* Modal body containing tabs */}
          <div className="flex-1 p-6 overflow-y-auto min-h-[300px]">
            {/* TAB 1: COMBINED FLOWCHART */}
            {activeTab === "combined" && (
              <div className="space-y-6">
                <div className={`p-4 rounded-xl border text-xs leading-relaxed flex items-start gap-2.5 ${
                  isDarkMode ? "bg-slate-900/30 border-slate-800 text-slate-300" : "bg-slate-50 border-slate-150 text-slate-700"
                }`}>
                  <Info className="w-4 h-4 text-teal-500 flex-shrink-0 mt-0.5" />
                  <p>
                    This diagram shows the core decision branching in ACLS cardiac arrest management. CPR should only be interrupted briefly for rhythm analysis and shock delivery (maximum 10 seconds).
                  </p>
                </div>

                {/* Vertical/Horizontal interactive flowchart tree */}
                <div className="flex flex-col items-center">
                  
                  {/* Start Node */}
                  <div className={`p-3 rounded-xl border text-center max-w-sm w-full ${
                    isDarkMode ? "bg-slate-900 border-slate-700" : "bg-slate-100 border-slate-300 shadow-xs"
                  }`}>
                    <span className="text-[10px] uppercase font-bold tracking-wider text-rose-500 font-mono">Step 1</span>
                    <h4 className="font-extrabold text-xs md:text-sm mt-0.5">START CPR</h4>
                    <p className="text-[10px] text-slate-500 mt-1">Give Oxygen, Attach Monitor / Defibrillator</p>
                  </div>

                  {/* Down Arrow */}
                  <div className="h-6 w-0.5 bg-slate-300 dark:bg-slate-700 my-1 relative">
                    <ChevronRight className="w-3.5 h-3.5 absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 rotate-90 text-slate-400" />
                  </div>

                  {/* Rhythm Check Node */}
                  <div className={`p-3 rounded-xl border text-center max-w-md w-full relative ${
                    isDarkMode ? "bg-slate-850 border-teal-500/30" : "bg-teal-50 border-teal-200 shadow-sm"
                  }`}>
                    <span className="text-[10px] uppercase font-bold tracking-wider text-teal-600 dark:text-teal-400 font-mono">Step 2</span>
                    <h4 className="font-extrabold text-xs md:text-sm text-teal-700 dark:text-teal-400 mt-0.5">ASSESS RHYTHM</h4>
                    <p className="text-[10px] text-slate-500 mt-1">Is the rhythm shockable?</p>
                  </div>

                  {/* Bifurcation Split */}
                  <div className="grid grid-cols-2 gap-4 w-full max-w-3xl mt-4 relative">
                    
                    {/* Left/Right connector lines */}
                    <div className="absolute top-0 left-[25%] right-[25%] h-0.5 bg-slate-300 dark:bg-slate-700 -translate-y-4" />
                    <div className="absolute top-0 left-[25%] h-4 w-0.5 bg-slate-300 dark:bg-slate-700 -translate-y-4" />
                    <div className="absolute top-0 right-[25%] h-4 w-0.5 bg-slate-300 dark:bg-slate-700 -translate-y-4" />

                    {/* SHOCKABLE BRANCH (Left Side) */}
                    <div className="flex flex-col items-center">
                      <div className="text-[11px] font-bold text-rose-500 bg-rose-500/10 px-2 py-0.5 rounded border border-rose-500/20 mb-3 uppercase tracking-wider">
                        Yes (VF / pVT)
                      </div>

                      <div className={`p-3.5 rounded-xl border text-center w-full max-w-sm ${
                        isDarkMode ? "bg-rose-950/20 border-rose-900/40" : "bg-rose-50 border-rose-200"
                      } space-y-2`}>
                        <div className="flex items-center justify-center gap-1.5 text-rose-500">
                          <Zap className="w-4 h-4 animate-bounce" />
                          <span className="text-xs font-bold uppercase tracking-wide">SHOCK #1</span>
                        </div>
                        <p className="text-[10px] text-slate-500 leading-normal">
                          Deliver 1 Shock (200J Biphasic). <br />
                          Immediately resume CPR for 2 mins.
                        </p>
                      </div>

                      <div className="h-4 w-0.5 bg-slate-300 dark:bg-slate-700 my-1" />

                      <div className={`p-3.5 rounded-xl border text-center w-full max-w-sm ${
                        isDarkMode ? "bg-rose-950/20 border-rose-900/40" : "bg-rose-50 border-rose-200"
                      } space-y-2`}>
                        <div className="flex items-center justify-center gap-1.5 text-rose-500">
                          <Zap className="w-4 h-4" />
                          <span className="text-xs font-bold uppercase tracking-wide">SHOCK #2</span>
                        </div>
                        <p className="text-[10px] text-slate-500 leading-normal">
                          If VF/pVT persists: Deliver Shock #2. <br />
                          CPR 2 mins + give <strong>Adrenaline 1mg</strong> every 3-5 mins.
                        </p>
                      </div>

                      <div className="h-4 w-0.5 bg-slate-300 dark:bg-slate-700 my-1" />

                      <div className={`p-3.5 rounded-xl border text-center w-full max-w-sm ${
                        isDarkMode ? "bg-rose-950/20 border-rose-900/40" : "bg-rose-50 border-rose-200"
                      } space-y-2`}>
                        <div className="flex items-center justify-center gap-1.5 text-rose-500">
                          <Zap className="w-4 h-4" />
                          <span className="text-xs font-bold uppercase tracking-wide">SHOCK #3</span>
                        </div>
                        <p className="text-[10px] text-slate-500 leading-normal">
                          If VF/pVT persists: Deliver Shock #3. <br />
                          CPR 2 mins + give <strong>Amiodarone 300mg</strong> (or Lidocaine).
                        </p>
                      </div>

                      <div className="h-4 w-0.5 bg-slate-300 dark:bg-slate-700 my-1" />

                      <div className="text-[10px] font-semibold text-slate-500 p-2 rounded bg-slate-100 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 w-full text-center max-w-sm">
                        🔄 Continue Shock/CPR/Adrenaline/Amiodarone cycle until ROSC or Termination.
                      </div>
                    </div>

                    {/* NON-SHOCKABLE BRANCH (Right Side) */}
                    <div className="flex flex-col items-center">
                      <div className="text-[11px] font-bold text-amber-500 bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/20 mb-3 uppercase tracking-wider">
                        No (PEA / Asystole)
                      </div>

                      <div className={`p-3.5 rounded-xl border text-center w-full max-w-sm ${
                        isDarkMode ? "bg-amber-950/20 border-amber-900/40" : "bg-amber-50 border-amber-200"
                      } space-y-2`}>
                        <div className="flex items-center justify-center gap-1.5 text-amber-500">
                          <Syringe className="w-4 h-4" />
                          <span className="text-xs font-bold uppercase tracking-wide">ADRENALINE IMMEDIATELY</span>
                        </div>
                        <p className="text-[10px] text-slate-500 leading-normal">
                          Give <strong>Adrenaline 1mg IV/IO</strong> as soon as possible. <br />
                          Do NOT delay CPR.
                        </p>
                      </div>

                      <div className="h-4 w-0.5 bg-slate-300 dark:bg-slate-700 my-1" />

                      <div className={`p-3.5 rounded-xl border text-center w-full max-w-sm ${
                        isDarkMode ? "bg-amber-950/20 border-amber-900/40" : "bg-amber-50 border-amber-200"
                      } space-y-2`}>
                        <div className="flex items-center justify-center gap-1.5 text-amber-500">
                          <Clock className="w-4 h-4" />
                          <span className="text-xs font-bold uppercase tracking-wide">CPR 2 MINUTES</span>
                        </div>
                        <p className="text-[10px] text-slate-500 leading-normal">
                          High-quality continuous CPR. <br />
                          Address <strong>Reversible Causes (H's & T's)</strong>.
                        </p>
                      </div>

                      <div className="h-4 w-0.5 bg-slate-300 dark:bg-slate-700 my-1" />

                      <div className={`p-3.5 rounded-xl border text-center w-full max-w-sm ${
                        isDarkMode ? "bg-amber-950/20 border-amber-900/40" : "bg-amber-50 border-amber-200"
                      } space-y-2`}>
                        <div className="flex items-center justify-center gap-1.5 text-amber-500">
                          <Activity className="w-4 h-4 animate-pulse" />
                          <span className="text-xs font-bold uppercase tracking-wide">REASSESS RHYTHM</span>
                        </div>
                        <p className="text-[10px] text-slate-500 leading-normal">
                          After 2 mins of CPR, check rhythm. <br />
                          If still Non-Shockable, continue CPR 2 min. <br />
                          Repeat Adrenaline 1mg every 3-5 mins.
                        </p>
                      </div>

                      <div className="h-4 w-0.5 bg-slate-300 dark:bg-slate-700 my-1" />

                      <div className="text-[10px] font-semibold text-slate-500 p-2 rounded bg-slate-100 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 w-full text-center max-w-sm">
                        🔄 Continue CPR / Adrenaline loop. Check for shockable conversion or ROSC.
                      </div>
                    </div>

                  </div>

                  {/* ROSC box */}
                  <div className="h-6 w-0.5 bg-slate-300 dark:bg-slate-700 my-1" />
                  <div className={`p-3 rounded-xl border text-center max-w-md w-full ${
                    isDarkMode ? "bg-emerald-950/20 border-emerald-900/40 text-emerald-400" : "bg-emerald-50 border-emerald-200 text-emerald-800 shadow-xs"
                  }`}>
                    <div className="flex items-center justify-center gap-1.5">
                      <Sparkles className="w-4 h-4 text-emerald-500 animate-pulse" />
                      <h4 className="font-extrabold text-xs md:text-sm uppercase tracking-wide">ROSC achieved?</h4>
                    </div>
                    <p className="text-[10px] text-slate-500 mt-1">If yes, initiate Immediate Post-Cardiac Arrest Care protocol.</p>
                  </div>

                </div>
              </div>
            )}

            {/* TAB 2: SHOCKABLE (VF/pVT) */}
            {activeTab === "shockable" && (
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 animate-fade-in">
                <div className="md:col-span-2 space-y-4">
                  <div className={`p-4 rounded-xl border ${
                    isDarkMode ? "bg-rose-500/5 border-rose-500/20" : "bg-rose-50 border-rose-100"
                  }`}>
                    <h4 className="font-bold text-sm text-rose-500 flex items-center gap-2">
                      <Zap className="w-4 h-4 text-rose-500" />
                      Pathophysiology & Indications
                    </h4>
                    <p className="text-xs text-slate-500 mt-1 leading-normal">
                      Shockable rhythms are characterized by chaotic electrical activity (Ventricular Fibrillation) or extremely rapid, wide complex monomorphic or polymorphic ventricular pacing (pulseless Ventricular Tachycardia). The priority is <strong>early defibrillation</strong> to override the chaotic pacemaker and allow the sinoatrial node to resume control.
                    </p>
                  </div>

                  <div className="space-y-3">
                    <h5 className="text-xs font-extrabold uppercase tracking-widest text-slate-400">Step-by-Step Chronology</h5>
                    
                    {[
                      {
                        title: "1st Shock Delivery (200J Biphasic)",
                        desc: "Immediately discharge defibrillator (200J biphasic or 360J monophasic). Ensure all operators are clear of the bed. Do NOT perform rhythm analysis or pulse checks before shock."
                      },
                      {
                        title: "Immediate CPR (2 Minutes)",
                        desc: "Do not check rhythm or pulse after shock. Immediately resume chest compressions. Establish IV/IO access, do NOT interrupt compressions for cannulation."
                      },
                      {
                        title: "2nd Shock & Continued CPR",
                        desc: "Assess rhythm after 2 minutes. If VF/pVT persists, deliver 2nd Shock. Immediately resume CPR. Prepare Adrenaline to be administered on the next cycle."
                      },
                      {
                        title: "3rd Shock & First Drug Administration",
                        desc: "Assess rhythm after 4 minutes. If VF/pVT persists, deliver 3rd Shock. Resume CPR. Give Adrenaline 1mg IV/IO AND Amiodarone 300mg IV/IO (or Lidocaine 1-1.5mg/kg)."
                      },
                      {
                        title: "Subsequent Cycles",
                        desc: "Assess rhythm every 2 minutes. If shockable: deliver shock, resume CPR, alternate Adrenaline 1mg (every 3-5 mins, usually alternate cycles) and prepare Amiodarone 150mg 2nd dose (after 5th shock)."
                      }
                    ].map((step, idx) => (
                      <div key={idx} className={`p-3 rounded-xl border flex gap-3 ${
                        isDarkMode ? "bg-slate-900/60 border-slate-800" : "bg-slate-50 border-slate-200"
                      }`}>
                        <div className="w-6 h-6 rounded-full bg-rose-500 text-white font-mono font-bold text-xs flex items-center justify-center flex-shrink-0 mt-0.5">
                          {idx + 1}
                        </div>
                        <div>
                          <h6 className="font-bold text-xs md:text-sm text-slate-200 dark:text-slate-100">{step.title}</h6>
                          <p className="text-xs text-slate-400 mt-1 leading-normal">{step.desc}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Right Side: Quick Reference Sidebar */}
                <div className="space-y-4">
                  <div className={`p-4 rounded-xl border ${
                    isDarkMode ? "bg-slate-900 border-slate-800" : "bg-white border-slate-200"
                  } space-y-3`}>
                    <h5 className="font-extrabold text-xs uppercase tracking-widest text-teal-400">Shockable Drugs Cheat-Sheet</h5>
                    
                    <div className="space-y-2.5 text-xs">
                      <div className="p-2.5 rounded bg-rose-500/5 border border-rose-500/15">
                        <span className="font-bold text-rose-500 block">Adrenaline (Epinephrine)</span>
                        <p className="text-[11px] text-slate-500 mt-0.5"><strong>Dose:</strong> 1 mg IV/IO.</p>
                        <p className="text-[11px] text-slate-500"><strong>Timing:</strong> After the 3rd shock, then repeat every 3 to 5 minutes.</p>
                      </div>

                      <div className="p-2.5 rounded bg-teal-500/5 border border-teal-500/15">
                        <span className="font-bold text-teal-400 block">Amiodarone</span>
                        <p className="text-[11px] text-slate-500 mt-0.5"><strong>1st Dose:</strong> 300 mg IV/IO bolus (after 3rd shock).</p>
                        <p className="text-[11px] text-slate-500"><strong>2nd Dose:</strong> 150 mg IV/IO bolus (after 5th shock).</p>
                      </div>

                      <div className="p-2.5 rounded bg-blue-500/5 border border-blue-500/15">
                        <span className="font-bold text-blue-400 block">Lidocaine (Alternative to Amiodarone)</span>
                        <p className="text-[11px] text-slate-500 mt-0.5"><strong>1st Dose:</strong> 1 to 1.5 mg/kg IV/IO.</p>
                        <p className="text-[11px] text-slate-500"><strong>2nd Dose:</strong> 0.5 to 0.75 mg/kg IV/IO.</p>
                      </div>

                      <div className="p-2.5 rounded bg-purple-500/5 border border-purple-500/15">
                        <span className="font-bold text-purple-400 block">Magnesium Sulfate (Torsades de Pointes)</span>
                        <p className="text-[11px] text-slate-500 mt-0.5"><strong>Dose:</strong> 1 to 2 g IV/IO diluted in 10 mL D5W over 5 to 20 minutes.</p>
                      </div>
                    </div>
                  </div>

                  <div className={`p-4 rounded-xl border ${
                    isDarkMode ? "bg-slate-900 border-slate-800" : "bg-white border-slate-200"
                  } text-xs`}>
                    <h5 className="font-bold mb-1.5 flex items-center gap-1">
                      <Wind className="w-4 h-4 text-teal-400" /> Advanced Airway Goals
                    </h5>
                    <ul className="list-disc pl-4 space-y-1 text-[11px] text-slate-500">
                      <li>Use capnography (ETCO2) to guide compression quality and detect ROSC.</li>
                      <li>Continuous compressions without pauses for ventilation once advanced airway is in place.</li>
                      <li>Give 1 breath every 6 seconds (10 breaths/min).</li>
                    </ul>
                  </div>
                </div>
              </div>
            )}

            {/* TAB 3: NON-SHOCKABLE (PEA/ASYSTOLE) */}
            {activeTab === "non-shockable" && (
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 animate-fade-in">
                <div className="md:col-span-2 space-y-4">
                  <div className={`p-4 rounded-xl border ${
                    isDarkMode ? "bg-amber-500/5 border-amber-500/20" : "bg-amber-50 border-amber-100"
                  }`}>
                    <h4 className="font-bold text-sm text-amber-500 flex items-center gap-2">
                      <Activity className="w-4 h-4 text-amber-500" />
                      PEA & Asystole Overview
                    </h4>
                    <p className="text-xs text-slate-500 mt-1 leading-normal">
                      Non-shockable rhythms are characterized by either complete lack of electrical pacing activity (Asystole) or electrical pacing activity without mechanical output (Pulseless Electrical Activity). The absolute key to survival in non-shockable cardiac arrest is <strong>early Adrenaline delivery</strong> (within minutes of arrest identification) and systematic discovery and correction of the underlying <strong>reversible cause</strong>.
                    </p>
                  </div>

                  <div className="space-y-3">
                    <h5 className="text-xs font-extrabold uppercase tracking-widest text-slate-400">Step-by-Step Chronology</h5>
                    
                    {[
                      {
                        title: "1st Adrenaline Administration - IMMEDIATE",
                        desc: "Secure IV or IO access immediately. Administer Adrenaline 1 mg IV/IO as soon as possible after starting resuscitation. Do NOT delay for CPR cycles."
                      },
                      {
                        title: "High-Performance CPR (2 Minutes)",
                        desc: "Provide 2 minutes of continuous high-performance CPR. Direct a secondary team member to systematically run through the 4 Hs & 4 Ts checklist."
                      },
                      {
                        title: "Rhythm & Pulse Check",
                        desc: "After 2 minutes of CPR, check the rhythm on the monitor. If rhythm is organized (e.g. narrow complex QRS on screen), pause briefly to check for a central pulse (carotid/femoral)."
                      },
                      {
                        title: "Determine Rhythm Class Integration",
                        desc: "1) If still non-shockable: Resume CPR immediately. Give Adrenaline every 3-5 mins (alternate cycles). <br />2) If converted to shockable rhythm: Transition immediately to the Shockable Pathway (Shock 200J)."
                      },
                      {
                        title: "Active Etiology Troubleshooting",
                        desc: "Consider ultrasound (e.g. FOCUS protocol) to look for tamponade, PE, hypervolemia or hypovolemia. Consider empirical Sodium Bicarbonate for severe hyperkalemia or TCA overdose."
                      }
                    ].map((step, idx) => (
                      <div key={idx} className={`p-3 rounded-xl border flex gap-3 ${
                        isDarkMode ? "bg-slate-900/60 border-slate-800" : "bg-slate-50 border-slate-200"
                      }`}>
                        <div className="w-6 h-6 rounded-full bg-amber-500 text-white font-mono font-bold text-xs flex items-center justify-center flex-shrink-0 mt-0.5">
                          {idx + 1}
                        </div>
                        <div>
                          <h6 className="font-bold text-xs md:text-sm text-slate-200 dark:text-slate-100" dangerouslySetInnerHTML={{ __html: step.title }} />
                          <p className="text-xs text-slate-400 mt-1 leading-normal" dangerouslySetInnerHTML={{ __html: step.desc }} />
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Right Side: Quick Reference Sidebar */}
                <div className="space-y-4">
                  <div className={`p-4 rounded-xl border ${
                    isDarkMode ? "bg-slate-900 border-slate-800" : "bg-white border-slate-200"
                  } space-y-4`}>
                    <h5 className="font-extrabold text-xs uppercase tracking-widest text-amber-500">Etiology Search (H's & T's)</h5>
                    
                    <div className="space-y-3 text-xs">
                      <div>
                        <span className="font-bold text-amber-400 block">The H's</span>
                        <ul className="list-disc pl-4 mt-1 space-y-1 text-[11px] text-slate-500">
                          <li><strong>Hypoxia:</strong> Pre-oxygenate, verify airway placement.</li>
                          <li><strong>Hypovolemia:</strong> Infuse crystalloid, packed cells.</li>
                          <li><strong>Hydrogen Ion (Acidosis):</strong> Hyperventilate, Bicarbonate.</li>
                          <li><strong>Hypo-/Hyperkalemia:</strong> empirical treatment (Calcium).</li>
                          <li><strong>Hypothermia:</strong> Active/passive warming methods.</li>
                        </ul>
                      </div>

                      <div>
                        <span className="font-bold text-amber-400 block">The T's</span>
                        <ul className="list-disc pl-4 mt-1 space-y-1 text-[11px] text-slate-500">
                          <li><strong>Tension Pneumothorax:</strong> Needle decompression/finger thoracostomy.</li>
                          <li><strong>Tamponade (Cardiac):</strong> pericardiocentesis.</li>
                          <li><strong>Toxins:</strong> Antidotes (Naloxone, Intralipid, etc.).</li>
                          <li><strong>Thrombosis (Pulmonary/Coronary):</strong> Thrombolysis, emergency angiogram.</li>
                        </ul>
                      </div>
                    </div>
                  </div>

                  <div className={`p-4 rounded-xl border ${
                    isDarkMode ? "bg-slate-900/60 border-slate-800 text-slate-300" : "bg-slate-50 border-slate-200"
                  } text-xs`}>
                    <span className="font-bold text-rose-500 block">⚠️ Adrenaline Warning</span>
                    <p className="text-[11px] text-slate-500 leading-normal mt-1">
                      Giving Adrenaline too late in non-shockable arrests is strongly linked to poorer neurological outcomes. Ensure it is drawn and administered immediately when access is established.
                    </p>
                  </div>
                </div>
              </div>
            )}

            {/* TAB 4: CRITICAL PARAMETERS */}
            {activeTab === "parameters" && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 animate-fade-in text-xs">
                
                {/* CPR Quality & Defibrillation */}
                <div className="space-y-4">
                  <div className={`p-4 rounded-xl border ${
                    isDarkMode ? "bg-slate-900 border-slate-800" : "bg-white border-slate-200"
                  }`}>
                    <h4 className="font-bold text-sm text-teal-400 mb-3 flex items-center gap-2">
                      <CheckCircle2 className="w-4 h-4 text-teal-400" />
                      CPR Quality Standards
                    </h4>
                    <ul className="space-y-2.5 text-slate-500">
                      <li className="flex items-start gap-2">
                        <ChevronRight className="w-4 h-4 text-teal-500 flex-shrink-0 mt-0.5" />
                        <div>
                          <strong>Compression Rate:</strong> 100 to 120 compressions per minute.
                        </div>
                      </li>
                      <li className="flex items-start gap-2">
                        <ChevronRight className="w-4 h-4 text-teal-500 flex-shrink-0 mt-0.5" />
                        <div>
                          <strong>Compression Depth:</strong> At least 2 inches (5 cm) but no more than 2.4 inches (6 cm).
                        </div>
                      </li>
                      <li className="flex items-start gap-2">
                        <ChevronRight className="w-4 h-4 text-teal-500 flex-shrink-0 mt-0.5" />
                        <div>
                          <strong>Chest Recoil:</strong> Allow full chest wall recoil after each compression. Avoid leaning on the chest.
                        </div>
                      </li>
                      <li className="flex items-start gap-2">
                        <ChevronRight className="w-4 h-4 text-teal-500 flex-shrink-0 mt-0.5" />
                        <div>
                          <strong>Minimise Interruptions:</strong> Keep pauses in chest compressions to less than 10 seconds (e.g. for rhythm checks, shocks, or airway placement).
                        </div>
                      </li>
                      <li className="flex items-start gap-2">
                        <ChevronRight className="w-4 h-4 text-teal-500 flex-shrink-0 mt-0.5" />
                        <div>
                          <strong>Rotate Compressors:</strong> Switch compressors every 2 minutes (or sooner if fatigued) to maintain compression quality.
                        </div>
                      </li>
                      <li className="flex items-start gap-2">
                        <ChevronRight className="w-4 h-4 text-teal-500 flex-shrink-0 mt-0.5" />
                        <div>
                          <strong>Ventilation Ratio:</strong> 
                          <ul className="list-disc pl-4 mt-0.5 space-y-0.5 text-[11px]">
                            <li>Without advanced airway: 30 compressions to 2 breaths (Adult).</li>
                            <li>With advanced airway: continuous compressions, 1 breath every 6 seconds (10 breaths/min).</li>
                          </ul>
                        </div>
                      </li>
                    </ul>
                  </div>

                  <div className={`p-4 rounded-xl border ${
                    isDarkMode ? "bg-slate-900 border-slate-800" : "bg-white border-slate-200"
                  }`}>
                    <h4 className="font-bold text-sm text-teal-400 mb-3 flex items-center gap-2">
                      <Zap className="w-4 h-4 text-teal-400" />
                      Defibrillator Shock Energy
                    </h4>
                    <div className="space-y-2.5 text-slate-500">
                      <p>
                        <strong>Biphasic Defibrillator:</strong> Manufacturer recommendation (typically 120 J to 200 J). If manufacturer recommendation is unknown, deliver the <strong>maximum available dose</strong>. Second and subsequent doses should be equivalent or higher.
                      </p>
                      <p>
                        <strong>Monophasic Defibrillator:</strong> 360 J for all shocks.
                      </p>
                    </div>
                  </div>
                </div>

                {/* Advanced Airway & ROSC */}
                <div className="space-y-4">
                  <div className={`p-4 rounded-xl border ${
                    isDarkMode ? "bg-slate-900 border-slate-800" : "bg-white border-slate-200"
                  }`}>
                    <h4 className="font-bold text-sm text-teal-400 mb-3 flex items-center gap-2">
                      <Wind className="w-4 h-4 text-teal-400" />
                      Advanced Airway & Capnography
                    </h4>
                    <ul className="space-y-2 text-slate-500">
                      <li>
                        <strong>Airway Types:</strong> Endotracheal (ET) intubation or Supraglottic Advanced Airway (e.g. Laryngeal Mask Airway - LMA / i-gel).
                      </li>
                      <li>
                        <strong>Verification:</strong> Confirm placement via waveform capnography (the gold standard) and chest auscultation.
                      </li>
                      <li>
                        <strong>ETCO2 Monitoring Targets:</strong>
                        <ul className="list-disc pl-4 mt-1 space-y-1 text-[11px]">
                          <li><strong>ETCO2 &lt; 10 mmHg:</strong> Suggests sub-optimal compression quality. Focus on improving compressor depth, rate, and chest recoil.</li>
                          <li><strong>ETCO2 &gt;= 10 to 20 mmHg:</strong> Reflects adequate high-performance chest compressions.</li>
                          <li><strong>ETCO2 Spike (e.g. &gt;= 35-40 mmHg):</strong> A sudden sustained increase in ETCO2 indicates <strong>Return of Spontaneous Circulation (ROSC)</strong>.</li>
                        </ul>
                      </li>
                    </ul>
                  </div>

                  <div className={`p-4 rounded-xl border ${
                    isDarkMode ? "bg-slate-900 border-slate-800" : "bg-white border-slate-200"
                  }`}>
                    <h4 className="font-bold text-sm text-teal-400 mb-3 flex items-center gap-2">
                      <Sparkles className="w-4 h-4 text-teal-400 animate-pulse" />
                      ROSC Verification Criteria
                    </h4>
                    <ul className="space-y-2 text-slate-500">
                      <li className="flex items-start gap-1.5">
                        <CheckCircle2 className="w-4 h-4 text-emerald-500 flex-shrink-0 mt-0.5" />
                        <div>
                          <strong>Pulse and Blood Pressure:</strong> Sustained presence of palpable central pulse and measurable blood pressure.
                        </div>
                      </li>
                      <li className="flex items-start gap-1.5">
                        <CheckCircle2 className="w-4 h-4 text-emerald-500 flex-shrink-0 mt-0.5" />
                        <div>
                          <strong>Arterial Pressure:</strong> Sudden sustained rise in spontaneous arterial pressure waves (if invasive arterial line is in place).
                        </div>
                      </li>
                      <li className="flex items-start gap-1.5">
                        <CheckCircle2 className="w-4 h-4 text-emerald-500 flex-shrink-0 mt-0.5" />
                        <div>
                          <strong>Capnography:</strong> Sudden sustained spike in ETCO2 (typically &gt;= 35 to 40 mmHg).
                        </div>
                      </li>
                    </ul>
                  </div>
                </div>

              </div>
            )}
          </div>

          {/* Footer */}
          <div className={`p-4 border-t flex flex-col sm:flex-row justify-between items-center gap-4 text-xs ${
            isDarkMode ? "border-slate-800/80 bg-slate-950/60 text-slate-400" : "border-slate-150 bg-slate-50 text-slate-500"
          }`}>
            <span>Double check drug doses and local cardiac arrest protocols.</span>
            <button
              onClick={onClose}
              id="close-acls-modal-footer-btn"
              className="px-4 py-2 rounded-lg bg-teal-500 hover:bg-teal-600 text-slate-950 font-bold transition-all shadow-md shadow-teal-500/10"
            >
              Dismiss Reference
            </button>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}
