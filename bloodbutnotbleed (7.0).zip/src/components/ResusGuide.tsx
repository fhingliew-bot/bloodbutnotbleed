import React, { useState, useEffect } from "react";
import AclsAlgorithmModal from "./AclsAlgorithmModal";
import EcgGallery from "./EcgGallery";
import { 
  Play, 
  Pause, 
  RotateCcw, 
  Activity, 
  Volume2, 
  VolumeX, 
  Clock, 
  PlusCircle, 
  Trash2, 
  Heart, 
  ShieldAlert, 
  CheckCircle2, 
  Info, 
  AlertTriangle, 
  Check, 
  Flame, 
  Zap, 
  Thermometer, 
  FileText, 
  Baby, 
  Syringe,
  Copy
} from "lucide-react";

interface ResusGuideProps {
  isDarkMode: boolean;
  resusActiveAlg: "cardiac" | "anaphylaxis" | "asthma" | "seizures" | "hyperkalemia";
  setResusActiveAlg: (alg: "cardiac" | "anaphylaxis" | "asthma" | "seizures" | "hyperkalemia") => void;
  resusRhythm: "shockable" | "non-shockable";
  setResusRhythm: (r: "shockable" | "non-shockable") => void;
  resusCprTimeLeft: number;
  setResusCprTimeLeft: React.Dispatch<React.SetStateAction<number>>;
  resusCprTimerRunning: boolean;
  setResusCprTimerRunning: (r: boolean) => void;
  resusAdrenalineCount: number;
  setResusAdrenalineCount: React.Dispatch<React.SetStateAction<number>>;
  resusAmiodaroneCount: number;
  setResusAmiodaroneCount: React.Dispatch<React.SetStateAction<number>>;
  resusCyclesCompleted: number;
  setResusCyclesCompleted: React.Dispatch<React.SetStateAction<number>>;
  resusMetronomeActive: boolean;
  setResusMetronomeActive: (r: boolean) => void;
  resusTimeHistory: { id: string; time: string; event: string }[];
  setResusTimeHistory: React.Dispatch<React.SetStateAction<{ id: string; time: string; event: string }[]>>;
}

export default function ResusGuide({
  isDarkMode,
  resusActiveAlg,
  setResusActiveAlg,
  resusRhythm,
  setResusRhythm,
  resusCprTimeLeft,
  setResusCprTimeLeft,
  resusCprTimerRunning,
  setResusCprTimerRunning,
  resusAdrenalineCount,
  setResusAdrenalineCount,
  resusAmiodaroneCount,
  setResusAmiodaroneCount,
  resusCyclesCompleted,
  setResusCyclesCompleted,
  resusMetronomeActive,
  setResusMetronomeActive,
  resusTimeHistory,
  setResusTimeHistory
}: ResusGuideProps) {
  // Reversible Causes State
  const [reversibleChecked, setReversibleChecked] = useState<Record<string, boolean>>({});
  
  // Anaphylaxis States
  const [anaphylaxisType, setAnaphylaxisType] = useState<"adult" | "child_older" | "child_younger" | "infant">("adult");
  
  // Asthma States
  const [asthmaSeverity, setAsthmaSeverity] = useState<"moderate" | "severe" | "life_threatening">("severe");
  
  // Seizure/Epilepsy States
  const [seizurePhase, setSeizurePhase] = useState<"initial" | "first_line" | "second_line" | "refractory">("initial");
  const [seizureSubView, setSeizureSubView] = useState<"emergency" | "maintenance">("emergency");
  const [epilepsySeizureType, setEpilepsySeizureType] = useState<"focal" | "generalized" | "absence" | "myoclonic">("focal");
  const [epilepsyPatientGroup, setEpilepsyPatientGroup] = useState<"general" | "pregnancy" | "elderly">("general");

  // ACLS Algorithm Modal State
  const [isAclsModalOpen, setIsAclsModalOpen] = useState(false);

  // Local helper to format seconds into mm:ss
  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, "0")}`;
  };

  // Add event to timeline log
  const logEvent = (eventText: string) => {
    const now = new Date();
    const timeStr = now.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" });
    setResusTimeHistory((prev) => [
      { id: Math.random().toString(), time: timeStr, event: eventText },
      ...prev
    ]);
  };

  // Timeline copying helper
  const copyTimeline = () => {
    if (resusTimeHistory.length === 0) return;
    const text = resusTimeHistory
      .map((item) => `[${item.time}] ${item.event}`)
      .join("\n");
    navigator.clipboard.writeText(`--- RESUSCITATION TIMELINE EVENT LOG ---\n${text}`).then(() => {
      alert("Timeline copied to clipboard!");
    }).catch(() => {
      alert("Unable to copy to clipboard.");
    });
  };

  const handleToggleReversible = (id: string) => {
    setReversibleChecked((prev) => ({
      ...prev,
      [id]: !prev[id]
    }));
  };

  const clearLog = () => {
    if (confirm("Are you sure you want to clear the resus timeline event log?")) {
      setResusTimeHistory([]);
      setResusAdrenalineCount(0);
      setResusAmiodaroneCount(0);
      setResusCyclesCompleted(0);
    }
  };

  const renderTimelineLogger = () => (
    <div className="space-y-4">
      <div className={`p-4 rounded-2xl border ${isDarkMode ? "bg-slate-950/40 border-slate-800/80" : "bg-white border-slate-200 shadow-sm"} space-y-4`}>
        <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800/60">
          <div className="flex items-center gap-1.5">
            <FileText className="w-4 h-4 text-rose-500" />
            <h3 className={`font-bold text-xs uppercase tracking-widest ${isDarkMode ? "text-slate-200" : "text-slate-800"}`}>
              Resus Timeline Log
            </h3>
          </div>
          <div className="flex gap-1">
            <button
              onClick={copyTimeline}
              disabled={resusTimeHistory.length === 0}
              className="p-1.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 disabled:opacity-50 text-[10px] font-bold flex items-center gap-1"
              title="Copy timeline log for clinical records"
            >
              <Copy className="w-3 h-3" /> Copy
            </button>
            <button
              onClick={clearLog}
              disabled={resusTimeHistory.length === 0}
              className="p-1.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-rose-500 hover:text-rose-700 disabled:opacity-50"
              title="Clear log"
            >
              <Trash2 className="w-3 h-3" />
            </button>
          </div>
        </div>

        {/* Quick intervention add bar */}
        <div className="space-y-1.5">
          <span className="text-[9px] font-extrabold text-slate-500 dark:text-slate-400 block uppercase">Manual Custom Log Entry:</span>
          <form
            onSubmit={(e) => {
              e.preventDefault();
              const form = e.currentTarget;
              const input = form.elements.namedItem("eventText") as HTMLInputElement;
              if (input && input.value.trim()) {
                logEvent(input.value.trim());
                input.value = "";
              }
            }}
            className="flex gap-1.5"
          >
            <input
              name="eventText"
              type="text"
              placeholder="e.g., IV Access established"
              className={`flex-1 px-3 py-1.5 rounded-xl border text-xs focus:outline-none focus:ring-1 focus:ring-rose-500 ${
                isDarkMode
                  ? "bg-slate-900 border-slate-800 text-slate-200"
                  : "bg-white border-slate-200 text-slate-900"
              }`}
            />
            <button
              type="submit"
              className="px-2.5 py-1.5 bg-rose-500 hover:bg-rose-600 text-white rounded-xl font-bold text-xs flex items-center justify-center flex-shrink-0"
            >
              Log
            </button>
          </form>
        </div>

        {/* Event List */}
        <div className={`max-h-96 overflow-y-auto pr-1 space-y-2 font-mono text-[11px] scrollbar-thin`}>
          {resusTimeHistory.length === 0 ? (
            <div className="text-center py-8 text-slate-500 italic">
              No resuscitation events recorded yet. Actions clicked in the checklists above will automatically appear here with exact millisecond-precision timestamps.
            </div>
          ) : (
            resusTimeHistory.map((item) => (
              <div
                key={item.id}
                className={`p-2 rounded-lg border flex gap-2 leading-relaxed transition-all ${
                  item.event.includes("🚨") || item.event.includes("Shock") || item.event.includes("Adrenaline")
                    ? isDarkMode
                      ? "bg-rose-950/20 border-rose-900/40 text-rose-300"
                      : "bg-rose-50 border-rose-200 text-rose-800"
                    : isDarkMode
                      ? "bg-slate-900 border-slate-800 text-slate-300"
                      : "bg-slate-100 border-slate-200 text-slate-700"
                }`}
              >
                <span className="text-rose-500 dark:text-rose-400 font-bold flex-shrink-0">
                  [{item.time}]
                </span>
                <span className="flex-1 break-words">{item.event}</span>
              </div>
            ))
          )}
        </div>
      </div>

      {/* Quick instructions block */}
      <div className={`p-4 rounded-2xl border ${isDarkMode ? "bg-slate-950/20 border-slate-800" : "bg-slate-50 border-slate-200"} space-y-2`}>
        <span className="text-[10px] font-bold text-teal-500 uppercase tracking-wider block">Clinical Workflow Helper:</span>
        <p className="text-[11px] leading-relaxed text-slate-600 dark:text-slate-400">
          The resuscitation timeline history allows doctors to easily track every step of an active emergency. Once the patient is stabilized, click <strong>Copy</strong> in the timeline log to instantly paste the exact chronological sequence directly into the Electronic Medical Record (EMR) or case summary.
        </p>
      </div>
    </div>
  );

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Resus Header Block */}
      <div className={`p-4 rounded-xl border flex flex-col md:flex-row justify-between items-start md:items-center gap-4 ${
        isDarkMode 
          ? "bg-[#1e1b1b]/30 border-rose-900/30 text-rose-300" 
          : "bg-rose-50 border-rose-100 text-rose-800"
      }`}>
        <div className="flex gap-3">
          <div className="p-2.5 rounded-xl bg-rose-500 text-white flex-shrink-0 animate-pulse">
            <Activity className="w-5 h-5" />
          </div>
          <div>
            <h2 className="font-bold text-base tracking-tight">Active Resuscitation & Emergency Algorithms</h2>
            <p className="text-xs mt-0.5 opacity-85">
              Rapid Bedside Decision Support. Interactive timing logs, metronome, dosing guides, and reversible causes checklist.
            </p>
          </div>
        </div>
        <div className="flex flex-wrap gap-2">
          <button
            onClick={() => setIsAclsModalOpen(true)}
            id="view-acls-algorithms-btn"
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
              isDarkMode
                ? "bg-rose-950/40 hover:bg-rose-900/40 border border-rose-800/60 text-rose-300"
                : "bg-rose-100 hover:bg-rose-200/80 border border-rose-200 text-rose-800 shadow-xs"
            }`}
          >
            <Heart className="w-3.5 h-3.5 text-rose-500 animate-pulse" />
            ACLS Cardiac Arrest Chart
          </button>
          <button
            onClick={() => setResusMetronomeActive(!resusMetronomeActive)}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold font-mono transition-all flex items-center gap-1.5 cursor-pointer ${
              resusMetronomeActive
                ? "bg-rose-500 text-white animate-pulse"
                : isDarkMode
                  ? "bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-300"
                  : "bg-white hover:bg-slate-50 border border-slate-200 text-slate-700 shadow-sm"
            }`}
          >
            {resusMetronomeActive ? <Volume2 className="w-3.5 h-3.5" /> : <VolumeX className="w-3.5 h-3.5" />}
            Metronome {resusMetronomeActive ? "ON (110 bpm)" : "OFF"}
          </button>
        </div>
      </div>

      {/* Grid of Algorithms Navigation */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-2">
        {[
          { id: "cardiac", label: "Cardiac Arrest", icon: "❤️" },
          { id: "anaphylaxis", label: "Anaphylaxis", icon: "🐝" },
          { id: "asthma", label: "Severe Asthma", icon: "🫁" },
          { id: "seizures", label: "Seizure", icon: "🧠" },
          { id: "hyperkalemia", label: "Hyperkalemia", icon: "🧪" }
        ].map((alg) => (
          <button
            key={alg.id}
            onClick={() => setResusActiveAlg(alg.id as any)}
            className={`p-3 rounded-xl border flex flex-col items-center justify-center gap-1.5 text-center font-bold text-xs transition-all cursor-pointer ${
              resusActiveAlg === alg.id
                ? "bg-rose-500/15 border-rose-500 text-rose-500 dark:text-rose-400 ring-1 ring-rose-500/20"
                : isDarkMode
                  ? "bg-[#111827] border-slate-800 text-slate-400 hover:bg-slate-900 hover:text-slate-200"
                  : "bg-white border-slate-200 text-slate-600 hover:bg-slate-50 hover:border-slate-300 shadow-sm"
            }`}
          >
            <span className="text-xl">{alg.icon}</span>
            <span>{alg.label}</span>
          </button>
        ))}
      </div>

      {/* Main Single Column layout (Algorithm detail + Event Timeline logger) */}
      <div className="flex flex-col space-y-6">
          
          {/* ALGORITHM 1: CARDIAC ARREST */}
          {resusActiveAlg === "cardiac" && (
            <>
              <div className={`p-5 rounded-2xl border ${isDarkMode ? "bg-slate-950/40 border-slate-800/80" : "bg-white border-slate-200 shadow-sm"} space-y-6`}>
              
              {/* Rhythm Selector Card */}
              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 pb-4 border-b border-slate-100 dark:border-slate-800/60">
                <div>
                  <h3 className={`font-bold text-lg ${isDarkMode ? "text-slate-100" : "text-slate-900"}`}>ALS Cardiac Arrest Algorithm</h3>
                  <p className="text-xs text-slate-500 mt-0.5 font-mono flex items-center gap-1.5 flex-wrap">
                    Assessed as Pulseless Cardiac Arrest • 
                    <button 
                      onClick={() => setIsAclsModalOpen(true)}
                      className="text-xs text-teal-600 hover:text-teal-700 dark:text-teal-400 dark:hover:text-teal-300 font-bold underline cursor-pointer"
                    >
                      View Full ACLS Diagram &amp; Parameters
                    </button>
                  </p>
                </div>
                
                <div className="flex bg-slate-100 dark:bg-slate-900 p-1 rounded-xl border border-slate-200 dark:border-slate-800">
                  <button
                    onClick={() => {
                      setResusRhythm("shockable");
                      logEvent("Assessed Rhythm: SHOCKABLE (VF / pVT)");
                    }}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                      resusRhythm === "shockable"
                        ? "bg-red-500 text-white shadow-sm"
                        : "text-slate-500 hover:text-slate-800 dark:hover:text-slate-200"
                    }`}
                  >
                    Shockable (VF / pVT)
                  </button>
                  <button
                    onClick={() => {
                      setResusRhythm("non-shockable");
                      logEvent("Assessed Rhythm: NON-SHOCKABLE (PEA / Asystole)");
                    }}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                      resusRhythm === "non-shockable"
                        ? "bg-amber-500 text-white shadow-sm"
                        : "text-slate-500 hover:text-slate-800 dark:hover:text-slate-200"
                    }`}
                  >
                    Non-Shockable (PEA / Asystole)
                  </button>
                </div>
              </div>

              {/* CPR Timer Controls & Metronome visualization */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                
                {/* 2 Min CPR Cycle Timer Box */}
                <div className={`p-4 rounded-xl border ${
                  resusCprTimerRunning
                    ? "bg-emerald-500/5 border-emerald-500/20 text-emerald-400"
                    : isDarkMode 
                      ? "bg-slate-900/60 border-slate-800 text-slate-300" 
                      : "bg-slate-50 border-slate-200 text-slate-700 shadow-inner"
                } flex flex-col justify-between`}>
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-bold uppercase tracking-wider flex items-center gap-1">
                      <Clock className="w-3 h-3" /> 2-Min CPR Cycle Countdown
                    </span>
                    <span className="text-[10px] font-mono opacity-80">
                      Cycles Done: <strong className="text-base font-bold text-rose-500 dark:text-rose-400">{resusCyclesCompleted}</strong>
                    </span>
                  </div>

                  <div className="py-4 text-center">
                    <div className="text-4xl font-extrabold font-mono tracking-tight select-none">
                      {formatTime(resusCprTimeLeft)}
                    </div>
                    
                    {/* Visual Progress bar */}
                    <div className={`w-full h-1.5 rounded-full mt-3 overflow-hidden ${isDarkMode ? "bg-slate-950" : "bg-slate-200"}`}>
                      <div 
                        className={`h-full rounded-full transition-all duration-1000 ${
                          resusCprTimeLeft < 30 ? "bg-rose-500" : "bg-emerald-500"
                        }`}
                        style={{ width: `${(resusCprTimeLeft / 120) * 100}%` }}
                      />
                    </div>
                  </div>

                  <div className="flex gap-2">
                    <button
                      onClick={() => {
                        const nextState = !resusCprTimerRunning;
                        setResusCprTimerRunning(nextState);
                        logEvent(nextState ? "CPR Cycle Timer STARTED" : "CPR Cycle Timer PAUSED");
                      }}
                      className={`flex-1 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-1 ${
                        resusCprTimerRunning
                          ? "bg-amber-500 hover:bg-amber-600 text-white"
                          : "bg-emerald-600 hover:bg-emerald-700 text-white"
                      }`}
                    >
                      {resusCprTimerRunning ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
                      {resusCprTimerRunning ? "Pause" : "Start Timer"}
                    </button>
                    <button
                      onClick={() => {
                        setResusCprTimeLeft(120);
                        setResusCprTimerRunning(false);
                        logEvent("CPR Cycle Timer RESET to 2:00");
                      }}
                      className={`p-1.5 rounded-lg border transition-all ${
                        isDarkMode
                          ? "bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-200"
                          : "bg-white border-slate-200 text-slate-500 hover:bg-slate-50"
                      }`}
                      title="Reset countdown"
                    >
                      <RotateCcw className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                {/* Metronome & Rhythm Interactive Prompt */}
                <div className={`p-4 rounded-xl border ${
                  isDarkMode ? "bg-slate-900/60 border-slate-800" : "bg-slate-50 border-slate-200 shadow-inner"
                } flex flex-col justify-between`}>
                  <div>
                    <span className="text-[10px] font-bold uppercase tracking-wider text-rose-500 flex items-center gap-1">
                      <Activity className="w-3 h-3 animate-pulse" /> Active Decision Guidance
                    </span>
                    <h4 className={`font-bold text-sm mt-2 ${isDarkMode ? "text-slate-200" : "text-slate-950"}`}>
                      {resusRhythm === "shockable" ? "SHOCKABLE RHYTHM (VF / pVT)" : "NON-SHOCKABLE RHYTHM (PEA / Asystole)"}
                    </h4>
                    <p className={`text-[11px] leading-relaxed mt-1 ${isDarkMode ? "text-slate-400" : "text-slate-700"}`}>
                      {resusRhythm === "shockable"
                        ? "Action: Deliver 1 Shock (200J Biphasic) immediately. Resume CPR (2 mins) immediately after shock. DO NOT delay chest compressions."
                        : "Action: Resume CPR (2 mins) immediately. Secure vascular access, give Adrenaline 1mg IV/IO immediately."}
                    </p>
                  </div>

                  <div className="flex flex-wrap gap-1.5 mt-3">
                    <button
                      onClick={() => {
                        setResusAdrenalineCount((c) => c + 1);
                        logEvent(`Adrenaline 1mg IV/IO administered (Total: ${resusAdrenalineCount + 1})`);
                      }}
                      className={`px-2.5 py-1 rounded-lg text-[11px] font-bold transition-all flex items-center gap-1 bg-rose-500 hover:bg-rose-600 text-white`}
                    >
                      <Syringe className="w-3 h-3" /> + Adrenaline 1mg
                    </button>
                    {resusRhythm === "shockable" && (
                      <button
                        onClick={() => {
                          setResusAmiodaroneCount((c) => c + 1);
                          const dose = resusAmiodaroneCount === 0 ? "300mg" : "150mg";
                          logEvent(`Amiodarone ${dose} IV/IO administered (Total: ${resusAmiodaroneCount + 1} dose(s))`);
                        }}
                        className={`px-2.5 py-1 rounded-lg text-[11px] font-bold transition-all flex items-center gap-1 bg-teal-600 hover:bg-teal-700 text-white`}
                      >
                        <PlusCircle className="w-3 h-3" /> + Amiodarone
                      </button>
                    )}
                    <button
                      onClick={() => {
                        logEvent(`⚡ Shock Delivered (${resusRhythm === "shockable" ? "200J Biphasic" : "Synchronized / Safety Override"})`);
                      }}
                      className={`px-2.5 py-1 rounded-lg text-[11px] font-bold transition-all flex items-center gap-1 bg-amber-600 hover:bg-amber-700 text-white`}
                    >
                      <Zap className="w-3 h-3" /> Log Shock
                    </button>
                  </div>
                </div>

              </div>

              {renderTimelineLogger()}

              {/* Step by Step Flow Actions depending on Selected Rhythm */}
              <div className={`p-4 rounded-xl border ${isDarkMode ? "bg-slate-900/30 border-slate-800" : "bg-slate-50 border-slate-150"} space-y-4`}>
                <h4 className="text-xs font-extrabold uppercase tracking-widest text-teal-500 flex items-center gap-1.5">
                  <Info className="w-3.5 h-3.5" /> High-Performance ALS Protocol Checklist
                </h4>

                <div className="space-y-2.5 text-xs">
                  {resusRhythm === "shockable" ? (
                    <>
                      <div className="flex gap-2">
                        <span className="font-bold text-red-500">1.</span>
                        <p><strong>SHOCK FIRST:</strong> Deliver 1 Shock immediately (200J biphasic or maximum output of the defibrillator).</p>
                      </div>
                      <div className="flex gap-2">
                        <span className="font-bold text-red-500">2.</span>
                        <p><strong>CPR 2 MINUTES:</strong> Resume chest compressions (100-120 bpm) and ventilations (15:2 for pediatric, 30:2 or continuous if advanced airway is in place) for 2 minutes.</p>
                      </div>
                      <div className="flex gap-2">
                        <span className="font-bold text-red-500">3.</span>
                        <p><strong>EVALUATE:</strong> After 2 minutes, reassess rhythm. If still shockable, deliver 2nd shock and immediately resume CPR.</p>
                      </div>
                      <div className="flex gap-2">
                        <span className="font-bold text-red-500">4.</span>
                        <p><strong>ADRENALINE:</strong> Give Adrenaline 1mg IV/IO <strong>after the 3rd shock</strong>, and repeat every 3-5 minutes (every alternate cycle).</p>
                      </div>
                      <div className="flex gap-2">
                        <span className="font-bold text-red-500">5.</span>
                        <p><strong>AMIODARONE:</strong> Give Amiodarone 300mg IV/IO <strong>after the 3rd shock</strong>. Consider an additional 150mg IV/IO after the 5th shock.</p>
                      </div>
                    </>
                  ) : (
                    <>
                      <div className="flex gap-2">
                        <span className="font-bold text-amber-500">1.</span>
                        <p><strong>GIVE ADRENALINE IMMEDIATELY:</strong> Give Adrenaline 1mg IV/IO as soon as access is secured (Do NOT wait for CPR cycles).</p>
                      </div>
                      <div className="flex gap-2">
                        <span className="font-bold text-amber-500">2.</span>
                        <p><strong>CPR 2 MINUTES:</strong> High-performance continuous CPR. Focus on rate (100-120 bpm), depth (5-6cm), and full recoil with minimal interruptions.</p>
                      </div>
                      <div className="flex gap-2">
                        <span className="font-bold text-amber-500">3.</span>
                        <p><strong>ADRENALINE INTERVALS:</strong> Give Adrenaline 1mg IV/IO every 3-5 minutes (every alternate CPR cycle).</p>
                      </div>
                      <div className="flex gap-2">
                        <span className="font-bold text-amber-500">4.</span>
                        <p><strong>REASSESS:</strong> Reassess rhythm after 2 minutes. Look for signs of life (coughing, movement, capnographic spike) or organized electrical activity (check pulse).</p>
                      </div>
                    </>
                  )}
                  <div className="flex gap-2 pt-1 border-t border-slate-200 dark:border-slate-800/60">
                    <span className="font-bold text-teal-500">A.</span>
                    <p><strong>Airway & Breathing:</strong> High-flow oxygen. Waveform capnography is critical (sudden rise indicates ROSC, persistent &lt;10 mmHg suggests sub-optimal chest compressions).</p>
                  </div>
                </div>
              </div>

              {/* Reversible Causes Checklist (4 Hs & 4 Ts) */}
              <div>
                <h4 className={`text-xs font-bold uppercase tracking-wider mb-2.5 ${isDarkMode ? "text-slate-300" : "text-slate-800"}`}>
                  Address Reversible Causes (4 Hs & 4 Ts)
                </h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  
                  {/* 4 Hs */}
                  <div className={`p-3 rounded-xl border ${isDarkMode ? "bg-slate-900/40 border-slate-800" : "bg-slate-50 border-slate-200"} space-y-2`}>
                    <span className="text-[10px] font-extrabold uppercase tracking-widest text-teal-500 block">4 Hs</span>
                    <div className="space-y-1.5">
                      {[
                        { id: "h_hypoxia", label: "Hypoxia", detail: "Optimise airway, 100% O2, verify tube placement" },
                        { id: "h_hypovolemia", label: "Hypovolemia", detail: "IV/IO fluid boluses, stop visible hemorrhage" },
                        { id: "h_hydrogen", label: "Hydrogen Ion (Acidosis)", detail: "Hyperventilate, consider Sodium Bicarbonate" },
                        { id: "h_hyper_hypo", label: "Hyper/Hypokalemia", detail: "Check electrolytes, treat Hyperkalemia (see tab)" }
                      ].map((item) => (
                        <label 
                          key={item.id} 
                          className="flex items-start gap-2 p-1.5 rounded hover:bg-slate-200/50 dark:hover:bg-slate-800/40 cursor-pointer transition-colors"
                        >
                          <input
                            type="checkbox"
                            checked={reversibleChecked[item.id] || false}
                            onChange={() => {
                              handleToggleReversible(item.id);
                              logEvent(`${reversibleChecked[item.id] ? "Deselected" : "Checked & Addressed"} Reversible Cause: ${item.label}`);
                            }}
                            className="mt-0.5 rounded border-slate-300 dark:border-slate-700 text-teal-600 focus:ring-teal-500"
                          />
                          <div>
                            <span className="text-xs font-bold block">{item.label}</span>
                            <span className="text-[10px] text-slate-500 block">{item.detail}</span>
                          </div>
                        </label>
                      ))}
                    </div>
                  </div>

                  {/* 4 Ts */}
                  <div className={`p-3 rounded-xl border ${isDarkMode ? "bg-slate-900/40 border-slate-800" : "bg-slate-50 border-slate-200"} space-y-2`}>
                    <span className="text-[10px] font-extrabold uppercase tracking-widest text-teal-500 block">4 Ts</span>
                    <div className="space-y-1.5">
                      {[
                        { id: "t_tension", label: "Tension Pneumothorax", detail: "Needle decompression / Finger thoracostomy" },
                        { id: "t_tamponade", label: "Tamponade (Cardiac)", detail: "Bedside ultrasound, emergency pericardiocentesis" },
                        { id: "t_toxins", label: "Toxins / Poisoning", detail: "Search for toxidrome, administer specific antidote" },
                        { id: "t_thrombosis", label: "Thrombosis (Pulmonary/Coronary)", detail: "Consider thrombolysis for suspected massive PE" }
                      ].map((item) => (
                        <label 
                          key={item.id} 
                          className="flex items-start gap-2 p-1.5 rounded hover:bg-slate-200/50 dark:hover:bg-slate-800/40 cursor-pointer transition-colors"
                        >
                          <input
                            type="checkbox"
                            checked={reversibleChecked[item.id] || false}
                            onChange={() => {
                              handleToggleReversible(item.id);
                              logEvent(`${reversibleChecked[item.id] ? "Deselected" : "Checked & Addressed"} Reversible Cause: ${item.label}`);
                            }}
                            className="mt-0.5 rounded border-slate-300 dark:border-slate-700 text-teal-600 focus:ring-teal-500"
                          />
                          <div>
                            <span className="text-xs font-bold block">{item.label}</span>
                            <span className="text-[10px] text-slate-500 block">{item.detail}</span>
                          </div>
                        </label>
                      ))}
                    </div>
                  </div>

                </div>
              </div>

            </div>

              <EcgGallery isDarkMode={isDarkMode} />
            </>
          )}
          
          {/* ALGORITHM 2: ANAPHYLAXIS */}
          {resusActiveAlg === "anaphylaxis" && (
            <div className={`p-5 rounded-2xl border ${isDarkMode ? "bg-slate-950/40 border-slate-800/80" : "bg-white border-slate-200 shadow-sm"} space-y-5`}>
              <div>
                <h3 className={`font-bold text-lg ${isDarkMode ? "text-slate-100" : "text-slate-900"}`}>Anaphylaxis Emergency Protocol</h3>
                <p className="text-xs text-slate-500 mt-0.5 font-mono">Immediate Interventions for Severe Life-Threatening Allergic Reactions</p>
              </div>

              {/* Quick Checklist */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className={`p-3.5 rounded-xl border border-red-500/20 bg-red-500/5 text-xs space-y-2`}>
                  <strong className="text-rose-500 flex items-center gap-1"><ShieldAlert className="w-3.5 h-3.5" /> CRITICAL ACTIONS:</strong>
                  <ul className="list-disc pl-4 space-y-1 text-slate-700 dark:text-slate-300">
                    <li><strong>Remove trigger</strong> (stop IV infusions immediately!)</li>
                    <li><strong>ABCDE Assessment:</strong> Call Resus / Arrest team if airway or airway swelling is suspected.</li>
                    <li><strong>Position patient flat:</strong> Raise legs (helps circulation). Do NOT stand or walk.</li>
                    <li><strong>Oxygen:</strong> High-flow 100% via non-rebreather mask.</li>
                  </ul>
                </div>

                <div className={`p-3.5 rounded-xl border ${isDarkMode ? "bg-slate-900 border-slate-800" : "bg-slate-50 border-slate-200"} text-xs space-y-2`}>
                  <strong className="text-teal-500 flex items-center gap-1"><CheckCircle2 className="w-3.5 h-3.5" /> Adrenaline IM route:</strong>
                  <p className="text-slate-600 dark:text-slate-400">
                    Give <strong>Intramuscular (IM)</strong> Adrenaline in the mid-outer aspect of the thigh (anterolateral aspect). 
                    The IV route must only be used by experienced specialists in an ICU/Resus environment.
                  </p>
                </div>
              </div>

              {/* IM Adrenaline Dose Calculator Box */}
              <div className={`p-4 rounded-xl border ${isDarkMode ? "bg-slate-900 border-slate-800" : "bg-slate-50 border-slate-150"} space-y-4`}>
                <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-teal-500 flex items-center gap-1.5">
                    <Baby className="w-4 h-4" /> Dose calculation by patient group (1:1000 Adrenaline)
                  </h4>
                  <div className="flex bg-slate-100 dark:bg-slate-900 p-1 rounded-lg border border-slate-200 dark:border-slate-800">
                    {[
                      { id: "adult", label: "Adult (>12y)" },
                      { id: "child_older", label: "Child (6-12y)" },
                      { id: "child_younger", label: "Child (6m-6y)" },
                      { id: "infant", label: "Infant (<6m)" }
                    ].map((btn) => (
                      <button
                        key={btn.id}
                        onClick={() => setAnaphylaxisType(btn.id as any)}
                        className={`px-2 py-1 rounded text-[10px] font-bold transition-all ${
                          anaphylaxisType === btn.id
                            ? "bg-rose-500 text-white shadow-sm"
                            : "text-slate-500 hover:text-slate-800 dark:hover:text-slate-200"
                        }`}
                      >
                        {btn.label}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Selected Dose Display */}
                <div className={`p-3.5 rounded-xl border ${isDarkMode ? "bg-slate-950/40 border-slate-800" : "bg-white border-slate-200"} flex justify-between items-center`}>
                  <div>
                    <span className="text-[10px] font-semibold text-slate-500 dark:text-slate-400 block uppercase">ADRENALINE IM DOSE (1:1000, 1mg/mL):</span>
                    <strong className="text-xl text-rose-500 dark:text-rose-400 mt-1 block">
                      {anaphylaxisType === "adult" && "0.5 mg IM (0.5 mL of 1:1000)"}
                      {anaphylaxisType === "child_older" && "0.3 mg IM (0.3 mL of 1:1000)"}
                      {anaphylaxisType === "child_younger" && "0.15 mg IM (0.15 mL of 1:1000)"}
                      {anaphylaxisType === "infant" && "0.05 - 0.1 mg IM (0.05 - 0.1 mL of 1:1000)"}
                    </strong>
                    <span className="text-[11px] text-slate-500 mt-1 block">
                      {anaphylaxisType === "adult" && "Repeat in 5 minutes if no clinical improvement."}
                      {anaphylaxisType === "child_older" && "For pediatric patients of typical age weight range."}
                      {anaphylaxisType === "child_younger" && "Half dose of older child. Clean anterolateral thigh IM."}
                      {anaphylaxisType === "infant" && "Syringe-drawn micro-dose. Extremely careful measurement."}
                    </span>
                  </div>
                  <button
                    onClick={() => {
                      let label = "";
                      if (anaphylaxisType === "adult") label = "Adrenaline 0.5mg IM";
                      if (anaphylaxisType === "child_older") label = "Adrenaline 0.3mg IM (Pediatric)";
                      if (anaphylaxisType === "child_younger") label = "Adrenaline 0.15mg IM (Pediatric)";
                      if (anaphylaxisType === "infant") label = "Adrenaline 0.05-0.1mg IM (Infant)";
                      logEvent(`Administered ${label} for Anaphylaxis`);
                    }}
                    className="px-3.5 py-2 rounded-xl bg-rose-500 hover:bg-rose-600 text-white font-bold text-xs flex items-center gap-1.5"
                  >
                    <Syringe className="w-4 h-4" /> Log Dose
                  </button>
                </div>
              </div>

              {/* Fluid Resuscitation & Adjuncts */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                
                {/* Fluid resuscitation */}
                <div className={`p-4 rounded-xl border ${isDarkMode ? "bg-slate-900/60 border-slate-800" : "bg-slate-50 border-slate-200"} space-y-2`}>
                  <strong className="text-xs font-bold text-teal-500 block">IV Fluids (Crystalloid Bolus):</strong>
                  <p className="text-xs leading-relaxed text-slate-700 dark:text-slate-300">
                    Immediately establish large bore IV access. Give crystalloid fluid bolus:
                  </p>
                  <ul className="list-disc pl-4 text-xs space-y-1 text-slate-600 dark:text-slate-400">
                    <li><strong>Adult:</strong> 500 - 1000 mL Rapid Bolus</li>
                    <li><strong>Pediatric:</strong> 20 mL/kg Bolus</li>
                  </ul>
                  <button
                    onClick={() => logEvent("Administered IV Fluid Bolus for resuscitation")}
                    className="mt-2 text-[10px] font-bold text-teal-500 hover:underline flex items-center gap-1"
                  >
                    + Log Fluid Bolus
                  </button>
                </div>

                {/* Pharmacological Adjuncts */}
                <div className={`p-4 rounded-xl border ${isDarkMode ? "bg-slate-900/60 border-slate-800" : "bg-slate-50 border-slate-200"} space-y-2`}>
                  <strong className="text-xs font-bold text-teal-500 block">Pharmacological Adjuncts (Post-Adrenaline):</strong>
                  <ul className="text-xs space-y-1.5 text-slate-700 dark:text-slate-300">
                    <li>
                      <strong>IV Hydrocortisone:</strong> Adult 100 - 200 mg slowly (or Pediatric weight-adjusted).
                    </li>
                    <li>
                      <strong>IV Chlorpheniramine:</strong> Adult 10 mg slowly (anti-histamine aid).
                    </li>
                    <li>
                      <strong>Nebulized Salbutamol:</strong> 5mg (if persistent wheeze/bronchospasm).
                    </li>
                  </ul>
                  <div className="flex gap-2 mt-2">
                    <button
                      onClick={() => logEvent("Administered Adjunctive IV Hydrocortisone & Antihistamine")}
                      className="text-[10px] font-bold text-teal-500 hover:underline"
                    >
                      + Log IV Hydrocortisone
                    </button>
                  </div>
                </div>

              </div>

            </div>
          )}

          {/* ALGORITHM 3: SEVERE ASTHMA */}
          {resusActiveAlg === "asthma" && (
            <div className={`p-5 rounded-2xl border ${isDarkMode ? "bg-slate-950/40 border-slate-800/80" : "bg-white border-slate-200 shadow-sm"} space-y-5`}>
              <div>
                <h3 className={`font-bold text-lg ${isDarkMode ? "text-slate-100" : "text-slate-900"}`}>Acute Severe Asthma Management</h3>
                <p className="text-xs text-slate-500 mt-0.5 font-mono">Stratification and Emergency Treatment Escalation Protocol</p>
              </div>

              {/* Severity assessment toggles */}
              <div>
                <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500 block mb-2">Assess Severity Group:</span>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-2">
                  {[
                    { id: "moderate", label: "Moderate Exacerbation", border: "border-teal-500/20", text: "text-teal-500 bg-teal-500/5" },
                    { id: "severe", label: "Acute Severe Asthma", border: "border-amber-500/20", text: "text-amber-500 bg-amber-500/5" },
                    { id: "life_threatening", label: "Life-Threatening / Silent Chest", border: "border-rose-500/20", text: "text-rose-500 bg-rose-500/5" }
                  ].map((group) => (
                    <button
                      key={group.id}
                      onClick={() => {
                        setAsthmaSeverity(group.id as any);
                        logEvent(`Asthma severity group selected: ${group.label.toUpperCase()}`);
                      }}
                      className={`p-3 rounded-xl border text-xs font-bold text-left transition-all ${
                        asthmaSeverity === group.id
                          ? group.text + " ring-1 ring-current"
                          : isDarkMode
                            ? "bg-slate-900 border-slate-800 text-slate-400"
                            : "bg-white border-slate-200 text-slate-600 shadow-sm hover:bg-slate-50"
                      }`}
                    >
                      <div className="flex justify-between items-center">
                        <span>{group.label}</span>
                        {asthmaSeverity === group.id && <Check className="w-3.5 h-3.5" />}
                      </div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Dynamic Assessment and Guidelines Display */}
              <div className={`p-4 rounded-xl border ${isDarkMode ? "bg-slate-900 border-slate-800" : "bg-slate-50 border-slate-150"} space-y-4`}>
                
                {/* Visual Indicators/signs */}
                <div>
                  <span className="text-[10px] font-extrabold uppercase tracking-widest text-slate-500 dark:text-slate-400">Clinical Markers & Signs:</span>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-1.5 text-xs">
                    {asthmaSeverity === "moderate" && (
                      <>
                        <div className="p-2 rounded-lg border dark:border-slate-800 bg-slate-950/20">PEF: <strong>50 - 75% best</strong></div>
                        <div className="p-2 rounded-lg border dark:border-slate-800 bg-slate-950/20">Speech: <strong>Full sentences</strong></div>
                        <div className="p-2 rounded-lg border dark:border-slate-800 bg-slate-950/20">Resp Rate: <strong>&lt; 25 /min</strong></div>
                        <div className="p-2 rounded-lg border dark:border-slate-800 bg-slate-950/20">Heart Rate: <strong>&lt; 110 /min</strong></div>
                      </>
                    )}
                    {asthmaSeverity === "severe" && (
                      <>
                        <div className="p-2 rounded-lg border border-amber-500/10 bg-amber-500/5 text-amber-500">PEF: <strong>33 - 50% best</strong></div>
                        <div className="p-2 rounded-lg border border-amber-500/10 bg-amber-500/5 text-amber-500">Speech: <strong>Incomplete phrases</strong></div>
                        <div className="p-2 rounded-lg border border-amber-500/10 bg-amber-500/5 text-amber-500">Resp Rate: <strong>&ge; 25 /min</strong></div>
                        <div className="p-2 rounded-lg border border-amber-500/10 bg-amber-500/5 text-amber-500">Heart Rate: <strong>&ge; 110 /min</strong></div>
                      </>
                    )}
                    {asthmaSeverity === "life_threatening" && (
                      <>
                        <div className="p-2 rounded-lg border border-rose-500/10 bg-rose-500/5 text-rose-500">PEF: <strong>&lt; 33% (or unable)</strong></div>
                        <div className="p-2 rounded-lg border border-rose-500/10 bg-rose-500/5 text-rose-500">Chest: <strong>Silent / Wheeze absent</strong></div>
                        <div className="p-2 rounded-lg border border-rose-500/10 bg-rose-500/5 text-rose-500">SpO2: <strong>&lt; 92% / Cyanosis</strong></div>
                        <div className="p-2 rounded-lg border border-rose-500/10 bg-rose-500/5 text-rose-500">Sensorium: <strong>Exhausted / Confused</strong></div>
                      </>
                    )}
                  </div>
                </div>

                {/* Treatment details */}
                <div className={`p-4 rounded-xl border ${isDarkMode ? "bg-slate-950/40 border-slate-800" : "bg-white border-slate-200"} space-y-3`}>
                  <span className="text-[10px] font-bold uppercase tracking-wider text-rose-500 flex items-center gap-1">
                    <Activity className="w-3 h-3" /> Mandatory Treatment Directives
                  </span>
                  
                  <div className="text-xs space-y-2 text-slate-700 dark:text-slate-300">
                    {asthmaSeverity === "moderate" && (
                      <>
                        <p>🔹 <strong>SABA Nebulisers:</strong> Salbutamol 5mg via oxygen-driven nebuliser. Repeat every 20-30 mins if needed.</p>
                        <p>🔹 <strong>Steroids:</strong> Give oral Prednisolone 40-50mg immediately, continue for at least 5 days.</p>
                        <p>🔹 <strong>Oxygen:</strong> Titrate to maintain SpO2 target of 94 - 98%.</p>
                      </>
                    )}
                    {asthmaSeverity === "severe" && (
                      <>
                        <p>🔥 <strong>Oxygen:</strong> High-flow oxygen-driven nebuliser immediately. Target SpO2: <strong>94 - 98%</strong>.</p>
                        <p>🔥 <strong>Nebulisers (Immediate):</strong> Salbutamol 5mg PLUS Ipratropium Bromide 0.5mg nebulised together. Repeat every 20 minutes up to 3 times in the first hour.</p>
                        <p>🔥 <strong>Systemic Corticosteroids:</strong> IV Hydrocortisone 100mg slowly OR oral Prednisolone 40-50mg immediately.</p>
                        <p>🔥 <strong>Vascular Access:</strong> Secure IV cannula, consider hydration support if tachycardic/tachypneic.</p>
                      </>
                    )}
                    {asthmaSeverity === "life_threatening" && (
                      <>
                        <p>🚨 <strong>IMMEDIATE ICU CONSULT:</strong> Call ICU registrar / Senior Anaesthetist immediately for airway planning.</p>
                        <p>🚨 <strong>Nebulisers:</strong> Continuous nebulised Salbutamol 5mg PLUS Ipratropium 0.5mg.</p>
                        <p>🚨 <strong>Magnesium Sulfate:</strong> Administer <strong>IV Magnesium Sulfate 2.0g slowly over 20 minutes</strong> (requires cardiac monitoring).</p>
                        <p>🚨 <strong>IV Hydrocortisone:</strong> 100mg - 200mg IV immediately.</p>
                        <p>🚨 <strong>Prepare for intubation:</strong> Ketamine induction preferred for bronchodilatory properties. Avoid high peep/barotrauma.</p>
                      </>
                    )}
                  </div>

                  <div className="flex flex-wrap gap-2 pt-2 border-t dark:border-slate-800/60">
                    <button
                      onClick={() => logEvent("Administered Salbutamol + Ipratropium Nebulizer")}
                      className="px-2.5 py-1.5 rounded-lg bg-teal-600 hover:bg-teal-700 text-white font-bold text-[10px] flex items-center gap-1"
                    >
                      + Log Nebulizer
                    </button>
                    {asthmaSeverity === "life_threatening" && (
                      <button
                        onClick={() => logEvent("Administered IV Magnesium Sulfate 2g slow infusion")}
                        className="px-2.5 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-700 text-white font-bold text-[10px] flex items-center gap-1"
                      >
                        + Log IV Magnesium
                      </button>
                    )}
                    <button
                      onClick={() => logEvent("Administered IV Hydrocortisone 100mg for severe asthma")}
                      className="px-2.5 py-1.5 rounded-lg bg-amber-600 hover:bg-amber-700 text-white font-bold text-[10px] flex items-center gap-1"
                    >
                      + Log IV Steroids
                    </button>
                  </div>
                </div>

              </div>
            </div>
          )}

          {/* ALGORITHM 4: STATUS EPILEPTICUS */}
          {resusActiveAlg === "seizures" && (
            <div className={`p-5 rounded-2xl border ${isDarkMode ? "bg-slate-950/40 border-slate-800/80" : "bg-white border-slate-200 shadow-sm"} space-y-5`}>
              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 pb-2 border-b border-slate-100 dark:border-slate-800/60">
                <div>
                  <h3 className={`font-bold text-lg ${isDarkMode ? "text-slate-100" : "text-slate-900"}`}>Emergency Seizure & Epilepsy Guide</h3>
                  <p className="text-xs text-slate-500 mt-0.5 font-mono">Consensus guidelines for acute status epilepticus & maintenance management</p>
                </div>
                
                {/* Sub-view switcher */}
                <div className="flex bg-slate-100 dark:bg-slate-900 p-1 rounded-xl border border-slate-200 dark:border-slate-800 self-start sm:self-auto">
                  <button
                    onClick={() => setSeizureSubView("emergency")}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                      seizureSubView === "emergency"
                        ? "bg-rose-500 text-white shadow-xs"
                        : "text-slate-500 hover:text-slate-800 dark:hover:text-slate-200"
                    }`}
                  >
                    ⚡ Active Seizure / Status
                  </button>
                  <button
                    onClick={() => setSeizureSubView("maintenance")}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                      seizureSubView === "maintenance"
                        ? "bg-teal-600 text-white shadow-xs"
                        : "text-slate-500 hover:text-slate-800 dark:hover:text-slate-200"
                    }`}
                  >
                    📘 Maintenance Guide (MSN 2024)
                  </button>
                </div>
              </div>

              {seizureSubView === "emergency" ? (
                <div className="space-y-4">
                  {/* Timeline selector */}
                  <div className="flex flex-wrap bg-slate-100 dark:bg-slate-900 p-1 rounded-xl border border-slate-200 dark:border-slate-800">
                    {[
                      { id: "initial", label: "T = 0 to 5 min (Initial)" },
                      { id: "first_line", label: "T = 5 to 20 min (1st Line)" },
                      { id: "second_line", label: "T = 20 to 40 min (2nd Line)" },
                      { id: "refractory", label: "T > 40 min (Refractory)" }
                    ].map((phase) => (
                      <button
                        key={phase.id}
                        onClick={() => setSeizurePhase(phase.id as any)}
                        className={`flex-1 min-w-[120px] px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                          seizurePhase === phase.id
                            ? "bg-rose-500 text-white shadow-sm"
                            : "text-slate-500 hover:text-slate-800 dark:hover:text-slate-200"
                        }`}
                      >
                        {phase.label}
                      </button>
                    ))}
                  </div>

                  {/* Seizure Phase Content */}
                  <div className={`p-4 rounded-xl border ${isDarkMode ? "bg-slate-900 border-slate-800" : "bg-slate-50 border-slate-150"} space-y-4`}>
                    
                    {seizurePhase === "initial" && (
                      <div className="space-y-3 text-xs leading-relaxed">
                        <span className="text-[10px] font-bold text-teal-500 uppercase tracking-widest block">Stage 1: Bedside Assessment & Safety (0 - 5 Minutes)</span>
                        <p>🔹 <strong>Protect patient:</strong> Clear the surrounding area of dangerous objects. Support/cushion head. Do NOT insert anything in the mouth.</p>
                        <p>🔹 <strong>ABCDE Assessment:</strong> Apply high-flow oxygen via face mask. Monitor SpO2 and ECG.</p>
                        <p>🔹 <strong>Check blood glucose:</strong> Immediately rule out/treat hypoglycemia (Give 50mL Dextrose 50% IV if glucose &lt; 4.0 mmol/L).</p>
                        <p>🔹 <strong>IV access:</strong> Secure large-bore IV cannula (ideally 2 sites) and draw bloods (FBC, U&E, Calcium, anticonvulsant drug levels).</p>
                      </div>
                    )}

                    {seizurePhase === "first_line" && (
                      <div className="space-y-4">
                        <div className="text-xs leading-relaxed space-y-3">
                          <span className="text-[10px] font-bold text-rose-500 uppercase tracking-widest block">Stage 2: First-Line Benzodiazepines (5 - 20 Minutes)</span>
                          <p className="font-bold text-rose-500 dark:text-rose-400">If seizure continues beyond 5 minutes, administer emergency anticonvulsant therapy immediately:</p>
                          
                          <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs font-mono">
                            <div className="p-2.5 rounded-lg border dark:border-slate-850 bg-slate-950/20">
                              <strong className="text-rose-500 block">IV Route (Preferred):</strong>
                              IV Lorazepam 4mg slow push (rate of 2mg/min). Repeat once in 10 mins if needed.
                            </div>
                            <div className="p-2.5 rounded-lg border dark:border-slate-850 bg-slate-950/20">
                              <strong className="text-rose-500 block">IV Alternative:</strong>
                              IV Diazepam 10mg over 2-3 minutes (or rectal gel 10-20mg).
                            </div>
                            <div className="p-2.5 rounded-lg border dark:border-slate-850 bg-slate-950/20">
                              <strong className="text-rose-500 block">IM Route (No IV access):</strong>
                              IM Midazolam 10mg (or 0.2mg/kg) in the mid-thigh immediately.
                            </div>
                          </div>
                        </div>

                        <div className="flex gap-2 pt-2 border-t dark:border-slate-800/60">
                          <button
                            onClick={() => logEvent("Administered IV Diazepam 10mg slow push")}
                            className="px-2.5 py-1.5 rounded-lg bg-rose-500 hover:bg-rose-600 text-white font-bold text-[10px] cursor-pointer"
                          >
                            Log IV Diazepam Given
                          </button>
                          <button
                            onClick={() => logEvent("Administered IM Midazolam 10mg in outer thigh")}
                            className="px-2.5 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-600 text-white font-bold text-[10px] cursor-pointer"
                          >
                            Log IM Midazolam Given
                          </button>
                        </div>
                      </div>
                    )}

                    {seizurePhase === "second_line" && (
                      <div className="space-y-4">
                        <div className="text-xs leading-relaxed space-y-3">
                          <span className="text-[10px] font-bold text-amber-500 uppercase tracking-widest block">Stage 3: Second-Line Infusions (20 - 40 Minutes)</span>
                          <p>If seizure persists after 1 or 2 doses of benzodiazepines, immediately prepare and start a second-line anticonvulsant infusion:</p>
                          
                          <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs font-mono">
                            <div className="p-3 rounded-lg border dark:border-slate-850 bg-slate-950/20 space-y-1.5">
                              <strong className="text-teal-400 block">IV Levetiracetam (Keppra):</strong>
                              <span>Dose: <strong>60 mg/kg IV</strong> (maximum 4500mg) infused over 10-15 minutes. High safety profile, minimal respiratory depression.</span>
                            </div>
                            <div className="p-3 rounded-lg border dark:border-slate-850 bg-slate-950/20 space-y-1.5">
                              <strong className="text-teal-400 block">IV Sodium Valproate (Epilim):</strong>
                              <span>Dose: <strong>20 - 30 mg/kg IV</strong> loading (maximum 2500mg) over 5-10 minutes. Preferred in Malaysian MOH protocols due to low cardiorespiratory sedation.</span>
                            </div>
                            <div className="p-3 rounded-lg border dark:border-slate-850 bg-slate-950/20 space-y-1.5">
                              <strong className="text-teal-400 block">IV Phenytoin (Dilantin):</strong>
                              <span>Dose: <strong>20 mg/kg IV</strong> (maximum 1500mg) infused at maximum rate of 50mg/min. Requires ECG and blood pressure monitoring. Do NOT dilute in Dextrose (precipitates!).</span>
                            </div>
                          </div>
                        </div>

                        <div className="flex flex-wrap gap-2 pt-2 border-t dark:border-slate-800/60">
                          <button
                            onClick={() => logEvent("Started Levetiracetam (Keppra) 60mg/kg IV infusion")}
                            className="px-2.5 py-1.5 rounded-lg bg-teal-600 hover:bg-teal-700 text-white font-bold text-[10px] cursor-pointer"
                          >
                            Log Keppra Infusion Started
                          </button>
                          <button
                            onClick={() => logEvent("Started Sodium Valproate (Epilim) 25mg/kg IV loading infusion")}
                            className="px-2.5 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-[10px] cursor-pointer"
                          >
                            Log Epilim Infusion Started
                          </button>
                          <button
                            onClick={() => logEvent("Started Phenytoin 20mg/kg IV loading infusion")}
                            className="px-2.5 py-1.5 rounded-lg bg-amber-600 hover:bg-amber-700 text-white font-bold text-[10px] cursor-pointer"
                          >
                            Log Phenytoin Infusion Started
                          </button>
                        </div>
                      </div>
                    )}

                    {seizurePhase === "refractory" && (
                      <div className="space-y-3 text-xs leading-relaxed">
                        <span className="text-[10px] font-bold text-rose-500 uppercase tracking-widest block">Stage 4: Refractory Status Epilepticus (&gt; 40 Minutes)</span>
                        <p className="font-semibold text-rose-500">Seizure ongoing despite first and second-line therapies. High risk of systemic hypoxia, rhabdomyolysis, and brain injury.</p>
                        <p>🔹 <strong>General Anaesthesia:</strong> Secure airway via endotracheal intubation and mechanical ventilation.</p>
                        <p>🔹 <strong>Continuous IV Infusions (Titrated under EEG monitoring):</strong></p>
                        <ul className="list-disc pl-4 space-y-1 font-mono text-[11px]">
                          <li><strong>IV Propofol:</strong> Loading dose 1-2 mg/kg, then maintenance 2-10 mg/kg/hr.</li>
                          <li><strong>IV Midazolam:</strong> Loading dose 0.2 mg/kg, then maintenance 0.05-2.0 mg/kg/hr.</li>
                        </ul>
                        <button
                          onClick={() => logEvent("Escalated to Refractory status: Anaesthetist / ICU consulted for Propofol infusion")}
                          className="mt-2 text-rose-500 font-bold hover:underline cursor-pointer"
                        >
                          + Log Refractory / ICU Escalation
                        </button>
                      </div>
                    )}

                  </div>
                </div>
              ) : (
                /* MAINTENANCE EPILEPSY GUIDE (MSN Consensus Guidelines 2024) */
                <div className="space-y-5 animate-fade-in text-xs">
                  {/* Selectors Row */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {/* Seizure Classification Selector */}
                    <div className="space-y-2">
                      <label className={`text-[11px] font-extrabold uppercase tracking-wider block ${isDarkMode ? "text-slate-300" : "text-slate-700"}`}>
                        1. Seizure Classification & Type
                      </label>
                      <div className="grid grid-cols-2 gap-2">
                        {[
                          { id: "focal", label: "Focal Seizures", desc: "± 2° generalization" },
                          { id: "generalized", label: "Gen. Tonic-Clonic", desc: "Primary generalized" },
                          { id: "absence", label: "Absence Seizures", desc: "Avoid sodium-channel blockers!" },
                          { id: "myoclonic", label: "Myoclonic Seizures", desc: "Avoid sodium-channel blockers!" }
                        ].map((t) => (
                          <button
                            key={t.id}
                            onClick={() => setEpilepsySeizureType(t.id as any)}
                            className={`p-2.5 rounded-xl border text-left transition-all cursor-pointer ${
                              epilepsySeizureType === t.id
                                ? "bg-rose-500 text-white border-rose-500 shadow-sm ring-1 ring-rose-500/20 font-bold"
                                : isDarkMode
                                  ? "bg-slate-900 border-slate-800 text-slate-300 hover:bg-slate-850"
                                  : "bg-white border-slate-200 text-slate-700 hover:bg-slate-50 shadow-xs"
                            }`}
                          >
                            <div className="font-bold text-xs">{t.label}</div>
                            <div className={`text-[10px] mt-0.5 ${epilepsySeizureType === t.id ? "text-rose-100" : "text-slate-400"}`}>
                              {t.desc}
                            </div>
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* Patient Subgroup Selector */}
                    <div className="space-y-2">
                      <label className={`text-[11px] font-extrabold uppercase tracking-wider block ${isDarkMode ? "text-slate-300" : "text-slate-700"}`}>
                        2. Patient Subgroup / Considerations
                      </label>
                      <div className="grid grid-cols-3 gap-2">
                        {[
                          { id: "general", label: "General", desc: "Adult population" },
                          { id: "pregnancy", label: "Pregnancy / WOCBP", desc: "Childbearing potential" },
                          { id: "elderly", label: "Elderly", desc: "Age > 65 / interactions" }
                        ].map((g) => (
                          <button
                            key={g.id}
                            onClick={() => setEpilepsyPatientGroup(g.id as any)}
                            className={`p-2.5 rounded-xl border text-left transition-all flex flex-col justify-between cursor-pointer ${
                              epilepsyPatientGroup === g.id
                                ? "bg-teal-600 text-white border-teal-600 shadow-sm ring-1 ring-teal-500/20 font-bold"
                                : isDarkMode
                                  ? "bg-slate-900 border-slate-800 text-slate-300 hover:bg-slate-850"
                                  : "bg-white border-slate-200 text-slate-700 hover:bg-slate-50 shadow-xs"
                            }`}
                          >
                            <div className="font-bold text-xs">{g.label}</div>
                            <div className={`text-[9px] mt-1 leading-normal ${epilepsyPatientGroup === g.id ? "text-teal-50" : "text-slate-400"}`}>
                              {g.desc}
                            </div>
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* Recommendation Outputs */}
                  <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
                    {/* Drug Recommendations Box (8 cols) */}
                    <div className={`lg:col-span-8 p-4 rounded-xl border ${isDarkMode ? "bg-slate-900 border-slate-800" : "bg-slate-50 border-slate-200 shadow-xs"} space-y-4`}>
                      <div>
                        <h4 className={`text-xs font-bold uppercase tracking-wider ${isDarkMode ? "text-rose-400" : "text-rose-600"}`}>
                          Recommended Anti-Seizure Medications (ASMs)
                        </h4>
                        <p className="text-[10px] text-slate-400 dark:text-slate-500 mt-0.5">
                          Initiate as monotherapy at lowest effective dose. Titrate slowly to avoid severe cutaneous reactions.
                        </p>
                      </div>

                      {/* First-Line Medicines */}
                      <div className="space-y-3">
                        <span className={`text-[10px] font-extrabold uppercase tracking-widest ${isDarkMode ? "text-slate-300" : "text-slate-500"} block`}>
                          ⭐ First-Line Therapy Choices (consensus 2024)
                        </span>
                        
                        <div className="space-y-2.5">
                          {/* Dynamically filter medicines based on seizure type & patient group */}
                          {epilepsySeizureType === "focal" && (
                            <>
                              <div className={`p-3 rounded-lg border text-xs ${isDarkMode ? "bg-slate-950/40 border-slate-800" : "bg-white border-slate-200"}`}>
                                <div className="flex justify-between items-center font-bold">
                                  <span className={isDarkMode ? "text-teal-400" : "text-teal-600"}>Levetiracetam (Keppra)</span>
                                  <span className="text-[10px] bg-teal-500/10 text-teal-500 px-1.5 py-0.5 rounded font-bold">First Choice</span>
                                </div>
                                <p className="mt-1.5 text-slate-600 dark:text-slate-400 leading-normal">
                                  <strong>Starting Dose:</strong> Start 250mg BD, increase to 500mg BD after 1-2 weeks. Maintenance: 1000mg - 3000mg daily in 2 divided doses.
                                </p>
                                <p className="mt-1 text-[10px] text-slate-500 font-mono">
                                  💡 <em>No hepatic drug-drug interactions. Ideal in elderly. May cause irritability or mood changes in some patients.</em>
                                </p>
                              </div>

                              {epilepsyPatientGroup !== "pregnancy" && (
                                <div className={`p-3 rounded-lg border text-xs ${isDarkMode ? "bg-slate-950/40 border-slate-800" : "bg-white border-slate-200"}`}>
                                  <div className="flex justify-between items-center font-bold">
                                    <span className={isDarkMode ? "text-teal-400" : "text-teal-600"}>Carbamazepine (Tegretol)</span>
                                    {epilepsyPatientGroup === "elderly" && <span className="text-[10px] text-amber-500 bg-amber-500/10 px-1.5 py-0.5 rounded font-bold">Caution in Elderly</span>}
                                  </div>
                                  <p className="mt-1.5 text-slate-600 dark:text-slate-400 leading-normal">
                                    <strong>Starting Dose:</strong> Start 100mg - 200mg BD. Maintenance: 400mg - 1200mg daily in 2-3 divided doses.
                                  </p>
                                  <p className="mt-1 text-[10px] text-rose-500 font-bold font-mono">
                                    ⚠️ <em>MANDATORY HLA-B*1502 screening in Malaysia. Strong CYP enzyme inducer. Monitor sodium level.</em>
                                  </p>
                                </div>
                              )}

                              <div className={`p-3 rounded-lg border text-xs ${isDarkMode ? "bg-slate-950/40 border-slate-800" : "bg-white border-slate-200"}`}>
                                <div className="flex justify-between items-center font-bold">
                                  <span className={isDarkMode ? "text-teal-400" : "text-teal-600"}>Lamotrigine (Lamictal)</span>
                                  <span className="text-[10px] bg-emerald-500/10 text-emerald-500 px-1.5 py-0.5 rounded font-bold">Safe in Pregnancy</span>
                                </div>
                                <p className="mt-1.5 text-slate-600 dark:text-slate-400 leading-normal">
                                  <strong>Starting Dose:</strong> Start 25mg OD for 2 weeks, then 50mg OD for 2 weeks, then 100mg - 400mg daily in 1-2 divided doses.
                                </p>
                                <p className="mt-1 text-[10px] text-slate-500 font-mono">
                                  💡 <em>Must titrate extremely slowly to avoid serious life-threatening skin rashes (SJS/TEN). Safe in pregnancy.</em>
                                </p>
                              </div>

                              {epilepsyPatientGroup === "general" && (
                                <div className={`p-3 rounded-lg border text-xs ${isDarkMode ? "bg-slate-950/40 border-slate-800" : "bg-white border-slate-200"}`}>
                                  <div className="flex justify-between items-center font-bold">
                                    <span className={isDarkMode ? "text-teal-400" : "text-teal-600"}>Sodium Valproate (Epilim)</span>
                                    <span className="text-[10px] bg-slate-500/10 text-slate-400 px-1.5 py-0.5 rounded">Broad-Spectrum</span>
                                  </div>
                                  <p className="mt-1.5 text-slate-600 dark:text-slate-400 leading-normal">
                                    <strong>Starting Dose:</strong> Start 200mg - 300mg BD. Maintenance: 600mg - 2000mg daily in 2 divided doses.
                                  </p>
                                  <p className="mt-1 text-[10px] text-slate-500 font-mono">
                                    💡 <em>Avoid in girls and women of childbearing potential. Broad-spectrum agent, highly effective.</em>
                                  </p>
                                </div>
                              )}

                              {epilepsyPatientGroup !== "pregnancy" && (
                                <div className={`p-3 rounded-lg border text-xs ${isDarkMode ? "bg-slate-950/40 border-slate-800" : "bg-white border-slate-200"}`}>
                                  <div className="flex justify-between items-center font-bold">
                                    <span className={isDarkMode ? "text-teal-400" : "text-teal-600"}>Oxcarbazepine (Trileptal)</span>
                                  </div>
                                  <p className="mt-1.5 text-slate-600 dark:text-slate-400 leading-normal">
                                    <strong>Starting Dose:</strong> Start 150mg BD, increase weekly. Maintenance: 600mg - 1200mg daily in 2 divided doses.
                                  </p>
                                  <p className="mt-1 text-[10px] text-slate-500 font-mono">
                                    💡 <em>Slightly lower rash risk than Carbamazepine, but significant risk of hyponatremia (check sodium regularly).</em>
                                  </p>
                                </div>
                              )}
                            </>
                          )}

                          {epilepsySeizureType === "generalized" && (
                            <>
                              {epilepsyPatientGroup === "general" && (
                                <div className={`p-3 rounded-lg border text-xs ${isDarkMode ? "bg-slate-950/40 border-slate-800" : "bg-white border-slate-200"}`}>
                                  <div className="flex justify-between items-center font-bold">
                                    <span className={isDarkMode ? "text-teal-400" : "text-teal-600"}>Sodium Valproate (Epilim)</span>
                                    <span className="text-[10px] bg-rose-500/10 text-rose-500 px-1.5 py-0.5 rounded font-bold">Most Effective</span>
                                  </div>
                                  <p className="mt-1.5 text-slate-600 dark:text-slate-400 leading-normal">
                                    <strong>Starting Dose:</strong> Start 200mg - 300mg BD. Maintenance: 600mg - 2000mg daily.
                                  </p>
                                  <p className="mt-1 text-[10px] text-slate-500 font-mono">
                                    💡 <em>Highly effective broad-spectrum drug. Avoid in girls and females of childbearing potential.</em>
                                  </p>
                                </div>
                              )}

                              <div className={`p-3 rounded-lg border text-xs ${isDarkMode ? "bg-slate-950/40 border-slate-800" : "bg-white border-slate-200"}`}>
                                <div className="flex justify-between items-center font-bold">
                                  <span className={isDarkMode ? "text-teal-400" : "text-teal-600"}>Levetiracetam (Keppra)</span>
                                  <span className="text-[10px] bg-teal-500/10 text-teal-500 px-1.5 py-0.5 rounded font-bold">Preferred</span>
                                </div>
                                <p className="mt-1.5 text-slate-600 dark:text-slate-400 leading-normal">
                                  <strong>Starting Dose:</strong> Start 250mg BD, titrate up to 500mg - 1500mg BD.
                                </p>
                                <p className="mt-1 text-[10px] text-slate-500 font-mono">
                                  💡 <em>Preferred alternative to Valproate. Extremely safe in pregnancy. No significant hepatic interactions.</em>
                                </p>
                              </div>

                              <div className={`p-3 rounded-lg border text-xs ${isDarkMode ? "bg-slate-950/40 border-slate-800" : "bg-white border-slate-200"}`}>
                                <div className="flex justify-between items-center font-bold">
                                  <span className={isDarkMode ? "text-teal-400" : "text-teal-600"}>Lamotrigine (Lamictal)</span>
                                </div>
                                <p className="mt-1.5 text-slate-600 dark:text-slate-400 leading-normal">
                                  <strong>Starting Dose:</strong> Start 25mg OD for 2 weeks, then 50mg OD for 2 weeks, then 100mg - 200mg BD.
                                </p>
                                <p className="mt-1 text-[10px] text-slate-500 font-mono">
                                  💡 <em>Broad-spectrum efficacy. Must titrate slowly. Safe profile in pregnancy.</em>
                                </p>
                              </div>

                              {epilepsyPatientGroup !== "pregnancy" && (
                                <div className={`p-3 rounded-lg border text-xs ${isDarkMode ? "bg-slate-950/40 border-slate-800" : "bg-white border-slate-200"}`}>
                                  <div className="flex justify-between items-center font-bold">
                                    <span className={isDarkMode ? "text-teal-400" : "text-teal-600"}>Topiramate (Topamax)</span>
                                  </div>
                                  <p className="mt-1.5 text-slate-600 dark:text-slate-400 leading-normal">
                                    <strong>Starting Dose:</strong> Start 25mg OD/BD. Maintenance: 100mg - 400mg daily.
                                  </p>
                                  <p className="mt-1 text-[10px] text-slate-500 font-mono">
                                    💡 <em>Can cause cognitive slowing and weight loss. Do not use in pregnancy (teratogenic risk).</em>
                                  </p>
                                </div>
                              )}
                            </>
                          )}

                          {epilepsySeizureType === "absence" && (
                            <>
                              {epilepsyPatientGroup === "general" && (
                                <div className={`p-3 rounded-lg border text-xs ${isDarkMode ? "bg-slate-950/40 border-slate-800" : "bg-white border-slate-200"}`}>
                                  <div className="flex justify-between items-center font-bold">
                                    <span className={isDarkMode ? "text-teal-400" : "text-teal-600"}>Sodium Valproate (Epilim)</span>
                                    <span className="text-[10px] bg-rose-500/10 text-rose-500 px-1.5 py-0.5 rounded font-bold">First-Line</span>
                                  </div>
                                  <p className="mt-1.5 text-slate-600 dark:text-slate-400 leading-normal">
                                    <strong>Starting Dose:</strong> Start 15-30mg/kg daily in divided doses. Excellent broad-spectrum response.
                                  </p>
                                </div>
                              )}
                              
                              <div className={`p-3 rounded-lg border text-xs ${isDarkMode ? "bg-slate-950/40 border-slate-800" : "bg-white border-slate-200"}`}>
                                <div className="flex justify-between items-center font-bold">
                                  <span className={isDarkMode ? "text-teal-400" : "text-teal-600"}>Ethosuximide</span>
                                  <span className="text-[10px] bg-emerald-500/10 text-emerald-500 px-1.5 py-0.5 rounded font-bold">Highly Effective</span>
                                </div>
                                <p className="mt-1.5 text-slate-600 dark:text-slate-400 leading-normal">
                                  <strong>Starting Dose:</strong> Start 250mg BD, titrate slowly up to 500mg BD/TDS (max 1.5g daily).
                                </p>
                                <p className="mt-1 text-[10px] text-slate-500 font-mono">
                                  💡 <em>Highly selective for absence seizures. No effect on tonic-clonic seizures.</em>
                                </p>
                              </div>
                            </>
                          )}

                          {epilepsySeizureType === "myoclonic" && (
                            <>
                              {epilepsyPatientGroup === "general" && (
                                <div className={`p-3 rounded-lg border text-xs ${isDarkMode ? "bg-slate-950/40 border-slate-800" : "bg-white border-slate-200"}`}>
                                  <div className="flex justify-between items-center font-bold">
                                    <span className={isDarkMode ? "text-teal-400" : "text-teal-600"}>Sodium Valproate (Epilim)</span>
                                    <span className="text-[10px] bg-rose-500/10 text-rose-500 px-1.5 py-0.5 rounded font-bold">First-Line Gold Standard</span>
                                  </div>
                                  <p className="mt-1.5 text-slate-600 dark:text-slate-400 leading-normal">
                                    <strong>Starting Dose:</strong> Start 200mg - 300mg BD, titrate to effect. Excellent clinical outcomes.
                                  </p>
                                </div>
                              )}

                              <div className={`p-3 rounded-lg border text-xs ${isDarkMode ? "bg-slate-950/40 border-slate-800" : "bg-white border-slate-200"}`}>
                                <div className="flex justify-between items-center font-bold">
                                  <span className={isDarkMode ? "text-teal-400" : "text-teal-600"}>Levetiracetam (Keppra)</span>
                                  <span className="text-[10px] bg-teal-500/10 text-teal-500 px-1.5 py-0.5 rounded font-bold">Highly Effective</span>
                                </div>
                                <p className="mt-1.5 text-slate-600 dark:text-slate-400 leading-normal">
                                  <strong>Starting Dose:</strong> Start 250mg BD, maintenance up to 1500mg BD. Preferred option in female patients.
                                </p>
                              </div>

                              {epilepsyPatientGroup !== "pregnancy" && (
                                <div className={`p-3 rounded-lg border text-xs ${isDarkMode ? "bg-slate-950/40 border-slate-800" : "bg-white border-slate-200"}`}>
                                  <div className="flex justify-between items-center font-bold">
                                    <span className={isDarkMode ? "text-teal-400" : "text-teal-600"}>Topiramate (Topamax)</span>
                                  </div>
                                  <p className="mt-1.5 text-slate-600 dark:text-slate-400 leading-normal">
                                    <strong>Starting Dose:</strong> Start 25mg BD, titrate up.
                                  </p>
                                </div>
                              )}
                            </>
                          )}
                        </div>
                      </div>

                      {/* Contraindicated/Avoid drugs warning box */}
                      {(epilepsySeizureType === "absence" || epilepsySeizureType === "myoclonic") && (
                        <div className="p-3.5 rounded-lg bg-rose-500/10 border border-rose-500/20 text-xs">
                          <strong className="text-rose-500 flex items-center gap-1.5 mb-1">
                            <AlertTriangle className="w-4 h-4" /> CRITICAL CONTRAINDICATIONS
                          </strong>
                          <p className="text-slate-600 dark:text-slate-300 leading-relaxed">
                            For {epilepsySeizureType === "absence" ? "Absence" : "Myoclonic"} seizures, do <strong className="text-rose-500 font-bold">NOT</strong> use sodium-channel blockers as they can <strong>severely exacerbate</strong> seizures:
                          </p>
                          <div className="mt-2 grid grid-cols-2 gap-2 text-[10px] font-mono font-bold text-rose-500">
                            <div>🚫 Carbamazepine (Tegretol)</div>
                            <div>🚫 Oxcarbazepine (Trileptal)</div>
                            <div>🚫 Phenytoin (Dilantin)</div>
                            <div>🚫 Gabapentin / Pregabalin</div>
                          </div>
                        </div>
                      )}
                    </div>

                    {/* Guidelines & Counseling Sidebar (4 cols) */}
                    <div className="lg:col-span-4 space-y-4">
                      {/* Special Subgroup Alerts Card */}
                      {epilepsyPatientGroup === "pregnancy" && (
                        <div className="p-4 rounded-xl bg-amber-500/10 border border-amber-500/20 text-xs space-y-2.5">
                          <strong className="text-amber-500 flex items-center gap-1.5 font-bold">
                            <Info className="w-4 h-4" /> Pregnancy & WOCBP Protocol
                          </strong>
                          <div className="space-y-2 text-slate-600 dark:text-slate-300 leading-relaxed text-[11px]">
                            <p>
                              🚫 <strong>Strict Valproate Contraindication:</strong> Teratogenicity risk is up to 10% for physical malformations, and 30-40% for neurodevelopmental/autism risk. Avoid in women of childbearing potential unless no alternatives exist and pregnancy prevention program is active.
                            </p>
                            <p>
                              💊 <strong>High-Dose Folic Acid:</strong> Guidelines recommend <strong>Folic Acid 5 mg OD</strong> starting at least 3 months pre-conception and through 1st trimester.
                            </p>
                            <p>
                              📈 <strong>Clearance Monitoring:</strong> Lamotrigine and Levetiracetam clearance increases significantly during pregnancy (especially 2nd/3rd trimesters). Monitor clinical seizures closely and adjust dose.
                            </p>
                          </div>
                        </div>
                      )}

                      {epilepsyPatientGroup === "elderly" && (
                        <div className="p-4 rounded-xl bg-teal-500/10 border border-teal-500/20 text-xs space-y-2.5">
                          <strong className="text-teal-400 flex items-center gap-1.5 font-bold">
                            <Info className="w-4 h-4" /> Geriatric Epilepsy Guide
                          </strong>
                          <div className="space-y-2 text-slate-600 dark:text-slate-300 leading-relaxed text-[11px]">
                            <p>
                              🐢 <strong>Start Low, Go Slow:</strong> Start at 50% or less of the normal adult starting dose and titrate at longer intervals (e.g., 2-4 weeks).
                            </p>
                            <p>
                              🔬 <strong>Avoid Interactions:</strong> Prefer Levetiracetam or Lamotrigine. Avoid Carbamazepine/Phenytoin due to severe CYP induction that alters cardiovascular and blood-thinning drug levels.
                            </p>
                            <p>
                              💧 <strong>Hyponatremia Check:</strong> Monitor sodium level regularly if starting Oxcarbazepine or Carbamazepine.
                            </p>
                          </div>
                        </div>
                      )}

                      {epilepsyPatientGroup === "general" && (
                        <div className="p-4 rounded-xl bg-slate-100 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-xs space-y-2.5">
                          <strong className={`flex items-center gap-1.5 ${isDarkMode ? "text-slate-200" : "text-slate-800"} font-bold`}>
                            <CheckCircle2 className="w-4 h-4 text-emerald-500" /> Key MSN 2024 Principles
                          </strong>
                          <ul className="space-y-2 text-slate-600 dark:text-slate-400 text-[11px] list-disc pl-4 leading-normal">
                            <li>Prioritize <strong>monotherapy</strong>. Avoid polytherapy until multiple monotherapies fail.</li>
                            <li>Start with a low dose and titrate slowly to minimize dose-dependent adverse effects.</li>
                            <li>Start therapy only after a <strong>second unprovoked seizure</strong>, unless high-risk factors (abnormal EEG/structural lesion) are present.</li>
                          </ul>
                        </div>
                      )}

                      {/* Malaysia Specific HLA Alerts Card */}
                      <div className="p-4 rounded-xl bg-rose-500/5 border border-rose-500/10 text-xs space-y-2.5">
                        <strong className="text-rose-500 flex items-center gap-1.5 font-bold">
                          <ShieldAlert className="w-4 h-4" /> Malaysia Clinical Safety Rules
                        </strong>
                        <div className="space-y-2 text-slate-600 dark:text-slate-300 leading-normal text-[11px]">
                          <div>
                            <strong className="text-rose-500 block font-bold">Carbamazepine & HLA-B*1502:</strong>
                            Prior to starting Carbamazepine in Malay, Chinese, and Indian patients, MSN guidelines recommend screening for the HLA-B*1502 allele. Positive patients have extreme risk of SJS/TEN.
                          </div>
                          <div className="border-t border-rose-500/10 pt-2">
                            <strong className="text-amber-500 block font-bold">Slow Lamotrigine Titration:</strong>
                            Adhering strictly to the 25mg OD starting dose and titrating slow prevents SJS drug rash.
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              )}

            </div>
          )}

          {/* ALGORITHM 5: ACUTE HYPERKALEMIA */}
          {resusActiveAlg === "hyperkalemia" && (
            <div className={`p-5 rounded-2xl border ${isDarkMode ? "bg-slate-950/40 border-slate-800/80" : "bg-white border-slate-200 shadow-sm"} space-y-5`}>
              <div>
                <h3 className={`font-bold text-lg ${isDarkMode ? "text-slate-100" : "text-slate-900"}`}>Emergency Hyperkalemia Protocol (K+ &ge; 6.5 mmol/L)</h3>
                <p className="text-xs text-slate-500 mt-0.5 font-mono">Three-stage rapid treatment algorithm to stabilize, shift, and eliminate potassium</p>
              </div>

              {/* Three Stages Cards */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                
                {/* Stage 1: Stabilise */}
                <div className={`p-4 rounded-xl border ${isDarkMode ? "bg-slate-900/60 border-slate-800" : "bg-slate-50 border-slate-200"} flex flex-col justify-between space-y-3`}>
                  <div className="space-y-1">
                    <span className="text-[10px] font-extrabold uppercase tracking-widest text-rose-500 block">Stage 1: Membrane Stabilisation</span>
                    <strong className="text-xs font-bold block mt-1">Calcium Gluconate 10%</strong>
                    <p className="text-[11px] leading-relaxed text-slate-600 dark:text-slate-400 mt-1">
                      Indicated if ECG changes are present (peaked T waves, flat P waves, wide QRS, sine wave). Protects myocardium.
                    </p>
                    <p className="text-[11px] font-mono font-bold text-rose-500 mt-1">
                      Dose: 10 mL IV over 5-10 mins. Repeat after 5 mins if ECG changes persist.
                    </p>
                  </div>
                  <button
                    onClick={() => logEvent("Administered Calcium Gluconate 10% 10mL IV over 5-10 mins")}
                    className="w-full py-1.5 rounded-lg bg-rose-500 hover:bg-rose-600 text-white font-bold text-[10px] flex items-center justify-center gap-1"
                  >
                    <Syringe className="w-3.5 h-3.5" /> Log Calcium Given
                  </button>
                </div>

                {/* Stage 2: Shift */}
                <div className={`p-4 rounded-xl border ${isDarkMode ? "bg-slate-900/60 border-slate-800" : "bg-slate-50 border-slate-200"} flex flex-col justify-between space-y-3`}>
                  <div className="space-y-1">
                    <span className="text-[10px] font-extrabold uppercase tracking-widest text-amber-500 block">Stage 2: Intracellular Shift</span>
                    <strong className="text-xs font-bold block mt-1">Insulin-Dextrose & Salbutamol</strong>
                    <p className="text-[11px] leading-relaxed text-slate-600 dark:text-slate-400 mt-1">
                      Temporarily shifts potassium back into cells. Lowers serum K+ by 0.5-1.5 mmol/L within 30-60 mins.
                    </p>
                    <p className="text-[11px] font-mono font-bold text-amber-500 mt-1">
                      Dose: 10 units Actrapid Insulin in 50 mL Dextrose 50% IV over 15-30 mins. Salbutamol 10-20mg nebulised.
                    </p>
                  </div>
                  <div className="space-y-1">
                    <button
                      onClick={() => logEvent("Started IV Insulin-Dextrose (10U Actrapid in 50ml D50% infusion)")}
                      className="w-full py-1 rounded-lg bg-amber-500 hover:bg-amber-600 text-white font-bold text-[10px]"
                    >
                      Log Insulin-Dextrose Started
                    </button>
                    <button
                      onClick={() => logEvent("Administered Salbutamol 10mg Nebulizer for K+ shifting")}
                      className="w-full py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-[10px]"
                    >
                      Log Salbutamol Neb Given
                    </button>
                  </div>
                </div>

                {/* Stage 3: Eliminate */}
                <div className={`p-4 rounded-xl border ${isDarkMode ? "bg-slate-900/60 border-slate-800" : "bg-slate-50 border-slate-200"} flex flex-col justify-between space-y-3`}>
                  <div className="space-y-1">
                    <span className="text-[10px] font-extrabold uppercase tracking-widest text-teal-500 block">Stage 3: Potassium Elimination</span>
                    <strong className="text-xs font-bold block mt-1">Loop Diuretics & Dialysis</strong>
                    <p className="text-[11px] leading-relaxed text-slate-600 dark:text-slate-400 mt-1">
                      Removes potassium from the body permanently.
                    </p>
                    <ul className="text-[11px] space-y-1 text-slate-600 dark:text-slate-400 font-mono mt-1">
                      <li>• <strong>IV Furosemide:</strong> 40-80mg (if urine output is maintained).</li>
                      <li>• <strong>Calcium Resonium:</strong> 15g oral / rectal.</li>
                      <li>• <strong>Urgent Hemodialysis:</strong> If refractory or anuric.</li>
                    </ul>
                  </div>
                  <button
                    onClick={() => logEvent("Initiated Loop Diuretics / Potassium Binding therapy")}
                    className="w-full py-1.5 rounded-lg bg-teal-600 hover:bg-teal-700 text-white font-bold text-[10px]"
                  >
                    Log Elimination Started
                  </button>
                </div>

              </div>

              {/* Warning/ECG changes callout */}
              <div className={`p-3.5 rounded-xl border border-rose-500/10 bg-rose-500/5 text-xs flex gap-2`}>
                <AlertTriangle className="w-4 h-4 flex-shrink-0 mt-0.5 text-rose-500 animate-pulse" />
                <div>
                  <strong className="text-rose-500">Continuous Monitoring Required:</strong> Attach patient to continuous ECG telemetry and monitor serum glucose every 30 minutes to prevent hypoglycemia secondary to the insulin infusion. Re-check serum potassium level 1-2 hours after completing shifted therapies.
                </div>
              </div>

            </div>
          )}
        
        {resusActiveAlg !== "cardiac" && renderTimelineLogger()}

      </div>

      <AclsAlgorithmModal 
        isOpen={isAclsModalOpen} 
        onClose={() => setIsAclsModalOpen(false)} 
        isDarkMode={isDarkMode} 
      />

    </div>
  );
}
