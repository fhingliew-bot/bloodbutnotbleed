import { useState } from "react";
import { 
  Heart, 
  Search, 
  AlertTriangle, 
  CheckCircle2, 
  ChevronDown, 
  ChevronUp, 
  Calculator, 
  Activity, 
  ClipboardList, 
  Info,
  ShieldAlert,
  Droplet,
  FileText
} from "lucide-react";

type Symptom = {
  id: string;
  emoji: string;
  name: string;
  description: string;
  details: {
    title: string;
    items: string[];
  }[];
  treatment: string[];
};

export default function PalliativeGuide({ isDarkMode }: { isDarkMode: boolean }) {
  const [activeSubTab, setActiveSubTab] = useState<"symptoms" | "converter" | "csci" | "dilutions" | "formulary">("symptoms");
  const [expandedSymptom, setExpandedSymptom] = useState<string | null>(null);

  // States for Dilution Guide
  const [dilutionSelectedDrug, setDilutionSelectedDrug] = useState<"morphine" | "midazolam" | "fentanyl">("morphine");

  // States for Opioid Converter
  const [calcSource, setCalcSource] = useState<"oral_morphine" | "sc_morphine">("oral_morphine");
  const [calcDose, setCalcDose] = useState<number>(30);

  // States for CSCI Cocktail Builder
  const [organStatus, setOrganStatus] = useState<"normal" | "impaired">("normal");

  // Symptoms data
  const symptoms: Symptom[] = [
    {
      id: "pain",
      emoji: "🤕",
      name: "Pain Management",
      description: "Classify pain etiology and assess using the clinical Pain Score (Mild 1-4, Moderate 5-6, Severe 7-10) to guide therapy.",
      details: [
        {
          title: "1. Somatic Pain",
          items: ["Direct tissue damage to skin, muscle, or bone", "Examples: Bone metastases, pressure sores, malignant ulcers", "Characteristics: Well-localized, aching, throbbing, or gnawing"]
        },
        {
          title: "2. Visceral Pain",
          items: ["Compression, stretch, or mass effect on internal organs", "Examples: Liver metastases, bowel obstruction, pancreatic cancer", "Characteristics: Poorly localized, deep squeezing, pressure, or cramping"]
        },
        {
          title: "3. Neuropathic Pain",
          items: ["Nerve compression, infiltration, or injury", "Examples: Spinal cord compression (spine mets), plexus infiltration, chemotherapy-induced neuropathy", "Characteristics: Burning, shooting, electric-shock like, or lancinating"]
        },
        {
          title: "Pain Severity & Approach",
          items: [
            "Mild (1 - 4): Non-opioid (e.g. Paracetamol, NSAIDs) +/- Adjuvant.",
            "Moderate (5 - 6): Weak opioid (e.g. Tramadol) or low-dose strong opioid +/- Non-opioid +/- Adjuvant.",
            "Severe (7 - 10): Strong opioid (e.g. Morphine, Fentanyl, Oxycodone) +/- Non-opioid +/- Adjuvant."
          ]
        }
      ],
      treatment: [
        "Opioids (Morphine, Oxycodone, Fentanyl)",
        "NSAIDs (Ibuprofen, Celecoxib, Etoricoxib) with PPI cover",
        "Neuromodulators for neuropathic pain (Gabapentin, Amitriptyline)"
      ]
    },
    {
      id: "nausea",
      emoji: "🤢",
      name: "Nausea & Vomiting",
      description: "Nausea and vomiting in advanced disease can be multi-factorial. Tailor antiemetics to the underlying pathway.",
      details: [
        {
          title: "Common Etiologies",
          items: [
            "Chemotherapy or radiotherapy side effects (triggers chemoreceptor trigger zone)",
            "Gastric stasis or intestinal obstruction",
            "Increased Intracranial Pressure (ICP) from brain metastases",
            "Metabolic derangements (Uremia, Hypercalcemia)",
            "Opioid-induced nausea (especially during initiation)"
          ]
        },
        {
          title: "Therapeutic Options",
          items: [
            "Metoclopramide (Maxolon) 10mg TDS: Prokinetic of choice for gastric stasis or standard uremia. Avoid in complete bowel obstruction.",
            "Haloperidol 1mg - 3mg BD: Highly effective central antiemetic for drug-induced/metabolic causes.",
            "Dexamethasone: Helpful for malignant bowel obstruction and cerebral edema/ICP."
          ]
        }
      ],
      treatment: [
        "Metoclopramide (Maxolon) 10mg TDS",
        "Haloperidol 1mg - 3mg BD (or 0.5-1.5mg ON)",
        "Dexamethasone 4mg - 8mg daily (mass effect / ICP)"
      ]
    },
    {
      id: "dyspnea",
      emoji: "😮‍💨",
      name: "Dyspnea (Breathlessness)",
      description: "Subjective sensation of breathlessness. Actively manage reversible causes while using low-dose opioids as the gold standard symptomatic therapy.",
      details: [
        {
          title: "Common Etiologies",
          items: [
            "Primary Lung Cancer or extensive pulmonary metastases",
            "Pleural effusions or pericardial effusions",
            "Pulmonary edema or Congestive Cardiac Failure (CCF)",
            "COPD / Asthma flare-ups",
            "Superior Vena Cava Obstruction (SVCO)"
          ]
        },
        {
          title: "Opioid Mechanism in Dyspnea",
          items: [
            "Opioids reduce the central perception of breathlessness, decrease ventilatory drive, and cause mild vasodilation.",
            "Fears of respiratory depression are unfounded when opioids are titrated carefully for symptom control."
          ]
        }
      ],
      treatment: [
        "Opioids (Morphine aqueous 2.5mg - 5mg PO 4-6 hourly or SC Morphine 1.25mg - 2.5mg PRN)",
        "Oxygen therapy (only if patient is hypoxic)",
        "Fan/Cool breeze blowing across the face (highly effective neuro-stimulus)",
        "Anxiolytics (e.g. Midazolam 1.25mg - 2.5mg SC PRN if accompanied by severe panic)"
      ]
    },
    {
      id: "neuro",
      emoji: "🧠",
      name: "Neurological & Agitation",
      description: "Delirium, agitated terminal restlessness, and insomnia are common towards the end of life and require rapid, compassionate pharmacological stabilization.",
      details: [
        {
          title: "Terminal Delirium & Restlessness",
          items: [
            "Agitation, confusion, hallucinations, or plucking at bedclothes.",
            "Exclude easily reversible causes (urinary retention, severe constipation/fecal impaction, pain, hypoxia).",
            "Pharmacotherapy is critical to prevent injury and distress for both patient and family."
          ]
        },
        {
          title: "Insomnia & Panic",
          items: [
            "Benzodiazepines can help settle severe anxiety, panic, or insomnia, but use with caution as they can occasionally cause paradoxical excitation in older adults if used alone."
          ]
        }
      ],
      treatment: [
        "Haloperidol 0.5mg - 3mg SC/PO (Antipsychotic of choice for delirium/hallucinations)",
        "Midazolam 2.5mg - 5mg SC/IV (Rapid sedative for acute distress or severe terminal agitation)",
        "Levomepromazine (Nozinan) as a second-line sedating antipsychotic if Haloperidol is insufficient"
      ]
    },
    {
      id: "compression",
      emoji: "⚡",
      name: "Compression (Mass Effect / Spine)",
      description: "Oncological emergencies like Metastatic Spinal Cord Compression (MSCC) or severe cerebral edema require high-dose corticosteroids.",
      details: [
        {
          title: "Spinal Cord Compression",
          items: [
            "Symptoms: Progressive back pain, lower limb weakness, sensory level changes, bowel/bladder dysfunction (retention/incontinence).",
            "Urgent action: High-dose steroids, MRI spine, and urgent oncology/neurosurgery referral for radiotherapy or decompression."
          ]
        },
        {
          title: "Cerebral Edema (Brain Metastases)",
          items: [
            "Symptoms: Early morning headache, projectile vomiting, focal neurological deficits, altered GCS.",
            "Mechanism: Dexamethasone reduces vasogenic peritumoral edema rapidly."
          ]
        }
      ],
      treatment: [
        "Dexamethasone 4mg - 8mg BD or TDS (Typically start 16mg/day in divided doses)",
        "Always prescribe concurrently with PPI (e.g. Pantoprazole 40mg OD) for gastroprotection",
        "Gradually down-titrate the steroid dose once symptoms stabilize to the lowest effective maintenance level"
      ]
    }
  ];

  // Opioid conversion calculator helper
  const getConversions = () => {
    const val = calcDose || 0;
    if (calcSource === "oral_morphine") {
      return {
        sc_morphine: val / 2,
        sc_fentanyl_daily: val * 10,
        sc_fentanyl_hourly: (val * 10) / 24,
        tramadol: val * 5,
        oxynorm: val / 2,
        fentanyl_patch: val >= 30 ? (val / 30) * 12.5 : 0
      };
    } else {
      // SC Morphine
      const oralEq = val * 2;
      return {
        sc_morphine: val,
        sc_fentanyl_daily: oralEq * 10,
        sc_fentanyl_hourly: (oralEq * 10) / 24,
        tramadol: oralEq * 5,
        oxynorm: oralEq / 2,
        fentanyl_patch: oralEq >= 30 ? (oralEq / 30) * 12.5 : 0
      };
    }
  };

  const conversions = getConversions();

  return (
    <div className="space-y-6 animate-fade-in" id="palliative-tab-root">
      {/* HEADER SECTION */}
      <div className={`p-5 rounded-2xl border ${
        isDarkMode ? "bg-[#111827] border-slate-800" : "bg-white border-slate-200 shadow-sm"
      }`}>
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h2 className={`text-lg sm:text-xl font-bold font-sans ${isDarkMode ? "text-teal-400" : "text-teal-700"} flex items-center gap-2`}>
              <Heart className="w-5 h-5 text-red-500 fill-red-500/10" /> Palliative Symptom & Opioid Guide
            </h2>
            <p className={`text-xs mt-1 ${isDarkMode ? "text-slate-400" : "text-slate-500"}`}>
              Malaysia Clinical Protocol Integration. Pain scoring, continuous subcutaneous infusions (CSCI), and equianalgesic conversions.
            </p>
          </div>
          
          {/* Sub tab navigation */}
          <div className={`flex flex-wrap p-0.5 rounded-lg border ${
            isDarkMode ? "bg-slate-900 border-slate-800" : "bg-slate-100 border-slate-200"
          }`}>
            {[
              { id: "symptoms", label: "Symptoms", icon: <Activity className="w-3.5 h-3.5" /> },
              { id: "converter", label: "Converter", icon: <Calculator className="w-3.5 h-3.5" /> },
              { id: "csci", label: "CSCI", icon: <Droplet className="w-3.5 h-3.5" /> },
              { id: "dilutions", label: "Dilutions", icon: <ClipboardList className="w-3.5 h-3.5" /> },
              { id: "formulary", label: "Drugs", icon: <FileText className="w-3.5 h-3.5" /> }
            ].map((sub) => (
              <button
                key={sub.id}
                onClick={() => setActiveSubTab(sub.id as any)}
                className={`flex items-center gap-1 px-2 py-1 rounded-md text-[10px] font-semibold transition-all ${
                  activeSubTab === sub.id
                    ? isDarkMode 
                      ? "bg-teal-500/20 text-teal-400 border border-teal-500/30" 
                      : "bg-white text-teal-700 shadow-sm border border-slate-200"
                    : "text-slate-400 hover:text-slate-300 border border-transparent"
                }`}
              >
                {sub.icon}
                <span className="hidden md:inline">{sub.label}</span>
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* SUB-TAB CONTENT 1: SYMPTOMS */}
      {activeSubTab === "symptoms" && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 gap-3">
            {symptoms.map((sym) => {
              const isExpanded = expandedSymptom === sym.id;
              return (
                <div 
                  key={sym.id}
                  className={`border rounded-xl overflow-hidden transition-all ${
                    isDarkMode 
                      ? isExpanded ? "bg-slate-800/60 border-teal-500/30" : "bg-slate-900/50 border-slate-800 hover:border-slate-700" 
                      : isExpanded ? "bg-white border-teal-500/30 shadow-md" : "bg-white border-slate-200 hover:border-slate-300 shadow-sm"
                  }`}
                  id={`symptom-card-${sym.id}`}
                >
                  <div 
                    className="p-4 cursor-pointer flex items-center justify-between"
                    onClick={() => setExpandedSymptom(isExpanded ? null : sym.id)}
                  >
                    <div className="flex items-center gap-3">
                      <span className="text-2xl">{sym.emoji}</span>
                      <div>
                        <h4 className={`font-bold ${isDarkMode ? "text-slate-200" : "text-slate-800"}`}>
                          {sym.name}
                        </h4>
                        <p className={`text-xs mt-0.5 ${isDarkMode ? "text-slate-400" : "text-slate-500"}`}>
                          {sym.description}
                        </p>
                      </div>
                    </div>
                    <div>
                      {isExpanded ? <ChevronUp className="w-5 h-5 text-slate-400" /> : <ChevronDown className="w-5 h-5 text-slate-400" />}
                    </div>
                  </div>

                  {isExpanded && (
                    <div className={`p-4 pt-0 border-t ${isDarkMode ? "border-slate-800" : "border-slate-100"} space-y-4`}>
                      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 mt-4">
                        {sym.details.map((detail, idx) => (
                          <div 
                            key={idx} 
                            className={`p-3.5 rounded-xl border ${
                              isDarkMode ? "bg-slate-950/40 border-slate-800" : "bg-slate-50 border-slate-200"
                            } ${idx === 3 ? "lg:col-span-3 border-teal-500/20 bg-teal-500/[0.02]" : ""}`}
                          >
                            <h5 className={`text-xs font-bold uppercase tracking-wider mb-2 ${isDarkMode ? "text-teal-400" : "text-teal-700"}`}>
                              {detail.title}
                            </h5>
                            <ul className="space-y-1.5 list-disc list-inside">
                              {detail.items.map((item, i) => (
                                <li key={i} className={`text-xs leading-relaxed ${isDarkMode ? "text-slate-300" : "text-slate-700"}`}>
                                  {item}
                                </li>
                              ))}
                            </ul>
                          </div>
                        ))}
                      </div>

                      {/* Therapeutic Directives */}
                      <div className={`p-3.5 rounded-xl border ${
                        isDarkMode ? "bg-emerald-500/10 border-emerald-500/20" : "bg-emerald-50 border-emerald-200"
                      }`}>
                        <h5 className={`text-xs font-bold uppercase tracking-wide flex items-center gap-1.5 ${
                          isDarkMode ? "text-emerald-400" : "text-emerald-800"
                        } mb-2`}>
                          <CheckCircle2 className="w-4 h-4" /> Recommended First-Line Pharmacotherapy (NAG)
                        </h5>
                        <div className="flex flex-wrap gap-2">
                          {sym.treatment.map((treat, idx) => (
                            <span 
                              key={idx} 
                              className={`text-xs font-mono font-medium px-2.5 py-1 rounded-md ${
                                isDarkMode ? "bg-slate-900 text-teal-300 border border-slate-800" : "bg-white text-teal-800 border border-teal-200 shadow-sm"
                              }`}
                            >
                              {treat}
                            </span>
                          ))}
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>

          {/* OPIOID INITIATION & BREAKTHROUGH COMPASS CARD */}
          <div className={`p-5 rounded-2xl border ${
            isDarkMode ? "bg-amber-500/[0.04] border-amber-500/20" : "bg-amber-50 border-amber-100 shadow-sm"
          }`}>
            <h3 className={`text-sm font-bold flex items-center gap-2 ${isDarkMode ? "text-amber-400" : "text-amber-800"}`}>
              <AlertTriangle className="w-4.5 h-4.5 text-amber-500" /> Opioid Initiation & Breakthrough Protocol
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mt-3">
              <div className="space-y-1">
                <strong className={`text-xs font-semibold block ${isDarkMode ? "text-slate-200" : "text-slate-800"}`}>1. Administration Route</strong>
                <p className={`text-xs ${isDarkMode ? "text-slate-400" : "text-slate-600"}`}>
                  If unable to tolerate orally, switch to Subcutaneous (SC). If stable and tolerating, use Aqueous Syrup or Capsules.
                </p>
              </div>
              <div className="space-y-1">
                <strong className={`text-xs font-semibold block ${isDarkMode ? "text-slate-200" : "text-slate-800"}`}>2. Opioid Naive Patients</strong>
                <p className={`text-xs ${isDarkMode ? "text-slate-400" : "text-slate-600"}`}>
                  Always "Start Slow, Go Low". Starting dose: <strong>Sy Morphine 2.5mg - 5mg</strong> (1.3 - 2.5ml) or <strong>SC Morphine 2.5mg - 5mg</strong> 4-6 hourly + PRN.
                </p>
              </div>
              <div className="space-y-1">
                <strong className={`text-xs font-semibold block ${isDarkMode ? "text-slate-200" : "text-slate-800"}`}>3. Breakthrough Dose (PRN)</strong>
                <p className={`text-xs ${isDarkMode ? "text-slate-400" : "text-slate-600"}`}>
                  Always prescribe a regular dose plus a breakthrough PRN dose. Breakthrough dose is strictly <strong>1/6th of total daily Morphine dose</strong>.
                </p>
              </div>
              <div className="space-y-1">
                <strong className={`text-xs font-semibold block ${isDarkMode ? "text-slate-200" : "text-slate-800"}`}>4. Strict Safety Monitoring</strong>
                <p className={`text-xs ${isDarkMode ? "text-slate-400" : "text-slate-600"}`}>
                  Monitor using an Opioid Chart: <strong>Glasgow Coma Scale (GCS), pupil size, respiratory rate, and blood pressure (BP)</strong>. No ceiling dose exists, titrate to effect.
                </p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* SUB-TAB CONTENT 2: OPIOID CONVERTER */}
      {activeSubTab === "converter" && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* CALCULATOR PANEL */}
          <div className={`p-5 rounded-2xl border lg:col-span-7 flex flex-col justify-between ${
            isDarkMode ? "bg-[#111827] border-slate-800" : "bg-white border-slate-200 shadow-sm"
          }`}>
            <div>
              <h3 className={`text-base font-bold mb-4 flex items-center gap-2 ${isDarkMode ? "text-slate-200" : "text-slate-800"}`}>
                <Calculator className="w-5 h-5 text-teal-400" /> Equianalgesic Converter
              </h3>
              
              <div className="space-y-4">
                {/* SOURCE SELECTOR */}
                <div>
                  <label className={`text-xs font-semibold block mb-1.5 ${isDarkMode ? "text-slate-400" : "text-slate-700"}`}>Source Opioid</label>
                  <div className="flex gap-2">
                    {[
                      { id: "oral_morphine", label: "Oral Morphine (Syrup/Tab)" },
                      { id: "sc_morphine", label: "Subcutaneous Morphine (SC)" }
                    ].map((src) => (
                      <button
                        key={src.id}
                        onClick={() => {
                          setCalcSource(src.id as any);
                          // convert dose to look sensible
                          if (src.id === "sc_morphine" && calcSource === "oral_morphine") {
                            setCalcDose(prev => Math.round(prev / 2));
                          } else if (src.id === "oral_morphine" && calcSource === "sc_morphine") {
                            setCalcDose(prev => prev * 2);
                          }
                        }}
                        className={`flex-1 py-2 px-3 rounded-xl text-xs font-bold border transition-all ${
                          calcSource === src.id
                            ? isDarkMode ? "bg-teal-500/20 text-teal-400 border-teal-500/40" : "bg-teal-100 text-teal-800 border-teal-300"
                            : isDarkMode ? "bg-slate-900 border-slate-800 text-slate-400 hover:bg-slate-800" : "bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100"
                        }`}
                      >
                        {src.label}
                      </button>
                    ))}
                  </div>
                </div>

                {/* DOSE INPUT */}
                <div>
                  <label className={`text-xs font-semibold block mb-1 ${isDarkMode ? "text-slate-400" : "text-slate-700"}`}>
                    Enter Total Daily Dose (mg/24 hours)
                  </label>
                  <div className="relative">
                    <input
                      type="number"
                      min="0"
                      value={calcDose || ""}
                      onChange={(e) => setCalcDose(Math.max(0, parseFloat(e.target.value) || 0))}
                      className={`w-full pl-4 pr-12 py-3 rounded-xl font-mono text-base font-bold border focus:outline-none focus:ring-2 focus:ring-teal-500/50 ${
                        isDarkMode 
                          ? "bg-slate-900 border-slate-700 text-teal-400" 
                          : "bg-slate-50 border-slate-300 text-teal-700"
                      }`}
                    />
                    <span className="absolute right-4 top-1/2 -translate-y-1/2 text-xs font-bold text-slate-500">
                      mg
                    </span>
                  </div>
                </div>
              </div>

              {/* OUTPUTS GRID */}
              <div className="mt-6 space-y-3">
                <span className={`text-[10px] font-bold uppercase tracking-wider block ${isDarkMode ? "text-slate-500" : "text-slate-400"}`}>
                  Equivalency Profiles & Conversion Outputs
                </span>
                <div className="grid grid-cols-2 gap-3">
                  {/* SC/IV Morphine */}
                  {calcSource !== "sc_morphine" && (
                    <div className={`p-3 rounded-xl border ${isDarkMode ? "bg-slate-950/40 border-slate-800" : "bg-slate-50 border-slate-200"}`}>
                      <span className={`text-[10px] block font-medium ${isDarkMode ? "text-slate-400" : "text-slate-500"}`}>SC/IV Morphine Dose</span>
                      <strong className={`text-base font-mono text-emerald-400 block mt-0.5`}>
                        {conversions.sc_morphine.toFixed(1)} <span className="text-xs">mg/24h</span>
                      </strong>
                      <span className="text-[9px] text-slate-500 block mt-1">Formula: Divide by 2</span>
                    </div>
                  )}

                  {/* Oral Morphine equivalent if source is SC */}
                  {calcSource === "sc_morphine" && (
                    <div className={`p-3 rounded-xl border ${isDarkMode ? "bg-slate-950/40 border-slate-800" : "bg-slate-50 border-slate-200"}`}>
                      <span className={`text-[10px] block font-medium ${isDarkMode ? "text-slate-400" : "text-slate-500"}`}>Oral Morphine Equivalent</span>
                      <strong className={`text-base font-mono text-emerald-400 block mt-0.5`}>
                        {(calcDose * 2).toFixed(1)} <span className="text-xs">mg/24h</span>
                      </strong>
                      <span className="text-[9px] text-slate-500 block mt-1">Formula: Multiply by 2</span>
                    </div>
                  )}

                  {/* Fentanyl Equivalents (CSCI & Patch) */}
                  <div className={`p-3 rounded-xl border ${isDarkMode ? "bg-slate-950/40 border-slate-800" : "bg-slate-50 border-slate-200"}`}>
                    <span className={`text-[10px] block font-medium ${isDarkMode ? "text-slate-400" : "text-slate-500"}`}>Fentanyl Equivalents</span>
                    <div className="mt-1 space-y-1">
                      <strong className={`text-xs font-mono text-teal-400 block`}>
                        CSCI: {conversions.sc_fentanyl_daily.toFixed(0)} <span className="text-xs">mcg/24h</span>
                      </strong>
                      <strong className={`text-xs font-mono text-teal-400 block`}>
                        Patch: {conversions.fentanyl_patch.toFixed(1)} <span className="text-xs">mcg/h (72h)</span>
                      </strong>
                    </div>
                    <span className="text-[9px] text-slate-500 block mt-1">
                      Ratio: {calcSource === "oral_morphine" ? "Oral Morphine 30mg ➡️ Fentanyl 300mcg/24h or 12.5mcg/h patch" : "SC Morphine 15mg ➡️ Fentanyl 300mcg/24h or 12.5mcg/h patch"}
                    </span>
                  </div>

                  {/* Tramadol */}
                  <div className={`p-3 rounded-xl border ${isDarkMode ? "bg-slate-950/40 border-slate-800" : "bg-slate-50 border-slate-200"}`}>
                    <span className={`text-[10px] block font-medium ${isDarkMode ? "text-slate-400" : "text-slate-500"}`}>Tramadol PO equivalent</span>
                    <strong className={`text-base font-mono text-teal-400 block mt-0.5`}>
                      {conversions.tramadol.toFixed(0)} <span className="text-xs">mg/24h</span>
                    </strong>
                    <span className="text-[9px] text-slate-500 block mt-1">Formula: Oral Morphine * 5</span>
                  </div>

                  {/* Oxycodone (Oxynorm) */}
                  <div className={`p-3 rounded-xl border ${isDarkMode ? "bg-slate-950/40 border-slate-800" : "bg-slate-50 border-slate-200"}`}>
                    <span className={`text-[10px] block font-medium ${isDarkMode ? "text-slate-400" : "text-slate-500"}`}>Oral Oxycodone (Oxynorm)</span>
                    <strong className={`text-base font-mono text-teal-400 block mt-0.5`}>
                      {conversions.oxynorm.toFixed(1)} <span className="text-xs">mg/24h</span>
                    </strong>
                    <span className="text-[9px] text-slate-500 block mt-1">Formula: Oral Morphine / 2</span>
                  </div>
                </div>
              </div>
            </div>

            {/* BREAKTHROUGH CALCULATOR ADJUNCT */}
            <div className={`mt-4 p-3 rounded-xl border ${isDarkMode ? "bg-amber-500/10 border-amber-500/20" : "bg-amber-50 border-amber-200"}`}>
              <div className="flex items-center gap-2 mb-1.5">
                <Info className="w-4 h-4 text-amber-400" />
                <span className={`text-xs font-bold ${isDarkMode ? "text-amber-300" : "text-amber-800"}`}>
                  Breakthrough PRN Dose Calculator
                </span>
              </div>
              <p className={`text-xs ${isDarkMode ? "text-amber-200/80" : "text-amber-900"}`}>
                For a total daily oral morphine dose of <strong>{calcSource === "oral_morphine" ? calcDose : calcDose * 2}mg/day</strong>, the individual breakthrough PRN dose (1/6th of daily dose) should be:
              </p>
              <div className="flex flex-wrap gap-4 mt-2">
                <div>
                  <span className="text-[10px] text-slate-400 block">Oral Morphine PRN</span>
                  <strong className="text-sm font-mono text-amber-400">
                    {((calcSource === "oral_morphine" ? calcDose : calcDose * 2) / 6).toFixed(1)} mg PO
                  </strong>
                </div>
                <div>
                  <span className="text-[10px] text-slate-400 block">SC Morphine PRN</span>
                  <strong className="text-sm font-mono text-amber-400">
                    {(((calcSource === "oral_morphine" ? calcDose : calcDose * 2) / 6) / 2).toFixed(1)} mg SC
                  </strong>
                </div>
                <div>
                  <span className="text-[10px] text-slate-400 block">SC Fentanyl PRN</span>
                  <strong className="text-sm font-mono text-amber-400">
                    {(((calcSource === "oral_morphine" ? calcDose : calcDose * 2) * 10) / 6).toFixed(0)} mcg SC
                  </strong>
                </div>
              </div>
            </div>
          </div>

          {/* LAXATIVE MANDATE & PATCH CLINICAL PEARLS */}
          <div className="lg:col-span-5 space-y-4">
            {/* LAXATIVE WARNING */}
            <div className={`p-4 rounded-2xl border ${
              isDarkMode ? "bg-[#111827] border-slate-800" : "bg-white border-slate-200 shadow-sm"
            }`}>
              <h4 className="text-xs font-bold uppercase tracking-wider text-red-500 flex items-center gap-1.5 mb-2.5">
                <AlertTriangle className="w-4 h-4 text-red-500" /> Strict Laxative Co-prescribing
              </h4>
              <p className={`text-xs leading-relaxed ${isDarkMode ? "text-slate-300" : "text-slate-700"}`}>
                <strong>CRITICAL:</strong> Opioid-induced constipation does not develop tolerance over time. 
                Always prescribe regular laxatives concurrently when using opioids:
              </p>
              
              <div className="mt-3 space-y-2">
                <div className={`p-2.5 rounded-lg text-xs ${isDarkMode ? "bg-slate-900" : "bg-slate-50"} border border-slate-800`}>
                  <strong className={isDarkMode ? "text-slate-300" : "text-slate-700"}>Sy Lactulose</strong>
                  <span className="block text-slate-400 text-[11px]">10 - 15 ml ON / BD / TDS</span>
                </div>
                <div className={`p-2.5 rounded-lg text-xs ${isDarkMode ? "bg-slate-900" : "bg-slate-50"} border border-slate-800`}>
                  <strong className={isDarkMode ? "text-slate-300" : "text-slate-700"}>T Bisacodyl</strong>
                  <span className="block text-slate-400 text-[11px]">10 mg ON / BD</span>
                </div>
                <div className={`p-2.5 rounded-lg text-xs ${isDarkMode ? "bg-slate-900" : "bg-slate-50"} border border-slate-800`}>
                  <strong className={isDarkMode ? "text-slate-300" : "text-slate-700"}>Ravin Enema</strong>
                  <span className="block text-slate-400 text-[11px]">Use PRN if no bowel action for 3 days</span>
                </div>
              </div>
            </div>

            {/* FENTANYL PATCH SECTION */}
            <div className={`p-4 rounded-2xl border ${
              isDarkMode ? "bg-[#111827] border-slate-800" : "bg-white border-slate-200 shadow-sm"
            }`}>
              <h4 className="text-xs font-bold uppercase tracking-wider text-teal-400 flex items-center gap-1.5 mb-2">
                <Info className="w-4 h-4 text-teal-500" /> Transdermal Fentanyl Patch Rules
              </h4>
              <ul className="space-y-2 text-xs list-disc list-inside">
                <li className={isDarkMode ? "text-slate-300" : "text-slate-700"}>
                  <strong>Never use in opioid-naive patients:</strong> Risk of fatal respiratory depression is extremely high.
                </li>
                <li className={isDarkMode ? "text-slate-300" : "text-slate-700"}>
                  <strong>Lowest dose:</strong> 12.5 mcg/h (can cut a 25 mcg/h patch exactly in half in resource-limited setups if 12.5mcg is unavailable).
                </li>
                <li className={isDarkMode ? "text-slate-300" : "text-slate-700"}>
                  <strong>Frequency:</strong> Change patch strictly every 3 days (72 hours).
                </li>
                <li className={isDarkMode ? "text-slate-300" : "text-slate-700"}>
                  <strong>Conversion Rule:</strong> 
                  <span className="block font-mono text-[11px] text-teal-400 mt-1 bg-slate-900 p-1.5 rounded">
                    - CSCI Fentanyl 300mcg/24h ➡️ TD Fentanyl 12.5mcg/h<br />
                    - CSCI Fentanyl 450-600mcg/24h ➡️ TD Fentanyl 25mcg/h
                  </span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      )}

      {/* SUB-TAB CONTENT 3: CSCI COCKTAIL BUILDER */}
      {activeSubTab === "csci" && (
        <div className="space-y-6">
          <div className={`p-5 rounded-2xl border ${
            isDarkMode ? "bg-[#111827] border-slate-800" : "bg-white border-slate-200 shadow-sm"
          }`}>
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
              <div>
                <h3 className={`text-base font-bold flex items-center gap-2 ${isDarkMode ? "text-slate-200" : "text-slate-800"}`}>
                  <Droplet className="w-5 h-5 text-teal-400" /> Continuous Subcutaneous Infusion (CSCI) Syringe Driver
                </h3>
                <p className={`text-xs ${isDarkMode ? "text-slate-400" : "text-slate-500"} mt-0.5`}>
                  Continuous subcutaneous delivery of medications over 24 hours for dying patients who cannot tolerate oral intake.
                </p>
              </div>

              {/* ORGAN FUNCTION FILTER */}
              <div className="flex items-center gap-2">
                <span className={`text-xs font-semibold ${isDarkMode ? "text-slate-400" : "text-slate-600"}`}>Patient RP/LFT:</span>
                <div className={`flex p-1 rounded-xl border ${
                  isDarkMode ? "bg-slate-900 border-slate-800" : "bg-slate-100 border-slate-200"
                }`}>
                  <button
                    onClick={() => setOrganStatus("normal")}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                      organStatus === "normal"
                        ? isDarkMode ? "bg-teal-500/20 text-teal-400" : "bg-white text-teal-700 shadow-sm"
                        : "text-slate-400 hover:text-slate-300"
                    }`}
                  >
                    Normal (G1)
                  </button>
                  <button
                    onClick={() => setOrganStatus("impaired")}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                      organStatus === "impaired"
                        ? "bg-red-500/20 text-red-400 border border-red-500/30"
                        : "text-slate-400 hover:text-slate-300"
                    }`}
                  >
                    Deranged (G2)
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* COCKTAIL RECIPE CARD */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            <div className={`p-5 rounded-2xl border lg:col-span-8 ${
              isDarkMode ? "bg-[#111827] border-slate-800" : "bg-white border-slate-200 shadow-sm"
            }`}>
              <h4 className="text-xs font-bold uppercase tracking-wider text-teal-400 mb-4 flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-teal-400" /> 
                {organStatus === "normal" ? "24-Hour Dying Patient Standard Cocktail (RP/LFT Normal)" : "24-Hour Dying Patient Nephro/Hepato-Protective Cocktail (RP/LFT Impaired)"}
              </h4>

              {/* RECIPE INGREDIENTS */}
              <div className="space-y-3">
                {organStatus === "normal" ? (
                  <>
                    <div className={`flex justify-between items-center p-3 rounded-xl border ${isDarkMode ? "bg-slate-900/50 border-slate-800" : "bg-slate-50 border-slate-200"}`}>
                      <div>
                        <strong className={isDarkMode ? "text-slate-200" : "text-slate-800"}>CSCI Morphine</strong>
                        <p className="text-[11px] text-slate-400">First-line opioid for pain and breathlessness</p>
                      </div>
                      <span className="font-mono text-sm font-bold text-teal-400">20 mg / 24 hours</span>
                    </div>
                    <div className={`flex justify-between items-center p-3 rounded-xl border ${isDarkMode ? "bg-slate-900/50 border-slate-800" : "bg-slate-50 border-slate-200"}`}>
                      <div>
                        <strong className={isDarkMode ? "text-slate-200" : "text-slate-800"}>CSCI Buscopan (Hyoscine Butylbromide)</strong>
                        <p className="text-[11px] text-slate-400">Antisecretory for noisy respiratory rattling (death rattle)</p>
                      </div>
                      <span className="font-mono text-sm font-bold text-teal-400">80 mg / 24 hours</span>
                    </div>
                    <div className={`flex justify-between items-center p-3 rounded-xl border ${isDarkMode ? "bg-slate-900/50 border-slate-800" : "bg-slate-50 border-slate-200"}`}>
                      <div>
                        <strong className={isDarkMode ? "text-slate-200" : "text-slate-800"}>CSCI Midazolam</strong>
                        <p className="text-[11px] text-slate-400">Anxiolytic & sedative for terminal agitation/delirium</p>
                      </div>
                      <span className="font-mono text-sm font-bold text-teal-400">10 mg / 24 hours</span>
                    </div>
                  </>
                ) : (
                  <>
                    <div className={`flex justify-between items-center p-3 rounded-xl border ${isDarkMode ? "bg-slate-900/50 border-slate-800" : "bg-slate-50 border-slate-200"}`}>
                      <div>
                        <strong className={isDarkMode ? "text-slate-200" : "text-slate-800"}>CSCI Fentanyl</strong>
                        <p className="text-[11px] text-red-400">Preferred strong opioid in renal/hepatic impairment (avoids metabolite build-up)</p>
                      </div>
                      <span className="font-mono text-sm font-bold text-red-400">200 mcg / 24 hours</span>
                    </div>
                    <div className={`flex justify-between items-center p-3 rounded-xl border ${isDarkMode ? "bg-slate-900/50 border-slate-800" : "bg-slate-50 border-slate-200"}`}>
                      <div>
                        <strong className={isDarkMode ? "text-slate-200" : "text-slate-800"}>CSCI Buscopan (Hyoscine Butylbromide)</strong>
                        <p className="text-[11px] text-slate-400">Antisecretory for rattling secretions</p>
                      </div>
                      <span className="font-mono text-sm font-bold text-teal-400">120 mg / 24 hours</span>
                    </div>
                    <div className={`flex justify-between items-center p-3 rounded-xl border ${isDarkMode ? "bg-slate-900/50 border-slate-800" : "bg-slate-50 border-slate-200"}`}>
                      <div>
                        <strong className={isDarkMode ? "text-slate-200" : "text-slate-800"}>CSCI Midazolam</strong>
                        <p className="text-[11px] text-slate-400">For terminal agitation or restlessness</p>
                      </div>
                      <span className="font-mono text-sm font-bold text-teal-400">20 mg / 24 hours</span>
                    </div>
                    <div className={`flex justify-between items-center p-3 rounded-xl border ${isDarkMode ? "bg-slate-900/50 border-slate-800" : "bg-slate-50 border-slate-200"}`}>
                      <div>
                        <strong className={isDarkMode ? "text-slate-200" : "text-slate-800"}>CSCI Haloperidol</strong>
                        <p className="text-[11px] text-slate-400">For persistent delirium, terminal restlessness or uremic nausea</p>
                      </div>
                      <span className="font-mono text-sm font-bold text-teal-400">3 mg / 24 hours</span>
                    </div>
                  </>
                )}
              </div>

              {/* METHOD OF PREPARATION */}
              <div className="mt-5 space-y-2">
                <span className={`text-[10px] font-bold uppercase tracking-wider block ${isDarkMode ? "text-slate-500" : "text-slate-400"}`}>
                  Preparation & Dilution Protocol
                </span>
                <p className={`text-xs leading-relaxed ${isDarkMode ? "text-slate-300" : "text-slate-700"}`}>
                  Dilute all selected medications together inside a single syringe. Total volume of syringe should be <strong>exactly 24 ml</strong> (typically dilute with Normal Saline (0.9% NaCl) or Water for Injection). 
                  Run the syringe driver at a rate of <strong>1 ml / hour</strong> over 24 hours.
                </p>
              </div>
            </div>

            {/* PRN BREAKTHROUGH COMPASS (SIDEBAR) */}
            <div className="lg:col-span-4 space-y-4">
              <div className={`p-4 rounded-2xl border ${
                isDarkMode ? "bg-emerald-500/[0.03] border-emerald-500/20" : "bg-emerald-50 border-emerald-100 shadow-sm"
              }`}>
                <h4 className={`text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 mb-2.5 ${isDarkMode ? "text-emerald-400" : "text-emerald-800"}`}>
                  <CheckCircle2 className="w-4 h-4 text-emerald-500" /> Breakthrough PRN Orders
                </h4>
                
                <div className="space-y-3 text-xs">
                  <div className={`p-2.5 rounded-lg ${isDarkMode ? "bg-slate-900" : "bg-white border border-slate-200"}`}>
                    <strong className="text-red-400">For Breathlessness / Pain:</strong>
                    <p className={`mt-1 ${isDarkMode ? "text-slate-300" : "text-slate-700"}`}>
                      {organStatus === "normal" 
                        ? "SC Morphine 2.5mg PRN (4-6 hourly)" 
                        : "SC Fentanyl 25mcg PRN (4-6 hourly)"}
                    </p>
                  </div>
                  <div className={`p-2.5 rounded-lg ${isDarkMode ? "bg-slate-900" : "bg-white border border-slate-200"}`}>
                    <strong className="text-amber-400">For Terminal Agitation:</strong>
                    <p className={`mt-1 ${isDarkMode ? "text-slate-300" : "text-slate-700"}`}>
                      SC Midazolam 2.5mg PRN (every 2-4 hours)
                    </p>
                  </div>
                  <div className={`p-2.5 rounded-lg ${isDarkMode ? "bg-slate-900" : "bg-white border border-slate-200"}`}>
                    <strong className="text-blue-400">For Terminal Restlessness:</strong>
                    <p className={`mt-1 ${isDarkMode ? "text-slate-300" : "text-slate-700"}`}>
                      SC Haloperidol 0.5mg - 1mg PRN (every 4-12 hours)
                    </p>
                  </div>
                </div>
              </div>

              {/* INFUSION RANGE CHEATSHEETS */}
              <div className={`p-4 rounded-2xl border ${
                isDarkMode ? "bg-slate-900/50 border-slate-800" : "bg-white border-slate-200 shadow-sm"
              }`}>
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">CSCI Dose Ranges Cheatsheet</h4>
                <ul className="space-y-1.5 text-[11px] font-mono text-slate-400">
                  <li>- Morphine: 10 - 20 mg (up-titrate as needed)</li>
                  <li>- Fentanyl: 100 - 600 mcg</li>
                  <li>- Buscopan: 20 - 120 mg (for secretions)</li>
                  <li>- Midazolam: 5 - 15 mg (for agitation)</li>
                  <li>- Haloperidol: 1 - 3 mg (for delirium)</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* SUB-TAB CONTENT 4: DILUTION GUIDE (Malaysia Palliative Guidelines) */}
      {activeSubTab === "dilutions" && (
        <div className="space-y-6">
          {/* TOP EXPLANATORY CARD */}
          <div className={`p-5 rounded-2xl border ${
            isDarkMode ? "bg-[#111827] border-slate-800" : "bg-white border-slate-200 shadow-sm"
          }`}>
            <h3 className={`text-base font-bold flex items-center gap-2 ${isDarkMode ? "text-slate-200" : "text-slate-800"}`}>
              <ClipboardList className="w-5 h-5 text-teal-400" /> Ministry of Health (MOH) Malaysia Dilution & Compatibility Guidelines
            </h3>
            <p className={`text-xs ${isDarkMode ? "text-slate-400" : "text-slate-500"} mt-1 leading-relaxed`}>
              Clinical protocols for preparing and diluting subcutaneous medications in palliative care. Proper selection of diluents prevents site irritation, drug crystallization, and ensures stable delivery over 24 hours.
            </p>
          </div>

          {/* DRUG SELECTOR BUTTONS */}
          <div className="flex flex-col sm:flex-row gap-2">
            {[
              { id: "morphine", label: "Morphine Sulphate", desc: "Gold standard for pain & dyspnea" },
              { id: "midazolam", label: "Midazolam HCl", desc: "Anxiolytic & sedative of choice" },
              { id: "fentanyl", label: "Fentanyl Citrate", desc: "Preferred in renal/hepatic impairment" }
            ].map((drug) => (
              <button
                key={drug.id}
                onClick={() => setDilutionSelectedDrug(drug.id as any)}
                className={`flex-1 text-left p-3.5 rounded-xl border transition-all ${
                  dilutionSelectedDrug === drug.id
                    ? isDarkMode 
                      ? "bg-teal-500/10 border-teal-500/40 shadow-lg" 
                      : "bg-teal-50 border-teal-300 shadow-md"
                    : isDarkMode 
                      ? "bg-slate-900 border-slate-800 text-slate-400 hover:bg-slate-800" 
                      : "bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100"
                }`}
              >
                <div className="flex justify-between items-center">
                  <span className={`text-xs font-bold ${dilutionSelectedDrug === drug.id ? isDarkMode ? "text-teal-400" : "text-teal-700" : isDarkMode ? "text-slate-300" : "text-slate-700"}`}>
                    {drug.label}
                  </span>
                  <span className={`w-2 h-2 rounded-full ${dilutionSelectedDrug === drug.id ? "bg-teal-400 animate-pulse" : "bg-transparent"}`}></span>
                </div>
                <span className="text-[10px] text-slate-500 block mt-0.5">{drug.desc}</span>
              </button>
            ))}
          </div>

          {/* ACTIVE DRUG DETAILS & PREPARATION GUIDE */}
          <div className="space-y-6">
            {/* JUNIOR HOUSE OFFICER QUICK GUIDE */}
            <div className={`p-5 rounded-2xl border ${
              isDarkMode ? "bg-teal-900/10 border-teal-800/40" : "bg-teal-50 border-teal-200 shadow-sm"
            }`}>
              <h4 className={`text-sm font-bold flex items-center gap-2 ${isDarkMode ? "text-teal-400" : "text-teal-700"}`}>
                <Info className="w-4 h-4" /> House Officer Quick Guide: Preparing a 24-hour Syringe Driver (CSCI)
              </h4>
              <div className="mt-4 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3">
                <div className={`p-3 rounded-xl border ${isDarkMode ? "bg-slate-900/50 border-slate-800" : "bg-white border-slate-200"}`}>
                  <span className="text-xl font-bold block mb-1 text-slate-400">1</span>
                  <strong className={`text-xs block ${isDarkMode ? "text-slate-200" : "text-slate-800"}`}>Calculate Dose</strong>
                  <p className="text-[10px] text-slate-500 mt-1">Determine total 24-hour dose for the selected medication(s).</p>
                </div>
                <div className={`p-3 rounded-xl border ${isDarkMode ? "bg-slate-900/50 border-slate-800" : "bg-white border-slate-200"}`}>
                  <span className="text-xl font-bold block mb-1 text-slate-400">2</span>
                  <strong className={`text-xs block ${isDarkMode ? "text-slate-200" : "text-slate-800"}`}>Draw Medication</strong>
                  <p className="text-[10px] text-slate-500 mt-1">Draw the required drug(s) into a 30ml syringe. Note the total drug volume.</p>
                </div>
                <div className={`p-3 rounded-xl border ${isDarkMode ? "bg-slate-900/50 border-slate-800" : "bg-white border-slate-200"}`}>
                  <span className="text-xl font-bold block mb-1 text-teal-400">3</span>
                  <strong className={`text-xs block ${isDarkMode ? "text-slate-200" : "text-slate-800"}`}>Add Diluent to 24ml</strong>
                  <p className="text-[10px] text-slate-500 mt-1">Standard total volume is <strong className={isDarkMode ? "text-teal-300" : "text-teal-600"}>24ml</strong>. Diluent volume = 24ml - (Drug volume).</p>
                </div>
                <div className={`p-3 rounded-xl border ${isDarkMode ? "bg-slate-900/50 border-slate-800" : "bg-white border-slate-200"}`}>
                  <span className="text-xl font-bold block mb-1 text-slate-400">4</span>
                  <strong className={`text-xs block ${isDarkMode ? "text-slate-200" : "text-slate-800"}`}>Set Rate</strong>
                  <p className="text-[10px] text-slate-500 mt-1">Run the syringe driver at <strong className={isDarkMode ? "text-teal-300" : "text-teal-600"}>1 ml/hour</strong> (24 hours).</p>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              {/* DETAIL CARDS */}
              <div className={`p-5 rounded-2xl border lg:col-span-8 ${
                isDarkMode ? "bg-[#111827] border-slate-800" : "bg-white border-slate-200 shadow-sm"
              }`}>
              {dilutionSelectedDrug === "morphine" && (
                <div className="space-y-4">
                  <div className="flex justify-between items-start border-b border-slate-800/50 pb-3">
                    <div>
                      <h4 className={`text-sm font-bold ${isDarkMode ? "text-slate-200" : "text-slate-800"}`}>Morphine Sulphate Injection</h4>
                      <p className="text-xs text-slate-500 mt-0.5">MOH Malaysia Standard Formulation</p>
                    </div>
                    <span className="px-2.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider bg-red-500/15 text-red-400">
                      Strong Opioid
                    </span>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className={`p-3 rounded-xl border ${isDarkMode ? "bg-slate-900/50 border-slate-800" : "bg-slate-50 border-slate-200"}`}>
                      <span className="text-[10px] text-slate-400 block font-semibold uppercase tracking-wider">Strengths</span>
                      <strong className={`text-xs mt-1 block ${isDarkMode ? "text-slate-200" : "text-slate-800"}`}>
                        10 mg / 1 ml ampoules
                      </strong>
                    </div>
                    <div className={`p-3 rounded-xl border ${isDarkMode ? "bg-emerald-500/5 border-emerald-500/10" : "bg-emerald-50/50 border-emerald-100"}`}>
                      <span className="text-[10px] text-emerald-400 block font-semibold uppercase tracking-wider">Diluent & Volume</span>
                      <strong className={`text-xs mt-1 block ${isDarkMode ? "text-emerald-300" : "text-emerald-800"}`}>
                        Top up with Water for Injection (WFI) to 24 ml total
                      </strong>
                      <span className="text-[9px] text-slate-500 block mt-0.5">
                        Delivered at 1 ml/hr over 24 hrs via Syringe Driver.
                      </span>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <h5 className={`text-xs font-bold uppercase tracking-wider ${isDarkMode ? "text-teal-400" : "text-teal-700"}`}>
                      Protocol Summary
                    </h5>
                    <ul className="space-y-2 text-xs list-disc list-inside">
                      <li className={isDarkMode ? "text-slate-300" : "text-slate-700"}>
                        <strong>Starting Dose:</strong> 20 mg/24h (titrate to effect).
                      </li>
                      <li className={isDarkMode ? "text-slate-300" : "text-slate-700"}>
                        <strong>Breakthrough PRN:</strong> 1/6th of total daily dose SC.
                      </li>
                      <li className={isDarkMode ? "text-slate-300" : "text-slate-700"}>
                        <strong>Compatibility:</strong> Compatible with Midazolam, Haloperidol, Buscopan in WFI.
                      </li>
                    </ul>
                  </div>

                  <div className="space-y-2">
                    <h5 className="text-xs font-bold uppercase tracking-wider text-red-400">
                      Incompatibilities
                    </h5>
                    <div className={`p-3 rounded-xl text-xs space-y-1.5 ${isDarkMode ? "bg-red-500/5 border border-red-500/10" : "bg-red-50 border border-red-100"}`}>
                      <p className={isDarkMode ? "text-slate-300" : "text-slate-700"}>
                        ⚠️ <strong>Dexamethasone:</strong> Avoid mixing directly; use separate SC line.
                      </p>
                    </div>
                  </div>
                </div>
              )}

              {dilutionSelectedDrug === "midazolam" && (
                <div className="space-y-4">
                  <div className="flex justify-between items-start border-b border-slate-800/50 pb-3">
                    <div>
                      <h4 className={`text-sm font-bold ${isDarkMode ? "text-slate-200" : "text-slate-800"}`}>Midazolam HCl Injection</h4>
                      <p className="text-xs text-slate-500 mt-0.5">MOH Malaysia Standard Formulation</p>
                    </div>
                    <span className="px-2.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider bg-amber-500/15 text-amber-400">
                      Sedative / Anxiolytic
                    </span>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className={`p-3 rounded-xl border ${isDarkMode ? "bg-slate-900/50 border-slate-800" : "bg-slate-50 border-slate-200"}`}>
                      <span className="text-[10px] text-slate-400 block font-semibold uppercase tracking-wider">Strengths</span>
                      <strong className={`text-xs mt-1 block ${isDarkMode ? "text-slate-200" : "text-slate-800"}`}>
                        - 5 mg / 5 ml<br />
                        - 15 mg / 3 ml
                      </strong>
                    </div>
                    <div className={`p-3 rounded-xl border ${isDarkMode ? "bg-emerald-500/5 border-emerald-500/10" : "bg-emerald-50/50 border-emerald-100"}`}>
                      <span className="text-[10px] text-emerald-400 block font-semibold uppercase tracking-wider">Diluent & Volume</span>
                      <strong className={`text-xs mt-1 block ${isDarkMode ? "text-emerald-300" : "text-emerald-800"}`}>
                        Top up with WFI or 0.9% Normal Saline to 24 ml total
                      </strong>
                      <span className="text-[9px] text-slate-500 block mt-0.5">
                        Delivered at 1 ml/hr over 24 hrs via Syringe Driver.
                      </span>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <h5 className={`text-xs font-bold uppercase tracking-wider ${isDarkMode ? "text-teal-400" : "text-teal-700"}`}>
                      Protocol Summary
                    </h5>
                    <ul className="space-y-2 text-xs list-disc list-inside">
                      <li className={isDarkMode ? "text-slate-300" : "text-slate-700"}>
                        <strong>CSCI Rate:</strong> 5-10 mg/24h (titrate up to 30 mg).
                      </li>
                      <li className={isDarkMode ? "text-slate-300" : "text-slate-700"}>
                        <strong>Breakthrough PRN:</strong> 2.5-5 mg SC 2-4 hourly.
                      </li>
                      <li className={isDarkMode ? "text-slate-300" : "text-slate-700"}>
                        <strong>Compatibility:</strong> Compatible with Morphine, Fentanyl, Haloperidol, Buscopan.
                      </li>
                    </ul>
                  </div>

                  <div className="space-y-2">
                    <h5 className="text-xs font-bold uppercase tracking-wider text-red-400">
                      Incompatibilities
                    </h5>
                    <div className={`p-3 rounded-xl text-xs space-y-1.5 ${isDarkMode ? "bg-red-500/5 border border-red-500/10" : "bg-red-50 border border-red-100"}`}>
                      <p className={isDarkMode ? "text-slate-300" : "text-slate-700"}>
                        ⚠️ <strong>Dexamethasone:</strong> NEVER mix; causes immediate precipitation.
                      </p>
                    </div>
                  </div>
                </div>
              )}

              {dilutionSelectedDrug === "fentanyl" && (
                <div className="space-y-4">
                  <div className="flex justify-between items-start border-b border-slate-800/50 pb-3">
                    <div>
                      <h4 className={`text-sm font-bold ${isDarkMode ? "text-slate-200" : "text-slate-800"}`}>Fentanyl Citrate Injection</h4>
                      <p className="text-xs text-slate-500 mt-0.5">MOH Malaysia Standard Formulation</p>
                    </div>
                    <span className="px-2.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider bg-teal-500/15 text-teal-400">
                      Strong Opioid (Renal Safe)
                    </span>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className={`p-3 rounded-xl border ${isDarkMode ? "bg-slate-900/50 border-slate-800" : "bg-slate-50 border-slate-200"}`}>
                      <span className="text-[10px] text-slate-400 block font-semibold uppercase tracking-wider">Strengths</span>
                      <strong className={`text-xs mt-1 block ${isDarkMode ? "text-slate-200" : "text-slate-800"}`}>
                        - 100 mcg / 2 ml<br />
                        - 500 mcg / 10 ml
                      </strong>
                    </div>
                    <div className={`p-3 rounded-xl border ${isDarkMode ? "bg-emerald-500/5 border-emerald-500/10" : "bg-emerald-50/50 border-emerald-100"}`}>
                      <span className="text-[10px] text-emerald-400 block font-semibold uppercase tracking-wider">Diluent & Volume</span>
                      <strong className={`text-xs mt-1 block ${isDarkMode ? "text-emerald-300" : "text-emerald-800"}`}>
                        Top up with 0.9% Normal Saline to 24 ml total
                      </strong>
                      <span className="text-[9px] text-slate-500 block mt-0.5">
                        Delivered at 1 ml/hr over 24 hrs via Syringe Driver.
                      </span>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <h5 className={`text-xs font-bold uppercase tracking-wider ${isDarkMode ? "text-teal-400" : "text-teal-700"}`}>
                      Protocol Summary
                    </h5>
                    <ul className="space-y-2 text-xs list-disc list-inside">
                      <li className={isDarkMode ? "text-slate-300" : "text-slate-700"}>
                        <strong>Indication:</strong> Opioid of choice in renal impairment (eGFR &lt; 30).
                      </li>
                      <li className={isDarkMode ? "text-slate-300" : "text-slate-700"}>
                        <strong>CSCI Rate:</strong> 100-300 mcg/24h.
                      </li>
                      <li className={isDarkMode ? "text-slate-300" : "text-slate-700"}>
                        <strong>Breakthrough PRN:</strong> 25-50 mcg SC 4-hourly.
                      </li>
                    </ul>
                  </div>

                  <div className="space-y-2">
                    <h5 className="text-xs font-bold uppercase tracking-wider text-red-400">
                      Incompatibilities
                    </h5>
                    <div className={`p-3 rounded-xl text-xs space-y-1.5 ${isDarkMode ? "bg-red-500/5 border border-red-500/10" : "bg-red-50 border border-red-100"}`}>
                      <p className={isDarkMode ? "text-slate-300" : "text-slate-700"}>
                        ⚠️ <strong>WFI:</strong> DO NOT use WFI; 0.9% NaCl required for stability.
                      </p>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* INTERACTIVE COMPATIBILITY SIDEBAR */}
            <div className="lg:col-span-4">
              <PalliativeCompatibilityChecker isDarkMode={isDarkMode} />
            </div>
          </div>
          </div>
        </div>
      )}

      {/* SUB-TAB CONTENT 5: FORMULARY */}
      {activeSubTab === "formulary" && (
        <div className="space-y-6">
          {/* DRUG SECTIONS CONTAINER */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* OPIOIDS */}
            <div className={`p-4 rounded-2xl border ${isDarkMode ? "bg-[#111827] border-slate-800" : "bg-white border-slate-200 shadow-sm"}`}>
              <h4 className="text-xs font-bold uppercase tracking-wider text-teal-400 flex items-center gap-1.5 mb-3 border-b border-slate-800 pb-2">
                <Heart className="w-4 h-4 text-red-500 fill-red-500/10" /> Key Opioids (MOH Malaysia)
              </h4>
              <div className="space-y-4">
                <div>
                  <strong className={`text-xs block ${isDarkMode ? "text-slate-200" : "text-slate-800"}`}>Fentanyl Citrate</strong>
                  <p className="text-[11px] text-slate-400 leading-relaxed">
                    - Fentanyl 100mcg/2ml injection.<br />
                    - 12.5mcg/h, 25mcg/h, or 50mcg/h patch (never for opioid naive; lowest patch is 12.5mcg/h by cutting a 25mcg/h patch in half).
                  </p>
                </div>
                <div>
                  <strong className={`text-xs block ${isDarkMode ? "text-slate-200" : "text-slate-800"}`}>Oxycodone IR (Oxynorm)</strong>
                  <p className="text-[11px] text-slate-400 leading-relaxed">
                    - Capsules 5mg or 10mg. High potency oral alternative to morphine.
                  </p>
                </div>
                <div>
                  <strong className={`text-xs block ${isDarkMode ? "text-slate-200" : "text-slate-800"}`}>Morphine Preparations</strong>
                  <p className="text-[11px] text-slate-400 leading-relaxed">
                    - Aqueous: 10mg/5ml syrup or 10mg/1ml concentrated syrup.<br />
                    - MST Continus (Sustained Release): 10mg, 30mg tablets.<br />
                    - Morphine Sulphate Injection: 10mg/1ml ampoule.
                  </p>
                </div>
                <div>
                  <strong className={`text-xs block ${isDarkMode ? "text-slate-200" : "text-slate-800"}`}>Methadone Syrup</strong>
                  <p className="text-[11px] text-slate-400 leading-relaxed">
                    - Methadone HCl 5mg/ml Syrup (60ml bottle). Highly specialty-restricted; very long half-life.
                  </p>
                </div>
              </div>
            </div>

            {/* ADJUVANT ANALGESICS */}
            <div className={`p-4 rounded-2xl border ${isDarkMode ? "bg-[#111827] border-slate-800" : "bg-white border-slate-200 shadow-sm"}`}>
              <h4 className="text-xs font-bold uppercase tracking-wider text-amber-400 flex items-center gap-1.5 mb-3 border-b border-slate-800 pb-2">
                <AlertTriangle className="w-4 h-4 text-amber-500" /> Adjuvant Analgesics
              </h4>
              <div className="space-y-4">
                <div>
                  <strong className={`text-xs block ${isDarkMode ? "text-slate-200" : "text-slate-800"}`}>Systemic NSAIDs</strong>
                  <p className="text-[11px] text-slate-400 leading-relaxed">
                    - Ibuprofen 200mg/400mg (somatic/bone pain).<br />
                    - Celecoxib (Celebrex) 200mg BD or Etoricoxib (Arcoxia) 90mg OD. (Always prescribe with PPI for gastroprotection).
                  </p>
                </div>
                <div>
                  <strong className={`text-xs block ${isDarkMode ? "text-slate-200" : "text-slate-800"}`}>Neuromodulators</strong>
                  <p className="text-[11px] text-slate-400 leading-relaxed">
                    - Gabapentin: Start 100mg ON, titrate up to 300mg TDS (syrup & capsules available).<br />
                    - Amitriptyline: 12.5mg or 25mg ON (excellent for neuropathic pain + insomnia).<br />
                    - Pregabalin (Lyrica): 50mg-75mg ON/BD (fast onset alternative).
                  </p>
                </div>
                <div>
                  <strong className={`text-xs block ${isDarkMode ? "text-slate-200" : "text-slate-800"}`}>Corticosteroids</strong>
                  <p className="text-[11px] text-slate-400 leading-relaxed">
                    - Dexamethasone: 2mg - 8mg daily (up to 16mg daily in divided doses for MSCC/brain edema). Strong anti-inflammatory and appetite stimulant.
                  </p>
                </div>
              </div>
            </div>

            {/* LAXATIVES & ANTIEMETICS */}
            <div className={`p-4 rounded-2xl border ${isDarkMode ? "bg-[#111827] border-slate-800" : "bg-white border-slate-200 shadow-sm"}`}>
              <h4 className="text-xs font-bold uppercase tracking-wider text-teal-400 flex items-center gap-1.5 mb-3 border-b border-slate-800 pb-2">
                <Activity className="w-4 h-4 text-teal-500" /> Laxatives & Antiemetics
              </h4>
              <div className="space-y-4">
                <div>
                  <strong className={`text-xs block ${isDarkMode ? "text-slate-200" : "text-slate-800"}`}>Regular Laxatives (MANDATORY)</strong>
                  <p className="text-[11px] text-slate-400 leading-relaxed">
                    - Syrup Lactulose: 10ml - 15ml ON / BD (osmotic laxative).<br />
                    - Tablet Bisacodyl: 5mg - 10mg ON (stimulant laxative).<br />
                    - Tablet Senna: 15mg (2 tabs) ON (highly standard bowel stimulant).
                  </p>
                </div>
                <div>
                  <strong className={`text-xs block ${isDarkMode ? "text-slate-200" : "text-slate-800"}`}>Antiemetics</strong>
                  <p className="text-[11px] text-slate-400 leading-relaxed">
                    - Metoclopramide (Maxolon): 10mg TDS (prokinetic for gastric stasis/uremia). Avoid in complete obstruction.<br />
                    - Haloperidol: 0.5mg - 1.5mg ON or BD (potent central antiemetic).<br />
                    - SC Cyclizine or Levomepromazine: Useful alternatives.
                  </p>
                </div>
                <div className={`p-2.5 rounded-lg border text-[11px] ${isDarkMode ? "bg-slate-900 border-slate-800" : "bg-slate-50 border-slate-200"}`}>
                  <strong className={`block ${isDarkMode ? "text-slate-300" : "text-slate-700"}`}>Clinical Guideline:</strong>
                  Opioid-induced constipation does NOT develop tolerance. Always prescribe a stimulant (Senna/Bisacodyl) and/or osmotic (Lactulose) laxative concurrently.
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function PalliativeCompatibilityChecker({ isDarkMode }: { isDarkMode: boolean }) {
  const [selectedDrugs, setSelectedDrugs] = useState<{ [key: string]: boolean }>({
    morphine: false,
    midazolam: false,
    fentanyl: false,
    buscopan: false,
    haloperidol: false,
    metoclopramide: false,
    dexamethasone: false,
  });

  const handleToggle = (drug: string) => {
    setSelectedDrugs(prev => {
      const next = { ...prev, [drug]: !prev[drug] };
      // Morphine and Fentanyl are mutually exclusive in a single syringe!
      if (drug === "morphine" && next.morphine) {
        next.fentanyl = false;
      }
      if (drug === "fentanyl" && next.fentanyl) {
        next.morphine = false;
      }
      return next;
    });
  };

  const getActiveList = () => Object.keys(selectedDrugs).filter(k => selectedDrugs[k]);

  const activeDrugs = getActiveList();

  // Compatibility Engine
  let status: "empty" | "compatible" | "warning" | "incompatible" = "empty";
  let diluent = "WFI or 0.9% NaCl";
  let message = "";
  let details: string[] = [];

  if (activeDrugs.length === 0) {
    status = "empty";
    message = "Select drugs below to check compatibility in a single 24-hour subcutaneous syringe driver.";
  } else if (activeDrugs.length === 1) {
    status = "compatible";
    const drug = activeDrugs[0];
    diluent = drug === "fentanyl" ? "0.9% Normal Saline" : "Water for Injection (WFI) or 0.9% NaCl";
    message = "Single drug infusion is fully compatible.";
    details = [`Diluting with ${diluent} is standard practice.`];
  } else {
    const hasMorphine = selectedDrugs.morphine;
    const hasFentanyl = selectedDrugs.fentanyl;
    const hasMidazolam = selectedDrugs.midazolam;
    const hasDexamethasone = selectedDrugs.dexamethasone;
    const hasHaloperidol = selectedDrugs.haloperidol;
    const hasBuscopan = selectedDrugs.buscopan;

    if (hasFentanyl) {
      diluent = "0.9% Normal Saline (NaCl)";
    } else {
      diluent = "Water for Injection (WFI)";
    }

    if (hasMidazolam && hasDexamethasone) {
      status = "incompatible";
      message = "❌ Incompatible (Precipitation Hazard)";
      details.push("Midazolam (acidic) and Dexamethasone (alkaline sodium phosphate) will precipitate immediately if mixed in the same syringe.");
      details.push("Action: MUST administer Dexamethasone as a separate SC injection, or place via separate SC cannula.");
    } else if (hasMorphine && hasDexamethasone) {
      status = "warning";
      message = "⚠️ High Risk of Precipitation";
      details.push("Morphine and Dexamethasone have limited compatibility depending on concentration. Mixing them is highly discouraged in Malaysian clinical practice due to high risk of crystallization.");
      details.push("Action: Administer Dexamethasone as a separate once-daily morning SC injection.");
    } else if (hasFentanyl && hasDexamethasone) {
      status = "warning";
      message = "⚠️ Risk of Precipitation";
      details.push("Fentanyl and Dexamethasone are poorly compatible in a single syringe. High risk of precipitation.");
      details.push("Action: Give Dexamethasone as a separate SC injection.");
    } else if (activeDrugs.length > 3) {
      status = "warning";
      message = "⚠️ Caution: High Drug Count";
      details.push("Mixing more than 3 drugs in a single syringe driver is discouraged due to unpredictable chemical stability and high crystallization risk.");
      details.push("Try to split into two separate syringe drivers, or switch to breakthrough PRN injections if appropriate.");
      if (hasFentanyl) {
        details.push("Diluent MUST be 0.9% Normal Saline to keep Fentanyl stable.");
      } else {
        details.push("Preferred Diluent is Water for Injection (WFI) to minimize precipitation with other drugs.");
      }
    } else {
      status = "compatible";
      message = "✅ Compatible Cocktail";
      if (hasFentanyl) {
        details.push("Diluent MUST be 0.9% Normal Saline (Fentanyl in WFI has precipitation risk when mixed).");
      } else {
        details.push("Preferred Diluent is Water for Injection (WFI) to prevent crystallization and reduce subcutaneous site irritation.");
      }
      details.push("Ensure syringe is visually inspected for cloudiness or crystals after preparation and during infusion.");
    }
  }

  const drugLabels: { [key: string]: string } = {
    morphine: "Morphine Sulphate",
    midazolam: "Midazolam",
    fentanyl: "Fentanyl Citrate",
    buscopan: "Buscopan (Hyoscine)",
    haloperidol: "Haloperidol",
    metoclopramide: "Metoclopramide",
    dexamethasone: "Dexamethasone",
  };

  return (
    <div className={`p-4 rounded-2xl border ${isDarkMode ? "bg-slate-900/50 border-slate-800" : "bg-slate-50 border-slate-200 shadow-sm"}`}>
      <h4 className={`text-xs font-bold uppercase tracking-wider mb-2.5 ${isDarkMode ? "text-slate-300" : "text-slate-700"}`}>
        Syringe Compatibility Checker
      </h4>
      <p className={`text-[11px] mb-3 leading-relaxed ${isDarkMode ? "text-slate-400" : "text-slate-500"}`}>
        Combine medications to check stability & diluent selection based on Malaysian clinical practice guidelines.
      </p>

      {/* Checklist */}
      <div className="space-y-1.5 mb-4">
        {Object.keys(drugLabels).map((drug) => (
          <label
            key={drug}
            className={`flex items-center gap-2 p-2 rounded-xl border text-xs cursor-pointer transition-all ${
              selectedDrugs[drug]
                ? isDarkMode
                  ? "bg-teal-500/10 border-teal-500/30 text-teal-400 font-semibold"
                  : "bg-teal-50 border-teal-200 text-teal-800 font-semibold"
                : isDarkMode
                  ? "bg-slate-950/40 border-slate-800/60 text-slate-400 hover:border-slate-700"
                  : "bg-white border-slate-200 text-slate-600 hover:border-slate-300 shadow-sm"
            }`}
          >
            <input
              type="checkbox"
              checked={selectedDrugs[drug]}
              onChange={() => handleToggle(drug)}
              className="rounded text-teal-500 border-slate-300 focus:ring-teal-500/30 w-3.5 h-3.5"
            />
            <span>{drugLabels[drug]}</span>
          </label>
        ))}
      </div>

      {/* Results panel */}
      <div className={`p-3 rounded-xl border ${
        status === "empty"
          ? isDarkMode ? "bg-slate-950/40 border-slate-800 text-slate-400" : "bg-white border-slate-200 text-slate-500"
          : status === "compatible"
            ? isDarkMode ? "bg-emerald-500/10 border-emerald-500/20 text-emerald-300" : "bg-emerald-50 border-emerald-200 text-emerald-800"
            : status === "warning"
              ? isDarkMode ? "bg-amber-500/10 border-amber-500/20 text-amber-300" : "bg-amber-50 border-amber-200 text-amber-800"
              : isDarkMode ? "bg-red-500/10 border-red-500/20 text-red-300" : "bg-red-50 border-red-200 text-red-800"
      }`}>
        {status !== "empty" && (
          <div className="mb-2">
            <span className="text-xs font-bold block">{message}</span>
            <span className="text-[10px] block mt-1 font-mono">
              Recommended Diluent: <strong>{diluent}</strong>
            </span>
          </div>
        )}
        <div className="text-[11px] leading-relaxed space-y-1">
          {status === "empty" ? (
            <p className="text-center py-2">{message}</p>
          ) : (
            details.map((detail, idx) => (
              <p key={idx} className="flex gap-1" style={{ textIndent: "-8px", paddingLeft: "8px" }}>
                <span>•</span>
                <span>{detail}</span>
              </p>
            ))
          )}
        </div>
      </div>
    </div>
  );
}

