import React, { useState, useMemo } from "react";
import { 
  Activity, 
  Calculator, 
  ShieldAlert, 
  Database, 
  HelpCircle, 
  Search, 
  TrendingUp, 
  Info, 
  CheckCircle2, 
  ChevronRight, 
  Play, 
  RotateCcw,
  Plus,
  Trash2,
  Lock,
  Copy,
  Check,
  AlertTriangle
} from "lucide-react";

interface CriticalCareNutritionProps {
  isDarkMode: boolean;
}

// Formulation Database
interface Formulation {
  name: string;
  category: "Standard" | "Glycemic Control" | "Low Electrolyte / Fluid Restricted" | "Modified Fiber" | "Semi-hydrolyzed";
  type: "RTU" | "Powder";
  energy: number; // kcal/ml
  protein: number; // g/L
  sodium: number; // mg/L
  lactose: string;
  rate: string; // ml/hr
  preparation?: string;
  relevance?: string;
}

const FORMULATIONS: Formulation[] = [
  {
    name: "Ensure Gold Liquid*",
    category: "Standard",
    type: "RTU",
    energy: 1.2,
    protein: 50,
    sodium: 733,
    lactose: "Free",
    rate: "30/50/75",
    relevance: "Currently available standard option"
  },
  {
    name: "Ensure Gold*",
    category: "Standard",
    type: "Powder",
    energy: 1.0,
    protein: 39,
    sodium: 728,
    lactose: "Free",
    rate: "30/50/75/100",
    preparation: "9 scoops + H2O = 400 ml"
  },
  {
    name: "Nutren Optimum*",
    category: "Standard",
    type: "Powder",
    energy: 1.0,
    protein: 40,
    sodium: 456,
    lactose: "Free",
    rate: "30/50/75/100",
    preparation: "11 scoops + H2O = 400 ml"
  },
  {
    name: "Glucerna RTD*",
    category: "Glycemic Control",
    type: "RTU",
    energy: 1.0,
    protein: 42,
    sodium: 930,
    lactose: "Free",
    rate: "30/50/75/100"
  },
  {
    name: "Glucerna*",
    category: "Glycemic Control",
    type: "Powder",
    energy: 1.0,
    protein: 46,
    sodium: 948,
    lactose: "Free",
    rate: "30/50/75/100",
    preparation: "9 scoops + H2O = 400 ml"
  },
  {
    name: "Supplement-D*",
    category: "Glycemic Control",
    type: "Powder",
    energy: 1.0,
    protein: 45,
    sodium: 954,
    lactose: "Free",
    rate: "30/50/75/100",
    preparation: "9 scoops + H2O = 400 ml"
  },
  {
    name: "Renomed*",
    category: "Low Electrolyte / Fluid Restricted",
    type: "RTU",
    energy: 1.8,
    protein: 81,
    sodium: 793,
    lactose: "Free",
    rate: "30/50",
    relevance: "Low electrolyte (Na, P, K) or require fluid restriction. *Currently available (subject to local budget availability)"
  },
  {
    name: "Nepro HP",
    category: "Low Electrolyte / Fluid Restricted",
    type: "RTU",
    energy: 1.8,
    protein: 81,
    sodium: 700,
    lactose: "Free",
    rate: "30/50",
    relevance: "Low electrolyte (Na, P, K) or require fluid restriction"
  },
  {
    name: "Novasource Renal",
    category: "Low Electrolyte / Fluid Restricted",
    type: "RTU",
    energy: 2.0,
    protein: 91,
    sodium: 610,
    lactose: "Free",
    rate: "30/50"
  },
  {
    name: "Jevity",
    category: "Modified Fiber",
    type: "RTU",
    energy: 1.0,
    protein: 44,
    sodium: 928,
    lactose: "Free",
    rate: "30/50/75/100",
    relevance: "Modified fiber for diarrhea & constipation"
  },
  {
    name: "ActivMax FOS*",
    category: "Modified Fiber",
    type: "Powder",
    energy: 1.0,
    protein: 42,
    sodium: 886,
    lactose: "Free",
    rate: "30/50/75/100",
    preparation: "7 scoops + H2O = 400 ml"
  },
  {
    name: "Nutren Fibre",
    category: "Modified Fiber",
    type: "Powder",
    energy: 1.0,
    protein: 41,
    sodium: 979,
    lactose: "Free",
    rate: "30/50/75/100",
    preparation: "13 scoops + H2O = 400 ml"
  },
  {
    name: "Vital*",
    category: "Semi-hydrolyzed",
    type: "RTU",
    energy: 1.5,
    protein: 67.5,
    sodium: 1690,
    lactose: "Free",
    rate: "30/50/75",
    relevance: "Semi-hydrolysed formula for impaired GI function"
  },
  {
    name: "Semital*",
    category: "Semi-hydrolyzed",
    type: "Powder",
    energy: 1.0,
    protein: 47,
    sodium: 281,
    lactose: "Free",
    rate: "30/50/75/100",
    preparation: "9 scoops + H2O = 400 ml"
  },
  {
    name: "Peptamen",
    category: "Semi-hydrolyzed",
    type: "Powder",
    energy: 1.0,
    protein: 40,
    sodium: 853,
    lactose: "Free",
    rate: "30/50/75/100",
    preparation: "11 scoops + H2O = 400 ml"
  }
];

export default function CriticalCareNutrition({ isDarkMode }: CriticalCareNutritionProps) {
  const [activeSubTab, setActiveSubTab] = useState<"calc" | "refeeding" | "protocol" | "formulas" | "safe">("calc");

  // --- CALCULATOR STATES ---
  const [gender, setGender] = useState<"male" | "female" | "none">("none");
  const [weight, setWeight] = useState<string>("");
  const [height, setHeight] = useState<string>("");
  const [clinicalScenario, setClinicalScenario] = useState<"standard" | "hd" | "crrt" | "burns" | "trophic">("standard");
  const [calorieMultiplier, setCalorieMultiplier] = useState<number>(22.5); // Default in the middle of 20-25
  const [proteinMultiplier, setProteinMultiplier] = useState<number>(1.5); // Default in the middle of 1.3-2.0

  // --- REFEEDING SYNDROME RISK CHECKLIST ---
  const [rfsBmiUnder, setRfsBmiUnder] = useState<boolean>(false);
  const [rfsWeightLoss, setRfsWeightLoss] = useState<boolean>(false);
  const [rfsNoIntake, setRfsNoIntake] = useState<boolean>(false);
  const [rfsLowElectrolytes, setRfsLowElectrolytes] = useState<boolean>(false);
  const [rfsAlcoholDrugs, setRfsAlcoholDrugs] = useState<boolean>(false);

  // --- PROTOCOL SIMULATOR STATES ---
  const [feedingMethod, setFeedingMethod] = useState<"continuous" | "intermittent" | "bolus">("continuous");
  const [grvInput, setGrvInput] = useState<string>("");
  const [grvSubmitted, setGrvSubmitted] = useState<boolean>(false);
  const [intoleranceEpisode, setIntoleranceEpisode] = useState<"none" | "1st" | "2nd" | "3rd">("none");

  // --- FORMULA DATABASE STATES ---
  const [formSearch, setFormSearch] = useState<string>("");
  const [formFilter, setFormFilter] = useState<string>("All");

  // --- CALCULATIONS ---
  const calculatedBmi = useMemo(() => {
    const w = parseFloat(weight);
    const h = parseFloat(height);
    if (!w || !h) return null;
    const hMeter = h / 100;
    return w / (hMeter * hMeter);
  }, [weight, height]);

  const calculatedBmiCategory = useMemo(() => {
    if (!calculatedBmi) return "";
    if (calculatedBmi < 18.5) return "Underweight (<18.5)";
    if (calculatedBmi < 25) return "Normal Weight (18.5 - 24.9)";
    if (calculatedBmi < 30) return "Overweight (25.0 - 29.9)";
    if (calculatedBmi < 50) return "Obese Class I/II (30.0 - 49.9)";
    return "Obese Class III / Super Obese (≥50.0)";
  }, [calculatedBmi]);

  const calculatedIbw = useMemo(() => {
    const h = parseFloat(height);
    if (!h || gender === "none") return null;
    // Formula:
    // Male: 50 + 0.91 * (Height - 152.4)
    // Female: 45.5 + 0.91 * (Height - 152.4)
    const baseWeight = gender === "male" ? 50 : 45.5;
    return baseWeight + 0.91 * (h - 152.4);
  }, [height, gender]);

  // Determine weight reference based on BMI
  const weightReference = useMemo(() => {
    if (!calculatedBmi) return "TBW";
    if (calculatedBmi < 18.5) return "IBW";
    if (calculatedBmi < 30.0) return "TBW";
    if (calculatedBmi < 50.0) return "TBW";
    return "IBW"; // BMI > 50
  }, [calculatedBmi]);

  const activeWeightUsedForEnergy = useMemo(() => {
    const tbw = parseFloat(weight) || 0;
    const ibw = calculatedIbw || tbw;
    if (weightReference === "IBW") return ibw;
    return tbw;
  }, [weight, calculatedIbw, weightReference]);

  const activeWeightUsedForProtein = useMemo(() => {
    const tbw = parseFloat(weight) || 0;
    const ibw = calculatedIbw || tbw;
    // Rule: Ideal body weight used for BMI > 30 for protein
    if (calculatedBmi && calculatedBmi > 30.0) {
      return ibw;
    }
    if (weightReference === "IBW") return ibw;
    return tbw;
  }, [weight, calculatedIbw, calculatedBmi, weightReference]);

  // Calorie and Protein target calculations
  const energyRequirement = useMemo(() => {
    const w = activeWeightUsedForEnergy;
    if (!w) return null;

    if (clinicalScenario === "trophic") {
      return { min: 240, max: 500, label: "Trophic Feeding (10-20 kcal/h or ~500 kcal/day)" };
    }

    if (!calculatedBmi) {
      // Standard fallback
      return { min: w * 20, max: w * 25, label: "20 - 25 kcal/kg/day (Standard)" };
    }

    if (calculatedBmi < 18.5) {
      return { min: w * 20, max: w * 25, label: "20 - 25 kcal/kg/day of IBW (BMI < 18.5)" };
    } else if (calculatedBmi < 30.0) {
      return { min: w * 20, max: w * 25, label: "20 - 25 kcal/kg/day of TBW (BMI 18.5 - 29.9)" };
    } else if (calculatedBmi < 50.0) {
      return { min: w * 11, max: w * 14, label: "11 - 14 kcal/kg/day of TBW (BMI 30 - 50)" };
    } else {
      return { min: w * 22, max: w * 25, label: "22 - 25 kcal/kg/day of IBW (BMI > 50)" };
    }
  }, [activeWeightUsedForEnergy, calculatedBmi, clinicalScenario]);

  const proteinRequirement = useMemo(() => {
    const w = activeWeightUsedForProtein;
    if (!w) return null;

    // Based on clinicalScenario
    switch (clinicalScenario) {
      case "standard":
        return { min: w * 1.3, max: w * 2.0, rangeLabel: "1.3 - 2.0 g/kg/day", text: "Standard Critical Illness Target" };
      case "hd":
        return { min: w * 1.3, max: w * 1.5, rangeLabel: "1.3 - 1.5 g/kg/day", text: "Intermittent Hemodialysis Dose" };
      case "crrt":
        return { min: w * 2.0, max: w * 2.5, rangeLabel: "2.0 - 2.5 g/kg/day", text: "Continuous Renal Replacement Therapy Dose" };
      case "burns":
        return { min: w * 1.5, max: w * 2.0, rangeLabel: "1.5 - 2.0 g/kg/day", text: "Severe Burn / Trauma Dose" };
      case "trophic":
        return { min: w * 1.2, max: w * 1.5, rangeLabel: "≥1.2 g/kg/day", text: "Aim for early protein even during trophic feeding" };
    }
  }, [activeWeightUsedForProtein, clinicalScenario]);

  // Determine RFS Risk Criteria
  const rfsSelectedCount = useMemo(() => {
    let count = 0;
    if (rfsBmiUnder) count++;
    if (rfsWeightLoss) count++;
    if (rfsNoIntake) count++;
    if (rfsLowElectrolytes) count++;
    if (rfsAlcoholDrugs) count++;
    return count;
  }, [rfsBmiUnder, rfsWeightLoss, rfsNoIntake, rfsLowElectrolytes, rfsAlcoholDrugs]);

  const rfsRiskLevel = useMemo(() => {
    // If the patient has BMI calculated and it's < 18.5, we should automatically suggest the BMI check is active
    const bmiUnderVal = (calculatedBmi && calculatedBmi < 18.5) || rfsBmiUnder;
    let count = 0;
    if (bmiUnderVal) count++;
    if (rfsWeightLoss) count++;
    if (rfsNoIntake) count++;
    if (rfsLowElectrolytes) count++;
    if (rfsAlcoholDrugs) count++;

    if (count >= 2) return "HIGH RISK";
    if (count === 1) return "MODERATE RISK";
    return "LOW RISK";
  }, [calculatedBmi, rfsBmiUnder, rfsWeightLoss, rfsNoIntake, rfsLowElectrolytes, rfsAlcoholDrugs]);

  // Handle auto checkbox for BMI underweight
  React.useEffect(() => {
    if (calculatedBmi !== null) {
      setRfsBmiUnder(calculatedBmi < 18.5);
    }
  }, [calculatedBmi]);

  // Filtering formulas
  const filteredFormulations = useMemo(() => {
    return FORMULATIONS.filter(f => {
      const matchesSearch = f.name.toLowerCase().includes(formSearch.toLowerCase()) || 
                            f.category.toLowerCase().includes(formSearch.toLowerCase());
      const matchesFilter = formFilter === "All" || f.category === formFilter;
      return matchesSearch && matchesFilter;
    });
  }, [formSearch, formFilter]);

  return (
    <div className={`rounded-xl border ${isDarkMode ? "bg-slate-950 border-slate-800" : "bg-white border-slate-200"} shadow-xl overflow-hidden`}>
      
      {/* SECTION HEADER */}
      <div className={`p-5 border-b ${isDarkMode ? "bg-gradient-to-r from-red-950/20 to-amber-950/20 border-slate-800" : "bg-gradient-to-r from-red-50 to-amber-50 border-slate-200"}`}>
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className={`p-2.5 rounded-xl ${isDarkMode ? "bg-rose-500/10 text-rose-400" : "bg-rose-50 text-rose-600"}`}>
              <Activity className="w-5 h-5" />
            </div>
            <div>
              <h2 className={`text-base font-bold tracking-tight ${isDarkMode ? "text-slate-100" : "text-slate-900"}`}>
                Critical Care Nutrition
              </h2>
              <p className={`text-xs ${isDarkMode ? "text-slate-400" : "text-slate-600"} mt-0.5`}>
                Enteral & Parenteral feeding algorithms, formulations database, & Refeeding Syndrome advisor
              </p>
            </div>
          </div>
          <div className="flex items-center gap-1 text-[11px] font-mono rounded-lg px-2.5 py-1 bg-slate-900/40 border border-slate-800/40 text-amber-500">
            <Info className="w-3.5 h-3.5 mr-1 text-amber-500" />
            Clinical Feeding Protocol (AIM Dept)
          </div>
        </div>
      </div>

      {/* INTERNAL NAVIGATION */}
      <div className={`flex border-b overflow-x-auto scrollbar-none ${isDarkMode ? "bg-slate-900/40 border-slate-800" : "bg-slate-50 border-slate-200"}`}>
        <button
          onClick={() => setActiveSubTab("calc")}
          className={`flex items-center gap-1.5 px-4 py-3 text-xs font-bold uppercase border-b-2 tracking-wider transition-all whitespace-nowrap cursor-pointer ${
            activeSubTab === "calc"
              ? "border-rose-500 text-rose-500 bg-rose-500/5"
              : `border-transparent ${isDarkMode ? "text-slate-400 hover:text-slate-200" : "text-slate-600 hover:text-slate-800"}`
          }`}
        >
          <Calculator className="w-4 h-4" />
          1. Target Calculator
        </button>
        <button
          onClick={() => setActiveSubTab("refeeding")}
          className={`flex items-center gap-1.5 px-4 py-3 text-xs font-bold uppercase border-b-2 tracking-wider transition-all whitespace-nowrap cursor-pointer ${
            activeSubTab === "refeeding"
              ? "border-rose-500 text-rose-500 bg-rose-500/5"
              : `border-transparent ${isDarkMode ? "text-slate-400 hover:text-slate-200" : "text-slate-600 hover:text-slate-800"}`
          }`}
        >
          <ShieldAlert className="w-4 h-4" />
          2. Refeeding Syndrome
        </button>
        <button
          onClick={() => setActiveSubTab("protocol")}
          className={`flex items-center gap-1.5 px-4 py-3 text-xs font-bold uppercase border-b-2 tracking-wider transition-all whitespace-nowrap cursor-pointer ${
            activeSubTab === "protocol"
              ? "border-rose-500 text-rose-500 bg-rose-500/5"
              : `border-transparent ${isDarkMode ? "text-slate-400 hover:text-slate-200" : "text-slate-600 hover:text-slate-800"}`
          }`}
        >
          <TrendingUp className="w-4 h-4" />
          3. Feeding Protocol
        </button>
        <button
          onClick={() => setActiveSubTab("formulas")}
          className={`flex items-center gap-1.5 px-4 py-3 text-xs font-bold uppercase border-b-2 tracking-wider transition-all whitespace-nowrap cursor-pointer ${
            activeSubTab === "formulas"
              ? "border-rose-500 text-rose-500 bg-rose-500/5"
              : `border-transparent ${isDarkMode ? "text-slate-400 hover:text-slate-200" : "text-slate-600 hover:text-slate-800"}`
          }`}
        >
          <Database className="w-4 h-4" />
          4. Formulation DB
        </button>
        <button
          onClick={() => setActiveSubTab("safe")}
          className={`flex items-center gap-1.5 px-4 py-3 text-xs font-bold uppercase border-b-2 tracking-wider transition-all whitespace-nowrap cursor-pointer ${
            activeSubTab === "safe"
              ? "border-rose-500 text-rose-500 bg-rose-500/5"
              : `border-transparent ${isDarkMode ? "text-slate-400 hover:text-slate-200" : "text-slate-600 hover:text-slate-800"}`
          }`}
        >
          <CheckCircle2 className="w-4 h-4" />
          5. Parenteral & Safe Practice
        </button>
      </div>

      {/* CONTENT BODY */}
      <div className="p-5">

        {/* SUBTAB 1: TARGET CALCULATOR */}
        {activeSubTab === "calc" && (
          <div className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              
              {/* INPUT PANEL */}
              <div className="lg:col-span-5 space-y-4">
                <div className={`p-4 rounded-xl border ${isDarkMode ? "bg-slate-900/50 border-slate-800" : "bg-slate-50 border-slate-200"}`}>
                  <h3 className={`text-xs font-bold uppercase tracking-wider mb-3 flex items-center gap-2 ${isDarkMode ? "text-slate-300" : "text-slate-700"}`}>
                    <Calculator className="w-4 h-4 text-rose-500" />
                    Patient Demographics
                  </h3>
                  
                  <div className="space-y-3">
                    {/* Gender Selection */}
                    <div>
                      <label className={`block text-xs font-medium mb-1.5 ${isDarkMode ? "text-slate-400" : "text-slate-700"}`}>
                        Patient Gender
                      </label>
                      <div className="grid grid-cols-2 gap-2">
                        <button
                          onClick={() => setGender("male")}
                          className={`py-2 text-xs font-bold rounded-lg border transition-all ${
                            gender === "male"
                              ? "bg-rose-500 text-slate-950 border-rose-500"
                              : isDarkMode
                                ? "bg-slate-950 border-slate-800 text-slate-300 hover:bg-slate-800/50"
                                : "bg-white border-slate-200 text-slate-700 hover:bg-slate-100"
                          }`}
                        >
                          Male
                        </button>
                        <button
                          onClick={() => setGender("female")}
                          className={`py-2 text-xs font-bold rounded-lg border transition-all ${
                            gender === "female"
                              ? "bg-rose-500 text-slate-950 border-rose-500"
                              : isDarkMode
                                ? "bg-slate-950 border-slate-800 text-slate-300 hover:bg-slate-800/50"
                                : "bg-white border-slate-200 text-slate-700 hover:bg-slate-100"
                          }`}
                        >
                          Female
                        </button>
                      </div>
                    </div>

                    {/* Weight and Height */}
                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label className={`block text-xs font-medium mb-1 ${isDarkMode ? "text-slate-400" : "text-slate-700"}`}>
                          Actual Weight (TBW)
                        </label>
                        <div className="relative">
                          <input
                            type="number"
                            value={weight}
                            onChange={(e) => setWeight(e.target.value)}
                            placeholder="e.g. 70"
                            className={`w-full px-3 py-1.5 text-xs rounded-lg border focus:outline-none focus:ring-1 focus:ring-rose-500 ${
                              isDarkMode ? "bg-slate-950 border-slate-800 text-slate-200" : "bg-white border-slate-300 text-slate-800"
                            }`}
                          />
                          <span className="absolute right-3 top-1/2 -translate-y-1/2 text-[10px] text-slate-500 font-mono">kg</span>
                        </div>
                      </div>
                      <div>
                        <label className={`block text-xs font-medium mb-1 ${isDarkMode ? "text-slate-400" : "text-slate-700"}`}>
                          Height
                        </label>
                        <div className="relative">
                          <input
                            type="number"
                            value={height}
                            onChange={(e) => setHeight(e.target.value)}
                            placeholder="e.g. 170"
                            className={`w-full px-3 py-1.5 text-xs rounded-lg border focus:outline-none focus:ring-1 focus:ring-rose-500 ${
                              isDarkMode ? "bg-slate-950 border-slate-800 text-slate-200" : "bg-white border-slate-300 text-slate-800"
                            }`}
                          />
                          <span className="absolute right-3 top-1/2 -translate-y-1/2 text-[10px] text-slate-500 font-mono">cm</span>
                        </div>
                      </div>
                    </div>

                    {/* Clinical Scenario */}
                    <div>
                      <label className={`block text-xs font-medium mb-1 ${isDarkMode ? "text-slate-400" : "text-slate-700"}`}>
                        Clinical State / Condition
                      </label>
                      <select
                        value={clinicalScenario}
                        onChange={(e) => setClinicalScenario(e.target.value as any)}
                        className={`w-full px-3 py-2 text-xs rounded-lg border focus:outline-none focus:ring-1 focus:ring-rose-500 ${
                          isDarkMode ? "bg-slate-950 border-slate-800 text-slate-200" : "bg-white border-slate-300 text-slate-800"
                        }`}
                      >
                        <option value="standard">Standard ICU Patient (1.3 - 2.0g protein)</option>
                        <option value="hd">Intermittent Hemodialysis (1.3 - 1.5g protein)</option>
                        <option value="crrt">Continuous Renal Replacement Therapy (CRRT: 2.0 - 2.5g protein)</option>
                        <option value="burns">Severe Burns / Trauma (1.5 - 2.0g protein)</option>
                        <option value="trophic">Low Vasopressor Support Trophic Feeding (10-20 kcal/h)</option>
                      </select>
                    </div>
                  </div>
                </div>

                <div className={`p-4 rounded-xl border ${isDarkMode ? "bg-slate-900/50 border-slate-800 text-slate-300" : "bg-slate-50 border-slate-200 text-slate-600"} text-xs leading-relaxed space-y-2`}>
                  <div className="flex items-start gap-2">
                    <Info className="w-4 h-4 text-amber-500 mt-0.5 shrink-0" />
                    <div>
                      <span className="font-bold text-amber-500">Weight Reference Rules (ESPEN/ASPEN):</span>
                      <ul className="list-disc pl-4 mt-1 space-y-1">
                        <li>BMI &lt; 18.5 (Malnourished) &rarr; Calculate targets via **Ideal Body Weight (IBW)**.</li>
                        <li>BMI &ge; 50 (Severely Obese) &rarr; Calculate energy via **Ideal Body Weight (IBW)**.</li>
                        <li>BMI 18.5 - 49.9 &rarr; Calculate via **Total Body Weight (TBW)**.</li>
                        <li><span className="underline">Protein Exception</span>: Always use **IBW** for BMI &gt; 30 to prevent over-dosing.</li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>

              {/* OUTPUT PANEL */}
              <div className="lg:col-span-7 space-y-4">
                <div className={`p-5 rounded-xl border ${isDarkMode ? "bg-slate-900/30 border-slate-800" : "bg-white border-slate-200"} relative overflow-hidden`}>
                  <div className="absolute top-0 right-0 p-3 opacity-10">
                    <TrendingUp className="w-24 h-24 text-rose-500" />
                  </div>

                  <h3 className={`text-sm font-bold tracking-tight mb-4 ${isDarkMode ? "text-slate-100" : "text-slate-900"} flex items-center gap-2`}>
                    <TrendingUp className="w-4 h-4 text-rose-500" />
                    Calculated Nutrition Targets
                  </h3>

                  {(!weight || !height) ? (
                    <div className="flex flex-col items-center justify-center py-10 text-center">
                      <HelpCircle className="w-10 h-10 text-slate-500 mb-2" />
                      <p className={`text-xs ${isDarkMode ? "text-slate-400" : "text-slate-600"} max-w-xs`}>
                        Enter patient demographics (weight, height, gender) to view customized daily caloric & protein goals.
                      </p>
                    </div>
                  ) : (
                    <div className="space-y-5">
                      
                      {/* STATS ROW */}
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                        <div className={`p-3 rounded-lg ${isDarkMode ? "bg-slate-900" : "bg-slate-100"}`}>
                          <span className="block text-[10px] text-slate-500 uppercase font-mono font-bold">Patient BMI</span>
                          <span className={`block text-sm font-extrabold ${isDarkMode ? "text-slate-100" : "text-slate-900"} mt-0.5`}>
                            {calculatedBmi ? calculatedBmi.toFixed(1) : "--"} <span className="text-[10px] font-normal">kg/m²</span>
                          </span>
                          <span className="block text-[9px] text-slate-400 mt-0.5 font-medium truncate">
                            {calculatedBmiCategory}
                          </span>
                        </div>
                        <div className={`p-3 rounded-lg ${isDarkMode ? "bg-slate-900" : "bg-slate-100"}`}>
                          <span className="block text-[10px] text-slate-500 uppercase font-mono font-bold">Ideal Wt (IBW)</span>
                          <span className={`block text-sm font-extrabold ${isDarkMode ? "text-slate-100" : "text-slate-900"} mt-0.5`}>
                            {calculatedIbw ? `${calculatedIbw.toFixed(1)}` : "--"} <span className="text-[10px] font-normal">kg</span>
                          </span>
                          <span className="block text-[9px] text-slate-400 mt-0.5 font-medium">
                            {gender !== "none" ? "Devine Formula" : "Select Gender first"}
                          </span>
                        </div>
                        <div className={`p-3 rounded-lg ${isDarkMode ? "bg-slate-900" : "bg-slate-100"}`}>
                          <span className="block text-[10px] text-slate-500 uppercase font-mono font-bold">Energy Ref Wt</span>
                          <span className={`block text-sm font-extrabold text-amber-500 mt-0.5`}>
                            {activeWeightUsedForEnergy ? `${activeWeightUsedForEnergy.toFixed(1)}` : "--"} <span className="text-[10px] font-normal">kg</span>
                          </span>
                          <span className="block text-[9px] text-slate-400 mt-0.5 font-medium">
                            Based on {weightReference} rules
                          </span>
                        </div>
                        <div className={`p-3 rounded-lg ${isDarkMode ? "bg-slate-900" : "bg-slate-100"}`}>
                          <span className="block text-[10px] text-slate-500 uppercase font-mono font-bold">Protein Ref Wt</span>
                          <span className={`block text-sm font-extrabold text-teal-400 mt-0.5`}>
                            {activeWeightUsedForProtein ? `${activeWeightUsedForProtein.toFixed(1)}` : "--"} <span className="text-[10px] font-normal">kg</span>
                          </span>
                          <span className="block text-[9px] text-slate-400 mt-0.5 font-medium">
                            {calculatedBmi && calculatedBmi > 30.0 ? "IBW (BMI > 30 Exception)" : "Standard reference"}
                          </span>
                        </div>
                      </div>

                      {/* TARGET RESULTS CARDS */}
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        
                        {/* CALORIC GOAL */}
                        <div className={`p-4 rounded-xl border ${isDarkMode ? "bg-amber-950/10 border-amber-900/30 text-amber-100" : "bg-amber-50/50 border-amber-200 text-amber-900"}`}>
                          <span className="text-[10px] font-mono font-bold uppercase tracking-wider text-amber-500">Daily Calorie Target</span>
                          <div className="mt-1 flex items-baseline gap-1.5">
                            <span className="text-2xl font-black">
                              {energyRequirement ? `${Math.round(energyRequirement.min)} - ${Math.round(energyRequirement.max)}` : "--"}
                            </span>
                            <span className="text-xs font-bold font-mono">kcal/day</span>
                          </div>
                          <span className="block text-[10px] text-slate-400 mt-2 font-mono leading-tight">
                            ℹ️ {energyRequirement?.label}
                          </span>
                        </div>

                        {/* PROTEIN GOAL */}
                        <div className={`p-4 rounded-xl border ${isDarkMode ? "bg-teal-950/10 border-teal-900/30 text-teal-100" : "bg-teal-50/50 border-teal-200 text-teal-900"}`}>
                          <span className="text-[10px] font-mono font-bold uppercase tracking-wider text-teal-400">Daily Protein Target</span>
                          <div className="mt-1 flex items-baseline gap-1.5">
                            <span className="text-2xl font-black">
                              {proteinRequirement ? `${Math.round(proteinRequirement.min)} - ${Math.round(proteinRequirement.max)}` : "--"}
                            </span>
                            <span className="text-xs font-bold font-mono">g/day</span>
                          </div>
                          <span className="block text-[10px] text-slate-400 mt-2 leading-tight">
                            ℹ️ {proteinRequirement?.rangeLabel} ({proteinRequirement?.text})
                          </span>
                          <span className="block text-[9px] text-slate-500 mt-1">
                            Supplements: Myotein/Miralac [5g per scoop] &rarr; {(proteinRequirement ? Math.ceil((proteinRequirement.min) / 5) : 0)}-{(proteinRequirement ? Math.ceil((proteinRequirement.max) / 5) : 0)} scoops/day
                          </span>
                        </div>

                      </div>

                      {/* PROGRESSIVE STEP-UP TIMELINE */}
                      {clinicalScenario !== "trophic" && energyRequirement && (
                        <div className={`p-4 rounded-xl border ${isDarkMode ? "bg-slate-900/40 border-slate-800" : "bg-slate-50 border-slate-200"}`}>
                          <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-3 flex items-center justify-between">
                            <span>Progressive Feeding Plan (72H Step-Up)</span>
                            <span className="text-[10px] font-mono text-rose-400">Aim for 70-80% at 72H</span>
                          </h4>
                          
                          <div className="grid grid-cols-4 gap-2">
                            <div className="p-2.5 rounded-lg border border-dashed border-slate-800 bg-slate-950/30 text-center">
                              <span className="block text-[9px] font-bold text-slate-400 uppercase">Day 1 (25%)</span>
                              <span className="block text-xs font-extrabold text-slate-100 mt-1">
                                {Math.round(energyRequirement.min * 0.25)}-{Math.round(energyRequirement.max * 0.25)} <span className="text-[9px] font-normal">kcal</span>
                              </span>
                              <span className="block text-[8px] text-slate-500 mt-0.5 font-mono">~5 kcal/kg/d</span>
                            </div>
                            <div className="p-2.5 rounded-lg border border-dashed border-slate-800 bg-slate-950/30 text-center">
                              <span className="block text-[9px] font-bold text-slate-400 uppercase">Day 2 (50%)</span>
                              <span className="block text-xs font-extrabold text-slate-100 mt-1">
                                {Math.round(energyRequirement.min * 0.5)}-{Math.round(energyRequirement.max * 0.5)} <span className="text-[9px] font-normal">kcal</span>
                              </span>
                              <span className="block text-[8px] text-slate-500 mt-0.5 font-mono">~10 kcal/kg/d</span>
                            </div>
                            <div className="p-2.5 rounded-lg border border-dashed border-slate-800 bg-slate-950/30 text-center">
                              <span className="block text-[9px] font-bold text-slate-400 uppercase">Day 3 (75%)</span>
                              <span className="block text-xs font-extrabold text-slate-100 mt-1">
                                {Math.round(energyRequirement.min * 0.75)}-{Math.round(energyRequirement.max * 0.75)} <span className="text-[9px] font-normal">kcal</span>
                              </span>
                              <span className="block text-[8px] text-slate-500 mt-0.5 font-mono">~15 kcal/kg/d</span>
                            </div>
                            <div className="p-2.5 rounded-lg border border-rose-500/30 bg-rose-500/5 text-center">
                              <span className="block text-[9px] font-bold text-rose-400 uppercase">Day 4 (&gt;80%)</span>
                              <span className="block text-xs font-extrabold text-rose-300 mt-1">
                                {Math.round(energyRequirement.min * 0.8)}-{Math.round(energyRequirement.max * 0.85)} <span className="text-[9px] font-normal">kcal</span>
                              </span>
                              <span className="block text-[8px] text-rose-400 mt-0.5 font-mono">20-25 kcal/kg/d</span>
                            </div>
                          </div>
                        </div>
                      )}

                    </div>
                  )}

                </div>
              </div>

            </div>
          </div>
        )}

        {/* SUBTAB 2: REFEEDING SYNDROME RISK & ADVISOR */}
        {activeSubTab === "refeeding" && (
          <div className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              
              {/* CHECKLIST PANEL */}
              <div className="lg:col-span-5 space-y-4">
                <div className={`p-5 rounded-xl border ${isDarkMode ? "bg-slate-900/50 border-slate-800" : "bg-slate-50 border-slate-200"}`}>
                  <h3 className={`text-xs font-bold uppercase tracking-wider mb-4 flex items-center gap-2 ${isDarkMode ? "text-slate-300" : "text-slate-700"}`}>
                    <ShieldAlert className="w-4 h-4 text-rose-500" />
                    RFS Risk Factor Checklist
                  </h3>

                  <div className="space-y-3">
                    {/* BMI Factor */}
                    <label className="flex items-start gap-3 cursor-pointer group">
                      <input
                        type="checkbox"
                        checked={rfsBmiUnder}
                        onChange={(e) => setRfsBmiUnder(e.target.checked)}
                        className="mt-1 accent-rose-500"
                      />
                      <div className="text-xs">
                        <span className={`block font-bold ${rfsBmiUnder ? "text-rose-400" : isDarkMode ? "text-slate-300" : "text-slate-700"}`}>
                          BMI &lt; 18.5 kg/m²
                        </span>
                        <span className="block text-[10px] text-slate-500 mt-0.5">
                          {calculatedBmi !== null ? `Auto-detected from demographics: BMI is ${calculatedBmi.toFixed(1)}` : "Malnourished or underweight patient"}
                        </span>
                      </div>
                    </label>

                    {/* Weight Loss */}
                    <label className="flex items-start gap-3 cursor-pointer group">
                      <input
                        type="checkbox"
                        checked={rfsWeightLoss}
                        onChange={(e) => setRfsWeightLoss(e.target.checked)}
                        className="mt-1 accent-rose-500"
                      />
                      <div className="text-xs">
                        <span className={`block font-bold ${rfsWeightLoss ? "text-rose-400" : isDarkMode ? "text-slate-300" : "text-slate-700"}`}>
                          Unintentional Weight Loss &gt; 10%
                        </span>
                        <span className="block text-[10px] text-slate-500 mt-0.5">
                          In the preceding 3 months
                        </span>
                      </div>
                    </label>

                    {/* No Intake */}
                    <label className="flex items-start gap-3 cursor-pointer group">
                      <input
                        type="checkbox"
                        checked={rfsNoIntake}
                        onChange={(e) => setRfsNoIntake(e.target.checked)}
                        className="mt-1 accent-rose-500"
                      />
                      <div className="text-xs">
                        <span className={`block font-bold ${rfsNoIntake ? "text-rose-400" : isDarkMode ? "text-slate-300" : "text-slate-700"}`}>
                          Very Little to No Nutrient Intake
                        </span>
                        <span className="block text-[10px] text-slate-500 mt-0.5">
                          Starving or fasting for &gt; 5 days
                        </span>
                      </div>
                    </label>

                    {/* Low Electrolytes */}
                    <label className="flex items-start gap-3 cursor-pointer group">
                      <input
                        type="checkbox"
                        checked={rfsLowElectrolytes}
                        onChange={(e) => setRfsLowElectrolytes(e.target.checked)}
                        className="mt-1 accent-rose-500"
                      />
                      <div className="text-xs">
                        <span className={`block font-bold ${rfsLowElectrolytes ? "text-rose-400" : isDarkMode ? "text-slate-300" : "text-slate-700"}`}>
                          Low Electrolytes Prior to Feeding
                        </span>
                        <span className="block text-[10px] text-slate-500 mt-0.5">
                          Low Baseline Serum K+, Mg2+, or Phosphate (PO4-)
                        </span>
                      </div>
                    </label>

                    {/* Alcohol or Drugs */}
                    <label className="flex items-start gap-3 cursor-pointer group">
                      <input
                        type="checkbox"
                        checked={rfsAlcoholDrugs}
                        onChange={(e) => setRfsAlcoholDrugs(e.target.checked)}
                        className="mt-1 accent-rose-500"
                      />
                      <div className="text-xs">
                        <span className={`block font-bold ${rfsAlcoholDrugs ? "text-rose-400" : isDarkMode ? "text-slate-300" : "text-slate-700"}`}>
                          Chronic Alcohol/Drug Abuse History
                        </span>
                        <span className="block text-[10px] text-slate-500 mt-0.5">
                          Or on insulin, chemotherapy, antacids, or diuretics
                        </span>
                      </div>
                    </label>

                  </div>
                </div>
              </div>

              {/* ACTIONABLE ADVISOR PANEL */}
              <div className="lg:col-span-7 space-y-4">
                <div className={`p-5 rounded-xl border ${
                  rfsRiskLevel === "HIGH RISK"
                    ? isDarkMode 
                      ? "bg-red-950/20 border-red-500/30 text-slate-200" 
                      : "bg-red-50 border-red-200 text-red-900"
                    : isDarkMode
                      ? "bg-slate-900/40 border-slate-800 text-slate-200"
                      : "bg-white border-slate-200 text-slate-800"
                }`}>
                  
                  {/* RISK FACTOR BANNER */}
                  <div className="flex items-center justify-between border-b pb-4 mb-4 border-slate-800/40">
                    <div className="flex items-center gap-2">
                      <ShieldAlert className={`w-5 h-5 ${rfsRiskLevel === "HIGH RISK" ? "text-red-500 animate-pulse" : "text-amber-500"}`} />
                      <div>
                        <span className="text-[10px] uppercase font-mono font-bold tracking-wider text-slate-400">Refeeding Syndrome Risk Status</span>
                        <h4 className={`text-sm font-black ${rfsRiskLevel === "HIGH RISK" ? "text-red-500" : "text-amber-400"} mt-0.5`}>
                          {rfsRiskLevel} ({rfsSelectedCount} / 5 Criteria Met)
                        </h4>
                      </div>
                    </div>
                    
                    <span className={`px-2.5 py-1 text-[10px] font-mono font-bold rounded-lg ${
                      rfsRiskLevel === "HIGH RISK"
                        ? "bg-red-500 text-slate-950"
                        : "bg-amber-500 text-slate-950"
                    }`}>
                      {rfsRiskLevel === "HIGH RISK" ? "⚠️ CRITICAL CARE PROMPT" : "STANDARD PRECAUTION"}
                    </span>
                  </div>

                  {/* CLINICAL MANAGEMENT ROADMAP */}
                  <div className="space-y-4">
                    
                    {/* CALORIC RESTRICTION PANEL */}
                    <div className={`p-4 rounded-lg ${isDarkMode ? "bg-slate-950/50" : "bg-slate-100/50"}`}>
                      <span className="text-[10px] uppercase font-mono font-bold text-rose-400">Caloric Restriction Guidance</span>
                      
                      {rfsRiskLevel === "HIGH RISK" ? (
                        <div className="mt-2 space-y-1.5 text-xs">
                          <p className="font-extrabold text-red-500">
                            🚨 LIMIT CALORIES TO 10 kcal/kg/day FOR THE FIRST 48 HOURS!
                          </p>
                          {weight ? (
                            <p className="font-semibold text-amber-500 mt-1">
                              👉 Patient limit: Max <span className="underline text-lg font-black font-mono">{Math.round(parseFloat(weight) * 10)} kcal/day</span> including non-nutritional calories.
                            </p>
                          ) : (
                            <p className="text-slate-400 text-[10px]">Enter weight in calculator to display the exact patient cap.</p>
                          )}
                          <div className="text-[10px] text-slate-400 mt-2 space-y-1 bg-slate-900 p-2.5 rounded-lg font-mono">
                            <span className="font-bold text-slate-200">Non-Nutritional Calorie Equivalents:</span>
                            <div className="flex justify-between"><span>• Dextrose 5% solution:</span> <span className="text-amber-500">200 kcal/L</span></div>
                            <div className="flex justify-between"><span>• QSD1 (Dextrose saline):</span> <span className="text-amber-500">170 kcal/L</span></div>
                            <div className="flex justify-between"><span>• Propofol 10% infusion:</span> <span className="text-amber-500">1.1 kcal/ml</span></div>
                          </div>
                        </div>
                      ) : (
                        <p className="text-xs mt-1 text-slate-400 leading-relaxed">
                          Standard progressive feeds. However, closely monitor serum Phosphate (PO4-), Potassium (K+), and Magnesium (Mg2+) daily during the first week. Suspect refeeding syndrome if phosphate levels drop.
                        </p>
                      )}
                    </div>

                    {/* SUPPLEMENTATION & MONITORING PANEL */}
                    <div className="space-y-2">
                      <span className="text-[10px] uppercase font-mono font-bold text-slate-400 block">Required Supplementation Regimen</span>
                      
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-2.5">
                        <div className={`p-3 rounded-lg text-xs leading-normal ${isDarkMode ? "bg-slate-950/30" : "bg-white border"}`}>
                          <span className="font-extrabold text-teal-400 block mb-1">⚡ Immediate Nutrition Supplements</span>
                          <span className="block font-medium">Provide immediately before and during first 10 days of feeding:</span>
                          <ul className="list-disc pl-4 mt-1 text-[11px] text-slate-400 space-y-0.5">
                            <li><span className="text-slate-200">Oral Thiamine:</span> 200mg OD</li>
                            <li><span className="text-slate-200">Oral Vit B Complex:</span> 1-2 tabs OD</li>
                            <li><span className="text-slate-200">Oral Multivitamin:</span> 1 tab OD</li>
                            <li className="mt-1 text-[10px] italic text-rose-400 font-semibold">If unable to tolerate orally: IV Thiamine 200-300mg OD for 3 days, then change to oral.</li>
                          </ul>
                        </div>

                        <div className={`p-3 rounded-lg text-xs leading-normal ${isDarkMode ? "bg-slate-950/30" : "bg-white border"}`}>
                          <span className="font-extrabold text-amber-400 block mb-1">🧪 Electrolyte Monitoring Schedule</span>
                          <span className="block font-medium">Measurement & Correction:</span>
                          <ul className="list-disc pl-4 mt-1 text-[11px] text-slate-400 space-y-0.5">
                            <li>Measure <span className="text-slate-200">K+, Mg2+, PO4-</span> once daily during the first week.</li>
                            <li><span className="text-rose-400 font-semibold">IF PO4- LEVEL DROPS (Suspected RFS):</span> Measure electrolytes 8-hourly or 12-hourly and correct accordingly immediately.</li>
                            <li>Slowly step up feeding: Increase by 5 kcal/kg/day every 4-5 days once stable.</li>
                          </ul>
                        </div>
                      </div>

                    </div>

                  </div>
                </div>
              </div>

            </div>
          </div>
        )}

        {/* SUBTAB 3: INTERACTIVE FEEDING PROTOCOL SIMULATOR */}
        {activeSubTab === "protocol" && (
          <div className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              
              {/* SIDEBAR SELECTOR */}
              <div className="lg:col-span-4 space-y-4">
                <div className={`p-4 rounded-xl border ${isDarkMode ? "bg-slate-900/50 border-slate-800" : "bg-slate-50 border-slate-200"}`}>
                  <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-3">
                    Select Feeding Pathway
                  </h3>
                  
                  <div className="flex flex-col gap-2">
                    <button
                      onClick={() => {
                        setFeedingMethod("continuous");
                        setGrvInput("");
                        setGrvSubmitted(false);
                      }}
                      className={`p-3 rounded-lg border text-left transition-all flex items-center justify-between ${
                        feedingMethod === "continuous"
                          ? "bg-rose-500/10 border-rose-500 text-rose-400 font-bold"
                          : isDarkMode ? "bg-slate-950 border-slate-800 text-slate-400 hover:text-slate-200" : "bg-white border-slate-200 text-slate-600 hover:text-slate-800"
                      }`}
                    >
                      <div className="text-xs">
                        <span className="block font-bold text-slate-100">Continuous Feeding</span>
                        <span className="block text-[10px] text-slate-400 mt-0.5 font-normal">Preferred mode for critical care</span>
                      </div>
                      <ChevronRight className="w-4 h-4 text-slate-500" />
                    </button>

                    <button
                      onClick={() => {
                        setFeedingMethod("intermittent");
                        setGrvInput("");
                        setGrvSubmitted(false);
                      }}
                      className={`p-3 rounded-lg border text-left transition-all flex items-center justify-between ${
                        feedingMethod === "intermittent"
                          ? "bg-rose-500/10 border-rose-500 text-rose-400 font-bold"
                          : isDarkMode ? "bg-slate-950 border-slate-800 text-slate-400 hover:text-slate-200" : "bg-white border-slate-200 text-slate-600 hover:text-slate-800"
                      }`}
                    >
                      <div className="text-xs">
                        <span className="block font-bold text-slate-100">Intermittent Feeding</span>
                        <span className="block text-[10px] text-slate-400 mt-0.5 font-normal">e.g. 4 hours feed + 2 hours rest</span>
                      </div>
                      <ChevronRight className="w-4 h-4 text-slate-500" />
                    </button>

                    <button
                      onClick={() => {
                        setFeedingMethod("bolus");
                        setGrvInput("");
                        setGrvSubmitted(false);
                      }}
                      className={`p-3 rounded-lg border text-left transition-all flex items-center justify-between ${
                        feedingMethod === "bolus"
                          ? "bg-rose-500/10 border-rose-500 text-rose-400 font-bold"
                          : isDarkMode ? "bg-slate-950 border-slate-800 text-slate-400 hover:text-slate-200" : "bg-white border-slate-200 text-slate-600 hover:text-slate-800"
                      }`}
                    >
                      <div className="text-xs">
                        <span className="block font-bold text-slate-100">Bolus Feeding</span>
                        <span className="block text-[10px] text-slate-400 mt-0.5 font-normal">Only for stable/non-ventilated</span>
                      </div>
                      <ChevronRight className="w-4 h-4 text-slate-500" />
                    </button>
                  </div>
                </div>

                {/* FEEDING INTOLERANCE SELECTOR */}
                <div className={`p-4 rounded-xl border ${isDarkMode ? "bg-slate-900/50 border-slate-800" : "bg-slate-50 border-slate-200"}`}>
                  <h3 className="text-xs font-bold uppercase tracking-wider text-rose-400 mb-3 flex items-center gap-1.5">
                    <AlertTriangle className="w-4 h-4" />
                    Feeding Intolerance Advisor
                  </h3>
                  <p className="text-[10px] text-slate-400 mb-3 leading-normal">
                    Select the intolerance episode to view standard bedside protocols for high Gastric Residual Volume (GRV &gt; 300 ml) or vomiting.
                  </p>
                  <div className="grid grid-cols-3 gap-1">
                    <button
                      onClick={() => setIntoleranceEpisode(intoleranceEpisode === "1st" ? "none" : "1st")}
                      className={`py-1.5 text-[10px] uppercase font-mono font-bold rounded border ${
                        intoleranceEpisode === "1st"
                          ? "bg-rose-500 text-slate-950 border-rose-500"
                          : isDarkMode ? "bg-slate-950 border-slate-800 text-slate-300" : "bg-white text-slate-700"
                      }`}
                    >
                      1st Ep
                    </button>
                    <button
                      onClick={() => setIntoleranceEpisode(intoleranceEpisode === "2nd" ? "none" : "2nd")}
                      className={`py-1.5 text-[10px] uppercase font-mono font-bold rounded border ${
                        intoleranceEpisode === "2nd"
                          ? "bg-rose-500 text-slate-950 border-rose-500"
                          : isDarkMode ? "bg-slate-950 border-slate-800 text-slate-300" : "bg-white text-slate-700"
                      }`}
                    >
                      2nd Ep
                    </button>
                    <button
                      onClick={() => setIntoleranceEpisode(intoleranceEpisode === "3rd" ? "none" : "3rd")}
                      className={`py-1.5 text-[10px] uppercase font-mono font-bold rounded border ${
                        intoleranceEpisode === "3rd"
                          ? "bg-rose-500 text-slate-950 border-rose-500"
                          : isDarkMode ? "bg-slate-950 border-slate-800 text-slate-300" : "bg-white text-slate-700"
                      }`}
                    >
                      3rd+ Ep
                    </button>
                  </div>
                </div>
              </div>

              {/* SIMULATOR DETAILS PANEL */}
              <div className="lg:col-span-8 space-y-4">
                
                {/* ACTIVE PATHWAY CARD */}
                <div className={`p-5 rounded-xl border ${isDarkMode ? "bg-slate-900/30 border-slate-800" : "bg-white border-slate-200"}`}>
                  
                  {/* TITLE */}
                  <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-4">
                    <div className="flex items-center gap-2">
                      <Activity className="w-4 h-4 text-rose-500 animate-pulse" />
                      <h4 className={`text-xs uppercase font-mono font-bold ${isDarkMode ? "text-slate-300" : "text-slate-700"}`}>
                        Active Pathway: {feedingMethod.toUpperCase()} FEEDING PROTOCOL
                      </h4>
                    </div>
                    <button 
                      onClick={() => {
                        setGrvInput("");
                        setGrvSubmitted(false);
                        setIntoleranceEpisode("none");
                      }}
                      className="flex items-center gap-1 text-[10px] text-slate-500 hover:text-slate-300 uppercase font-mono"
                    >
                      <RotateCcw className="w-3 h-3" /> Reset Simulator
                    </button>
                  </div>

                  {/* PROTOCOL STEPS FLOW */}
                  <div className="space-y-4 text-xs">
                    
                    {/* STARTING INSTRUCTION */}
                    <div className="flex items-start gap-3">
                      <div className="w-6 h-6 rounded-full bg-rose-500/10 border border-rose-500/30 flex items-center justify-center font-mono font-extrabold text-[10px] text-rose-400 shrink-0">1</div>
                      <div>
                        <span className="block font-bold text-slate-100">Step 1: Clinical Initiation</span>
                        <p className={`text-[11px] ${isDarkMode ? "text-slate-400" : "text-slate-600"} mt-0.5 leading-relaxed`}>
                          {feedingMethod === "continuous" && "Ensure stable hemodynamics. Start continuous enteral feeding at 20 ml/hour using an enteral feeding pump."}
                          {feedingMethod === "intermittent" && "Ensure stable hemodynamics. Start intermittent enteral feeding: 25 ml/hour for 4 hours, followed by 2 hours of rest."}
                          {feedingMethod === "bolus" && "Verify stable non-ventilated state (anticipated ICU stay < 48-72 hours). Start gravity bolus feeding: 50 ml administered over 15 minutes, every 3 hours."}
                        </p>
                      </div>
                    </div>

                    {/* GRV MONITORING STEP */}
                    <div className="flex items-start gap-3">
                      <div className="w-6 h-6 rounded-full bg-rose-500/10 border border-rose-500/30 flex items-center justify-center font-mono font-extrabold text-[10px] text-rose-400 shrink-0">2</div>
                      <div className="flex-1">
                        <span className="block font-bold text-slate-100">
                          Step 2: Gastric Aspiration / Residual Volume (GRV) Check
                        </span>
                        <p className={`text-[11px] ${isDarkMode ? "text-slate-400" : "text-slate-600"} mt-0.5 leading-relaxed`}>
                          {feedingMethod === "continuous" && "Measure gastric aspirate at the end of 4 hours."}
                          {feedingMethod === "intermittent" && "Measure gastric aspirate at the end of 6 hours (completion of first cycle, including rest period)."}
                          {feedingMethod === "bolus" && "Measure gastric aspirate immediately prior to the next scheduled bolus feed."}
                        </p>

                        {/* INTERACTIVE INPUT */}
                        <div className={`mt-3 p-3.5 rounded-lg border ${isDarkMode ? "bg-slate-950/60 border-slate-800" : "bg-slate-100 border-slate-200"} max-w-sm`}>
                          <label className="block text-[10px] font-mono font-bold text-slate-400 mb-1.5 uppercase">
                            Enter Simulated GRV Aspirate Volume:
                          </label>
                          <div className="flex gap-2">
                            <div className="relative flex-1">
                              <input
                                type="number"
                                value={grvInput}
                                onChange={(e) => {
                                  setGrvInput(e.target.value);
                                  setGrvSubmitted(false);
                                }}
                                placeholder="e.g. 150 or 350"
                                className={`w-full px-3 py-1.5 text-xs rounded border focus:outline-none focus:ring-1 focus:ring-rose-500 ${
                                  isDarkMode ? "bg-slate-900 border-slate-800 text-slate-100" : "bg-white border-slate-300 text-slate-800"
                                }`}
                              />
                              <span className="absolute right-3 top-1/2 -translate-y-1/2 text-[10px] text-slate-500 font-mono">ml</span>
                            </div>
                            <button
                              onClick={() => setGrvSubmitted(true)}
                              className="px-3 py-1.5 text-xs font-bold uppercase rounded bg-rose-500 text-slate-950 hover:bg-rose-600 transition-all cursor-pointer"
                            >
                              Check
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* INTERACTIVE SIMULATOR OUTCOME */}
                    {grvSubmitted && (
                      <div className="flex items-start gap-3">
                        <div className="w-6 h-6 rounded-full bg-rose-500/10 border border-rose-500/30 flex items-center justify-center font-mono font-extrabold text-[10px] text-rose-400 shrink-0">3</div>
                        <div className="flex-1">
                          <span className="block font-bold text-slate-100">Step 3: Pathway Outcome</span>
                          
                          {parseFloat(grvInput) > 300 ? (
                            <div className={`mt-2 p-4 rounded-xl border ${isDarkMode ? "bg-red-950/20 border-red-500/30 text-slate-200" : "bg-red-50 border-red-200 text-red-900"} space-y-2`}>
                              <div className="flex items-center gap-1.5 font-bold text-red-500 text-xs">
                                <AlertTriangle className="w-4 h-4 shrink-0" />
                                <span>ALERT: FEEDING INTOLERANCE DETECTED (GRV &gt; 300 ml)</span>
                              </div>
                              <p className="text-[11px] leading-relaxed">
                                Gastric residual volume of <span className="font-extrabold text-lg font-mono underline">{grvInput}ml</span> exceeds the 300 ml threshold. Under the clinical protocol, this requires immediate rate limitation and prokinetic support.
                              </p>
                              <div className="pt-2 border-t border-red-500/20 text-[10px] space-y-1">
                                <span className="font-extrabold text-red-400 block uppercase">Bedside Action Required:</span>
                                <div>1. Return up to 200 ml of aspirate to prevent acid loss; discard the excess.</div>
                                <div>2. Check gastric feeding tube placement and patient positioning (ensure bed is elevated 30-45°).</div>
                                <div>3. Apply the appropriate **Feeding Intolerance Episode** protocol below (1st, 2nd, or 3rd episode instructions).</div>
                              </div>
                              <button
                                onClick={() => setIntoleranceEpisode("1st")}
                                className="mt-2 text-[10px] bg-red-500 text-slate-950 font-bold px-3 py-1.5 rounded uppercase hover:bg-red-600 transition-all cursor-pointer"
                              >
                                View 1st Episode Protocol
                              </button>
                            </div>
                          ) : (
                            <div className={`mt-2 p-4 rounded-xl border ${isDarkMode ? "bg-teal-950/20 border-teal-500/30 text-slate-200" : "bg-teal-50 border-teal-200 text-teal-900"} space-y-2`}>
                              <div className="flex items-center gap-1.5 font-bold text-teal-400 text-xs">
                                <CheckCircle2 className="w-4 h-4 shrink-0" />
                                <span>TOLERATED: CONTINUE & GRADUALLY PROGRESS</span>
                              </div>
                              <p className="text-[11px] leading-relaxed">
                                Gastric residual volume of <span className="font-extrabold text-lg font-mono underline">{grvInput || "0"}ml</span> is within safe limits (&le; 300 ml). Proceed to upscale feeding as scheduled:
                              </p>
                              <div className="pt-2 border-t border-teal-500/20 text-[11px] space-y-1.5 font-medium">
                                {feedingMethod === "continuous" && (
                                  <>
                                    <span className="block font-bold text-teal-400 uppercase">Progression Routine:</span>
                                    <div>• Continue feeding at <span className="text-slate-100 font-bold font-mono">20 ml/hour</span>.</div>
                                    <div>• Repeat gastric aspiration check <span className="text-slate-100 font-bold font-mono">every 4 hours</span>.</div>
                                    <div>• If GRV remains &le; 300 ml, increase rate by <span className="text-slate-100 font-bold font-mono">20 ml/hour every 12 hours</span>.</div>
                                    <div className="text-[10px] text-slate-400">Maximum continuous rate ceiling is <span className="font-bold">80 ml/hour</span>.</div>
                                  </>
                                )}
                                {feedingMethod === "intermittent" && (
                                  <>
                                    <span className="block font-bold text-teal-400 uppercase">Progression Routine:</span>
                                    <div>• Continue feeding at <span className="text-slate-100 font-bold font-mono">24-25 ml/hour</span> for 4 hours, followed by 2 hours rest.</div>
                                    <div>• Repeat gastric aspiration check at the <span className="text-slate-100 font-bold font-mono">end of every 2-hour rest period</span> (6-hourly cycles).</div>
                                    <div>• If tolerated, increase feeding rate by <span className="text-slate-100 font-bold font-mono">25 ml/hour every 12 hours</span>.</div>
                                    <div className="text-[10px] text-slate-400">Maximum intermittent rate ceiling is <span className="font-bold">100 ml/hour</span>.</div>
                                  </>
                                )}
                                {feedingMethod === "bolus" && (
                                  <>
                                    <span className="block font-bold text-teal-400 uppercase">Progression Routine:</span>
                                    <div>• Administer bolus feeds of <span className="text-slate-100 font-bold font-mono">50 ml over 15 minutes</span> every 3 hours.</div>
                                    <div>• Aspirate before each feed to ensure &le; 300 ml residual.</div>
                                    <div>• If tolerated, increase bolus volume by <span className="text-slate-100 font-bold font-mono">50 ml/3H every 12 hours</span>.</div>
                                    <div className="text-[10px] text-slate-400">Maximum bolus volume ceiling is <span className="font-bold">250 ml / 3 hours</span>.</div>
                                  </>
                                )}
                              </div>
                            </div>
                          )}

                        </div>
                      </div>
                    )}

                  </div>

                </div>

                {/* DYNAMIC EPISODE DETAIL CONTAINER */}
                {intoleranceEpisode !== "none" && (
                  <div className={`p-5 rounded-xl border ${isDarkMode ? "bg-slate-900/50 border-rose-500/30 text-slate-100" : "bg-rose-50/20 border-rose-200 text-slate-900"} space-y-3`}>
                    <div className="flex items-center justify-between border-b border-rose-500/20 pb-2">
                      <h4 className="text-xs font-black uppercase font-mono text-rose-400 flex items-center gap-1.5">
                        <AlertTriangle className="w-4 h-4 text-rose-500 animate-bounce" />
                        Management: {intoleranceEpisode} Episode of Feeding Intolerance
                      </h4>
                      <button 
                        onClick={() => setIntoleranceEpisode("none")}
                        className="text-[10px] uppercase font-mono text-slate-500 hover:text-slate-300"
                      >
                        [Hide]
                      </button>
                    </div>

                    {intoleranceEpisode === "1st" && (
                      <div className="space-y-2 text-xs leading-relaxed">
                        <ol className="list-decimal pl-4 space-y-1 text-slate-300">
                          <li>Check gastric tube placement and elevate patient's bed head (30-45°).</li>
                          <li>Return aspirates up to <span className="font-extrabold text-slate-100">200 ml</span>; discard the excess.</li>
                          <li><span className="text-rose-400 font-bold">Maintain Enteral Nutrition (EN)</span> at the exact same rate. Do not hold or decrease yet.</li>
                          <li><span className="font-bold text-slate-100">Conditional Check:</span> If aspirates exceed <span className="font-extrabold text-red-400">500 ml</span>, withhold feeding for <span className="underline">1 cycle</span> and initiate prokinetic therapy.</li>
                        </ol>
                      </div>
                    )}

                    {intoleranceEpisode === "2nd" && (
                      <div className="space-y-3 text-xs leading-relaxed">
                        <ol className="list-decimal pl-4 space-y-1.5 text-slate-300">
                          <li>Return aspirates up to <span className="font-extrabold text-slate-100">200 ml</span>; discard the excess.</li>
                          <li><span className="text-rose-400 font-extrabold">Decrease Rate:</span> Reduce feeding rate by <span className="font-bold text-slate-100">20 to 25 ml/hour</span>.</li>
                          <li className="list-none pl-1 text-[11px] text-amber-500 font-semibold italic">
                            ⚠️ Note: If the patient is already on a low rate of 20-25 ml/hour, reduce rate down to <span className="underline">10 ml/hour</span>.
                          </li>
                          <li><span className="text-teal-400 font-bold">Start Prokinetics:</span>
                            <ul className="list-disc pl-5 text-[11px] text-slate-400 mt-0.5 space-y-0.5">
                              <li><span className="text-slate-200 font-semibold">1st Line:</span> IV Metoclopramide 10mg TDS</li>
                              <li><span className="text-slate-200 font-semibold">Adjuvant/Alternative:</span> IV Erythromycin 125mg QID or 250mg BD</li>
                              <li><span className="text-amber-500 font-medium">Warning:</span> Combined therapy has high efficacy but prolongs the QT interval. Review need after 48H.</li>
                            </ul>
                          </li>
                          <li><span className="font-bold text-slate-100">Route Conversion:</span> If on bolus feeding, consider converting to continuous or intermittent feeding to optimize gastric transit.</li>
                        </ol>
                      </div>
                    )}

                    {intoleranceEpisode === "3rd" && (
                      <div className="space-y-3 text-xs leading-relaxed">
                        <ol className="list-decimal pl-4 space-y-1.5 text-slate-300">
                          <li>Return aspirates up to <span className="font-extrabold text-slate-100">200 ml</span>; discard the excess.</li>
                          <li><span className="text-rose-400 font-extrabold">Withhold Feeds:</span> Stop feeding entirely for <span className="underline">1 cycle</span>.</li>
                          <li><span className="font-bold text-slate-100">Re-initiation Rate:</span> Restart feeding at a significantly lower rate or at <span className="text-teal-400 font-extrabold">10 ml/hour</span>.</li>
                          <li><span className="font-bold text-slate-100">Continue Prokinetic Regimen</span> as initiated.</li>
                          <li className="list-none pl-1 text-[11px] text-red-400 font-bold bg-slate-900/60 p-2.5 rounded border border-red-500/20">
                            🚨 POST-PYLORIC PATHWAY: If gastric feeding intolerance persists for more than 72 hours despite max prokinetic support, proceed with post-pyloric feeding catheter insertion.
                          </li>
                        </ol>
                      </div>
                    )}

                  </div>
                )}

              </div>

            </div>
          </div>
        )}

        {/* SUBTAB 4: FORMULATION DATABASE */}
        {activeSubTab === "formulas" && (
          <div className="space-y-5">
            {/* SEARCH AND FILTERS */}
            <div className="flex flex-col md:flex-row items-stretch md:items-center gap-3">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
                <input
                  type="text"
                  value={formSearch}
                  onChange={(e) => setFormSearch(e.target.value)}
                  placeholder="Search enteral formulations (e.g. Glucerna, Ensure, Renomed)..."
                  className={`w-full pl-9 pr-4 py-2 text-xs rounded-xl border focus:outline-none focus:ring-1 focus:ring-rose-500 ${
                    isDarkMode ? "bg-slate-900 border-slate-800 text-slate-100" : "bg-white border-slate-300 text-slate-800"
                  }`}
                />
              </div>

              <div className="flex gap-1.5 overflow-x-auto scrollbar-none pb-1 md:pb-0">
                {["All", "Standard", "Glycemic Control", "Low Electrolyte / Fluid Restricted", "Modified Fiber", "Semi-hydrolyzed"].map((cat) => (
                  <button
                    key={cat}
                    onClick={() => setFormFilter(cat)}
                    className={`px-3 py-1.5 text-[10px] font-bold uppercase tracking-wider rounded-lg border transition-all whitespace-nowrap cursor-pointer ${
                      formFilter === cat
                        ? "bg-rose-500 text-slate-950 border-rose-500 font-extrabold"
                        : isDarkMode
                          ? "bg-slate-950 border-slate-800 text-slate-400 hover:text-slate-200"
                          : "bg-white border-slate-200 text-slate-600 hover:text-slate-800"
                    }`}
                  >
                    {cat}
                  </button>
                ))}
              </div>
            </div>

            {/* BUDGET NOTICE */}
            <div className={`p-3.5 rounded-xl border text-xs leading-normal flex items-start gap-2.5 ${
              isDarkMode ? "bg-amber-950/20 border-amber-900/40 text-amber-200" : "bg-amber-50 border-amber-200 text-amber-900"
            }`}>
              <Info className="w-4 h-4 text-amber-500 mt-0.5 shrink-0" />
              <div>
                <span className="font-extrabold">Budget Formulary Info:</span> Formulas marked with an asterisk <span className="font-extrabold">(*)</span> are typically stocked or available via direct department stores (current status subject to local budget & regional purchasing availability).
              </div>
            </div>

            {/* FORMULA CARDS GRID */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {filteredFormulations.map((f, idx) => (
                <div 
                  key={idx} 
                  className={`p-4 rounded-xl border flex flex-col justify-between transition-all ${
                    isDarkMode 
                      ? "bg-slate-900/40 border-slate-800 hover:border-slate-700 hover:bg-slate-900/60" 
                      : "bg-white border-slate-200 hover:border-slate-300 hover:shadow-md"
                  }`}
                >
                  <div>
                    <div className="flex items-start justify-between gap-2 mb-2">
                      <span className={`px-2 py-0.5 text-[9px] font-mono font-bold uppercase rounded ${
                        f.category === "Standard" ? "bg-blue-500/10 text-blue-400 border border-blue-500/20" :
                        f.category === "Glycemic Control" ? "bg-green-500/10 text-green-400 border border-green-500/20" :
                        f.category === "Low Electrolyte / Fluid Restricted" ? "bg-purple-500/10 text-purple-400 border border-purple-500/20" :
                        f.category === "Modified Fiber" ? "bg-yellow-500/10 text-yellow-400 border border-yellow-500/20" :
                        "bg-red-500/10 text-red-400 border border-red-500/20"
                      }`}>
                        {f.category}
                      </span>
                      <span className={`text-[10px] font-mono px-1.5 py-0.5 rounded ${isDarkMode ? "bg-slate-950 text-slate-400" : "bg-slate-100 text-slate-600"}`}>
                        {f.type}
                      </span>
                    </div>

                    <h5 className={`font-black text-sm ${isDarkMode ? "text-slate-100" : "text-slate-900"} flex items-center gap-1.5`}>
                      {f.name}
                    </h5>

                    {/* SPECS */}
                    <div className="grid grid-cols-3 gap-2 mt-3 p-2.5 rounded-lg bg-slate-950/40 border border-slate-800/40 font-mono text-[11px]">
                      <div>
                        <span className="block text-[8px] text-slate-500 uppercase font-mono font-bold">Energy</span>
                        <span className="font-extrabold text-slate-200 mt-0.5 block">{f.energy.toFixed(1)} <span className="text-[9px] font-normal">kcal/ml</span></span>
                      </div>
                      <div>
                        <span className="block text-[8px] text-slate-500 uppercase font-mono font-bold">Protein</span>
                        <span className="font-extrabold text-teal-400 mt-0.5 block">{f.protein} <span className="text-[9px] font-normal">g/L</span></span>
                      </div>
                      <div>
                        <span className="block text-[8px] text-slate-500 uppercase font-mono font-bold">Sodium</span>
                        <span className="font-extrabold text-amber-400 mt-0.5 block">{f.sodium} <span className="text-[9px] font-normal">mg/L</span></span>
                      </div>
                    </div>

                    {f.preparation && (
                      <div className="mt-2.5 p-1.5 rounded bg-slate-900/60 border border-slate-800/30 text-[10px] font-mono flex items-center justify-between text-slate-400">
                        <span>Reconstitution:</span>
                        <span className="font-bold text-slate-200">{f.preparation}</span>
                      </div>
                    )}
                  </div>

                  <div className="mt-3 pt-3 border-t border-slate-800/60 text-[10px] space-y-1 text-slate-400 leading-normal">
                    <div className="flex justify-between">
                      <span>Lactose Status:</span>
                      <span className="font-bold text-slate-200">{f.lactose}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Recommended Rates:</span>
                      <span className="font-bold text-rose-400">{f.rate} ml/hr</span>
                    </div>
                    {f.relevance && (
                      <p className="text-[9px] text-slate-500 mt-1 italic border-l border-slate-700 pl-2">
                        {f.relevance}
                      </p>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* SUBTAB 5: PARENTERAL & SAFE PRACTICE */}
        {activeSubTab === "safe" && (
          <div className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              
              {/* PARENTERAL NUTRITION GUIDE */}
              <div className={`p-5 rounded-xl border ${isDarkMode ? "bg-slate-900/30 border-slate-800" : "bg-white border-slate-200"} space-y-4`}>
                <h3 className={`text-sm font-bold tracking-tight ${isDarkMode ? "text-slate-100" : "text-slate-900"} flex items-center gap-2 border-b border-slate-800 pb-3`}>
                  <Activity className="w-4.5 h-4.5 text-purple-400" />
                  Parenteral Nutrition (TPN / SPN) Guideline
                </h3>

                <div className="space-y-3.5 text-xs text-slate-300">
                  <div className="space-y-1.5">
                    <span className="font-extrabold text-purple-400 block uppercase font-mono text-[10px]">Initiation Criteria (Day 5-7):</span>
                    <p className="leading-relaxed">
                      Consider Total Parenteral Nutrition (TPN) or Supplemental Parenteral Nutrition (SPN) if enteral feeding is explicitly contraindicated or cannot be optimized by <span className="font-bold text-slate-100">day 5-7</span> of admission.
                    </p>
                    <p className="leading-relaxed text-[11px] text-slate-400 bg-slate-900/50 p-2.5 rounded border border-slate-800">
                      ℹ️ Supplemental PN is indicated if <span className="font-bold text-slate-100">&gt;60%</span> of calorie & protein requirements via the enteral route are not met after 7-10 days.
                    </p>
                  </div>

                  <div className="space-y-1.5">
                    <span className="font-extrabold text-purple-400 block uppercase font-mono text-[10px]">Parenteral Dosing Targets:</span>
                    <p className="leading-relaxed font-medium">
                      Start with non-protein calories of &le; 20-25 kcal/kg/day with protein &ge; 1.2 g/kg/day. Increase gradually and aim to achieve targeted rate in 5-7 days.
                    </p>
                    <div className="grid grid-cols-3 gap-2 mt-2 p-2.5 rounded bg-slate-950 font-mono text-[11px] text-center border border-slate-800">
                      <div>
                        <span className="block text-[8px] text-slate-500 font-bold uppercase">Carbohydrates</span>
                        <span className="font-extrabold text-slate-200">2 - 5 g/kg/d</span>
                      </div>
                      <div>
                        <span className="block text-[8px] text-slate-500 font-bold uppercase">Lipids</span>
                        <span className="font-extrabold text-slate-200 font-mono">0.75 - 1.5 g/kg/d</span>
                      </div>
                      <div>
                        <span className="block text-[8px] text-slate-500 font-bold uppercase">Proteins</span>
                        <span className="font-extrabold text-teal-400">1.2 - 2.0 g/kg/d</span>
                      </div>
                    </div>
                    <p className="text-[10px] text-slate-400 italic">
                      Ratio: Carbohydrate to lipid calorie ratio should be kept between <span className="font-bold">60:40 and 70:30</span>. Prescribe electrolytes based on daily serum levels; add trace elements and vitamins.
                    </p>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-2">
                    <div className="p-3 rounded-lg bg-slate-950 text-[11px] leading-normal border border-slate-800">
                      <span className="font-bold text-slate-100 block mb-1 uppercase font-mono text-[9px] tracking-wider text-rose-400">Administration Access:</span>
                      <ul className="list-disc pl-4 space-y-1 text-slate-400">
                        <li><span className="text-slate-200">Central Line:</span> Required for high osmolality formulas. Always run via a dedicated lumen.</li>
                        <li><span className="text-slate-200">Peripheral Line:</span> Safe ONLY for low osmolality formulas (<span className="text-slate-100">&lt;850 mOsmol/L</span>).</li>
                        <li>Change administrative IV set every 24 hours.</li>
                      </ul>
                    </div>

                    <div className="p-3 rounded-lg bg-slate-950 text-[11px] leading-normal border border-slate-800">
                      <span className="font-bold text-slate-100 block mb-1 uppercase font-mono text-[9px] tracking-wider text-amber-500">Laboratory Monitoring:</span>
                      <ul className="list-disc pl-4 space-y-1 text-slate-400">
                        <li><span className="text-slate-200">Glucose:</span> Check blood glucose 2-hourly (target: <span className="text-slate-100">8-10 mmol/L</span>).</li>
                        <li><span className="text-slate-200">Electrolytes:</span> Daily serum K+, PO4-, Ca2+, Mg2+ checks.</li>
                        <li><span className="text-slate-200">Organs:</span> LFT biweekly.</li>
                        <li><span className="text-slate-200">Triglyceride (TG):</span> Weekly (target <span className="text-slate-100">&lt;4.5 mmol/L</span>).</li>
                      </ul>
                    </div>
                  </div>

                  <div className="p-3 rounded-lg bg-teal-950/20 border border-teal-500/20 text-xs text-teal-300">
                    <span className="font-extrabold block uppercase tracking-wider font-mono text-[9px]">Discontinuation criteria:</span>
                    Wean off and discontinue parenteral nutrition as soon as patients safely tolerate <span className="font-bold font-mono text-slate-100">&gt;60%</span> of their targeted caloric requirements via enteral feeds.
                  </div>

                </div>
              </div>

              {/* SAFE EN BEDSIDE PRACTICES */}
              <div className={`p-5 rounded-xl border ${isDarkMode ? "bg-slate-900/30 border-slate-800" : "bg-white border-slate-200"} space-y-4`}>
                <h3 className={`text-sm font-bold tracking-tight ${isDarkMode ? "text-slate-100" : "text-slate-900"} flex items-center gap-2 border-b border-slate-800 pb-3`}>
                  <CheckCircle2 className="w-4.5 h-4.5 text-teal-400" />
                  Enteral Safe Practices Checklist
                </h3>

                <div className="space-y-4 text-xs text-slate-300 leading-normal">
                  <div className="flex gap-3">
                    <div className="w-5 h-5 rounded bg-teal-500/10 text-teal-400 font-mono font-bold flex items-center justify-center text-[10px] border border-teal-500/30 shrink-0 mt-0.5">✓</div>
                    <div>
                      <span className="block font-bold text-slate-100">Use Sterile Water:</span>
                      <p className="text-[11px] text-slate-400 mt-0.5">
                        Always use sterile water for formula reconstitution and routine tube flushing (to avoid tube contamination and line blockages).
                      </p>
                    </div>
                  </div>

                  <div className="flex gap-3">
                    <div className="w-5 h-5 rounded bg-teal-500/10 text-teal-400 font-mono font-bold flex items-center justify-center text-[10px] border border-teal-500/30 shrink-0 mt-0.5">✓</div>
                    <div>
                      <span className="block font-bold text-slate-100">Tube Flushing Routine:</span>
                      <p className="text-[11px] text-slate-400 mt-0.5">
                        Flush enteral feeding tubes with <span className="font-extrabold text-slate-100">at least 20-30ml sterile water</span> at the end of each feed or intermittent cycle. Always include this flush volume in the patient's daily fluid balance calculations.
                      </p>
                    </div>
                  </div>

                  <div className="flex gap-3">
                    <div className="w-5 h-5 rounded bg-teal-500/10 text-teal-400 font-mono font-bold flex items-center justify-center text-[10px] border border-teal-500/30 shrink-0 mt-0.5">✓</div>
                    <div>
                      <span className="block font-bold text-slate-100">Hang Time Durations:</span>
                      <p className="text-[11px] text-slate-400 mt-0.5">
                        Observe the maximum safe hang time duration at the bedside to prevent bacterial overgrowth:
                      </p>
                      <div className="grid grid-cols-3 gap-2 mt-2 p-2 bg-slate-950 rounded border border-slate-800 text-center font-mono text-[10px]">
                        <div>
                          <span className="block text-slate-500 font-bold text-[8px] uppercase">Closed RTU</span>
                          <span className="font-extrabold text-slate-200">24 Hours</span>
                        </div>
                        <div>
                          <span className="block text-slate-500 font-bold text-[8px] uppercase">Decanted Sterile</span>
                          <span className="font-extrabold text-slate-200">8 Hours</span>
                        </div>
                        <div>
                          <span className="block text-slate-500 font-bold text-[8px] uppercase">Powder Reconstituted</span>
                          <span className="font-extrabold text-slate-200">4 Hours</span>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="flex gap-3">
                    <div className="w-5 h-5 rounded bg-teal-500/10 text-teal-400 font-mono font-bold flex items-center justify-center text-[10px] border border-teal-500/30 shrink-0 mt-0.5">✓</div>
                    <div>
                      <span className="block font-bold text-slate-100">Administration Set Changes:</span>
                      <p className="text-[11px] text-slate-400 mt-0.5">
                        Always replace and change the enteral feeding administration set <span className="font-extrabold text-teal-400">every 24 hours</span> to maintain standard infection control.
                      </p>
                    </div>
                  </div>

                  <div className="flex gap-3">
                    <div className="w-5 h-5 rounded bg-teal-500/10 text-teal-400 font-mono font-bold flex items-center justify-center text-[10px] border border-teal-500/30 shrink-0 mt-0.5">✓</div>
                    <div>
                      <span className="block font-bold text-slate-100">Refrigeration & Waste Control:</span>
                      <p className="text-[11px] text-slate-400 mt-0.5">
                        Opened or decanted sterile feeds must be kept in the ward refrigerator and discarded within <span className="font-extrabold text-red-400">12 hours</span> if unused.
                      </p>
                    </div>
                  </div>
                </div>

              </div>

            </div>
          </div>
        )}

      </div>

    </div>
  );
}
