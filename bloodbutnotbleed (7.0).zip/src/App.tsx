import React, { useState, useEffect, useMemo } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  Search, 
  Droplet, 
  AlertTriangle, 
  Phone, 
  FileText, 
  Info, 
  Calculator, 
  Clock, 
  Wind, 
  ChevronRight, 
  CheckCircle2, 
  X, 
  HelpCircle, 
  Sparkles,
  Sun,
  Moon,
  Volume2,
  VolumeX,
  Copy,
  ArrowRight,
  Zap,
  ClipboardList,
  ShieldAlert,
  Heart,
  Trash2,
  Activity,
  Pill,
  ArrowUp,
  Coffee,
  Plus,
  Check,
  ListTodo
} from "lucide-react";
import { testDatabase } from "./data/labs";
import { dbDilution, dbRenalStable, dbRenalICU, dbRenalCommon, dbEnteral } from "./data/drugs";
import { dbEMTS } from "./data/emts";
import { LabTest, DilutionDrug, RenalStableDrug, RenalICUDrug, EMTSDrug, EnteralDrug } from "./types";
import { directoryData } from "./data/directory";
import { endocrineProtocols } from "./data/endocrine";
import NAGGuide from "./components/NAGGuide";
import PalliativeGuide from "./components/PalliativeGuide";
import ResusGuide from "./components/ResusGuide";
import CriticalCareNutrition from "./components/CriticalCareNutrition";

// Helper for synthesized calming sound (Deep Ambient Warm Pad with Ocean Filter Sweeps)
const playCalmingSound = () => {
  if (typeof window === 'undefined') return { stop: () => {} };
  
  const AudioContext = (window as any).AudioContext || (window as any).webkitAudioContext;
  if (!AudioContext) return { stop: () => {} };

  const audioCtx = new AudioContext();
  
  // Master volume node
  const masterGain = audioCtx.createGain();
  masterGain.connect(audioCtx.destination);
  masterGain.gain.setValueAtTime(0, audioCtx.currentTime);
  masterGain.gain.linearRampToValueAtTime(0.12, audioCtx.currentTime + 3.0);

  // Soft lowpass filter to remove clinical or metallic frequencies and make it extremely warm
  const filter = audioCtx.createBiquadFilter();
  filter.type = 'lowpass';
  filter.frequency.setValueAtTime(320, audioCtx.currentTime);
  filter.Q.setValueAtTime(0.8, audioCtx.currentTime);
  filter.connect(masterGain);

  // Filter LFO to create slow, breathing, ocean-wave-like sweeps
  const filterLfo = audioCtx.createOscillator();
  const filterLfoGain = audioCtx.createGain();
  filterLfo.frequency.setValueAtTime(0.08, audioCtx.currentTime); // 12-second sweep cycle
  filterLfoGain.gain.setValueAtTime(120, audioCtx.currentTime); // sweep range +/- 120Hz
  filterLfo.connect(filterLfoGain);
  filterLfoGain.connect(filter.frequency);
  filterLfo.start();

  // Celestial, deeply relaxing chord (G Major 9th / Sus2 Pentatonic stack)
  // G2 (98Hz) - deep warm ground
  // D3 (146.83Hz) - stabilizing fifth
  // G3 (196.00Hz) - anchor octave
  // A3 (220.00Hz) - lush suspension ninth
  // B3 (246.94Hz) - sweet third
  // D4 (293.66Hz) - shimmering fifth
  const frequencies = [98.00, 146.83, 196.00, 220.00, 246.94, 293.66];
  
  // Prime number LFO rates for asynchronous volume swells (ensuring they never align, creating endless organic evolution)
  const lfoRates = [0.035, 0.047, 0.023, 0.059, 0.037, 0.051];

  const oscillators = frequencies.map((freq, i) => {
    const osc = audioCtx.createOscillator();
    const voiceGain = audioCtx.createGain();
    
    // Mix sines (purity) and triangles (harmonic texture, smoothed by our low-pass filter)
    osc.type = i % 2 === 0 ? 'sine' : 'triangle';
    
    // Tiny analog detune to create a lush, warm, chorus-like widening effect
    const detuneAmount = (Math.random() - 0.5) * 0.7;
    osc.frequency.setValueAtTime(freq + detuneAmount, audioCtx.currentTime);
    
    // Dynamic swell controller
    const volLfo = audioCtx.createOscillator();
    const volLfoGain = audioCtx.createGain();
    
    volLfo.frequency.setValueAtTime(lfoRates[i % lfoRates.length], audioCtx.currentTime);
    
    // Calculate balanced gains per voice to ensure zero distortion or clipping
    const baseGain = 0.07 / frequencies.length;
    voiceGain.gain.setValueAtTime(baseGain, audioCtx.currentTime);
    
    // Modulate gain by up to 70% of its base value
    volLfoGain.gain.setValueAtTime(baseGain * 0.7, audioCtx.currentTime);
    
    volLfo.connect(volLfoGain);
    volLfoGain.connect(voiceGain.gain);
    
    volLfo.start();
    osc.connect(voiceGain);
    voiceGain.connect(filter);
    osc.start();
    
    return { osc, volLfo };
  });

  return {
    stop: () => {
      // Smooth 3.0-second fadeout
      masterGain.gain.linearRampToValueAtTime(0, audioCtx.currentTime + 3.0);
      setTimeout(() => {
        oscillators.forEach(({ osc, volLfo }) => {
          try {
            osc.stop();
            volLfo.stop();
          } catch (e) {}
        });
        try {
          filterLfo.stop();
        } catch (e) {}
        audioCtx.close().catch(() => {});
      }, 3100);
    }
  };
};

export default function App() {
  // Theme State
  const [theme, setTheme] = useState<"dark" | "light">("dark");
  
  // Scroll to Top State
  const [showScrollTop, setShowScrollTop] = useState(false);
  useEffect(() => {
    const handleScroll = () => {
      setShowScrollTop(window.scrollY > 400);
    };
    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);
  
  // Logo Error State
  const [logoError, setLogoError] = useState(false);

  // Search & Filter State
  const [searchQuery, setSearchQuery] = useState("");
  const [searchFilter, setSearchFilter] = useState<"All" | "Labs" | "Drugs" | "Renal" | "Algorithm">("All");
  const [selectedLabFilter, setSelectedLabFilter] = useState<string>("All");
  const [selectedDilutionFilter, setSelectedDilutionFilter] = useState<string>("All");
  const [selectedRenalFilter, setSelectedRenalFilter] = useState<string>("All");
  const [selectedEnteralFilter, setSelectedEnteralFilter] = useState<string>("All");
  const [selectedEMTSCategory, setSelectedEMTSCategory] = useState<string>("All");

  // Recent Searches State
  const [recentSearches, setRecentSearches] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem("recentSearches");
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });
  const [isSearchFocused, setIsSearchFocused] = useState(false);

  const addToRecentSearches = (query: string) => {
    const trimmed = query.trim();
    if (!trimmed || trimmed.length < 2) return;
    setRecentSearches(prev => {
      // Remove duplicates case-insensitively
      const filtered = prev.filter(item => item.toLowerCase() !== trimmed.toLowerCase());
      const newHistory = [trimmed, ...filtered].slice(0, 8);
      localStorage.setItem("recentSearches", JSON.stringify(newHistory));
      return newHistory;
    });
  };

  const removeRecentSearch = (e: React.MouseEvent, query: string) => {
    e.stopPropagation();
    e.preventDefault();
    setRecentSearches(prev => {
      const newHistory = prev.filter(item => item !== query);
      localStorage.setItem("recentSearches", JSON.stringify(newHistory));
      return newHistory;
    });
  };

  const clearRecentSearches = (e: React.MouseEvent) => {
    e.stopPropagation();
    e.preventDefault();
    setRecentSearches([]);
    localStorage.removeItem("recentSearches");
  };

  // Auto-save search queries to history when typing stops for 2 seconds
  useEffect(() => {
    if (!searchQuery.trim() || searchQuery.trim().length < 2) return;
    const handler = setTimeout(() => {
      addToRecentSearches(searchQuery);
    }, 2000);
    return () => clearTimeout(handler);
  }, [searchQuery]);
  
  // Synonym dictionary for clinical terms
  const getSynonyms = (query: string): string[] => {
    const qRaw = query.toLowerCase().trim();
    // Normalize common typos or variations, removing hyphens and spaces for spelling-level comparison
    let q = qRaw.replace(/[-\s]+/g, "");
    if (q.includes("anticaar") || q.includes("anticar") || q === "acl" || q.includes("cardiolipin")) {
      q = "anticardiolipin";
    }
    if (q.includes("phospholipid") || q === "aps" || q === "apl") {
      q = "antiphospholipid";
    }

    const synonyms: string[] = [qRaw, q];
    
    // Dictionary matching for clinical syndromes
    if (q === "anticardiolipin" || q === "antiphospholipid" || q === "lupusanticoagulant" || q === "beta2" || q === "b2gp1") {
      synonyms.push("anticardiolipin", "acl", "aps", "antiphospholipid", "lupus anticoagulant", "anti-dsdna", "beta-2 glycoprotein", "b2gp1", "sle", "lupus", "rheumatoid", "serology");
    }
    if (q === "sle" || q === "lupus" || q === "dsdna" || q === "ana" || q === "autoimmune") {
      synonyms.push("sle", "lupus", "dsdna", "anti-dsdna", "anti-nuclear", "ana", "autoimmune", "anticardiolipin", "lupus anticoagulant", "serology");
    }
    if (q === "renal" || q === "rft" || q === "rp" || q === "kidney") {
      synonyms.push("renal profile", "urea", "creatinine", "sodium", "potassium", "chloride", "gfr", "clearance");
    }
    if (q === "lft" || q === "liver") {
      synonyms.push("liver function test", "alt", "ast", "alp", "bilirubin", "albumin", "total protein", "gamma-glutamyltransferase");
    }
    if (q === "dic" || q === "divc") {
      synonyms.push("divc", "d-dimer", "fibrinogen", "aptt", "prothrombin");
    }
    if (q === "coag" || q === "clotting" || q === "coagulation") {
      synonyms.push("coagulation", "pt", "inr", "aptt", "fibrinogen", "lupus anticoagulant", "citrate", "blue cap");
    }
    if (q === "cardiac" || q === "heart" || q === "mi") {
      synonyms.push("troponin", "creatine kinase", "ast", "lactate dehydrogenase", "ckmb", "cardiac");
    }
    if (q === "bone" || q === "calcium") {
      synonyms.push("calcium", "phosphate", "alkaline phosphatase", "parathyroid", "vitamin d", "ipth");
    }
    if (q === "std" || q === "vdrl" || q === "hiv") {
      synonyms.push("syphilis", "hiv", "hepatitis", "gonococcal", "ct/ng");
    }
    if (q === "lipid" || q === "cholesterol") {
      synonyms.push("cholesterol", "triglycerides", "hdl", "fasting serum lipid", "fsl");
    }
    if (q === "tft" || q === "thyroid") {
      synonyms.push("thyroid", "tsh", "ft4", "ft3", "free t4", "free t3");
    }
    if (q === "ufeme" || q === "feme" || q === "urine") {
      synonyms.push("urine biochemistry", "feme", "dysmorphic");
    }
    if (q === "fbc" || q === "fbp" || q === "fullblood") {
      synonyms.push("full blood count", "full blood picture", "fbp", "fbc", "hemoglobin", "haemoglobin", "platelet", "wbc", "edta tube", "purple");
    }
    if (q === "abg" || q === "vbg" || q === "gas" || q === "bloodgas") {
      synonyms.push("blood gases", "cooximetry", "preheparinized syringe", "lactate", "ph");
    }
    if (q === "gxm" || q === "gsh" || q === "crossmatch" || q === "transfusion") {
      synonyms.push("group and crossmatch", "gsh", "blood bank", "screen and hold");
    }
    if (q === "neuro" || q === "neurology") {
      synonyms.push("acetylcholine", "musk", "aquaporin", "nmo", "mog", "encephalitis", "paraneoplastic", "14-3-3", "oligoclonal", "vdrl");
    }
    if (q === "endo" || q === "endocrinology") {
      synonyms.push("synacthen", "dexamethasone", "growth hormone", "water deprivation", "insulin tolerance", "aldosterone", "renin", "cortisol", "metanephrine");
    }
    if (q === "piptazo") {
      synonyms.push("piperacillin", "piperacilin/tazobactam");
    }
    if (q === "coamox" || q === "augmentin") {
      synonyms.push("amoxicillin/clavulanate");
    }
    if (q === "cloxa") {
      synonyms.push("cloxacillin");
    }
    if (q === "bactrim") {
      synonyms.push("trimethoprim / sulfamethoxazole", "tmp");
    }
    if (q === "hba1c") {
      synonyms.push("haemoglobin a1c");
    }
    if (q === "trop") {
      synonyms.push("troponin t high sensitive");
    }
    if (q === "lytic") {
      synonyms.push("lytic cocktail");
    }
    if (q === "paracetamol" || q === "panadol" || q === "pcm") {
      synonyms.push("acetaminophen", "paracetamol", "plain tube without gel", "pcm", "panadol");
    }
    if (q === "yellow" || q === "gold" || q === "sst" || q === "yellowcap" || q === "goldcap") {
      synonyms.push("plain tube with gel (yellow cap)", "gel", "yellow cap", "sst");
    }
    if (q.includes("hla") || q.includes("b27") || q.includes("b58") || q.includes("typing") || q.includes("genotype")) {
      synonyms.push("hla-b27", "hla-b*58:01", "allopurinol", "spondyloarthritis", "ankylosing spondylitis", "scar screening", "sjs", "ten", "genotyping");
    }
    if (q.includes("quantiferon") || q.includes("igra") || q.includes("latent") || q === "tb" || q.includes("tuberculosis")) {
      synonyms.push("quantiferon-tb gold plus (igra)", "latent", "interferon-gamma", "grey", "green", "yellow", "purple", "nil", "mitogen");
    }
    if (q.includes("fungal") || q.includes("galactomannan") || q.includes("glucan") || q.includes("aspergillus")) {
      synonyms.push("serum galactomannan antigen", "serum beta-d-glucan", "bdg", "aspergillus", "invasive fungal");
    }
    if (q === "blue" || q === "citrate" || q === "bluecap") {
      synonyms.push("blue cap (citrate)", "trisodium citrate", "blue cap");
    }
    if (q === "purple" || q === "lavender" || q === "edta" || q === "purplecap" || q === "lavendercap") {
      synonyms.push("edta tube", "purple");
    }
    if (q === "green" || q === "heparin" || q === "greencap") {
      synonyms.push("lithium heparin", "green");
    }
    if (q === "grey" || q === "fluoride" || q === "sugar") {
      synonyms.push("grey cap", "fluoride", "grey");
    }

    return Array.from(new Set(synonyms));
  };

  // Pre-calculate queries and synonyms to avoid overhead in the item loops
  const queryInfo = useMemo(() => {
    const trimmed = searchQuery.trim();
    if (!trimmed) return null;

    const cleanQuery = trimmed.toLowerCase()
      .replace(/anticaardiolpin/g, "anticardiolipin")
      .replace(/anticaar/g, "anticar");
    const cleanQueryNormalized = cleanQuery.replace(/[-\s]+/g, "");
    
    const words = cleanQuery.split(/\s+/).filter(Boolean);
    
    // For each word, resolve its synonyms and their normalized forms once
    const processedWords = words.map(word => {
      const normWord = word.replace(/[-\s]+/g, "");
      const wordSyns = getSynonyms(word);
      const synsWithNorms = wordSyns.map(syn => ({
        syn,
        normSyn: syn.replace(/[-\s]+/g, "")
      }));
      return {
        word,
        normWord,
        syns: synsWithNorms
      };
    });

    // Resolve whole query synonyms and their normalized forms once
    const wholeSyns = getSynonyms(cleanQuery);
    const wholeSynsWithNorms = wholeSyns.map(syn => ({
      syn,
      normSyn: syn.replace(/[-\s]+/g, "")
    }));

    return {
      cleanQuery,
      cleanQueryNormalized,
      words,
      processedWords,
      wholeSyns: wholeSynsWithNorms
    };
  }, [searchQuery]);

  // Memoized edit distance helper to calculate levenshtein distance with high performance
  const getEditDistance = (s1: string, s2: string): number => {
    const len1 = s1.length;
    const len2 = s2.length;
    if (len1 === 0) return len2;
    if (len2 === 0) return len1;
    
    let prevRow = Array.from({ length: len2 + 1 }, (_, j) => j);
    let currRow = new Array(len2 + 1);
    
    for (let i = 1; i <= len1; i++) {
      currRow[0] = i;
      for (let j = 1; j <= len2; j++) {
        const cost = s1[i - 1] === s2[j - 1] ? 0 : 1;
        currRow[j] = Math.min(
          currRow[j - 1] + 1,      // insertion
          prevRow[j] + 1,          // deletion
          prevRow[j - 1] + cost    // substitution
        );
      }
      prevRow = [...currRow];
    }
    return prevRow[len2];
  };

  const matchesQuery = (textToSearch: string, _query?: string) => {
    if (!queryInfo) return true;
    const target = textToSearch.toLowerCase();
    const targetNormalized = target.replace(/[-\s]+/g, "");

    // Direct match on full normalized query
    if (targetNormalized.includes(queryInfo.cleanQueryNormalized)) return true;

    // Helper to evaluate fuzzy match on a single word or token
    const fuzzyMatchWord = (targetText: string, queryWord: string): boolean => {
      if (targetText.includes(queryWord)) return true;

      // Extract alphanumeric-only words from target for clean token-level matching
      const targetTokens = targetText.split(/[^a-z0-9]+/).filter(Boolean);
      for (const token of targetTokens) {
        if (token.includes(queryWord) || (queryWord.includes(token) && token.length >= 3)) return true;

        // Perform edit distance check if word length is substantial
        if (queryWord.length >= 4 && token.length >= 4) {
          const maxAllowedEditDistance = queryWord.length <= 5 ? 1 : 2;
          const dist = getEditDistance(queryWord, token);
          if (dist <= maxAllowedEditDistance) return true;
        }
      }
      return false;
    };

    // 1. Check if every word in the query matches the target directly, via individual synonyms, or via fuzzy matching
    const matchesAllWords = queryInfo.processedWords.every(({ word, normWord, syns }) => {
      if (fuzzyMatchWord(target, word)) return true;
      if (fuzzyMatchWord(targetNormalized, normWord)) return true;

      return syns.some(({ syn, normSyn }) => 
        fuzzyMatchWord(target, syn) || fuzzyMatchWord(targetNormalized, normSyn)
      );
    });

    if (matchesAllWords) return true;

    // 2. Fallback: Check whole query synonyms
    return queryInfo.wholeSyns.some(({ syn, normSyn }) => 
      fuzzyMatchWord(target, syn) || fuzzyMatchWord(targetNormalized, normSyn)
    );
  };

  const highlightMatch = (text: string, query: string) => {
    if (!query) return <span>{text}</span>;
    const words = query.toLowerCase().split(/\s+/).filter(Boolean);
    if (words.length === 0) return <span>{text}</span>;
    
    // Escape and build regex to match words
    const escapedWords = words.map(w => w.replace(/[-\/\\^$*+?.()|[\]{}]/g, '\\$&'));
    const regex = new RegExp(`(${escapedWords.join('|')})`, 'gi');
    const parts = text.split(regex);
    const testRegex = new RegExp(`^(${escapedWords.join('|')})$`, 'i');
    
    return (
      <span>
        {parts.map((part, i) => 
          testRegex.test(part) ? (
            <mark key={i} className={`px-0.5 rounded font-semibold ${isDarkMode ? "bg-amber-400/40 text-amber-200" : "bg-amber-400/30 text-amber-900"}`}>
              {part}
            </mark>
          ) : (
            part
          )
        )}
      </span>
    );
  };

  const renderRenalBadge = (label: string, value: string) => {
    const isAvoid = value.toLowerCase().includes("avoid") || value.toLowerCase().includes("contraindicated");
    
    let badgeClass = "";
    let strongClass = "";
    
    if (isAvoid) {
      if (isDarkMode) {
        badgeClass = "bg-rose-950/20 border border-rose-900/40 text-rose-300";
        strongClass = "text-rose-400 font-bold";
      } else {
        badgeClass = "bg-rose-50 border border-rose-200 text-rose-800 shadow-sm";
        strongClass = "text-rose-700 font-bold";
      }
    } else {
      if (isDarkMode) {
        badgeClass = "bg-slate-900 border border-slate-800 text-slate-300";
        strongClass = "text-teal-400 font-bold";
      } else {
        badgeClass = "bg-slate-100 border border-slate-200 text-slate-700 shadow-sm";
        strongClass = "text-teal-700 font-bold";
      }
    }
    
    return (
      <span className={`px-2 py-1 rounded text-xs transition-colors ${badgeClass}`}>
        {label}: <strong className={strongClass}>{highlightMatch(value, searchQuery)}</strong>
      </span>
    );
  };

  const [activeTab, setActiveTab] = useState<"labs" | "drug" | "directory" | "calc" | "ho_guide" | "nag" | "palliative" | "resus" | "oncall">("labs");
  const [drugSubTab, setDrugSubTab] = useState<"renal" | "dilution" | "enteral">("renal");
  const [labsSubTab, setLabsSubTab] = useState<"database" | "endocrine">("database");
  const [resusSubTab, setResusSubTab] = useState<"interactive" | "em_drugs" | "nutrition">("interactive");
  const [renalSubTab, setRenalSubTab] = useState<"stable" | "icu">("stable");
  const [renalCategory, setRenalCategory] = useState<"antibiotic" | "common">("antibiotic");

  // On-Call Fatigue Kit States
  const [onCallTasks, setOnCallTasks] = useState<{ id: string; room: string; patient: string; task: string; urgency: "routine" | "important" | "urgent"; status: "pending" | "completed" }[]>(() => {
    try {
      const saved = localStorage.getItem("oncall_tasks");
      return saved ? JSON.parse(saved) : [
        { id: "1", room: "Ward 5B", patient: "Bed 12 (Mr Tan)", task: "Trace CT Brain report", urgency: "urgent", status: "pending" },
        { id: "2", room: "Ward 5B", patient: "Bed 4 (Mdm Aminah)", task: "Review post-op Hb", urgency: "important", status: "pending" },
        { id: "3", room: "Ward 5A", patient: "Bed 18 (Mr Raju)", task: "Insert green cannula", urgency: "routine", status: "pending" }
      ];
    } catch {
      return [];
    }
  });

  useEffect(() => {
    localStorage.setItem("oncall_tasks", JSON.stringify(onCallTasks));
  }, [onCallTasks]);

  const [onCallRoom, setOnCallRoom] = useState("");
  const [onCallPatient, setOnCallPatient] = useState("");
  const [onCallTaskType, setOnCallTaskType] = useState("Review bloods");
  const [onCallCustomTask, setOnCallCustomTask] = useState("");
  const [onCallUrgency, setOnCallUrgency] = useState<"routine" | "important" | "urgent">("routine");
  const [onCallSelectedGuide, setOnCallSelectedGuide] = useState<"fever" | "dyspnea" | "hypotension" | "agitated" | "oliguria">("fever");
  const [onCallSubTab, setOnCallSubTab] = useState<"tracker" | "survival" | "decompress">("tracker");
  const [onCallTaskFilter, setOnCallTaskFilter] = useState<"all" | "pending" | "completed">("all");

  // Decompress box breathing states
  const [onCallBreathingActive, setOnCallBreathingActive] = useState(false);
  const [onCallBreathingPhase, setOnCallBreathingPhase] = useState<"inhale" | "hold1" | "exhale" | "hold2">("inhale");
  const [onCallBreathingSecondsLeft, setOnCallBreathingSecondsLeft] = useState(4);
  const [onCallBreathingCycleCount, setOnCallBreathingCycleCount] = useState(0);

  // Triage checklist state
  const [survivalChecklist, setSurvivalChecklist] = useState<Record<string, boolean>>({});

  // Reset drug filters when active tabs or categories change
  useEffect(() => {
    setSelectedDilutionFilter("All");
    setSelectedRenalFilter("All");
    setSelectedEnteralFilter("All");
  }, [activeTab, drugSubTab, renalCategory]);

  // Box breathing interval effect for burnout relief
  useEffect(() => {
    let interval: any = null;
    if (onCallBreathingActive) {
      interval = setInterval(() => {
        setOnCallBreathingSecondsLeft((prev) => {
          if (prev <= 1) {
            setOnCallBreathingPhase((currentPhase) => {
              if (currentPhase === "inhale") return "hold1";
              if (currentPhase === "hold1") return "exhale";
              if (currentPhase === "exhale") return "hold2";
              // "hold2" -> increment cycle and go back to inhale
              setOnCallBreathingCycleCount((count) => count + 1);
              return "inhale";
            });
            return 4;
          }
          return prev - 1;
        });
      }, 1000);
    } else {
      setOnCallBreathingSecondsLeft(4);
      setOnCallBreathingPhase("inhale");
      setOnCallBreathingCycleCount(0);
    }
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [onCallBreathingActive]);

  // Resuscitation & Emergency States
  const [resusActiveAlg, setResusActiveAlg] = useState<"cardiac" | "anaphylaxis" | "asthma" | "seizures" | "hyperkalemia">("cardiac");
  const [resusRhythm, setResusRhythm] = useState<"shockable" | "non-shockable">("shockable");
  const [resusCprTimeLeft, setResusCprTimeLeft] = useState(120); // 2-minute CPR cycle countdown
  const [resusCprTimerRunning, setResusCprTimerRunning] = useState(false);
  const [resusAdrenalineCount, setResusAdrenalineCount] = useState(0);
  const [resusAmiodaroneCount, setResusAmiodaroneCount] = useState(0);
  const [resusCyclesCompleted, setResusCyclesCompleted] = useState(0);
  const [resusMetronomeActive, setResusMetronomeActive] = useState(false);
  const [resusTimeHistory, setResusTimeHistory] = useState<{ id: string; time: string; event: string }[]>([]);

  // House Officer Ward Guide States
  const [hoActiveGuide, setHoActiveGuide] = useState<"pleural" | "ascites" | "csf" | "bma" | "hemolytic">("pleural");
  const [hoChecklist, setHoChecklist] = useState<Record<string, boolean>>({});

  // Interactive clinical scoring calculator inputs
  const [hoPleuralFluidProtein, setHoPleuralFluidProtein] = useState("");
  const [hoSerumProtein, setHoSerumProtein] = useState("");
  const [hoPleuralFluidLdh, setHoPleuralFluidLdh] = useState("");
  const [hoSerumLdh, setHoSerumLdh] = useState("");
  const [hoSerumLdhUpperLimit, setHoSerumLdhUpperLimit] = useState("200");

  const [hoSerumAlbumin, setHoSerumAlbumin] = useState("");
  const [hoAscitesAlbumin, setHoAscitesAlbumin] = useState("");

  const [hoCsfGlucose, setHoCsfGlucose] = useState("");
  const [hoRandomBloodSugar, setHoRandomBloodSugar] = useState("");

  // Interactive Parenteral Iron states (HKL Preferred Parenteral Iron Protocol 2nd Edition)
  const [ironPatientWeight, setIronPatientWeight] = useState("70");
  const [ironActualHb, setIronActualHb] = useState("9.0");
  const [ironTargetHbOverride, setIronTargetHbOverride] = useState("");
  const [ironStoresOverride, setIronStoresOverride] = useState("");
  const [ironSelectedFormulation, setIronSelectedFormulation] = useState<"venofer" | "cosmofer" | "ferinject" | "monofer">("venofer");
  const [ironCalculationMethod, setIronCalculationMethod] = useState<"ganzoni" | "simplified">("ganzoni");

  // Procedure Note Generator States
  const [procIndication, setProcIndication] = useState("Diagnostic");
  const [procOperator, setProcOperator] = useState("Doctor / Medical Officer");
  const [procVolume, setProcVolume] = useState("20");
  const [procAppearance, setProcAppearance] = useState("clear straw-coloured");
  const [procComplications, setProcComplications] = useState("None");
  const [procAseptic, setProcAseptic] = useState(true);
  const [procAnaesthesia, setProcAnaesthesia] = useState("5ml of 2% Lignocaine");

  // Dynamic preset updating based on active procedure tab to reduce HO clerical burden
  useEffect(() => {
    if (hoActiveGuide === "pleural") {
      setProcVolume("20");
      setProcAppearance("clear straw-coloured");
      setProcIndication("Diagnostic (investigate effusion)");
    } else if (hoActiveGuide === "ascites") {
      setProcVolume("50");
      setProcAppearance("clear straw-coloured");
      setProcIndication("Diagnostic (investigate ascites/rule out SBP)");
    } else if (hoActiveGuide === "csf") {
      setProcVolume("8");
      setProcAppearance("clear and colourless");
      setProcIndication("Diagnostic (rule out meningitis/CNS infection)");
    } else if (hoActiveGuide === "bma") {
      setProcVolume("2");
      setProcAppearance("hemic with marrow fragments");
      setProcIndication("Diagnostic (pancytopenia / leukemia workup)");
    }
    setProcComplications("None");
  }, [hoActiveGuide]);

  // EMTS Calculator States
  const [emtsSelectedDrug, setEmtsSelectedDrug] = useState<"adrenaline" | "noradrenaline" | "dopamine" | "dobutamine" | "labetalol">("noradrenaline");
  const [emtsStrength, setEmtsStrength] = useState<"single" | "double">("single");
  const [emtsWeight, setEmtsWeight] = useState("");
  const [emtsDose, setEmtsDose] = useState(""); // mcg/kg/min or mg/min
  const [emtsResult, setEmtsResult] = useState<{ mlPerHour: number; concentration: number; prepText: string } | null>(null);

  // Calculator States
  const [cgAge, setCgAge] = useState("");
  const [cgWeight, setCgWeight] = useState("");
  const [cgHeight, setCgHeight] = useState("");
  const [cgCreatinine, setCgCreatinine] = useState("");
  const [cgSex, setCgSex] = useState<"male" | "female">("male");
  const [cgWeightType, setCgWeightType] = useState<"actual" | "ideal" | "adjusted">("actual");
  const [cgResult, setCgResult] = useState<number | null>(null);
  const [cgCalculatedWeights, setCgCalculatedWeights] = useState<{ ibw: number; ajbw: number; bmi: number; isObese: boolean; recommended: "actual" | "ideal" | "adjusted" } | null>(null);

  // Lab Interpreter States
  const [selectedInterpreterTest, setSelectedInterpreterTest] = useState("");
  const [interpreterValue, setInterpreterValue] = useState("");
  const [interpreterResult, setInterpreterResult] = useState<{ status: "low" | "normal" | "high" | "critical-low" | "critical-high"; text: string; action: string } | null>(null);

  // Bedside Calculators Sub-Tab State
  const [calcSubTab, setCalcSubTab] = useState<"standard" | "infusion">("standard");
  const [selectedStandardCalc, setSelectedStandardCalc] = useState<"fluids" | "crcl" | "calcium" | "flow_rate">("fluids");

  // Interactive Drug Infusion Calculator States
  const [infDrug, setInfDrug] = useState<"noradrenaline" | "adrenaline" | "dopamine" | "dobutamine" | "insulin" | "heparin" | "custom">("noradrenaline");
  const [infWeight, setInfWeight] = useState<string>("70");
  const [infPrep, setInfPrep] = useState<"single" | "double" | "custom">("single");
  const [infCustomConc, setInfCustomConc] = useState<string>("80"); // mcg/ml, units/ml, or mg/ml
  const [infCustomUnit, setInfCustomUnit] = useState<"mcg/kg/min" | "mcg/min" | "units/hr" | "mg/hr">("mcg/kg/min");
  const [infTargetDose, setInfTargetDose] = useState<string>("0.1");
  const [infMlPerHour, setInfMlPerHour] = useState<string>("2.63");
  const [infCalcMode, setInfCalcMode] = useState<"doseToRate" | "rateToDose">("doseToRate");

  // Bedside Reconstitution / Dilution Dosing Helper states
  const [selectedReconDrug, setSelectedReconDrug] = useState<string>("");
  const [reconDoseInput, setReconDoseInput] = useState("");
  const [reconResultText, setReconResultText] = useState<string>("");

  const [caMeasured, setCaMeasured] = useState("");
  const [caAlbumin, setCaAlbumin] = useState("");
  const [caResult, setCaResult] = useState<number | null>(null);

  const [infusionVol, setInfusionVol] = useState("");
  const [infusionDuration, setInfusionVolDuration] = useState("");
  const [infusionDropFactor, setInfusionDropFactor] = useState("20"); // 20 drops/ml standard IV, 60 microdrip
  const [infusionResult, setInfusionResult] = useState<{ mlPerHour: number; dropsPerMin: number } | null>(null);

  // Collapsible states for bedside calculators
  const [isCgExpanded, setIsCgExpanded] = useState(false);
  const [isCaExpanded, setIsCaExpanded] = useState(false);
  const [isInfusionExpanded, setIsInfusionExpanded] = useState(false);

  // Copy success notification
  const [copyFeedback, setCopySuccess] = useState<string | null>(null);

  // Rejection prevention panel
  const [showRejectionTips, setShowRejectionTips] = useState(false);

  // Toggle Theme
  const toggleTheme = () => {
    setTheme(prev => prev === "dark" ? "light" : "dark");
  };

  // Resus Interactive Timer Effect
  useEffect(() => {
    let interval: any = null;
    if (resusCprTimerRunning) {
      interval = setInterval(() => {
        setResusCprTimeLeft((prev) => {
          if (prev <= 1) {
            setResusCprTimerRunning(false);
            setResusCyclesCompleted((c) => c + 1);
            
            // Add to timeline log
            const now = new Date();
            const timeStr = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
            setResusTimeHistory((history) => [
              { id: Math.random().toString(), time: timeStr, event: "🚨 2-Minute CPR Cycle Completed. Reassess Rhythm & Pulse!" },
              ...history
            ]);
            
            // Play double-beep alarm sound
            try {
              const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
              
              const playBeep = (timeOffset: number) => {
                const osc = audioCtx.createOscillator();
                const gainNode = audioCtx.createGain();
                osc.connect(gainNode);
                gainNode.connect(audioCtx.destination);
                osc.frequency.setValueAtTime(880, audioCtx.currentTime + timeOffset);
                gainNode.gain.setValueAtTime(0, audioCtx.currentTime + timeOffset);
                gainNode.gain.linearRampToValueAtTime(0.3, audioCtx.currentTime + timeOffset + 0.05);
                gainNode.gain.linearRampToValueAtTime(0, audioCtx.currentTime + timeOffset + 0.45);
                osc.start(audioCtx.currentTime + timeOffset);
                osc.stop(audioCtx.currentTime + timeOffset + 0.5);
              };

              playBeep(0);
              playBeep(0.6);
              
              setTimeout(() => {
                audioCtx.close().catch(() => {});
              }, 1500);
            } catch (e) {}
            
            return 120;
          }
          return prev - 1;
        });
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [resusCprTimerRunning]);

  // CPR Metronome Effect (110 BPM)
  useEffect(() => {
    let metronomeInterval: any = null;
    if (resusMetronomeActive) {
      const bpm = 110;
      const intervalMs = (60 / bpm) * 1000;
      
      metronomeInterval = setInterval(() => {
        try {
          const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
          const osc = audioCtx.createOscillator();
          const gainNode = audioCtx.createGain();
          osc.connect(gainNode);
          gainNode.connect(audioCtx.destination);
          
          // Crisp, non-intrusive click
          osc.frequency.setValueAtTime(1200, audioCtx.currentTime); 
          gainNode.gain.setValueAtTime(0.1, audioCtx.currentTime);
          gainNode.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.04);
          
          osc.start();
          osc.stop(audioCtx.currentTime + 0.05);
          
          // Cleanup audio context after tick is done
          setTimeout(() => {
            audioCtx.close().catch(() => {});
          }, 100);
        } catch (e) {}
      }, intervalMs);
    }
    return () => clearInterval(metronomeInterval);
  }, [resusMetronomeActive]);

  // Keyboard shortcut to focus search
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        document.getElementById('global-search-input')?.focus();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  // Handle Calculators
  const calculateCrCl = () => {
    const age = parseFloat(cgAge);
    const weight = parseFloat(cgWeight);
    const height = parseFloat(cgHeight);
    const creatinine = parseFloat(cgCreatinine);

    if (age && weight && creatinine) {
      let ibw = weight;
      let ajbw = weight;
      let bmi = 0;
      let isObese = false;
      let recommended: "actual" | "ideal" | "adjusted" = "actual";

      if (height) {
        const heightInInches = height / 2.54;
        const inchesOver5Feet = Math.max(0, heightInInches - 60);
        ibw = cgSex === "male" 
          ? 50.0 + 2.3 * inchesOver5Feet 
          : 45.5 + 2.3 * inchesOver5Feet;
        
        bmi = weight / ((height / 100) ** 2);
        isObese = bmi >= 30 || weight > 1.2 * ibw;
        
        if (weight > 1.2 * ibw) {
          ajbw = ibw + 0.4 * (weight - ibw);
          recommended = "adjusted";
        } else if (weight < ibw) {
          recommended = "actual";
        } else {
          recommended = "ideal";
        }

        setCgCalculatedWeights({
          ibw: parseFloat(ibw.toFixed(1)),
          ajbw: parseFloat(ajbw.toFixed(1)),
          bmi: parseFloat(bmi.toFixed(1)),
          isObese,
          recommended
        });
      } else {
        setCgCalculatedWeights(null);
      }

      // Determine weight to use in formula based on selection
      let weightToUse = weight;
      if (height) {
        if (cgWeightType === "ideal") weightToUse = ibw;
        else if (cgWeightType === "adjusted") weightToUse = ajbw;
      }

      const factor = cgSex === "male" ? 1.23 : 1.04;
      const crcl = ((140 - age) * weightToUse * factor) / creatinine;
      setCgResult(crcl);
    } else {
      setCgResult(null);
      setCgCalculatedWeights(null);
    }
  };

  const calculateCalcium = () => {
    const ca = parseFloat(caMeasured);
    const alb = parseFloat(caAlbumin);

    if (ca && alb) {
      // Corrected Ca = Measured Ca + 0.02 * (40 - Albumin)
      const corrected = ca + 0.02 * (40 - alb);
      setCaResult(corrected);
    } else {
      setCaResult(null);
    }
  };

  const calculateInfusion = () => {
    const vol = parseFloat(infusionVol);
    const hrs = parseFloat(infusionDuration);
    const df = parseFloat(infusionDropFactor);

    if (vol && hrs && df) {
      const mlPerHour = vol / hrs;
      const dropsPerMin = (vol * df) / (hrs * 60);
      setInfusionResult({ mlPerHour, dropsPerMin });
    } else {
      setInfusionResult(null);
    }
  };

  const calculateEMTSDrip = () => {
    const weight = parseFloat(emtsWeight);
    const dose = parseFloat(emtsDose);
    if (!dose || isNaN(dose)) {
      setEmtsResult(null);
      return;
    }

    let conc = 0; // mcg/ml or mg/ml
    let prep = "";
    let rate = 0; // ml/hour

    if (emtsSelectedDrug === "noradrenaline") {
      if (emtsStrength === "single") {
        conc = 80; // 80 mcg/ml
        prep = "Dilute 4mg (1 ampoule) Noradrenaline in 46ml D5% (Total 50ml)";
      } else {
        conc = 160; // 160 mcg/ml
        prep = "Dilute 8mg (2 ampoules) Noradrenaline in 42ml D5% (Total 50ml)";
      }
      const wt = isNaN(weight) || weight <= 0 ? 1 : weight;
      rate = (dose * wt * 60) / conc;
    } else if (emtsSelectedDrug === "adrenaline") {
      if (emtsStrength === "single") {
        conc = 60; // 60 mcg/ml
        prep = "Dilute 3mg (3 ampoules) Adrenaline in 47ml NS or D5% (Total 50ml)";
      } else {
        conc = 120; // 120 mcg/ml
        prep = "Dilute 6mg (6 ampoules) Adrenaline in 44ml NS or D5% (Total 50ml)";
      }
      const wt = isNaN(weight) || weight <= 0 ? 1 : weight;
      rate = (dose * wt * 60) / conc;
    } else if (emtsSelectedDrug === "dopamine") {
      if (emtsStrength === "single") {
        conc = 4000; // 4000 mcg/ml
        prep = "Dilute 200mg (1 ampoule) Dopamine in 45ml NS or D5% (Total 50ml)";
      } else {
        conc = 8000; // 8000 mcg/ml
        prep = "Dilute 400mg (2 ampoules) Dopamine in 40ml NS or D5% (Total 50ml)";
      }
      const wt = isNaN(weight) || weight <= 0 ? 70 : weight;
      rate = (dose * wt * 60) / conc;
    } else if (emtsSelectedDrug === "dobutamine") {
      if (emtsStrength === "single") {
        conc = 5000; // 5000 mcg/ml
        prep = "Dilute 250mg (1 vial) Dobutamine in 30ml NS or D5% (Total 50ml)";
      } else {
        conc = 10000; // 10000 mcg/ml
        prep = "Dilute 500mg (2 vials) Dobutamine in 10ml NS or D5% (Total 50ml)";
      }
      const wt = isNaN(weight) || weight <= 0 ? 70 : weight;
      rate = (dose * wt * 60) / conc;
    } else if (emtsSelectedDrug === "labetalol") {
      conc = 2; // 2 mg/ml
      prep = "Dilute 100mg (4 ampoules) Labetalol in 50ml NS or D5% (Total 50ml)";
      rate = (dose * 60) / conc;
    }

    setEmtsResult({
      mlPerHour: parseFloat(rate.toFixed(2)),
      concentration: conc,
      prepText: prep
    });
  };

  useEffect(() => {
    calculateEMTSDrip();
  }, [emtsSelectedDrug, emtsStrength, emtsWeight, emtsDose]);

  useEffect(() => {
    calculateCrCl();
  }, [cgAge, cgWeight, cgHeight, cgCreatinine, cgSex, cgWeightType]);

  useEffect(() => {
    calculateCalcium();
  }, [caMeasured, caAlbumin]);

  useEffect(() => {
    calculateInfusion();
  }, [infusionVol, infusionDuration, infusionDropFactor]);

  // Lab interpreter logic
  useEffect(() => {
    const val = parseFloat(interpreterValue);
    if (!selectedInterpreterTest || isNaN(val)) {
      setInterpreterResult(null);
      return;
    }

    let status: "low" | "normal" | "high" | "critical-low" | "critical-high" = "normal";
    let text = "";
    let action = "";

    if (selectedInterpreterTest === "potassium") {
      if (val < 2.5) {
        status = "critical-low";
        text = `Potassium is ${val} mmol/L (Severe Hypokalemia)`;
        action = "CRITICAL ALERT: High risk of lethal cardiac arrhythmias and respiratory paralysis! Notify physician immediately, run a 12-lead ECG, monitor cardiac rhythm constantly, and initiate urgent IV Potassium chloride replacement (not exceeding 10-20 mmol/hour via central line or under cardiac monitoring).";
      } else if (val < 3.5) {
        status = "low";
        text = `Potassium is ${val} mmol/L (Mild to Moderate Hypokalemia)`;
        action = "Action: Correct with oral potassium supplements (e.g., Mist. KCl) or add KCl to IV fluids. Recheck level after replacement. Check magnesium levels as hypomagnesemia makes hypokalemia refractory to treatment.";
      } else if (val <= 5.0) {
        status = "normal";
        text = `Potassium is ${val} mmol/L (Normal)`;
        action = "Action: Within standard reference limits (3.5 - 5.0 mmol/L). Maintain maintenance fluid protocols.";
      } else if (val < 6.0) {
        status = "high";
        text = `Potassium is ${val} mmol/L (Mild to Moderate Hyperkalemia)`;
        action = "Action: Exclude sample hemolysis (pseudohyperkalemia). Restrict dietary/IV potassium intake, stop potassium-sparing medications (e.g., Spironolactone, ACE inhibitors), and monitor ECG.";
      } else {
        status = "critical-high";
        text = `Potassium is ${val} mmol/L (Severe Hyperkalemia)`;
        action = "CRITICAL ALERT: Extreme risk of ventricular fibrillation, sinusoidal ECG pattern, and cardiac arrest! Action: Notify physician immediately. Run 12-lead ECG. Administer 10ml Calcium Gluconate 10% IV over 5-10 mins (stabilizes cardiac membrane), run Insulin-Dextrose infusion (10U Actrapid in 50ml D50% IV), Salbutamol nebulization, and consider potassium binders or hemodialysis.";
      }
    } else if (selectedInterpreterTest === "sodium") {
      if (val < 120) {
        status = "critical-low";
        text = `Sodium is ${val} mmol/L (Severe Hyponatremia)`;
        action = "CRITICAL ALERT: Risk of cerebral edema, status epilepticus, permanent neurological damage, and coma! Action: Notify specialist. If symptomatic (seizures, altered mental state), consider hypertonic saline (3% NaCl) 100ml IV over 10-20 mins, capped at 4-6 mmol/L rise in 24 hours to prevent Central Pontine Myelinolysis.";
      } else if (val < 135) {
        status = "low";
        text = `Sodium is ${val} mmol/L (Mild to Moderate Hyponatremia)`;
        action = "Action: Investigate volume status (hypovolemic, euvolemic, hypervolemic) and urine/serum osmolality. Restrict free water intake if euvolemic/SIADH; give normal saline if hypovolemic.";
      } else if (val <= 145) {
        status = "normal";
        text = `Sodium is ${val} mmol/L (Normal)`;
        action = "Action: Within standard reference limits (135 - 145 mmol/L).";
      } else if (val <= 155) {
        status = "high";
        text = `Sodium is ${val} mmol/L (Mild to Moderate Hypernatremia)`;
        action = "Action: Calculate free water deficit. Administer oral hydration or slow IV D5% infusion to lower sodium by ≤10 mmol/L per 24 hours to prevent cerebral edema.";
      } else {
        status = "critical-high";
        text = `Sodium is ${val} mmol/L (Severe Hypernatremia)`;
        action = "CRITICAL ALERT: Severe cellular dehydration, risk of vascular rupture, intracranial hemorrhage, and hyperthermia! Action: Notify physician. Administer slow hypotonic fluids under rigorous electrolyte monitoring.";
      }
    } else if (selectedInterpreterTest === "platelet") {
      if (val < 20) {
        status = "critical-low";
        text = `Platelets are ${val} x10^9/L (Severe Thrombocytopenia)`;
        action = "CRITICAL ALERT: High risk of spontaneous life-threatening hemorrhage (e.g., intracranial, gastrointestinal)! Action: Restrict patient's physical activity to bed rest. Avoid intramuscular (IM) injections and NSAIDs. Order immediate platelet transfusion. Investigate for Dengue Severe phase, ITP, sepsis, or DIC.";
      } else if (val < 150) {
        status = "low";
        text = `Platelets are ${val} x10^9/L (Mild to Moderate Thrombocytopenia)`;
        action = "Action: Monitor for bleeding/bruising/petechiae. Investigate underlying etiology (dengue serology, drug-induced, EDTA-induced clumping - request blood smear).";
      } else if (val <= 400) {
        status = "normal";
        text = `Platelets are ${val} x10^9/L (Normal)`;
        action = "Action: Within standard reference limits (150 - 400 x10^9/L).";
      } else {
        status = "high";
        text = `Platelets are ${val} x10^9/L (Thrombocytosis)`;
        action = "Action: Exclude reactive causes (infection, iron deficiency, post-splenectomy, tissue inflammation). If persistent and extremely high (>1000), consult hematology for primary myeloproliferative disorder evaluation.";
      }
    } else if (selectedInterpreterTest === "hb") {
      if (val < 7.0) {
        status = "critical-low";
        text = `Hemoglobin is ${val} g/dL (Severe Anemia)`;
        action = "CRITICAL ALERT: High risk of high-output heart failure and severe tissue hypoxia! Action: Cross-match and prepare Packed Red Blood Cells (PRBC) for transfusion (usually transfuse to target Hb 7-8 g/dL, or >9 g/dL in acute coronary syndrome). Monitor vitals closely.";
      } else if (val < 12.0) {
        status = "low";
        text = `Hemoglobin is ${val} g/dL (Mild to Moderate Anemia)`;
        action = "Action: Assess iron indices (ferritin, transferrin), serum folate, Vitamin B12, renal function (EPO deficiency), and check for occult bleeding (Fecal Occult Blood Test).";
      } else if (val <= 17.5) {
        status = "normal";
        text = `Hemoglobin is ${val} g/dL (Normal)`;
        action = "Action: Within standard reference limits (12.0 - 17.5 g/dL).";
      } else {
        status = "high";
        text = `Hemoglobin is ${val} g/dL (Erythrocytosis)`;
        action = "Action: Assess hydration status (hemoconcentration). Exclude chronic hypoxemia (COPD, sleep apnea, smoking) or polycythemia vera. Consider hematology consultation.";
      }
    } else if (selectedInterpreterTest === "wbc") {
      if (val < 1.0) {
        status = "critical-low";
        text = `WBC is ${val} x10^9/L (Critical Leukopenia/Neutropenia)`;
        action = "CRITICAL ALERT: Extreme vulnerability to life-threatening infections! Action: Isolate patient in a single room (reverse isolation). Initiate neutropenic sepsis precautions (avoid raw foods, strict hand hygiene). If febrile (T ≥ 38.0°C), treat as a medical emergency and administer broad-spectrum IV antibiotics (e.g. Tazocin or Meropenem) within 1 hour.";
      } else if (val < 4.0) {
        status = "low";
        text = `WBC is ${val} x10^9/L (Leukopenia)`;
        action = "Action: Perform Full Blood Picture (FBP) for differential count. Check for viral infections, autoimmune conditions, bone marrow depression, or chemotherapy drug toxicity.";
      } else if (val <= 11.0) {
        status = "normal";
        text = `WBC is ${val} x10^9/L (Normal)`;
        action = "Action: Within standard reference limits (4.0 - 11.0 x10^9/L).";
      } else if (val < 30.0) {
        status = "high";
        text = `WBC is ${val} x10^9/L (Leukocytosis)`;
        action = "Action: Assess for clinical signs of infection, inflammation, trauma, or recent corticosteroid therapy. Check differential count (neutrophilia vs lymphocytosis).";
      } else {
        status = "critical-high";
        text = `WBC is ${val} x10^9/L (Severe Leukocytosis / Hyperleukocytosis)`;
        action = "CRITICAL ALERT: Extreme leukocytosis. Action: Investigate for hematological malignancies (Leukemia - AML, CML, CLL, ALL) or extreme leukemoid reaction in severe necrotizing infections. Order peripheral blood smear and consult hematology.";
      }
    }

    setInterpreterResult({ status, text, action });
  }, [selectedInterpreterTest, interpreterValue]);

  // Drug Reconstitution / Dilution helper logic
  useEffect(() => {
    if (!selectedReconDrug) {
      setReconResultText("");
      return;
    }

    const dose = parseFloat(reconDoseInput);
    if (isNaN(dose) || dose <= 0) {
      setReconResultText("Please enter a valid dose above 0.");
      return;
    }

    let text = "";
    const d = selectedReconDrug.toLowerCase();

    if (d.includes("noradrenaline")) {
      const conc = 80; // mcg/ml (4mg in 50ml)
      const rate = (dose * 60) / conc;
      text = `Dilution: Single Strength (4mg in 50ml D5%, Conc: 80 mcg/ml)\nTarget Dose: ${dose} mcg/min\nRequired Pump Flow Rate: ${rate.toFixed(1)} ml/hour.`;
    } else if (d.includes("adrenaline")) {
      const conc = 60; // mcg/ml (3mg in 50ml)
      const rate = (dose * 60) / conc;
      text = `Dilution: Single Strength (3mg in 50ml NS/D5%, Conc: 60 mcg/ml)\nTarget Dose: ${dose} mcg/min\nRequired Pump Flow Rate: ${rate.toFixed(1)} ml/hour.`;
    } else if (d.includes("amiodarone")) {
      const conc = 6; // mg/ml (300mg in 50ml D5%)
      const rate = dose / conc;
      text = `Dilution: Amiodarone (300mg in 50ml D5%, Conc: 6 mg/ml)\nTarget Maintenance Dose: ${dose} mg/hour\nRequired Pump Flow Rate: ${rate.toFixed(1)} ml/hour.`;
    } else if (d.includes("insulin") || d.includes("actrapid")) {
      const rate = dose; // 1U/ml, so ml/hr = U/hr
      text = `Dilution: Actrapid (50U in 50ml Normal Saline, Conc: 1 U/ml)\nTarget Dose: ${dose} U/hour\nRequired Pump Flow Rate: ${rate.toFixed(1)} ml/hour.\n\n*Check Capillary Blood Glucose (CBG) hourly!`;
    } else if (d.includes("fentanyl")) {
      const conc = 10; // mcg/ml (500mcg in 50ml)
      const rate = dose / conc;
      text = `Dilution: Fentanyl (500 mcg in 50ml NS, Conc: 10 mcg/ml)\nTarget Dose: ${dose} mcg/hour\nRequired Pump Flow Rate: ${rate.toFixed(1)} ml/hour.`;
    } else if (d.includes("pantoprazole")) {
      const conc = 4; // mg/ml (40mg reconstituted in 10ml)
      const vol = dose / conc;
      text = `Reconstitution: Pantoprazole 40mg vial reconstituted with 10ml Normal Saline (Conc: 4 mg/ml)\nTarget Dose: ${dose} mg\nRequired volume to draw: ${vol.toFixed(1)} ml of reconstituted solution.`;
    } else if (d.includes("piperacillin") || d.includes("tazocin")) {
      const conc = 225; // mg/ml (4.5g in 20ml)
      const vol = (dose * 1000) / conc;
      text = `Reconstitution: Tazocin 4.5g reconstituted with 20ml Normal Saline (Conc: 225 mg/ml)\nTarget Dose: ${dose} g (${dose * 1000} mg)\nRequired volume to draw: ${vol.toFixed(1)} ml of reconstituted solution.\nDilute in 100ml NS/D5% and infuse over 3-4 hours.`;
    } else {
      text = `General Calculation:\nFor dose of ${dose} units/mg, with concentration C, draw (Target Dose / C) ml.`;
    }

    setReconResultText(text);
  }, [selectedReconDrug, reconDoseInput]);

  // Copy helper
  const handleCopy = (text: string, identifier: string) => {
    navigator.clipboard.writeText(text);
    setCopySuccess(identifier);
    setTimeout(() => setCopySuccess(null), 2000);
  };

  // Memoized filtered collections for maximum search and rendering performance
  const filteredLabs = useMemo(() => {
    return testDatabase.filter(item => {
      // Improved text search with synonym-aware matching
      const contentString = `${item.test} ${item.container} ${item.specimen} ${item.remark} ${item.ranges} ${item.lab}`;
      const matchesSearch = matchesQuery(contentString);

      if (!matchesSearch) return false;

      // Category Quick Filters
      if (selectedLabFilter === "All") return true;
      if (selectedLabFilter === "Blood") {
        return item.specimen.toLowerCase().includes("blood") || 
               item.specimen.toLowerCase().includes("serum") || 
               item.specimen.toLowerCase().includes("plasma");
      }
      if (selectedLabFilter === "Urine") {
        return item.specimen.toLowerCase().includes("urine");
      }
      if (selectedLabFilter === "CSF/Fluid") {
        return item.specimen.toLowerCase().includes("csf") || 
               item.specimen.toLowerCase().includes("fluid");
      }
      if (selectedLabFilter === "Urgent") {
        return item.ltat.toLowerCase().includes("hour") || 
               item.ltat.toLowerCase().includes("min");
      }
      if (selectedLabFilter === "Ice") {
        return item.remark.toLowerCase().includes("ice") || 
               item.container.toLowerCase().includes("ice") ||
               item.test.toLowerCase().includes("ice");
      }
      if (selectedLabFilter === "Referred") {
        return item.test.toLowerCase().includes("referred") || 
               item.lab.toLowerCase().includes("ref:");
      }

      return true;
    });
  }, [queryInfo, selectedLabFilter, searchQuery]);

  const ironResults = useMemo(() => {
    const weight = parseFloat(ironPatientWeight) || 0;
    const actualHb = parseFloat(ironActualHb) || 0;
    
    // Target Hb
    const targetHb = ironTargetHbOverride !== "" ? (parseFloat(ironTargetHbOverride) || 0) : (weight < 35 ? 13 : 15);
    
    // Iron Stores
    const ironStores = ironStoresOverride !== "" ? (parseFloat(ironStoresOverride) || 0) : (weight < 35 ? Math.round(15 * weight) : 500);
    
    // Ganzoni Deficit
    const ganzoniDeficit = Math.max(0, Math.round(weight * (targetHb - actualHb) * 2.4 + ironStores));
    
    // Simplified Dosing Table for Ferinject / Monofer:
    let simplifiedDose = 0;
    if (weight > 0) {
      if (weight < 35) {
        simplifiedDose = Math.round(weight * 15);
      } else if (weight < 50) {
        simplifiedDose = actualHb >= 10 ? 500 : 1000;
      } else if (weight < 70) {
        simplifiedDose = actualHb >= 10 ? 1000 : 1500;
      } else {
        simplifiedDose = actualHb >= 10 ? 1500 : 2000;
      }
    }
    
    return {
      ganzoniDeficit,
      simplifiedDose,
      targetHb,
      ironStores
    };
  }, [ironPatientWeight, ironActualHb, ironTargetHbOverride, ironStoresOverride]);

  const filteredDilutions = useMemo(() => {
    return dbDilution.filter(item => {
      const contentString = `${item.drug} ${item.dilution} ${item.reconstitution} ${item.infusion}`;
      const matchesSearch = matchesQuery(contentString);
      if (!matchesSearch) return false;

      if (selectedDilutionFilter === "All") return true;

      const name = item.drug.toLowerCase();
      if (selectedDilutionFilter === "Antibiotic") {
        return name.includes("cef") || name.includes("clox") || name.includes("penem") || name.includes("piperacillin") || name.includes("tazobactam") || name.includes("vancomycin") || name.includes("amphotericin") || name.includes("fluconazole") || name.includes("caspo") || name.includes("penicillin");
      }
      if (selectedDilutionFilter === "Inotrope") {
        return name.includes("adrenaline") || name.includes("noradrenaline") || name.includes("dobutamine") || name.includes("dopamine");
      }
      if (selectedDilutionFilter === "Cardio") {
        return name.includes("digoxin") || name.includes("trinitrate") || name.includes("gtn") || name.includes("nitroprusside") || name.includes("amiodarone") || name.includes("nicardipine") || name.includes("labetalol") || name.includes("esmolol") || name.includes("milrinone");
      }
      if (selectedDilutionFilter === "Sedative") {
        return name.includes("midazolam") || name.includes("morphine") || name.includes("propofol") || name.includes("fentanyl") || name.includes("ketamine") || name.includes("dexmedetomidine");
      }
      if (selectedDilutionFilter === "Electrolytes") {
        return name.includes("potassium") || name.includes("kcl") || name.includes("magnesium") || name.includes("bicarbonate") || name.includes("gluconate") || name.includes("chloride");
      }
      return true;
    });
  }, [queryInfo, selectedDilutionFilter, searchQuery]);

  const filteredRenalStable = useMemo(() => {
    return dbRenalStable.filter(item => {
      const contentString = `${item.drug} ${item.dose} ${item.adjustments}`;
      const matchesSearch = matchesQuery(contentString);
      if (!matchesSearch) return false;

      if (selectedRenalFilter === "All") return true;

      const name = item.drug.toLowerCase();
      if (selectedRenalFilter === "Penicillins") {
        return name.includes("cillin") || name.includes("penicillin") || name.includes("amoxicillin");
      }
      if (selectedRenalFilter === "Cephalosporins") {
        return name.includes("cef");
      }
      if (selectedRenalFilter === "Carbapenems") {
        return name.includes("penem");
      }
      if (selectedRenalFilter === "Fluoroquinolones") {
        return name.includes("floxacin");
      }
      if (selectedRenalFilter === "Antifungals") {
        return name.includes("azole") || name.includes("fungin") || name.includes("amphotericin");
      }
      return true;
    });
  }, [queryInfo, selectedRenalFilter, searchQuery]);

  const filteredRenalICU = useMemo(() => {
    return dbRenalICU.filter(item => {
      const contentString = `${item.drug} ${item.dose} ${item.rrt}`;
      const matchesSearch = matchesQuery(contentString);
      if (!matchesSearch) return false;

      if (selectedRenalFilter === "All") return true;

      const name = item.drug.toLowerCase();
      if (selectedRenalFilter === "Penicillins") {
        return name.includes("cillin") || name.includes("penicillin") || name.includes("amoxicillin");
      }
      if (selectedRenalFilter === "Cephalosporins") {
        return name.includes("cef");
      }
      if (selectedRenalFilter === "Carbapenems") {
        return name.includes("penem");
      }
      if (selectedRenalFilter === "Fluoroquinolones") {
        return name.includes("floxacin");
      }
      if (selectedRenalFilter === "Antifungals") {
        return name.includes("azole") || name.includes("fungin") || name.includes("amphotericin");
      }
      return true;
    });
  }, [queryInfo, selectedRenalFilter, searchQuery]);

  const filteredRenalCommon = useMemo(() => {
    return dbRenalCommon.filter(item => {
      const contentString = `${item.drug} ${item.dose} ${item.cr3050} ${item.cr1030} ${item.cr10} ${item.rrt}`;
      const matchesSearch = matchesQuery(contentString);
      if (!matchesSearch) return false;

      if (selectedRenalFilter === "All") return true;

      const name = item.drug.toLowerCase();
      if (selectedRenalFilter === "Cardiovascular") {
        return name.includes("atenolol") || name.includes("pril") || name.includes("sartan") || name.includes("digoxin") || name.includes("spironolactone");
      }
      if (selectedRenalFilter === "Anticoagulants") {
        return name.includes("parin") || name.includes("gatran") || name.includes("xaban");
      }
      if (selectedRenalFilter === "Diabetes") {
        return name.includes("formin") || name.includes("gliptin") || name.includes("flozin");
      }
      if (selectedRenalFilter === "Analgesics") {
        return name.includes("morphine") || name.includes("tramadol") || name.includes("gabapentin") || name.includes("pregabalin") || name.includes("baclofen") || name.includes("colchicine");
      }
      if (selectedRenalFilter === "Gastro") {
        return name.includes("tidine") || name.includes("pramide");
      }
      return true;
    });
  }, [queryInfo, selectedRenalFilter, searchQuery]);

  const filteredEMTS = useMemo(() => {
    return dbEMTS.filter(item => {
      const contentString = `${item.drug} ${item.indication} ${item.preparation} ${item.bolus} ${item.infusion} ${item.precautions}`;
      const matchesSearch = matchesQuery(contentString);
      
      if (selectedEMTSCategory === "All") return matchesSearch;
      return matchesSearch && item.category === selectedEMTSCategory;
    });
  }, [queryInfo, selectedEMTSCategory]);

  const filteredEnteral = useMemo(() => {
    return dbEnteral.filter(item => {
      const contentString = `${item.drug} ${item.category} ${item.canCrush} ${item.instructions} ${item.alternative || ""}`;
      const matchesSearch = matchesQuery(contentString);
      if (!matchesSearch) return false;

      if (selectedEnteralFilter === "All") return true;
      return item.category === selectedEnteralFilter;
    });
  }, [queryInfo, selectedEnteralFilter, searchQuery]);

  const filteredEndocrine = useMemo(() => {
    if (!searchQuery.trim()) return endocrineProtocols;
    return endocrineProtocols.filter(proto => {
      const contentString = `${proto.title} ${proto.timeline || ""} ${
        Array.isArray(proto.interpretation) 
          ? proto.interpretation.join(" ") 
          : proto.interpretation || ""
      } ${proto.cap || ""} ${proto.components || ""} ${proto.critical || ""} ${
        proto.preBiopsy || ""
      } ${proto.prep || ""} ${proto.stability || ""} ${proto.coresRequired || ""} ${
        proto.warning || ""
      }`;
      return matchesQuery(contentString);
    });
  }, [queryInfo, searchQuery]);

  const filteredDirectory = useMemo(() => {
    if (!searchQuery.trim()) return directoryData;
    return directoryData.map(dept => {
      if (matchesQuery(dept.dept)) {
        return dept;
      }
      const matchingItems = dept.items.filter(item => 
        matchesQuery(`${item.name} ${item.ext}`)
      );
      if (matchingItems.length > 0) {
        return {
          ...dept,
          items: matchingItems
        };
      }
      return null;
    }).filter(Boolean) as typeof directoryData;
  }, [queryInfo, searchQuery]);

  const requisitionForms = useMemo(() => [
    { title: "PER-PAT 301 Form", desc: "General default form for chemical pathology, hematology, and microbiology. Must be stamped and signed." },
    { title: "AUTOIMMUNE FORM (v4.0)", desc: "Required for immunofluorescence assays (IMR) e.g. Anti-AChR, AQP4." },
    { title: "ENDOCRINE REQUEST FORM", desc: "For specialized endocrine assays referred to HKL or IMR (e.g. AMH, Diabetes antibodies)." },
    { title: "TBIS 20C Form", desc: "Specifically required for tuberculosis diagnostics (AFB smears, PCR, and cultures)." }
  ], []);

  const filteredForms = useMemo(() => {
    if (!searchQuery.trim()) return requisitionForms;
    return requisitionForms.filter(form => 
      matchesQuery(`${form.title} ${form.desc}`)
    );
  }, [queryInfo, requisitionForms, searchQuery]);

  // Backward compatible helper functions to avoid refactoring rendering markup
  const getFilteredLabs = () => filteredLabs;
  const getFilteredDilutions = () => filteredDilutions;
  const getFilteredRenalStable = () => filteredRenalStable;
  const getFilteredRenalICU = () => filteredRenalICU;
  const getFilteredRenalCommon = () => filteredRenalCommon;
  const getFilteredEMTS = () => filteredEMTS;
  const getFilteredEnteral = () => filteredEnteral;
  const getFilteredEndocrine = () => filteredEndocrine;
  const getFilteredDirectory = () => filteredDirectory;
  const getFilteredForms = () => filteredForms;

  // Tube visual colors map
  const getTubeCapColor = (container: string) => {
    const text = container.toLowerCase();
    if (text.includes("yellow") || text.includes("gold") || text.includes("separating")) {
      return { bg: "bg-amber-400", border: "border-amber-500", label: "Yellow (SST)" };
    }
    if (text.includes("pink")) {
      return { bg: "bg-pink-400", border: "border-pink-500", label: "Pink" };
    }
    if (text.includes("red") || text.includes("without gel")) {
      return { bg: "bg-rose-600", border: "border-rose-700", label: "Red (Plain)" };
    }
    if (text.includes("purple") || text.includes("edta")) {
      return { bg: "bg-violet-600", border: "border-violet-700", label: "Purple (EDTA)" };
    }
    if (text.includes("green") || text.includes("heparin")) {
      return { bg: "bg-emerald-600", border: "border-emerald-700", label: "Green (Heparin)" };
    }
    if (text.includes("blue") || text.includes("citrate")) {
      return { bg: "bg-sky-500", border: "border-sky-600", label: "Blue (Citrate)" };
    }
    if (text.includes("grey") || text.includes("fluoride")) {
      return { bg: "bg-slate-400", border: "border-slate-500", label: "Grey (Fluoride)" };
    }
    if (text.includes("sterile") || text.includes("container") || text.includes("bottle") || text.includes("bijou")) {
      return { bg: "bg-amber-100", border: "border-slate-300", label: "Sterile Container" };
    }
    return { bg: "bg-slate-300", border: "border-slate-400", label: "Other" };
  };

  
  
  // Maintenance Fluid State
  const [fluidWeight, setFluidWeight] = useState("");
  const [fluidResult, setFluidResult] = useState<number | null>(null);

  const calculateFluid = () => {
    const w = parseFloat(fluidWeight);
    if (!isNaN(w) && w > 0) {
      let rate = 0;
      if (w <= 10) rate = w * 4;
      else if (w <= 20) rate = 40 + ((w - 10) * 2);
      else rate = 60 + ((w - 20) * 1);
      setFluidResult(rate);
    }
  };

  const isDarkMode = theme === "dark";

  return (
    <div className={`min-height-screen font-sans transition-colors duration-150 ${
      isDarkMode ? "bg-[#0b0f19] text-slate-100" : "bg-slate-50 text-slate-900"
    }`}>
      
      {/* HEADER SECTION */}
      <header className={`relative border-b backdrop-blur-md ${
        isDarkMode ? "bg-[#0b0f19]/90 border-slate-800" : "bg-white/90 border-slate-200"
      } py-4 px-4 sm:px-6`}>
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <div className="flex items-center gap-3">
              <div className="flex-shrink-0">
                {!logoError ? (
                  <img 
                    src="/logo.jpg" 
                    alt="Blood But Not Bleed Logo" 
                    onError={() => setLogoError(true)}
                    className={`w-16 h-16 sm:w-20 sm:h-20 rounded-xl object-contain shadow-md transition-all duration-300 hover:scale-105 ${
                      isDarkMode 
                        ? "bg-slate-800 ring-1 ring-slate-700/50" 
                        : "bg-white ring-1 ring-slate-200/50"
                    }`}
                    referrerPolicy="no-referrer"
                  />
                ) : (
                  <div 
                    className={`w-16 h-16 sm:w-20 sm:h-20 rounded-xl flex flex-col items-center justify-center shadow-md transition-all duration-300 hover:scale-105 ${
                      isDarkMode 
                        ? "bg-gradient-to-br from-rose-950 to-slate-900 border border-rose-500/30 text-rose-400 ring-1 ring-rose-500/20" 
                        : "bg-gradient-to-br from-rose-50 to-slate-50 border border-rose-200 text-rose-600 ring-1 ring-rose-200/50"
                    }`}
                  >
                    <div className="relative flex items-center justify-center">
                      <Droplet className="w-8 h-8 fill-rose-600/10 animate-pulse text-rose-500" />
                      <span className={`absolute text-[9px] font-extrabold tracking-wider font-mono uppercase ${isDarkMode ? "text-rose-100" : "text-rose-900"} drop-shadow-sm select-none`}>
                        BBNB
                      </span>
                    </div>
                    <span className="text-[7px] font-mono mt-1 opacity-80 uppercase tracking-widest font-semibold">
                      CLINICAL
                    </span>
                  </div>
                )}
              </div>
              <div>
                <h1 className={`text-xl sm:text-2xl font-bold tracking-tight ${isDarkMode ? "text-slate-100" : "text-slate-900"} flex flex-col sm:flex-row sm:items-center gap-1 sm:gap-2`}>
                  Blood But Not Bleed
                  <span className={`text-[10px] sm:text-xs px-2 py-0.5 rounded-full bg-rose-700/10 ${isDarkMode ? "text-rose-400" : "text-rose-700"} border border-rose-700/20 font-mono font-normal w-fit`}>
                    By Clinicians to Clinicians
                  </span>
                </h1>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-3">
            {/* On-Call Kit Button */}
            <button 
              onClick={() => { 
                setActiveTab("oncall"); 
                setOnCallSubTab("decompress"); 
                setSearchQuery(""); 
              }}
              className={`flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-semibold transition-all ${
                activeTab === "oncall" && onCallSubTab === "decompress"
                  ? "bg-amber-500 text-slate-950 shadow-lg shadow-amber-500/20 font-bold" 
                  : isDarkMode 
                    ? "bg-slate-900 text-amber-400 hover:bg-slate-800 border border-slate-800" 
                    : "bg-amber-50 text-amber-700 hover:bg-amber-100 border border-amber-100"
              }`}
            >
              <Coffee className={`w-4 h-4 ${activeTab === "oncall" && onCallSubTab === "decompress" ? "animate-pulse" : ""}`} />
              <span>On-Call Kit</span>
            </button>

            {/* Theme Toggle */}
            <button 
              onClick={toggleTheme}
              className={`p-2 rounded-lg border transition-colors ${
                isDarkMode 
                  ? "bg-slate-900 border-slate-800 text-yellow-400 hover:bg-slate-800" 
                  : "bg-slate-100 border-slate-200 text-slate-700 hover:bg-slate-200"
              }`}
              title={isDarkMode ? "Switch to daylight mode" : "Switch to twilight mode"}
            >
              {isDarkMode ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 py-4 pb-24">

        {/* STICKY NAVIGATION & SEARCH HEADER */}
        <div className={`sticky top-0 z-40 -mx-4 px-4 sm:mx-0 sm:px-0 pt-2 pb-4 mb-6 backdrop-blur-md border-b ${
          isDarkMode ? "bg-[#0b0f19]/90 border-slate-800/60 shadow-lg shadow-black/20" : "bg-white/90 border-slate-200 shadow-sm shadow-slate-200/50"
        }`}>
          {/* NAVIGATION TABS */}
          <div className="hidden sm:grid sm:grid-cols-3 md:grid-cols-5 xl:grid-cols-9 sm:gap-2 sm:gap-y-3 pb-2">
            {[
              { id: "labs", label: "Labs", icon: <FileText className="w-4 h-4" /> },
              { id: "resus", label: "Resus", icon: <Activity className="w-4 h-4" /> },
              { id: "oncall", label: "On-Call Kit", icon: <Coffee className="w-4 h-4" /> },
              { id: "ho_guide", label: "Bedside", icon: <ClipboardList className="w-4 h-4" /> },
              { id: "nag", label: "AMS / NAG", icon: <ShieldAlert className="w-4 h-4" /> },
              { id: "palliative", label: "Palliative Care", icon: <Heart className="w-4 h-4" /> },
              { id: "drug", label: "Drug", icon: <Pill className="w-4 h-4" /> },
              { id: "calc", label: "Calc", icon: <Calculator className="w-4 h-4" /> },
              { id: "directory", label: "Directory", icon: <Phone className="w-4 h-4" /> }
            ].map((tab) => (
              <button 
                key={tab.id}
                onClick={() => { setActiveTab(tab.id as any); setSearchQuery(""); }}
                className={`flex flex-col items-center justify-center gap-1 p-2 sm:p-2.5 rounded-xl border transition-all min-w-0 ${
                  activeTab === tab.id
                    ? "bg-rose-500/10 border-rose-500/50 text-rose-400 shadow-lg shadow-rose-500/5 ring-1 ring-rose-500/20"
                    : isDarkMode 
                      ? "bg-slate-900/40 border-slate-800/60 text-slate-400 hover:bg-slate-800 hover:text-slate-300"
                      : "bg-white border-slate-200 text-slate-600 hover:bg-slate-50 hover:border-slate-300 shadow-sm"
                }`}
              >
                <div className={`p-1 rounded-lg flex-shrink-0 ${
                  activeTab === tab.id 
                    ? tab.id === "resus" ? "bg-rose-500 text-slate-950 font-bold" : tab.id === "oncall" ? "bg-amber-500 text-slate-950 font-bold" : "bg-teal-500 text-slate-950 font-bold"
                    : isDarkMode ? "bg-slate-800 text-slate-400" : "bg-slate-100 text-slate-600"
                }`}>
                  {tab.icon}
                </div>
                <span className="text-[10px] font-bold uppercase tracking-tight whitespace-nowrap">{tab.label}</span>
              </button>
            ))}
          </div>
          
          {/* MOBILE SWIPABLE NAVIGATION TABS */}
          <div className="block sm:hidden pb-2 -mx-4 px-4 overflow-x-auto scrollbar-none">
            <div className="flex gap-1.5 w-max">
              {[
                { id: "labs", label: "Labs", icon: <FileText className="w-3.5 h-3.5" /> },
                { id: "resus", label: "Resus", icon: <Activity className="w-3.5 h-3.5" /> },
                { id: "oncall", label: "On-Call Kit", icon: <Coffee className="w-3.5 h-3.5" /> },
                { id: "ho_guide", label: "Bedside", icon: <ClipboardList className="w-3.5 h-3.5" /> },
                { id: "nag", label: "AMS / NAG", icon: <ShieldAlert className="w-3.5 h-3.5" /> },
                { id: "palliative", label: "Palliative", icon: <Heart className="w-3.5 h-3.5" /> },
                { id: "drug", label: "Drug Guide", icon: <Pill className="w-3.5 h-3.5" /> },
                { id: "calc", label: "Calc", icon: <Calculator className="w-3.5 h-3.5" /> },
                { id: "directory", label: "Directory", icon: <Phone className="w-3.5 h-3.5" /> }
              ].map((tab) => (
                <button 
                  key={tab.id}
                  onClick={() => { setActiveTab(tab.id as any); setSearchQuery(""); }}
                  className={`flex items-center gap-1.5 px-3 py-2 rounded-xl border text-[11px] font-bold uppercase transition-all ${
                    activeTab === tab.id
                      ? "bg-rose-500/10 border-rose-500/40 text-rose-400 shadow-md shadow-rose-500/5 ring-1 ring-rose-500/20"
                      : isDarkMode 
                        ? "bg-slate-900/60 border-slate-800/80 text-slate-400 hover:bg-slate-800 hover:text-slate-300"
                        : "bg-white border-slate-200 text-slate-600 hover:bg-slate-50 hover:border-slate-300 shadow-sm"
                  }`}
                >
                  <div className={`p-1 rounded-lg ${
                    activeTab === tab.id 
                      ? "bg-rose-500 text-slate-950"
                      : isDarkMode ? "bg-slate-800 text-slate-400" : "bg-slate-100 text-slate-600"
                  }`}>
                    {tab.icon}
                  </div>
                  <span>{tab.label}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Sub-tabs and Search Bar */}
          <div className="mt-4 space-y-4">
            {activeTab === "labs" && (
              <div className="space-y-3">
                <div className="flex gap-2 p-1 rounded-xl bg-slate-900/20 dark:bg-slate-950/40 border border-slate-800/40">
                  <button
                    onClick={() => setLabsSubTab("database")}
                    className={`flex-1 py-2 rounded-lg text-xs font-bold uppercase transition-all flex items-center justify-center gap-1.5 ${
                      labsSubTab === "database"
                        ? "bg-teal-500 text-slate-950 shadow-lg shadow-teal-500/20"
                        : isDarkMode 
                          ? "text-slate-400 hover:text-slate-200" 
                          : "text-slate-600 hover:text-slate-800"
                    }`}
                  >
                    <FileText className="w-3.5 h-3.5" />
                    Labs Database
                  </button>
                  <button
                    onClick={() => setLabsSubTab("endocrine")}
                    className={`flex-1 py-2 rounded-lg text-xs font-bold uppercase transition-all flex items-center justify-center gap-1.5 ${
                      labsSubTab === "endocrine"
                        ? "bg-teal-500 text-slate-950 shadow-lg shadow-teal-500/20"
                        : isDarkMode 
                          ? "text-slate-400 hover:text-slate-200" 
                          : "text-slate-600 hover:text-slate-800"
                    }`}
                  >
                    <HelpCircle className="w-3.5 h-3.5" />
                    Endo & Specialty Protocols
                  </button>
                </div>

                {labsSubTab === "database" && (
                  <div className="flex overflow-x-auto scrollbar-none gap-2 pt-1">
                    {["All", "Blood", "Urine", "CSF/Fluid", "Urgent", "Ice", "Referred"].map((filt) => (
                      <button
                        key={filt}
                        onClick={() => setSelectedLabFilter(filt)}
                        className={`flex-shrink-0 px-3 py-1.5 rounded-full text-[10px] font-semibold border transition-all cursor-pointer whitespace-nowrap ${
                          selectedLabFilter === filt
                            ? isDarkMode 
                              ? "bg-teal-500/20 text-teal-400 border-teal-500/40" 
                              : "bg-teal-100 text-teal-800 border-teal-300 shadow-sm"
                            : isDarkMode
                              ? "bg-slate-900 border-slate-800 text-slate-400 hover:bg-slate-800 hover:text-slate-300"
                              : "bg-slate-100 border-slate-200 text-slate-600 hover:bg-slate-200 hover:text-slate-700"
                        }`}
                      >
                        {filt === "All" && "📁 All Tests"}
                        {filt === "Blood" && "🩸 Blood"}
                        {filt === "Urine" && "💧 Urine"}
                        {filt === "CSF/Fluid" && "🧠 Fluids"}
                        {filt === "Urgent" && "🚨 Urgent"}
                        {filt === "Ice" && "❄️ ICE"}
                        {filt === "Referred" && "✈️ Referred"}
                      </button>
                    ))}
                  </div>
                )}
              </div>
            )}

            {activeTab === "resus" && (
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 p-1 rounded-xl bg-slate-900/20 dark:bg-slate-950/40 border border-slate-800/40">
                <button
                  onClick={() => setResusSubTab("interactive")}
                  className={`py-2 rounded-lg text-xs font-bold uppercase transition-all flex items-center justify-center gap-1.5 ${
                    resusSubTab === "interactive"
                      ? "bg-rose-500 text-slate-950 shadow-lg shadow-rose-500/20"
                      : isDarkMode 
                        ? "text-slate-400 hover:text-slate-200 hover:bg-slate-900/40" 
                        : "text-slate-600 hover:text-slate-800 hover:bg-slate-100"
                  }`}
                >
                  <Activity className="w-3.5 h-3.5" />
                  Interactive Resus Guide
                </button>
                <button
                  onClick={() => setResusSubTab("em_drugs")}
                  className={`py-2 rounded-lg text-xs font-bold uppercase transition-all flex items-center justify-center gap-1.5 ${
                    resusSubTab === "em_drugs"
                      ? "bg-rose-500 text-slate-950 shadow-lg shadow-rose-500/20"
                      : isDarkMode 
                        ? "text-slate-400 hover:text-slate-200 hover:bg-slate-900/40" 
                        : "text-slate-600 hover:text-slate-800 hover:bg-slate-100"
                  }`}
                >
                  <Zap className="w-3.5 h-3.5" />
                  EM Drug Guide (EMTS)
                </button>
                <button
                  onClick={() => setResusSubTab("nutrition")}
                  className={`py-2 rounded-lg text-xs font-bold uppercase transition-all flex items-center justify-center gap-1.5 ${
                    resusSubTab === "nutrition"
                      ? "bg-rose-500 text-slate-950 shadow-lg shadow-rose-500/20"
                      : isDarkMode 
                        ? "text-slate-400 hover:text-slate-200 hover:bg-slate-900/40" 
                        : "text-slate-600 hover:text-slate-800 hover:bg-slate-100"
                  }`}
                >
                  <ClipboardList className="w-3.5 h-3.5" />
                  Critical Care Nutrition
                </button>
              </div>
            )}

            {activeTab === "drug" && (
              <div className="space-y-3">
                <div className="grid grid-cols-2 md:flex md:flex-row gap-2 p-1 rounded-xl bg-slate-900/20 dark:bg-slate-950/40 border border-slate-800/40">
                  <button
                    onClick={() => { setDrugSubTab("renal"); setSearchQuery(""); }}
                    className={`py-2 rounded-lg text-[10px] sm:text-xs font-bold uppercase transition-all flex items-center justify-center gap-1 cursor-pointer flex-1 ${
                      drugSubTab === "renal"
                        ? "bg-teal-500 text-slate-950 shadow-lg shadow-teal-500/20"
                        : isDarkMode 
                          ? "text-slate-400 hover:text-slate-200" 
                          : "text-slate-600 hover:text-slate-800"
                    }`}
                  >
                    <AlertTriangle className="w-3.5 h-3.5" />
                    Renal Dose
                  </button>
                  <button
                    onClick={() => { setDrugSubTab("dilution"); setSearchQuery(""); }}
                    className={`py-2 rounded-lg text-[10px] sm:text-xs font-bold uppercase transition-all flex items-center justify-center gap-1 cursor-pointer flex-1 ${
                      drugSubTab === "dilution"
                        ? "bg-teal-500 text-slate-950 shadow-lg shadow-teal-500/20"
                        : isDarkMode 
                          ? "text-slate-400 hover:text-slate-200" 
                          : "text-slate-600 hover:text-slate-800"
                    }`}
                  >
                    <Droplet className="w-3.5 h-3.5" />
                    Dilution
                  </button>
                  <button
                    onClick={() => { setDrugSubTab("enteral"); setSearchQuery(""); }}
                    className={`py-2 rounded-lg text-[10px] sm:text-xs font-bold uppercase transition-all flex items-center justify-center gap-1 cursor-pointer flex-1 ${
                      drugSubTab === "enteral"
                        ? "bg-teal-500 text-slate-950 shadow-lg shadow-teal-500/20"
                        : isDarkMode 
                          ? "text-slate-400 hover:text-slate-200" 
                          : "text-slate-600 hover:text-slate-800"
                    }`}
                  >
                    <Pill className="w-3.5 h-3.5" />
                    Enteral
                  </button>
                  <button
                    onClick={() => { setDrugSubTab("iron"); setSearchQuery(""); }}
                    className={`py-2 rounded-lg text-[10px] sm:text-xs font-bold uppercase transition-all flex items-center justify-center gap-1 cursor-pointer flex-1 ${
                      drugSubTab === "iron"
                        ? "bg-teal-500 text-slate-950 shadow-lg shadow-teal-500/20"
                        : isDarkMode 
                          ? "text-slate-400 hover:text-slate-200" 
                          : "text-slate-600 hover:text-slate-800"
                    }`}
                  >
                    <Activity className="w-3.5 h-3.5" />
                    Parenteral Iron
                  </button>
                </div>

                {drugSubTab === "renal" && (
                  <div className="space-y-3">
                    {/* Level 1: Category switcher (Antibiotics vs. Common Drugs) */}
                    <div className="flex gap-2">
                      <button 
                        onClick={() => setRenalCategory("antibiotic")}
                        className={`flex-1 py-2 rounded-lg border text-xs font-bold uppercase transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                          renalCategory === "antibiotic"
                            ? "bg-teal-500 text-slate-950 border-teal-500 shadow-lg shadow-teal-500/20"
                            : isDarkMode 
                              ? "bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-200" 
                              : "bg-slate-100 border-slate-200 text-slate-600 hover:text-slate-800"
                        }`}
                      >
                        🦠 Antibiotics
                      </button>
                      <button 
                        onClick={() => setRenalCategory("common")}
                        className={`flex-1 py-2 rounded-lg border text-xs font-bold uppercase transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                          renalCategory === "common"
                            ? "bg-teal-500 text-slate-950 border-teal-500 shadow-lg shadow-teal-500/20"
                            : isDarkMode 
                              ? "bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-200" 
                              : "bg-slate-100 border-slate-200 text-slate-600 hover:text-slate-800"
                        }`}
                      >
                        💊 Common Drugs
                      </button>
                    </div>

                    {/* Level 2: Sub-tab switcher (Only for Antibiotics) */}
                    {renalCategory === "antibiotic" && (
                      <div className="flex gap-2 p-1 rounded-xl bg-slate-950/20 border border-slate-800/40">
                        <button 
                          onClick={() => setRenalSubTab("stable")}
                          className={`flex-1 py-1.5 rounded-lg text-[10px] font-bold uppercase transition-all cursor-pointer ${
                            renalSubTab === "stable"
                              ? "bg-amber-500 text-slate-950 shadow-md shadow-amber-500/10"
                              : isDarkMode 
                                ? "text-slate-400 hover:text-slate-200" 
                                : "text-slate-600 hover:text-slate-800"
                          }`}
                        >
                          Stable CKD (Ward)
                        </button>
                        <button 
                          onClick={() => setRenalSubTab("icu")}
                          className={`flex-1 py-1.5 rounded-lg text-[10px] font-bold uppercase transition-all cursor-pointer ${
                            renalSubTab === "icu"
                              ? "bg-rose-500 text-slate-950 shadow-md shadow-rose-500/10"
                              : isDarkMode 
                                ? "text-slate-400 hover:text-slate-200" 
                                : "text-slate-600 hover:text-slate-800"
                          }`}
                        >
                          ICU / CRRT
                        </button>
                      </div>
                    )}
                  </div>
                )}

                {/* Quick Lookup Pills for Drugs */}
                {drugSubTab === "dilution" && (
                  <div className="flex overflow-x-auto scrollbar-none gap-2 pt-1">
                    {[
                      { id: "All", label: "📁 All Dilutions" },
                      { id: "Antibiotic", label: "🦠 Antibiotics" },
                      { id: "Inotrope", label: "⚡ Inotropes" },
                      { id: "Cardio", label: "❤️ Cardiovascular" },
                      { id: "Sedative", label: "💤 Sedatives" },
                      { id: "Electrolytes", label: "🧪 Electrolytes" }
                    ].map((filt) => (
                      <button
                        key={filt.id}
                        onClick={() => setSelectedDilutionFilter(filt.id)}
                        className={`flex-shrink-0 px-3 py-1.5 rounded-full text-[10px] font-semibold border transition-all cursor-pointer whitespace-nowrap ${
                          selectedDilutionFilter === filt.id
                            ? isDarkMode 
                              ? "bg-teal-500/20 text-teal-400 border-teal-500/40 shadow-sm" 
                              : "bg-teal-100 text-teal-800 border-teal-300 shadow-sm"
                            : isDarkMode
                              ? "bg-slate-900 border-slate-800/60 text-slate-400 hover:bg-slate-800 hover:text-slate-300"
                              : "bg-slate-100 border-slate-200 text-slate-600 hover:bg-slate-200 hover:text-slate-700"
                        }`}
                      >
                        {filt.label}
                      </button>
                    ))}
                  </div>
                )}

                {drugSubTab === "renal" && (
                  renalCategory === "antibiotic" ? (
                    <div className="flex overflow-x-auto scrollbar-none gap-2 pt-1">
                      {[
                        { id: "All", label: "📁 All Antibiotics" },
                        { id: "Penicillins", label: "💊 Penicillins" },
                        { id: "Cephalosporins", label: "🧬 Cephalosporins" },
                        { id: "Carbapenems", label: "🛡️ Carbapenems" },
                        { id: "Fluoroquinolones", label: "⚡ Fluoroquinolones" },
                        { id: "Antifungals", label: "🍄 Antifungals" }
                      ].map((filt) => (
                        <button
                          key={filt.id}
                          onClick={() => setSelectedRenalFilter(filt.id)}
                          className={`flex-shrink-0 px-3 py-1.5 rounded-full text-[10px] font-semibold border transition-all cursor-pointer whitespace-nowrap ${
                            selectedRenalFilter === filt.id
                              ? isDarkMode 
                                ? "bg-teal-500/20 text-teal-400 border-teal-500/40 shadow-sm" 
                                : "bg-teal-100 text-teal-800 border-teal-300 shadow-sm"
                              : isDarkMode
                                ? "bg-slate-900 border-slate-800/60 text-slate-400 hover:bg-slate-800 hover:text-slate-300"
                                : "bg-slate-100 border-slate-200 text-slate-600 hover:bg-slate-200 hover:text-slate-700"
                          }`}
                        >
                          {filt.label}
                        </button>
                      ))}
                    </div>
                  ) : (
                    <div className="flex overflow-x-auto scrollbar-none gap-2 pt-1">
                      {[
                        { id: "All", label: "📁 All Meds" },
                        { id: "Cardiovascular", label: "❤️ Cardiovascular" },
                        { id: "Anticoagulants", label: "🩸 Anticoagulants" },
                        { id: "Diabetes", label: "🍬 Diabetes" },
                        { id: "Analgesics", label: "🩹 Pain / Nerve" },
                        { id: "Gastro", label: "🧪 Gastrointestinal" }
                      ].map((filt) => (
                        <button
                          key={filt.id}
                          onClick={() => setSelectedRenalFilter(filt.id)}
                          className={`flex-shrink-0 px-3 py-1.5 rounded-full text-[10px] font-semibold border transition-all cursor-pointer whitespace-nowrap ${
                            selectedRenalFilter === filt.id
                              ? isDarkMode 
                                ? "bg-teal-500/20 text-teal-400 border-teal-500/40 shadow-sm" 
                                : "bg-teal-100 text-teal-800 border-teal-300 shadow-sm"
                              : isDarkMode
                                ? "bg-slate-900 border-slate-800/60 text-slate-400 hover:bg-slate-800 hover:text-slate-300"
                                : "bg-slate-100 border-slate-200 text-slate-600 hover:bg-slate-200 hover:text-slate-700"
                          }`}
                        >
                          {filt.label}
                        </button>
                      ))}
                    </div>
                  )
                )}

                {drugSubTab === "enteral" && (
                  <div className="flex overflow-x-auto scrollbar-none gap-2 pt-1">
                    {[
                      { id: "All", label: "📁 All Classes" },
                      { id: "Cardiovascular", label: "❤️ Cardiovascular" },
                      { id: "Infectious Disease", label: "🦠 Antibiotics" },
                      { id: "Endocrine", label: "🍬 Endocrine / DM" },
                      { id: "Neurology", label: "🧠 Neuro / Psych" },
                      { id: "Gastrointestinal", label: "🧪 Gastro" },
                      { id: "Others", label: "🩹 Others" }
                    ].map((filt) => (
                      <button
                        key={filt.id}
                        onClick={() => setSelectedEnteralFilter(filt.id)}
                        className={`flex-shrink-0 px-3 py-1.5 rounded-full text-[10px] font-semibold border transition-all cursor-pointer whitespace-nowrap ${
                          selectedEnteralFilter === filt.id
                            ? isDarkMode 
                              ? "bg-teal-500/20 text-teal-400 border-teal-500/40 shadow-sm" 
                              : "bg-teal-100 text-teal-800 border-teal-300 shadow-sm"
                            : isDarkMode
                              ? "bg-slate-900 border-slate-800/60 text-slate-400 hover:bg-slate-800 hover:text-slate-300"
                              : "bg-slate-100 border-slate-200 text-slate-600 hover:bg-slate-200 hover:text-slate-700"
                        }`}
                      >
                        {filt.label}
                      </button>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* SEARCH BAR (Context-aware search for active tab) */}
            {((activeTab !== "directory" && activeTab !== "calc" && activeTab !== "ho_guide" && activeTab !== "nag" && activeTab !== "palliative" && activeTab !== "resus" && activeTab !== "oncall") || (activeTab === "resus" && resusSubTab === "em_drugs") || activeTab === "directory" || activeTab === "ho_guide") && (
              <div className="relative z-50">
                <Search className={`absolute left-4 top-1/2 -translate-y-1/2 ${isDarkMode ? "text-slate-400" : "text-slate-500"} w-4 h-4`} />
                <input 
                  id="global-search-input"
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  onFocus={() => setIsSearchFocused(true)}
                  onBlur={() => setTimeout(() => setIsSearchFocused(false), 200)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter") {
                      addToRecentSearches(searchQuery);
                      e.currentTarget.blur();
                    }
                  }}
                  placeholder={
                    activeTab === "labs" 
                      ? (labsSubTab === "database" ? "Search 200+ lab tests..." : "Search endocrine protocols...")
                      : activeTab === "drug"
                        ? (drugSubTab === "dilution" ? "Search drug reconstitution..." : drugSubTab === "renal" ? "Search renal adjusted doses..." : "Search enteral tube advice (e.g., Aspirin, Omeprazole)...")
                        : (activeTab === "resus" && resusSubTab === "em_drugs")
                          ? "Search EM drug dilution..."
                          : activeTab === "directory"
                            ? "Search directory contacts & requisition forms..."
                            : activeTab === "ho_guide"
                              ? "Search bedside procedure guidelines & checklists..."
                              : "Search..."
                  }
                  className={`w-full py-2.5 pl-10 pr-10 rounded-xl border text-xs sm:text-sm transition-all outline-none ${
                    isDarkMode 
                      ? "bg-slate-950/40 border-slate-800/80 text-slate-100 focus:border-teal-400 focus:ring-1 focus:ring-teal-500/20 placeholder:text-slate-600" 
                      : "bg-white border-slate-200 text-slate-900 focus:border-teal-500 focus:ring-1 focus:ring-teal-500/20 shadow-sm placeholder:text-slate-400"
                  }`}
                />
                {searchQuery && (
                  <button 
                    onClick={() => setSearchQuery("")}
                    className={`absolute right-3 top-1/2 -translate-y-1/2 p-1.5 rounded-full transition-colors ${
                      isDarkMode ? "hover:bg-slate-800 text-slate-500" : "hover:bg-slate-100 text-slate-400"
                    }`}
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                )}

                {/* Recent Searches Dropdown */}
                <AnimatePresence>
                  {isSearchFocused && recentSearches.length > 0 && (
                    <motion.div
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: 10 }}
                      className={`absolute left-0 right-0 top-full mt-2 rounded-xl border p-3 z-50 shadow-xl backdrop-blur-md ${
                        isDarkMode 
                          ? "bg-slate-950/95 border-slate-800 text-slate-300 shadow-slate-950/80" 
                          : "bg-white/95 border-slate-200 text-slate-700 shadow-slate-200/50"
                      }`}
                    >
                      <div className="flex items-center justify-between pb-2 mb-2 border-b border-slate-800/20 dark:border-slate-800/60">
                        <span className="text-[10px] font-bold uppercase tracking-wider text-teal-500 dark:text-teal-400 flex items-center gap-1">
                          <Clock className="w-3 h-3 animate-pulse" /> Recent Searches
                        </span>
                        <button
                          onMouseDown={clearRecentSearches}
                          className="text-[10px] font-semibold text-slate-500 hover:text-rose-500 transition-colors flex items-center gap-1"
                        >
                          <Trash2 className="w-3 h-3" /> Clear all
                        </button>
                      </div>
                      <div className="flex flex-col gap-1 max-h-48 overflow-y-auto scrollbar-thin scrollbar-thumb-slate-800">
                        {recentSearches.map((term, index) => (
                          <div
                            key={index}
                            onMouseDown={() => {
                              setSearchQuery(term);
                              setIsSearchFocused(false);
                            }}
                            className={`flex items-center justify-between px-2 py-1.5 rounded-lg text-xs cursor-pointer transition-colors ${
                              isDarkMode 
                                ? "hover:bg-slate-900 text-slate-100" 
                                : "hover:bg-slate-50 text-slate-900"
                            }`}
                          >
                            <span className="truncate flex-1 mr-2 flex items-center gap-2">
                              <Search className="w-3 h-3 text-slate-500" />
                              {term}
                            </span>
                            <button
                              onMouseDown={(e) => removeRecentSearch(e, term)}
                              className={`p-1 rounded-full transition-colors ${
                                isDarkMode 
                                  ? "hover:bg-slate-800 text-slate-400 hover:text-slate-200" 
                                  : "hover:bg-slate-200 text-slate-500 hover:text-slate-700"
                              }`}
                              title="Remove search"
                            >
                              <X className="w-3 h-3" />
                            </button>
                          </div>
                        ))}
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>

                {/* Quick-tap Suggestions below search input when query is empty */}
                {!searchQuery && (
                  <div className="flex flex-wrap gap-1.5 mt-2 overflow-x-auto scrollbar-none py-0.5">
                    {(() => {
                      let suggestions: string[] = [];
                      if (activeTab === "labs") {
                        if (labsSubTab === "database") {
                          suggestions = ["TFT", "FBC", "LFT", "Renal", "Coag", "Urine", "GXM", "Amylase"];
                        } else {
                          suggestions = ["Synacthen", "Dexamethasone", "Cortisol", "Water Deprivation", "Growth Hormone", "Biopsy", "Muscle", "Renal"];
                        }
                      } else if (activeTab === "drug") {
                        if (drugSubTab === "dilution") {
                          suggestions = ["Ceftriaxone", "Noradrenaline", "GTN", "Amiodarone", "Cloxacillin", "Meropenem"];
                        } else if (drugSubTab === "renal") {
                          suggestions = ["Meropenem", "Piperacillin", "Colistin", "Fluconazole", "Ciprofloxacin"];
                        } else if (drugSubTab === "enteral") {
                          suggestions = ["Aspirin", "Omeprazole", "Pantoprazole", "Warfarin", "Metformin", "Felodipine", "Apixaban"];
                        }
                      } else if (activeTab === "resus" && resusSubTab === "em_drugs") {
                        suggestions = ["Adrenaline", "Atropine", "Amiodarone", "Calcium", "Magnesium"];
                      } else if (activeTab === "directory") {
                        suggestions = ["Chem", "Hema", "Micro", "HPE", "Pharmacy", "PER-PAT", "Autoimmune"];
                      } else if (activeTab === "ho_guide") {
                        suggestions = ["Pleural", "Ascites", "CSF", "BMA", "Hemolytic", "Light's", "SAAG"];
                      }
                      
                      if (suggestions.length === 0) return null;
                      
                      return (
                        <>
                          <span className={`text-[9px] font-bold self-center mr-1 uppercase tracking-wider opacity-60 flex items-center gap-0.5 ${isDarkMode ? "text-slate-400" : "text-slate-500"}`}>
                            ⚡ Quick:
                          </span>
                          {suggestions.map((s) => (
                            <button
                              key={s}
                              onClick={() => setSearchQuery(s)}
                              className={`px-2 py-1 rounded-full text-[10px] font-semibold border transition-all cursor-pointer whitespace-nowrap ${
                                isDarkMode
                                  ? "bg-slate-900/60 border-slate-800 text-slate-300 hover:bg-slate-800 hover:text-teal-400"
                                  : "bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100 hover:text-teal-600 shadow-sm"
                              }`}
                            >
                              {s}
                            </button>
                          ))}
                        </>
                      );
                    })()}
                  </div>
                )}

              </div>
            )}

            {searchQuery && ((activeTab !== "directory" && activeTab !== "calc" && activeTab !== "ho_guide" && activeTab !== "nag" && activeTab !== "palliative" && activeTab !== "resus" && activeTab !== "oncall") || (activeTab === "resus" && resusSubTab === "em_drugs")) && (
              <div className={`p-2.5 rounded-lg border text-[10px] flex justify-between items-center animate-fade-in ${
                isDarkMode ? "bg-teal-500/5 border-teal-500/10 text-teal-400" : "bg-teal-50 border-teal-100 text-teal-700 shadow-sm"
              }`}>
                <span className="font-medium truncate mr-2">
                  🔍 Searching for: <span className="font-bold underline">"{searchQuery}"</span>
                </span>
                <span className="font-mono bg-teal-500/10 px-2 py-0.5 rounded-full border border-teal-500/20 flex-shrink-0">
                  {activeTab === "labs" ? (labsSubTab === "database" ? `${getFilteredLabs().length} test(s)` : "Endocrine Protocols") :
                   activeTab === "drug" ? (drugSubTab === "dilution" ? `${getFilteredDilutions().length} drug(s)` : (renalCategory === "antibiotic" ? `${renalSubTab === "stable" ? getFilteredRenalStable().length : getFilteredRenalICU().length} drug(s)` : `${getFilteredRenalCommon().length} drug(s)`)) :
                   (activeTab === "resus" && resusSubTab === "em_drugs") ? `${getFilteredEMTS().length} drug(s)` :
                   "matching items"}
                </span>
              </div>
            )}
          </div>
        </div>


        {/* TAB: ON-CALL FATIGUE KIT */}
        {activeTab === "oncall" && (
          <div className="space-y-6 animate-fade-in">
            {/* Header Description */}
            <div className={`p-4 rounded-2xl border ${isDarkMode ? "bg-slate-900/60 border-slate-800" : "bg-white border-slate-200 shadow-sm"} flex flex-col md:flex-row items-start md:items-center justify-between gap-4`}>
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <Coffee className="w-5 h-5 text-amber-500 animate-pulse" />
                  <h2 className="text-base font-bold uppercase tracking-tight">On-Call Fatigue Kit</h2>
                </div>
                <p className={`text-xs ${isDarkMode ? "text-slate-400" : "text-slate-600"}`}>
                  A clinical support system designed to prevent medical errors, simplify shift handovers, and restore calm during intense calls.
                </p>
              </div>
              <button
                onClick={() => setOnCallSubTab("decompress")}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold uppercase flex items-center gap-1.5 border transition-all cursor-pointer ${
                  isDarkMode 
                    ? "bg-teal-500/10 border-teal-500/20 text-teal-400 hover:bg-teal-500/20" 
                    : "bg-teal-50 border-teal-200 text-teal-700 hover:bg-teal-100"
                }`}
              >
                <Wind className="w-3.5 h-3.5" />
                Quick Decompress
              </button>
            </div>

            {/* Sub-tabs Navigation */}
            <div className="flex p-1 rounded-xl bg-slate-900/20 dark:bg-slate-950/40 border border-slate-200/50 dark:border-slate-800/40">
              {[
                { id: "tracker", label: "Task Tracker & Handover", icon: <ClipboardList className="w-4 h-4" /> },
                { id: "survival", label: "Survival Triage Checklists", icon: <AlertTriangle className="w-4 h-4" /> },
                { id: "decompress", label: "Decompress / Breathe", icon: <Wind className="w-4 h-4" /> }
              ].map((subTab) => (
                <button
                  key={subTab.id}
                  onClick={() => setOnCallSubTab(subTab.id as any)}
                  className={`flex-1 py-2.5 rounded-lg text-xs font-bold uppercase transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                    onCallSubTab === subTab.id
                      ? isDarkMode
                        ? "bg-slate-800 text-amber-400 shadow-md border border-slate-700/50"
                        : "bg-white text-teal-700 shadow border border-slate-200"
                      : isDarkMode
                        ? "text-slate-400 hover:text-slate-200"
                        : "text-slate-500 hover:text-slate-700 hover:bg-slate-50/50"
                  }`}
                >
                  {subTab.icon}
                  <span className="hidden sm:inline">{subTab.label}</span>
                  <span className="sm:hidden">{subTab.label.split(" ")[0]}</span>
                </button>
              ))}
            </div>

            {/* SUB-TAB 1: TASK TRACKER */}
            {onCallSubTab === "tracker" && (
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
                {/* Add Task Box (Left / Top) */}
                <div className={`lg:col-span-4 p-5 rounded-2xl border ${isDarkMode ? "bg-slate-900/40 border-slate-800/80" : "bg-white border-slate-200 shadow-sm"} space-y-4`}>
                  <h3 className="text-xs font-extrabold uppercase tracking-wider text-slate-400 flex items-center gap-1">
                    <Plus className="w-3.5 h-3.5" />
                    Log On-Call Task
                  </h3>
                  
                  <div className="space-y-3">
                    <div>
                      <label className={`block text-[10px] font-bold uppercase mb-1 ${isDarkMode ? "text-slate-400" : "text-slate-500"}`}>Ward / Room</label>
                      <input
                        type="text"
                        placeholder="e.g. Ward 5B, ICU"
                        value={onCallRoom}
                        onChange={(e) => setOnCallRoom(e.target.value)}
                        className={`w-full p-2 rounded-lg border text-xs outline-none transition-all ${
                          isDarkMode 
                            ? "bg-slate-950/40 border-slate-800 focus:border-amber-500 text-slate-100 placeholder:text-slate-700" 
                            : "bg-white border-slate-200 focus:border-teal-500 text-slate-900 placeholder:text-slate-400 shadow-sm"
                        }`}
                      />
                    </div>

                    <div>
                      <label className={`block text-[10px] font-bold uppercase mb-1 ${isDarkMode ? "text-slate-400" : "text-slate-500"}`}>Bed / Patient Name</label>
                      <input
                        type="text"
                        placeholder="e.g. Bed 12 (Mr Tan)"
                        value={onCallPatient}
                        onChange={(e) => setOnCallPatient(e.target.value)}
                        className={`w-full p-2 rounded-lg border text-xs outline-none transition-all ${
                          isDarkMode 
                            ? "bg-slate-950/40 border-slate-800 focus:border-amber-500 text-slate-100 placeholder:text-slate-700" 
                            : "bg-white border-slate-200 focus:border-teal-500 text-slate-900 placeholder:text-slate-400 shadow-sm"
                        }`}
                      />
                    </div>

                    <div>
                      <label className={`block text-[10px] font-bold uppercase mb-1 ${isDarkMode ? "text-slate-400" : "text-slate-500"}`}>Action / Task Preset</label>
                      <select
                        value={onCallTaskType}
                        onChange={(e) => setOnCallTaskType(e.target.value)}
                        className={`w-full p-2 rounded-lg border text-xs outline-none transition-all cursor-pointer ${
                          isDarkMode 
                            ? "bg-slate-950 border-slate-800 text-slate-100 focus:border-amber-500" 
                            : "bg-white border-slate-200 text-slate-900 focus:border-teal-500 shadow-sm"
                        }`}
                      >
                        <option value="Review bloods">Review bloods / labs</option>
                        <option value="Take repeat blood culture">Take blood culture / GXM</option>
                        <option value="Review post-op Hb">Review post-op Hb</option>
                        <option value="Collect surgical consent">Collect consent</option>
                        <option value="Insert green cannula">Insert green cannula / line</option>
                        <option value="Trace CT scan / X-Ray">Trace scan report</option>
                        <option value="Update family on prognosis">Update family / family talk</option>
                        <option value="Prepare discharge summary">Prepare discharge summary</option>
                        <option value="Other">Other (write custom below)</option>
                      </select>
                    </div>

                    {onCallTaskType === "Other" && (
                      <div>
                        <label className={`block text-[10px] font-bold uppercase mb-1 ${isDarkMode ? "text-slate-400" : "text-slate-500"}`}>Custom Task Description</label>
                        <input
                          type="text"
                          placeholder="Type task details..."
                          value={onCallCustomTask}
                          onChange={(e) => setOnCallCustomTask(e.target.value)}
                          className={`w-full p-2 rounded-lg border text-xs outline-none transition-all ${
                            isDarkMode 
                              ? "bg-slate-950/40 border-slate-800 focus:border-amber-500 text-slate-100 placeholder:text-slate-700" 
                              : "bg-white border-slate-200 focus:border-teal-500 text-slate-900 placeholder:text-slate-400 shadow-sm"
                          }`}
                        />
                      </div>
                    )}

                    <div>
                      <label className={`block text-[10px] font-bold uppercase mb-1 ${isDarkMode ? "text-slate-400" : "text-slate-500"}`}>Urgency Category</label>
                      <div className="grid grid-cols-3 gap-1.5 p-1 rounded-lg bg-slate-950/30 border border-slate-800/40">
                        {(["routine", "important", "urgent"] as const).map((urg) => (
                          <button
                            key={urg}
                            type="button"
                            onClick={() => setOnCallUrgency(urg)}
                            className={`py-1.5 rounded text-[10px] font-bold uppercase transition-all cursor-pointer ${
                              onCallUrgency === urg
                                ? urg === "urgent"
                                  ? "bg-rose-500 text-slate-950"
                                  : urg === "important"
                                    ? "bg-amber-500 text-slate-950"
                                    : "bg-teal-500 text-slate-950"
                                : isDarkMode
                                  ? "text-slate-400 hover:text-slate-200"
                                  : "text-slate-500 hover:text-slate-800"
                            }`}
                          >
                            {urg === "urgent" ? "Urgent" : urg === "important" ? "Important" : "Routine"}
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>

                  <button
                    onClick={() => {
                      if (!onCallRoom || !onCallPatient) {
                        return;
                      }
                      const finalTaskText = onCallTaskType === "Other" ? onCallCustomTask : onCallTaskType;
                      if (!finalTaskText) return;

                      const newTask = {
                        id: Date.now().toString(),
                        room: onCallRoom,
                        patient: onCallPatient,
                        task: finalTaskText,
                        urgency: onCallUrgency,
                        status: "pending" as const
                      };

                      setOnCallTasks((prev) => [newTask, ...prev]);
                      setOnCallPatient("");
                      setOnCallCustomTask("");
                    }}
                    disabled={!onCallRoom || !onCallPatient}
                    className={`w-full py-2 rounded-xl text-xs font-bold uppercase border transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
                      (!onCallRoom || !onCallPatient)
                        ? "opacity-40 cursor-not-allowed bg-slate-950/25 border-slate-800 text-slate-500"
                        : isDarkMode
                          ? "bg-teal-500 text-slate-950 border-teal-400 font-extrabold hover:bg-teal-400 shadow-md shadow-teal-500/10"
                          : "bg-teal-600 text-white border-teal-500 font-extrabold hover:bg-teal-700 shadow-sm"
                    }`}
                  >
                    <Plus className="w-3.5 h-3.5" />
                    Add Ward Task
                  </button>
                </div>

                {/* Task List and Handover Copier (Right / Bottom) */}
                <div className="lg:col-span-8 space-y-4">
                  {/* List Controls & Handover Button */}
                  <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
                    <div className="flex items-center gap-1.5 p-1 rounded-xl bg-slate-900/20 dark:bg-slate-950/40 border border-slate-200/50 dark:border-slate-800/40">
                      {(["all", "pending", "completed"] as const).map((filterOpt) => {
                        const count = filterOpt === "all" 
                          ? onCallTasks.length 
                          : onCallTasks.filter(t => t.status === (filterOpt === "pending" ? "pending" : "completed")).length;
                        return (
                          <button
                            key={filterOpt}
                            onClick={() => setOnCallTaskFilter(filterOpt)}
                            className={`px-2.5 py-1 rounded-lg text-[10px] font-bold uppercase transition-all flex items-center gap-1.5 cursor-pointer ${
                              onCallTaskFilter === filterOpt
                                ? isDarkMode
                                  ? "bg-slate-800 text-amber-400"
                                  : "bg-white text-teal-700 shadow-sm border border-slate-200"
                                : "text-slate-500 hover:text-slate-700 dark:text-slate-400"
                            }`}
                          >
                            <span>{filterOpt}</span>
                            <span className="px-1.5 py-0.2 text-[9px] rounded-full bg-slate-950/20 dark:bg-slate-800/50">{count}</span>
                          </button>
                        );
                      })}
                    </div>

                    <div className="flex gap-2 w-full sm:w-auto">
                      <button
                        onClick={() => {
                          const dateStr = new Date().toLocaleDateString("en-MY", { day: "numeric", month: "short", year: "numeric" });
                          const urgentTasks = onCallTasks.filter(t => t.urgency === "urgent");
                          const importantTasks = onCallTasks.filter(t => t.urgency === "important");
                          const routineTasks = onCallTasks.filter(t => t.urgency === "routine");
                          
                          let txt = `📋 *WARD ON-CALL HANDOVER (${dateStr})*\n`;
                          txt += `Generated via Doctor's Companion\n\n`;
                          
                          txt += `🔴 *URGENT / ASAP (${urgentTasks.filter(t => t.status === "pending").length} PENDING)*\n`;
                          if (urgentTasks.length === 0) {
                            txt += `- Nil\n`;
                          } else {
                            urgentTasks.forEach(t => {
                              txt += `${t.status === "completed" ? "✅" : "☐"} [${t.room}] ${t.patient}: ${t.task}\n`;
                            });
                          }
                          txt += `\n`;
                          
                          txt += `🟡 *IMPORTANT / PENDING (${importantTasks.filter(t => t.status === "pending").length} PENDING)*\n`;
                          if (importantTasks.length === 0) {
                            txt += `- Nil\n`;
                          } else {
                            importantTasks.forEach(t => {
                              txt += `${t.status === "completed" ? "✅" : "☐"} [${t.room}] ${t.patient}: ${t.task}\n`;
                            });
                          }
                          txt += `\n`;
                          
                          txt += `🟢 *ROUTINE TASKS (${routineTasks.filter(t => t.status === "pending").length} PENDING)*\n`;
                          if (routineTasks.length === 0) {
                            txt += `- Nil\n`;
                          } else {
                            routineTasks.forEach(t => {
                              txt += `${t.status === "completed" ? "✅" : "☐"} [${t.room}] ${t.patient}: ${t.task}\n`;
                            });
                          }
                          txt += `\n`;
                          txt += `_Please review and carry over pending tasks. Thank you team!_`;
                          
                          handleCopy(txt, "handover-copy");
                        }}
                        className={`flex-1 sm:flex-initial px-4 py-2 rounded-xl text-xs font-bold uppercase transition-all flex items-center justify-center gap-1.5 border cursor-pointer ${
                          copyFeedback === "handover-copy"
                            ? "bg-emerald-500/10 border-emerald-500/30 text-emerald-400 font-extrabold"
                            : isDarkMode
                              ? "bg-amber-500/10 border-amber-500/20 text-amber-400 hover:bg-amber-500/20"
                              : "bg-amber-50 border-amber-200 text-amber-800 hover:bg-amber-100 shadow-sm"
                        }`}
                      >
                        <Copy className="w-3.5 h-3.5" />
                        {copyFeedback === "handover-copy" ? "Copied Handover! ✓" : "Copy Handover to WhatsApp"}
                      </button>

                      <button
                        onClick={() => {
                          if (confirm("Are you sure you want to clear all logged tasks?")) {
                            setOnCallTasks([]);
                          }
                        }}
                        className={`p-2 rounded-xl border transition-all cursor-pointer ${
                          isDarkMode
                            ? "bg-slate-900 border-slate-800 text-slate-500 hover:text-rose-400"
                            : "bg-white border-slate-200 text-slate-400 hover:text-rose-600 shadow-sm"
                        }`}
                        title="Clear all tasks"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>

                  {/* Task Cards Container */}
                  <div className="space-y-3">
                    {onCallTasks.filter(t => onCallTaskFilter === "all" ? true : t.status === onCallTaskFilter).length === 0 ? (
                      <div className={`p-10 rounded-2xl border text-center space-y-2 ${isDarkMode ? "bg-slate-900/20 border-slate-800/60" : "bg-slate-50 border-slate-200"}`}>
                        <ListTodo className="w-8 h-8 text-slate-500 mx-auto opacity-55" />
                        <h4 className="text-xs font-bold uppercase tracking-wide">No Matching Tasks</h4>
                        <p className={`text-[11px] ${isDarkMode ? "text-slate-500" : "text-slate-500"} max-w-sm mx-auto`}>
                          Add pending bloods, scan reviews, or bedside procedures here to maintain a clear mental map and export handovers seamlessly.
                        </p>
                      </div>
                    ) : (
                      onCallTasks
                        .filter(t => onCallTaskFilter === "all" ? true : t.status === onCallTaskFilter)
                        .map((t) => {
                          // Card urgency styling
                          let borderClass = "border-teal-500/40 dark:border-teal-500/20 bg-teal-500/5";
                          let badgeText = "Routine";
                          let badgeBg = "bg-teal-500/10 text-teal-400 border-teal-500/20";
                          if (t.urgency === "urgent") {
                            borderClass = "border-rose-500/50 dark:border-rose-500/30 bg-rose-500/5";
                            badgeText = "ASAP / Urgent";
                            badgeBg = "bg-rose-500/15 text-rose-400 border-rose-500/25";
                          } else if (t.urgency === "important") {
                            borderClass = "border-amber-500/50 dark:border-amber-500/30 bg-amber-500/5";
                            badgeText = "Important";
                            badgeBg = "bg-amber-500/15 text-amber-400 border-amber-500/25";
                          }

                          return (
                            <motion.div
                              key={t.id}
                              layout
                              initial={{ opacity: 0, y: 10 }}
                              animate={{ opacity: 1, y: 0 }}
                              exit={{ opacity: 0, scale: 0.95 }}
                              className={`p-3.5 rounded-xl border-l-4 border-y border-r transition-all flex items-center justify-between gap-3 ${borderClass} ${
                                t.status === "completed" ? "opacity-50 line-through scale-[0.98]" : ""
                              } ${isDarkMode ? "bg-slate-900/25 border-slate-800" : "bg-white border-slate-200"}`}
                            >
                              <div className="flex items-center gap-3 min-w-0">
                                <button
                                  onClick={() => {
                                    setOnCallTasks((prev) => 
                                      prev.map(task => task.id === t.id 
                                        ? { ...task, status: task.status === "pending" ? "completed" : "pending" } 
                                        : task
                                      )
                                    );
                                  }}
                                  className={`w-5 h-5 rounded-full border flex items-center justify-center cursor-pointer transition-all ${
                                    t.status === "completed"
                                      ? "bg-teal-500 border-teal-500 text-slate-950 font-bold"
                                      : isDarkMode 
                                        ? "border-slate-700 hover:border-teal-400" 
                                        : "border-slate-300 hover:border-teal-500"
                                  }`}
                                >
                                  {t.status === "completed" && <Check className="w-3 h-3 stroke-[3]" />}
                                </button>

                                <div className="space-y-0.5 min-w-0">
                                  <div className="flex items-center flex-wrap gap-1.5">
                                    <span className={`text-[9px] font-extrabold uppercase px-1.5 py-0.2 rounded border ${badgeBg}`}>
                                      {badgeText}
                                    </span>
                                    <span className={`text-[10px] font-bold ${isDarkMode ? "text-slate-300" : "text-slate-800"}`}>
                                      [{t.room}] {t.patient}
                                    </span>
                                  </div>
                                  <p className={`text-xs ${isDarkMode ? "text-slate-400" : "text-slate-600"} truncate font-medium`}>
                                    {t.task}
                                  </p>
                                </div>
                              </div>

                              <button
                                onClick={() => {
                                  setOnCallTasks((prev) => prev.filter(task => task.id !== t.id));
                                }}
                                className={`p-1.5 rounded-lg border transition-colors cursor-pointer ${
                                  isDarkMode 
                                    ? "border-slate-800 text-slate-500 hover:text-rose-400 hover:bg-slate-800" 
                                    : "border-slate-200 text-slate-400 hover:text-rose-600 hover:bg-slate-50"
                                }`}
                              >
                                <X className="w-3.5 h-3.5" />
                              </button>
                            </motion.div>
                          );
                        })
                    )}
                  </div>
                </div>
              </div>
            )}

            {/* SUB-TAB 2: NIGHT CALL SURVIVAL GUIDE */}
            {onCallSubTab === "survival" && (
              <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-start animate-fade-in">
                {/* Checklists selector menu */}
                <div className="md:col-span-3 space-y-2">
                  <h4 className="text-[10px] font-extrabold uppercase tracking-widest text-slate-500 dark:text-slate-400 mb-3">
                    Night-Call Triage
                  </h4>
                  {[
                    { id: "fever", label: "Fever Spike / Sepsis", color: "border-rose-500/50" },
                    { id: "dyspnea", label: "Acute Dyspnea", color: "border-blue-500/50" },
                    { id: "hypotension", label: "Hypotension / Shock", color: "border-amber-500/50" },
                    { id: "agitated", label: "Agitation / Delirium", color: "border-purple-500/50" },
                    { id: "oliguria", label: "Oliguria / Low Urine", color: "border-yellow-500/50" }
                  ].map((guide) => (
                    <button
                      key={guide.id}
                      onClick={() => setOnCallSelectedGuide(guide.id as any)}
                      className={`w-full text-left px-3 py-2.5 rounded-xl border text-xs font-bold transition-all uppercase flex items-center justify-between cursor-pointer ${
                        onCallSelectedGuide === guide.id
                          ? isDarkMode
                            ? "bg-slate-800 border-amber-500/50 text-amber-400 shadow-md shadow-amber-500/5"
                            : "bg-white border-teal-500 text-teal-850 shadow-sm"
                          : isDarkMode
                            ? "bg-slate-900/40 border-slate-800/80 text-slate-400 hover:bg-slate-800/50"
                            : "bg-white border-slate-200 text-slate-600 hover:bg-slate-50 hover:border-slate-300"
                      }`}
                    >
                      <span>{guide.label}</span>
                      <span className={`w-1.5 h-1.5 rounded-full ${onCallSelectedGuide === guide.id ? "bg-amber-400 animate-ping" : "bg-slate-700"}`} />
                    </button>
                  ))}
                </div>

                {/* Checklist guide panel */}
                <div className="md:col-span-9">
                  {(() => {
                    let title = "";
                    let urgencyAlert = "";
                    let bedsideActions: string[] = [];
                    let investigations: string[] = [];
                    let drugTherapy: string[] = [];
                    let escalationCriteria: string[] = [];

                    if (onCallSelectedGuide === "fever") {
                      title = "Fever Spike (T >= 38.0°C) or Suspected Sepsis";
                      urgencyAlert = "Immediate triage priority is to rule out septic shock, neutropenic sepsis, or meningitis. Initiate Sepsis 6 Bundle if severe.";
                      bedsideActions = [
                        "Assess GCS, airway, breathing, circulation. Take immediate vitals (PR, BP, RR, Temp, SpO2).",
                        "Perform thorough physical exam to trace focus: check neck stiffness, lungs, abdomen, IV cannulation sites, surgical sites, urine color.",
                        "Initiate physical cooling: tepid sponging, remove excess bedding/covers."
                      ];
                      investigations = [
                        "Send blood cultures x2 (from 2 separate sites; if central line present, draw 1 from line and 1 peripheral).",
                        "Check urgent Full Blood Count (FBC) - check for leukocytosis or neutropenia (Absolute Neutrophil Count).",
                        "Send Renal Profile, Liver Function, and Serum Lactate (critical marker of tissue hypoperfusion).",
                        "Send urine FEME & urine Culture, collect sputum sample, order Chest X-Ray if respiratory symptoms."
                      ];
                      drugTherapy = [
                        "Give Paracetamol 1g PO / IV if temp > 38.5°C and not contraindicated (max 4g/day).",
                        "Start empiric IV Antibiotics immediately (within 1 hour of sepsis recognition) AFTER blood cultures are drawn.",
                        "If BP is borderline (SBP < 90 mmHg), prepare 500mL IV crystalloid challenge (e.g. Normal Saline or Hartmann's) and monitor response."
                      ];
                      escalationCriteria = [
                        "Systolic BP remains < 90 mmHg despite 30mL/kg fluid resuscitation (signs of septic shock).",
                        "Serum Lactate > 2.0 mmol/L.",
                        "New onset acute confusion / drowsiness / neck stiffness.",
                        "Patient is on chemotherapy (absolute risk of high-mortality Neutropenic Sepsis!)."
                      ];
                    } else if (onCallSelectedGuide === "dyspnea") {
                      title = "Acute Shortness of Breath (Dyspnea)";
                      urgencyAlert = "High stakes! Common traps include missed pulmonary embolism, acute pulmonary edema, severe bronchospasm, or tension pneumothorax.";
                      bedsideActions = [
                        "Upright positioning (high Fowler's) immediately to maximize diaphragmatic excursion.",
                        "Apply supplementary Oxygen immediately: target SpO2 94-98% (or 88-92% if known COPD).",
                        "Auscultate lungs thoroughly: check for bilateral crepitations (fluid overload), wheezing (bronchospasm), or silent chest."
                      ];
                      investigations = [
                        "Perform bedside 12-lead ECG (look for acute MI, STEMI, S1Q3T3 for PE, tachycardia).",
                        "Order urgent Portable Chest X-Ray (to rule out pneumothorax, pulmonary congestion, lobar pneumonia).",
                        "Send Arterial Blood Gas (ABG) to check pH, PaCO2 (type II failure), PaO2, and lactate."
                      ];
                      drugTherapy = [
                        "If fluid overload (crepitations, JVP raised): give IV Frusemide 40mg to 80mg bolus stat.",
                        "If wheezing / bronchospasm: administer nebulized Salbutamol 5mg + Ipratropium Bromide 0.5mg stat.",
                        "If acute MI suspected: load Aspirin 300mg + Clopidogrel 300mg (or Ticagrelor 180mg) and notify cardiology."
                      ];
                      escalationCriteria = [
                        "SpO2 < 90% despite high-flow face mask or non-rebreather mask.",
                        "Respiratory rate > 30 breaths/min or use of accessory respiratory muscles.",
                        "Stridor, silent chest, or suspected airway obstruction.",
                        "ECG showing dynamic ST-elevation or new-onset left bundle branch block (LBBB)."
                      ];
                    } else if (onCallSelectedGuide === "hypotension") {
                      title = "Acute Hypotension (SBP < 90 mmHg or Drop > 40 mmHg)";
                      urgencyAlert = "Check for hidden haemorrhage, septic shock, cardiogenic shock (MI), or anaphylaxis. Never assume the patient is just 'sleeping'.";
                      bedsideActions = [
                        "Confirm blood pressure manually using appropriate cuff size. Check both arms.",
                        "Place patient in Trendelenburg (legs elevated) if tolerated to increase venous return (contraindicated in severe dyspnea).",
                        "Check for external bleeding, rash (anaphylaxis), fever, cold/clammy skin, or warm flushed skin."
                      ];
                      investigations = [
                        "Send urgent capillary blood glucose (DXT) - hypoglycemia can mimic shock.",
                        "Send urgent Full Blood Count, Renal Profile, Lactate, and Group Screen and Hold (GXM) if bleeding suspected.",
                        "Perform portable bedside ultrasound to check IVC collapsibility and cardiac contractility (if trained)."
                      ];
                      drugTherapy = [
                        "Unless in overt fluid overload / cardiogenic shock, administer 250-500mL crystalloid fluid challenge over 15 minutes.",
                        "Stop all active antihypertensives, diuretics, and vasodilators immediately.",
                        "In anaphylaxis: give IM Adrenaline (1:1000) 0.5mg immediately in the anterolateral thigh."
                      ];
                      escalationCriteria = [
                        "Systolic BP remains < 90 mmHg despite 1L of fluid challenge.",
                        "Shock accompanied by severe chest pain or new ECG changes (highly suspicious of cardiogenic shock).",
                        "Hypotension with acute oliguria (<0.5 mL/kg/h) or deteriorating GCS."
                      ];
                    } else if (onCallSelectedGuide === "agitated") {
                      title = "Agitated, Delirious, or Aggressive Patient";
                      urgencyAlert = "Crucial trap: Agitation is often secondary to hypoxia, hypoglycemia, or drug withdrawal. Do NOT sedate until metabolic causes are excluded!";
                      bedsideActions = [
                        "Check capillary glucose (DXT) and Oxygen saturation (SpO2) immediately. Hypoglycemia & hypoxia are high-fatality reversible causes!",
                        "Employ verbal de-escalation: speak in a calm, low voice, do not argue, maintain safe distance, simplify the environment.",
                        "Check bladder for acute urinary retention or abdominal distension (fecal impaction is a major delirium driver in elderly)."
                      ];
                      investigations = [
                        "Send basic electrolyte panel (specifically check for severe hyponatremia or hypercalcemia).",
                        "Send Urine FEME to screen for Urinary Tract Infection (UTI) - very common delirium trigger in geriatric patients.",
                        "Check arterial blood gas (ABG) if hypercapnic encephalopathy is suspected (CO2 retention)."
                      ];
                      drugTherapy = [
                        "First-line is ALWAYS non-pharmacological. Chemical sedation is a last resort to protect patient/staff safety.",
                        "If sedation required: Haloperidol 0.5mg to 1.5mg PO/IM (avoid in Parkinson's / Lewy body dementia).",
                        "Alternative: Lorazepam 0.5mg to 1mg PO/IM. Use extremely low doses in geriatric patients to avoid paradoxically worsening agitation."
                      ];
                      escalationCriteria = [
                        "Patient remains extremely combative, posing immediate risk to themselves or others despite initial low-dose chemical restraint.",
                        "Agitation accompanied by hyperpyrexia, muscular rigidity, or autonomic instability (suspect Neuroleptic Malignant Syndrome or Serotonin Syndrome).",
                        "New onset focal neurological deficits."
                      ];
                    } else if (onCallSelectedGuide === "oliguria") {
                      title = "Oliguria (Urine Output < 0.5 mL/kg/h for 2 consecutive hours)";
                      urgencyAlert = "Triage focus: differentiate obstructive catheter blockage (reversible in seconds) from prerenal dehydration or acute kidney injury (AKI).";
                      bedsideActions = [
                        "Check catheter patency first! Flush the urinary catheter with 20-30mL sterile normal saline to clear any clots or debris.",
                        "Auscultate heart and lungs to assess volume status (look for signs of overload like JVP height, peripheral edema, basal creps).",
                        "Check patient intake/output (I/O) charts over the past 24-48 hours. Confirm true fluid intake."
                      ];
                      investigations = [
                        "Send urgent Renal Profile (Urea, Creatinine, Electrolytes) to check for worsening AKI.",
                        "Perform bedside bladder scan or abdominal ultrasound to look for post-void residual urine (obstructive uropathy).",
                        "Analyze urine sodium and osmolarity if prerenal vs. renal etiology is unclear."
                      ];
                      drugTherapy = [
                        "If patient is hypovolemic (dry mucous membranes, flat JVP): administer fluid challenge 250-500mL crystalloid stat.",
                        "If patient is hypervolemic (crepitations, edema) with AKI / fluid overload: give IV Frusemide 40-80mg stat to recruit nephrons.",
                        "Ensure all nephrotoxic drugs (NSAIDs, Gentamicin, ACE inhibitors, ARBs) are held / discontinued immediately."
                      ];
                      escalationCriteria = [
                        "Complete anuria (no urine output at all for > 4 hours) unresponsive to catheter flushing.",
                        "Oliguria accompanied by fluid overload (refractory hypoxia, pulmonary edema).",
                        "Worsening metabolic acidosis (pH < 7.2) or severe hyperkalemia (K > 6.0 mmol/L with ECG changes)."
                      ];
                    }

                    return (
                      <div className={`p-6 rounded-2xl border ${isDarkMode ? "bg-slate-900/40 border-slate-800/80" : "bg-white border-slate-200 shadow-sm"} space-y-6`}>
                        {/* Section Title */}
                        <div className="space-y-1.5 pb-4 border-b border-slate-800/40">
                          <h3 className={`text-base font-extrabold uppercase tracking-tight ${isDarkMode ? "text-amber-400" : "text-teal-700"}`}>
                            {title}
                          </h3>
                          <div className={`text-[11px] font-medium leading-relaxed p-2.5 rounded-lg border ${
                            isDarkMode 
                              ? "bg-rose-500/5 border-rose-500/10 text-rose-300" 
                              : "bg-rose-50 border-rose-100 text-rose-850"
                          }`}>
                            ⚠️ {urgencyAlert}
                          </div>
                        </div>

                        {/* Interactive Steps Checklist */}
                        <div className="space-y-5">
                          {/* Part A: Bedside */}
                          <div className="space-y-2">
                            <h4 className="text-[10px] font-extrabold uppercase tracking-wider text-slate-500 flex items-center gap-1.5">
                              <span className="w-1.5 h-3 bg-red-500 rounded-sm" />
                              1. Immediate Bedside Assessment
                            </h4>
                            <div className="space-y-1.5">
                              {bedsideActions.map((act, idx) => {
                                const id = `survival-${onCallSelectedGuide}-bedside-${idx}`;
                                return (
                                  <label
                                    key={id}
                                    className={`flex items-start gap-2.5 p-2 rounded-lg border transition-all cursor-pointer ${
                                      survivalChecklist[id]
                                        ? "bg-slate-950/20 border-slate-800 opacity-60 line-through text-slate-500"
                                        : isDarkMode
                                          ? "bg-slate-950/10 border-slate-850 hover:bg-slate-900/40 hover:border-slate-800 text-slate-300"
                                          : "bg-slate-50/50 border-slate-200 hover:bg-slate-100/50 text-slate-700"
                                    }`}
                                  >
                                    <input
                                      type="checkbox"
                                      checked={!!survivalChecklist[id]}
                                      onChange={(e) => {
                                        setSurvivalChecklist(prev => ({
                                          ...prev,
                                          [id]: e.target.checked
                                        }));
                                      }}
                                      className="mt-0.5 rounded border-slate-700 text-teal-600 focus:ring-teal-500 bg-slate-950"
                                    />
                                    <span className="text-[11px] font-medium leading-relaxed">{act}</span>
                                  </label>
                                );
                              })}
                            </div>
                          </div>

                          {/* Part B: Investigations */}
                          <div className="space-y-2">
                            <h4 className="text-[10px] font-extrabold uppercase tracking-wider text-slate-500 flex items-center gap-1.5">
                              <span className="w-1.5 h-3 bg-blue-500 rounded-sm" />
                              2. Essential Investigations to Order
                            </h4>
                            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                              {investigations.map((inv, idx) => {
                                const id = `survival-${onCallSelectedGuide}-inv-${idx}`;
                                return (
                                  <label
                                    key={id}
                                    className={`flex items-start gap-2.5 p-2 rounded-lg border transition-all cursor-pointer ${
                                      survivalChecklist[id]
                                        ? "bg-slate-950/20 border-slate-800 opacity-60 line-through text-slate-500"
                                        : isDarkMode
                                          ? "bg-slate-950/10 border-slate-850 hover:bg-slate-900/40 hover:border-slate-800 text-slate-300"
                                          : "bg-slate-50/50 border-slate-200 hover:bg-slate-100/50 text-slate-700"
                                    }`}
                                  >
                                    <input
                                      type="checkbox"
                                      checked={!!survivalChecklist[id]}
                                      onChange={(e) => {
                                        setSurvivalChecklist(prev => ({
                                          ...prev,
                                          [id]: e.target.checked
                                        }));
                                      }}
                                      className="mt-0.5 rounded border-slate-700 text-teal-600 focus:ring-teal-500 bg-slate-950"
                                    />
                                    <span className="text-[11px] font-medium leading-relaxed">{inv}</span>
                                  </label>
                                );
                              })}
                            </div>
                          </div>

                          {/* Part C: Therapy */}
                          <div className="space-y-2">
                            <h4 className="text-[10px] font-extrabold uppercase tracking-wider text-slate-500 flex items-center gap-1.5">
                              <span className="w-1.5 h-3 bg-teal-500 rounded-sm" />
                              3. Stat Dosing & Empiric Therapy
                            </h4>
                            <div className="space-y-1.5">
                              {drugTherapy.map((rx, idx) => {
                                const id = `survival-${onCallSelectedGuide}-rx-${idx}`;
                                return (
                                  <label
                                    key={id}
                                    className={`flex items-start gap-2.5 p-2 rounded-lg border transition-all cursor-pointer ${
                                      survivalChecklist[id]
                                        ? "bg-slate-950/20 border-slate-800 opacity-60 line-through text-slate-500"
                                        : isDarkMode
                                          ? "bg-slate-950/10 border-slate-850 hover:bg-slate-900/40 hover:border-slate-800 text-slate-300"
                                          : "bg-slate-50/50 border-slate-200 hover:bg-slate-100/50 text-slate-700"
                                    }`}
                                  >
                                    <input
                                      type="checkbox"
                                      checked={!!survivalChecklist[id]}
                                      onChange={(e) => {
                                        setSurvivalChecklist(prev => ({
                                          ...prev,
                                          [id]: e.target.checked
                                        }));
                                      }}
                                      className="mt-0.5 rounded border-slate-700 text-teal-600 focus:ring-teal-500 bg-slate-950"
                                    />
                                    <span className="text-[11px] font-medium leading-relaxed">{rx}</span>
                                  </label>
                                );
                              })}
                            </div>
                          </div>

                          {/* Part D: Escalation */}
                          <div className="p-4 rounded-xl bg-rose-500/5 border border-rose-500/10 space-y-2.5">
                            <h4 className="text-[10px] font-extrabold uppercase tracking-wider text-rose-400 flex items-center gap-1.5">
                              🚨 Escalation Criteria (When to call the MO stat)
                            </h4>
                            <ul className="space-y-1 text-[11px] font-medium text-rose-300/90 list-disc list-inside leading-relaxed pl-1">
                              {escalationCriteria.map((esc, idx) => (
                                <li key={idx}>{esc}</li>
                              ))}
                            </ul>
                          </div>

                          {/* Copy Guideline Summary */}
                          <button
                            onClick={() => {
                              const summaryText = `Survival Reference: ${title}\n` +
                                `-----------------------------------------------\n` +
                                `Bedside Actions Checklist:\n` + bedsideActions.map((a, i) => `[ ] ${a}`).join("\n") + `\n\n` +
                                `Essential Investigations:\n` + investigations.map((i, idx) => `[ ] ${i}`).join("\n") + `\n\n` +
                                `Dosing & Empiric Therapy:\n` + drugTherapy.map((d, idx) => `[ ] ${d}`).join("\n") + `\n\n` +
                                `Escalation Markers:\n` + escalationCriteria.map((e, idx) => `- ${e}`).join("\n") +
                                `\n-----------------------------------------------\nGenerated via Doctor's Companion`;
                              handleCopy(summaryText, `survival-copy-${onCallSelectedGuide}`);
                            }}
                            className={`w-full py-2.5 rounded-xl font-bold uppercase text-[10px] transition-all border flex items-center justify-center gap-2 cursor-pointer ${
                              copyFeedback === `survival-copy-${onCallSelectedGuide}`
                                ? "bg-emerald-500/10 text-emerald-400 border-emerald-500/30 font-extrabold"
                                : isDarkMode
                                  ? "bg-slate-900 border-slate-800 text-slate-300 hover:bg-slate-800"
                                  : "bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100 shadow-sm"
                            }`}
                          >
                            {copyFeedback === `survival-copy-${onCallSelectedGuide}` ? "Survival Guideline Copied! ✓" : "Copy Guideline to Clipboard"}
                          </button>
                        </div>
                      </div>
                    );
                  })()}
                </div>
              </div>
            )}

            {/* SUB-TAB 3: DECOMPRESS breathing timer */}
            {onCallSubTab === "decompress" && (
              <div className="flex flex-col items-center justify-center py-6 text-center space-y-6 animate-fade-in">
                <div className="max-w-md space-y-2">
                  <h3 className="text-sm font-bold uppercase tracking-wider text-slate-400">Cortisol Reset Room</h3>
                  <p className={`text-xs ${isDarkMode ? "text-slate-400" : "text-slate-600"} leading-relaxed`}>
                    Sleep-deprived clinicians operate with highly elevated sympathetic tone. Take just 1 minute of Box Breathing (adapted from tactical stress relief) to reset your physiological heart rate.
                  </p>
                </div>

                {/* Concentric animation box */}
                <div className="relative w-64 h-64 flex items-center justify-center">
                  <AnimatePresence mode="popLayout">
                    {/* Concentric growing bubble based on breath phase */}
                    <motion.div
                      key={onCallBreathingPhase}
                      initial={{ scale: 0.8, opacity: 0.3 }}
                      animate={{
                        scale: onCallBreathingActive
                          ? onCallBreathingPhase === "inhale"
                            ? 1.4
                            : onCallBreathingPhase === "hold1"
                              ? 1.4
                              : onCallBreathingPhase === "exhale"
                                ? 0.8
                                : 0.8
                          : 1.0,
                        opacity: onCallBreathingActive
                          ? onCallBreathingPhase === "inhale"
                            ? 0.7
                            : onCallBreathingPhase === "hold1"
                              ? 0.9
                              : onCallBreathingPhase === "exhale"
                                ? 0.4
                                : 0.3
                          : 0.2
                      }}
                      transition={{ duration: 4, ease: "easeInOut" }}
                      className={`absolute rounded-full flex flex-col items-center justify-center transition-all ${
                        onCallBreathingActive
                          ? onCallBreathingPhase === "inhale"
                            ? "w-36 h-36 bg-teal-500/15 border border-teal-500/30 shadow-[0_0_20px_rgba(20,184,166,0.1)]"
                            : onCallBreathingPhase === "hold1"
                              ? "w-36 h-36 bg-amber-500/20 border border-amber-500/40 shadow-[0_0_30px_rgba(245,158,11,0.2)]"
                              : onCallBreathingPhase === "exhale"
                                ? "w-36 h-36 bg-indigo-500/15 border border-indigo-500/30 shadow-[0_0_20px_rgba(99,102,241,0.1)]"
                                : "w-36 h-36 bg-slate-500/10 border border-slate-500/20 shadow-none"
                          : "w-36 h-36 bg-slate-500/10 border border-slate-500/20"
                      }`}
                    />
                  </AnimatePresence>

                  {/* Static Core Text */}
                  <div className="z-10 flex flex-col items-center justify-center text-center space-y-1">
                    <span className="text-[10px] font-extrabold uppercase tracking-widest text-slate-500">
                      {onCallBreathingActive ? "Phase:" : "Decompress"}
                    </span>
                    <span className={`text-base font-extrabold uppercase tracking-tight ${
                      onCallBreathingActive
                        ? onCallBreathingPhase === "inhale"
                          ? "text-teal-400"
                          : onCallBreathingPhase === "hold1"
                            ? "text-amber-400 animate-pulse"
                            : onCallBreathingPhase === "exhale"
                              ? "text-indigo-400"
                              : "text-slate-400"
                        : "text-slate-400"
                    }`}>
                      {onCallBreathingActive ? onCallBreathingPhase : "Ready"}
                    </span>
                    <div className="text-2xl font-black font-mono text-slate-100">
                      {onCallBreathingActive ? `${onCallBreathingSecondsLeft}s` : "4s"}
                    </div>
                    {onCallBreathingActive && (
                      <span className="text-[9px] font-bold uppercase tracking-wider text-teal-500/70">
                        Cycle {onCallBreathingCycleCount + 1}
                      </span>
                    )}
                  </div>
                </div>

                {/* Start / Stop Button */}
                <div className="flex flex-col sm:flex-row items-center gap-3">
                  <button
                    onClick={() => {
                      setOnCallBreathingActive(!onCallBreathingActive);
                    }}
                    className={`px-6 py-2.5 rounded-xl text-xs font-bold uppercase border transition-all cursor-pointer shadow-md ${
                      onCallBreathingActive
                        ? "bg-rose-500/10 border-rose-500/20 text-rose-400 hover:bg-rose-500/20"
                        : "bg-teal-500 text-slate-950 border-teal-400 hover:bg-teal-400 font-extrabold"
                    }`}
                  >
                    {onCallBreathingActive ? "Stop Exercise" : "Start Box Breathing"}
                  </button>

                  <button
                    onClick={() => {
                      playCalmingSound();
                    }}
                    className={`px-4 py-2.5 rounded-xl text-xs font-bold uppercase transition-all flex items-center justify-center gap-1.5 border cursor-pointer ${
                      isDarkMode 
                        ? "bg-slate-900 border-slate-800 text-slate-300 hover:bg-slate-800" 
                        : "bg-white border-slate-200 text-slate-700 hover:bg-slate-50 shadow-sm"
                    }`}
                  >
                    <Volume2 className="w-3.5 h-3.5" />
                    Play Ambient Pad
                  </button>
                </div>

                {/* Calming Messages & Resources */}
                <div className="max-w-md p-5 rounded-2xl bg-teal-500/5 border border-teal-500/10 text-center space-y-3">
                  <Sparkles className="w-5 h-5 text-teal-400 mx-auto animate-pulse" />
                  <p className={`text-xs ${isDarkMode ? "text-teal-300/90" : "text-teal-800/90"} italic font-medium leading-relaxed animate-fade-in`}>
                    {onCallBreathingPhase === "inhale" && '"Inhale deep, slow breaths. Oxygenate your cortical cells to maintain focus under pressure."'}
                    {onCallBreathingPhase === "hold1" && '"Hold. Let the oxygen distribute. Release the physical muscle tension in your shoulders."'}
                    {onCallBreathingPhase === "exhale" && '"Exhale slowly. Release the lactic anxiety, the clinical pressure, and the sleep-deprived noise."'}
                    {onCallBreathingPhase === "hold2" && '"Hold. Empty and still. You are competent, you are prepared, and your clinical instincts are solid."'}
                  </p>
                  
                  <div className="pt-3 border-t border-teal-500/20 space-y-2">
                    <p className={`text-[10px] uppercase font-extrabold tracking-wider ${isDarkMode ? "text-slate-500" : "text-slate-500"}`}>
                      Clinician Distress Resources
                    </p>
                    <div className="flex flex-col sm:flex-row justify-center gap-2">
                      <a
                        href="tel:0340411140"
                        className={`text-[10px] px-3 py-1 rounded-full border flex items-center justify-center gap-1 font-bold ${
                          isDarkMode ? "bg-slate-950 border-teal-900/40 text-teal-400 hover:bg-slate-900" : "bg-white border-teal-100 text-teal-700 hover:bg-teal-50 shadow-sm"
                        }`}
                      >
                        📞 MMA HelpDoc Hotline (03-40411140)
                      </a>
                      <a
                        href="tel:0376272929"
                        className={`text-[10px] px-3 py-1 rounded-full border flex items-center justify-center gap-1 font-bold ${
                          isDarkMode ? "bg-slate-950 border-teal-900/40 text-teal-400 hover:bg-slate-900" : "bg-white border-teal-100 text-teal-700 hover:bg-teal-50 shadow-sm"
                        }`}
                      >
                        📞 Befrienders KL (03-76272929)
                      </a>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        {/* TAB 1: LABS REFERENCE SECTION */}
        {activeTab === "labs" && (
          <div>
            {labsSubTab === "database" ? (
              <div>
                {/* Labs Reference Grid */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {getFilteredLabs().map((lab, i) => {
                    const tubeConfig = getTubeCapColor(lab.container);
                    const isUrgent = lab.ltat.toLowerCase().includes("hour") || lab.ltat.toLowerCase().includes("min");
                    const hasIce = lab.remark.toLowerCase().includes("ice") || lab.container.toLowerCase().includes("ice") || lab.test.toLowerCase().includes("ice");

                    return (
                      <motion.div 
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: Math.min(i * 0.03, 0.4) }}
                        key={`${lab.test}-${lab.lab}-${i}`}
                        className={`p-5 rounded-xl border flex flex-col justify-between transition-all ${
                          isDarkMode ? "bg-[#111827] border-slate-800 hover:border-slate-700" : "bg-white border-slate-200 hover:border-slate-300 shadow-sm"
                        }`}
                      >
                        <div>
                          {/* Title & Lab Department */}
                          <div className="flex justify-between items-start gap-4 mb-3">
                            <div>
                              <h3 className={`font-bold text-base tracking-tight ${isDarkMode ? 'text-teal-400' : 'text-teal-700'}`}>{highlightMatch(lab.test, searchQuery)}</h3>
                              <span className={`text-[10px] uppercase font-mono tracking-wider font-semibold ${isDarkMode ? "text-slate-400" : "text-slate-700"} block mt-0.5`}>
                                {lab.lab}
                              </span>
                            </div>
                            {/* Highlights */}
                            <div className="flex flex-col gap-1 items-end">
                              {isUrgent && (
                                <span className={`text-[9px] px-2 py-0.5 rounded-full bg-rose-500/10 ${isDarkMode ? "text-rose-400" : "text-rose-700"} border border-rose-500/20 font-mono font-semibold uppercase`}>
                                  🚨 Urgent
                                </span>
                              )}
                              {hasIce && (
                                <span className="badge badge-ice bg-sky-950 text-sky-400 text-[10px] px-2 py-0.5 rounded border border-sky-800">❄️ ICE bath</span>
                              )}
                            </div>
                          </div>

                          {/* Specimen and Cap visual */}
                          <div className={`flex items-center gap-3 my-3 p-2 ${isDarkMode ? "bg-slate-500/10" : "bg-slate-100"} rounded-lg`}>
                            <div className={`w-8 h-8 rounded-full ${tubeConfig.bg} ${tubeConfig.border} flex items-center justify-center border-2 shadow-sm`}>
                              <span className="text-[10px] font-bold text-white uppercase">{tubeConfig.label.charAt(0)}</span>
                            </div>
                            <div>
                              <span className="text-xs font-semibold block">{highlightMatch(lab.container, searchQuery)}</span>
                              <span className={`text-[10px] ${isDarkMode ? "text-slate-400" : "text-slate-700"}`}>Specimen: <strong className={`${isDarkMode ? "text-slate-300" : "text-slate-800"}`}>{highlightMatch(lab.specimen, searchQuery)}</strong> ({lab.volume})</span>
                            </div>
                          </div>

                          {/* Ranges & Reference Parameters */}
                          <div className={`mt-3 p-3 rounded-lg border ${isDarkMode ? "bg-slate-950/20 border-slate-800" : "bg-slate-50 border-slate-200"}`}>
                            <span className={`text-[10px] ${isDarkMode ? "text-slate-400" : "text-slate-700"} font-bold block mb-1`}>Reference Range / Profile limits:</span>
                            <p className={`text-xs ${isDarkMode ? "text-teal-300" : "text-teal-700"} font-mono leading-relaxed`}>{highlightMatch(lab.ranges, searchQuery)}</p>
                          </div>

                          {/* Remark / Guide */}
                          {lab.remark && (
                            <div className={`mt-3 text-xs ${isDarkMode ? "text-slate-300" : "text-slate-800"} flex items-start gap-2`}>
                              <Info className={`w-4 h-4 ${isDarkMode ? "text-slate-400" : "text-slate-700"} flex-shrink-0 mt-0.5`} />
                              <p className="leading-normal"><span className={`font-semibold ${isDarkMode ? "text-slate-400" : "text-slate-700"}`}>Action Remarks: </span>{highlightMatch(lab.remark, searchQuery)}</p>
                            </div>
                          )}
                        </div>

                        <div className={`mt-4 pt-3 border-t border-slate-800/80 flex items-center justify-between text-xs ${isDarkMode ? "text-slate-400" : "text-slate-700"}`}>
                          <span>Lab Turnaround Time:</span>
                          <strong className={isUrgent ? "text-rose-400" : "text-slate-300"}>{lab.ltat}</strong>
                        </div>
                      </motion.div>
                    );
                  })}
                </div>
                {getFilteredLabs().length === 0 && (
                  <div className={`text-center py-12 ${isDarkMode ? "text-slate-400" : "text-slate-700"} font-mono text-sm`}>
                    No matching laboratory references found. Try adjusting filters or search terms.
                  </div>
                )}
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 animate-fade-in">
                {/* Column 1: Dynamic Endocrinology */}
                {getFilteredEndocrine().some(p => p.category === "dynamic") && (
                  <div className={`p-5 rounded-xl border ${
                    isDarkMode ? "bg-[#111827] border-slate-800" : "bg-white border-slate-200"
                  }`}>
                    <div className="flex items-center gap-2 mb-4">
                      <Clock className={`${isDarkMode ? "text-teal-400" : "text-teal-700"} h-5 w-5`} />
                      <h2 className="text-base font-semibold">MOH/MEMS Dynamic Endocrinology</h2>
                    </div>
                    <p className={`text-xs ${isDarkMode ? "text-slate-400" : "text-slate-700"} leading-normal mb-4`}>
                      These tests require strict diagnostic timing and synchronization of samples. Double-check request forms.
                    </p>

                    <div className="space-y-4">
                      {getFilteredEndocrine().filter(p => p.category === "dynamic").map(proto => (
                        <div key={proto.id} className={`p-3 rounded-lg border ${isDarkMode ? "bg-slate-950/20 border-slate-800" : "bg-slate-50 border-slate-200"}`}>
                          <h3 className={`font-bold text-sm ${isDarkMode ? "text-teal-400" : "text-teal-700"} mb-1`}>
                            {highlightMatch(proto.title, searchQuery)}
                          </h3>
                          <div className={`text-xs space-y-1.5 ${isDarkMode ? "text-slate-300" : "text-slate-800"}`}>
                            {proto.timeline && (
                              <p><strong className={`${isDarkMode ? "text-slate-400" : "text-slate-700"}`}>Timeline:</strong> {highlightMatch(proto.timeline, searchQuery)}</p>
                            )}
                            {proto.safety && (
                              <p><strong className="text-rose-500">Safety Cutoffs:</strong> {highlightMatch(proto.safety, searchQuery)}</p>
                            )}
                            {proto.interpretation && (
                              <div>
                                <strong className={`${isDarkMode ? "text-slate-400" : "text-slate-700"}`}>Interpretation:</strong>
                                {Array.isArray(proto.interpretation) ? (
                                  <ul className="list-disc pl-4 space-y-1 text-[11px] mt-1">
                                    {proto.interpretation.map((bullet, bidx) => (
                                      <li key={bidx}>{highlightMatch(bullet, searchQuery)}</li>
                                    ))}
                                  </ul>
                                ) : (
                                  <span className="ml-1">{highlightMatch(proto.interpretation, searchQuery)}</span>
                                )}
                              </div>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Column 2: Pituitary Panel & Biopsies */}
                {(getFilteredEndocrine().some(p => p.category === "pituitary") || getFilteredEndocrine().some(p => p.category === "biopsy")) && (
                  <div className="space-y-6">
                    {/* Anterior Pituitary Hormone Panel */}
                    {getFilteredEndocrine().some(p => p.category === "pituitary") && (
                      <div className={`p-5 rounded-xl border ${
                        isDarkMode ? "bg-[#111827] border-slate-800" : "bg-white border-slate-200"
                      }`}>
                        <div className="flex items-center gap-2 mb-4">
                          <ClipboardList className={`${isDarkMode ? "text-teal-400" : "text-teal-700"} h-5 w-5`} />
                          <h2 className="text-base font-semibold">Anterior Pituitary Hormone Panel</h2>
                        </div>
                        <p className={`text-xs ${isDarkMode ? "text-slate-400" : "text-slate-700"} leading-normal mb-4`}>
                          Baseline panel for assessing anterior pituitary axis integrity (adrenal, thyroid, gonadal, and lactotropic). Critical for investigating suspected pituitary macroadenomas, hypopituitarism, or Sheehan's syndrome. <strong>Draw strictly between 08:00 AM – 09:00 AM (diurnal hormone peaks).</strong>
                        </p>

                        <div className="space-y-3">
                          {getFilteredEndocrine().filter(p => p.category === "pituitary").map(proto => (
                            <div key={proto.id} className={`p-3 rounded-lg border ${isDarkMode ? "bg-slate-950/20 border-slate-800" : "bg-slate-50 border-slate-200"}`}>
                              <div className="flex justify-between items-start sm:items-center gap-2 mb-1.5 flex-wrap">
                                <h3 className={`font-bold text-xs ${isDarkMode ? "text-teal-400" : "text-teal-700"}`}>
                                  {highlightMatch(proto.title, searchQuery)}
                                </h3>
                                {proto.cap && (
                                  <span className={`text-[10px] px-1.5 py-0.5 rounded font-mono ${
                                    proto.cap.includes("Purple")
                                      ? "bg-purple-500/10 text-purple-400 border border-purple-500/20"
                                      : "bg-amber-500/10 text-amber-500 border border-amber-500/20"
                                  }`}>
                                    {highlightMatch(proto.cap, searchQuery)}
                                  </span>
                                )}
                              </div>
                              <div className={`text-xs space-y-1 ${isDarkMode ? "text-slate-300" : "text-slate-800"}`}>
                                {proto.components && (
                                  <p><strong className={`${isDarkMode ? "text-slate-400" : "text-slate-700"}`}>Components:</strong> {highlightMatch(proto.components, searchQuery)}</p>
                                )}
                                {proto.timeline && (
                                  <p><strong className={`${isDarkMode ? "text-slate-400" : "text-slate-700"}`}>Timing:</strong> {highlightMatch(proto.timeline, searchQuery)}</p>
                                )}
                                {proto.critical && (
                                  <p><strong className={`${isDarkMode ? "text-slate-400" : "text-slate-700"}`}>CRITICAL Handling:</strong> {highlightMatch(proto.critical, searchQuery)}</p>
                                )}
                                {proto.interpretation && (
                                  <div>
                                    <strong className={`${isDarkMode ? "text-slate-400" : "text-slate-700"}`}>Interpretation:</strong>
                                    {Array.isArray(proto.interpretation) ? (
                                      <ul className="list-disc pl-4 space-y-0.5 text-[11px] mt-0.5">
                                        {proto.interpretation.map((bullet, bidx) => (
                                          <li key={bidx}>{highlightMatch(bullet, searchQuery)}</li>
                                        ))}
                                      </ul>
                                    ) : (
                                      <span className="ml-1">{highlightMatch(proto.interpretation, searchQuery)}</span>
                                    )}
                                  </div>
                                )}
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Specialty Biopsy Protocols */}
                    {getFilteredEndocrine().some(p => p.category === "biopsy") && (
                      <div className={`p-5 rounded-xl border ${
                        isDarkMode ? "bg-[#111827] border-slate-800" : "bg-white border-slate-200"
                      }`}>
                        <div className="flex items-center gap-2 mb-4">
                          <FileText className={`${isDarkMode ? "text-teal-400" : "text-teal-700"} h-5 w-5`} />
                          <h2 className="text-base font-semibold">Specialty Biopsy Protocols</h2>
                        </div>
                        <p className={`text-xs ${isDarkMode ? "text-slate-400" : "text-slate-700"} leading-normal mb-4`}>
                          Specialized tissue biopsies are highly fragile. Ensure exact preparation parameters are followed to prevent re-taking samples.
                        </p>

                        <div className="space-y-4">
                          {getFilteredEndocrine().filter(p => p.category === "biopsy").map(proto => (
                            <div key={proto.id} className={`p-3 rounded-lg border ${isDarkMode ? "bg-slate-950/20 border-slate-800" : "bg-slate-50 border-slate-200"}`}>
                              <h3 className={`font-bold text-sm ${isDarkMode ? "text-teal-400" : "text-teal-700"} mb-1`}>
                                {highlightMatch(proto.title, searchQuery)}
                              </h3>
                              <div className={`text-xs space-y-1.5 ${isDarkMode ? "text-slate-300" : "text-slate-800"}`}>
                                {proto.preBiopsy && (
                                  <p><strong className={`${isDarkMode ? "text-slate-400" : "text-slate-700"}`}>Pre-Biopsy:</strong> {highlightMatch(proto.preBiopsy, searchQuery)}</p>
                                )}
                                {proto.prep && (
                                  <p><strong className={`${isDarkMode ? "text-slate-400" : "text-slate-700"}`}>Prep:</strong> {highlightMatch(proto.prep, searchQuery)}</p>
                                )}
                                {proto.stability && (
                                  <p><strong className={`${isDarkMode ? "text-slate-400" : "text-slate-700"}`}>Stability:</strong> {highlightMatch(proto.stability, searchQuery)}</p>
                                )}
                                {proto.coresRequired && (
                                  <p><strong className={`${isDarkMode ? "text-slate-400" : "text-slate-700"}`}>Cores Required:</strong> {highlightMatch(proto.coresRequired, searchQuery)}</p>
                                )}
                                {proto.warning && (
                                  <p><strong className="text-rose-500">Warning:</strong> {highlightMatch(proto.warning, searchQuery)}</p>
                                )}
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                )}

                {getFilteredEndocrine().length === 0 && (
                  <div className={`col-span-2 text-center py-12 ${isDarkMode ? "text-slate-400" : "text-slate-700"} font-mono text-sm`}>
                    No matching endocrine protocols or biopsies found. Try adjusting filters or search terms.
                  </div>
                )}
              </div>
            )}
          </div>
        )}

        {/* TAB 2: DRUG SECTION */}
        {activeTab === "drug" && (
          <div>
            {drugSubTab === "dilution" && (
              <div>
                <div className={`p-4 rounded-lg bg-teal-500/5 border border-teal-500/20 ${isDarkMode ? "text-teal-400" : "text-teal-700"} text-xs mb-6 max-w-3xl flex gap-2`}>
                  <Sparkles className="w-4 h-4 flex-shrink-0 mt-0.5 animate-bounce" />
                  <div>
                    <strong>Reduce Bedside Cognitive Error:</strong> Select a drug card to copy pre-formatted, standardized bedside reconstitution & infusion details for electronic logs or immediate clinical orders.
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {getFilteredDilutions().map((item, i) => (
                    <motion.div 
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: Math.min(i * 0.03, 0.4) }}
                      key={`dilution-${item.drug}-${i}`}
                      className={`p-5 rounded-xl border flex flex-col justify-between transition-all ${
                        isDarkMode ? "bg-[#111827] border-slate-800 hover:border-slate-700" : "bg-white border-slate-200 hover:border-slate-300 shadow-sm"
                      }`}
                    >
                      <div>
                        <div className="flex justify-between items-start gap-4 mb-3">
                          <h3 className={`font-bold text-base ${isDarkMode ? "text-teal-400" : "text-teal-700"}`}>{highlightMatch(item.drug, searchQuery)}</h3>
                          <button 
                            onClick={() => handleCopy(`${item.drug} -> Reconstitution: ${item.reconstitution} | Dilution: ${item.dilution} | Infusion: ${item.infusion}`, item.drug)}
                            className={`p-1.5 rounded border text-xs font-semibold flex items-center gap-1 transition-all ${
                              copyFeedback === item.drug 
                                ? "bg-teal-500 border-teal-500 text-slate-950 font-bold" 
                                : isDarkMode 
                                  ? "bg-slate-900 border-slate-800 text-slate-300 hover:bg-slate-800" 
                                  : "bg-slate-100 border-slate-200 text-slate-700 hover:bg-slate-200"
                            }`}
                          >
                            <Copy className="w-3.5 h-3.5" />
                            {copyFeedback === item.drug ? "Copied Order!" : "Copy Order Layout"}
                          </button>
                        </div>

                        <div className="space-y-3 text-xs leading-normal">
                          {/* Reconstitution */}
                          {item.reconstitution && (
                            <div>
                              <strong className={`${isDarkMode ? "text-slate-400" : "text-slate-700"} block text-[10px] uppercase font-bold`}>1. Reconstitution</strong>
                              <p className={`${isDarkMode ? "text-slate-200" : "text-slate-700"}`}>{highlightMatch(item.reconstitution, searchQuery)}</p>
                            </div>
                          )}

                          {/* Dilution */}
                          {item.dilution && (
                            <div>
                              <strong className={`${isDarkMode ? "text-slate-400" : "text-slate-700"} block text-[10px] uppercase font-bold`}>2. Dilution Pathway</strong>
                              <p className={`${isDarkMode ? "text-slate-200" : "text-slate-700"}`}>{highlightMatch(item.dilution, searchQuery)}</p>
                            </div>
                          )}
                        </div>
                      </div>

                      <div className="mt-4 pt-3 border-t border-slate-800/80 flex items-center justify-between text-xs">
                        <span className={`${isDarkMode ? "text-slate-400" : "text-slate-700"} font-bold uppercase text-[9px] tracking-wider font-mono`}>Infusion Parameter:</span>
                        <strong className={`${isDarkMode ? "text-teal-400" : "text-teal-700"}`}>{highlightMatch(item.infusion, searchQuery)}</strong>
                      </div>
                    </motion.div>
                  ))}
                </div>
              </div>
            )}

            {drugSubTab === "renal" && (
              <div>
                {renalCategory === "antibiotic" ? (
                  <>
                    {/* RENAL SUB TAB 1: STABLE WARD */}
                    {renalSubTab === "stable" && (
                      <div className="grid grid-cols-1 gap-4">
                        {getFilteredRenalStable().map((item, i) => (
                          <motion.div 
                            initial={{ opacity: 0, y: 8 }}
                            animate={{ opacity: 1, y: 0 }}
                            transition={{ delay: Math.min(i * 0.02, 0.4) }}
                            key={`renal-stable-${item.drug}-${i}`}
                            className={`p-4 rounded-xl border flex flex-col md:flex-row md:items-start md:justify-between gap-4 transition-all ${
                              isDarkMode ? "bg-[#111827] border-slate-800 hover:border-slate-700" : "bg-white border-slate-200 hover:border-slate-300 shadow-sm"
                            }`}
                          >
                            <div className="md:w-1/4">
                              <h3 className={`font-bold ${isDarkMode ? "text-teal-400" : "text-teal-700"} text-base`}>{highlightMatch(item.drug, searchQuery)}</h3>
                              <span className={`text-[10px] ${isDarkMode ? "text-slate-400" : "text-slate-700"} mt-0.5 block`}>Standard Ward Dose:</span>
                              <span className={`text-xs font-semibold ${isDarkMode ? "text-slate-200" : "text-slate-900"} font-mono block mt-0.5`}>{highlightMatch(item.dose, searchQuery)}</span>
                            </div>

                            <div className={`md:w-3/4 p-3 border ${isDarkMode ? "bg-slate-950/25 border-slate-800/40" : "bg-slate-50 border-slate-200"} rounded-lg`}>
                              {item.cr3050 || item.cr1030 || item.cr10 || item.rrt ? (
                                <>
                                  <div className="flex flex-wrap gap-2 text-xs font-mono mb-2">
                                    {item.cr3050 && renderRenalBadge("CrCl 30-50", item.cr3050)}
                                    {item.cr1030 && renderRenalBadge("CrCl 10-30", item.cr1030)}
                                    {item.cr10 && renderRenalBadge("CrCl <10", item.cr10)}
                                  </div>
                                  {item.rrt && (
                                    <div className="text-xs font-mono">
                                      <span className={`text-[10px] uppercase font-bold ${isDarkMode ? "text-teal-400" : "text-teal-700"} tracking-wider`}>RRT / Dialysis:</span>
                                      <p className={`${isDarkMode ? "text-slate-300" : "text-slate-800"}`} dangerouslySetInnerHTML={{ __html: item.rrt }} />
                                    </div>
                                  )}
                                </>
                              ) : (
                                <>
                                  <span className={`text-[10px] ${isDarkMode ? "text-teal-400" : "text-teal-700"} font-bold uppercase tracking-wider block mb-1`}>Renal Adjustments & Dialysis Clearance:</span>
                                  <p className={`text-xs ${isDarkMode ? "text-slate-200" : "text-slate-800"} leading-normal font-mono whitespace-pre-line`}>{highlightMatch(item.adjustments || "", searchQuery)}</p>
                                </>
                              )}
                            </div>
                          </motion.div>
                        ))}
                        {getFilteredRenalStable().length === 0 && (
                          <div className={`text-center py-12 ${isDarkMode ? "text-slate-400" : "text-slate-700"} font-mono text-sm`}>
                            No matching antibiotics found.
                          </div>
                        )}
                      </div>
                    )}

                    {/* RENAL SUB TAB 2: ICU & RRT */}
                    {renalSubTab === "icu" && (
                      <div className="grid grid-cols-1 gap-4">
                        {getFilteredRenalICU().map((item, i) => (
                          <motion.div 
                            initial={{ opacity: 0, y: 8 }}
                            animate={{ opacity: 1, y: 0 }}
                            transition={{ delay: Math.min(i * 0.02, 0.4) }}
                            key={`renal-icu-${item.drug}-${i}`}
                            className={`p-4 rounded-xl border transition-all ${
                              isDarkMode ? "bg-[#111827] border-slate-800 hover:border-slate-700" : "bg-white border-slate-200 hover:border-slate-300 shadow-sm"
                            }`}
                          >
                            <div className={`flex flex-col md:flex-row md:items-center justify-between gap-4 border-b pb-3 mb-3 ${isDarkMode ? "border-slate-800/60" : "border-slate-100"}`}>
                              <div>
                                <h3 className={`font-bold ${isDarkMode ? "text-teal-400" : "text-teal-700"} text-base`}>{highlightMatch(item.drug, searchQuery)}</h3>
                                <p className={`text-xs ${isDarkMode ? "text-slate-400" : "text-slate-700"} mt-0.5`}>
                                  Standard Loading/Dose: <strong className={`${isDarkMode ? "text-slate-300" : "text-slate-900"} font-mono`}>{highlightMatch(item.dose, searchQuery)}</strong>
                                </p>
                              </div>
                              <div className="flex flex-wrap gap-2 text-xs font-mono">
                                {item.cr3050 && renderRenalBadge("CrCl 30-50", item.cr3050)}
                                {item.cr1030 && renderRenalBadge("CrCl 10-30", item.cr1030)}
                                {item.cr10 && renderRenalBadge("CrCl <10", item.cr10)}
                              </div>
                            </div>

                            <div className={`p-3 border ${isDarkMode ? "bg-slate-950/25 border-slate-800/40" : "bg-slate-50 border-slate-200"} rounded flex gap-2 items-start`}>
                              <Info className={`w-4 h-4 ${isDarkMode ? "text-teal-400" : "text-teal-700"} flex-shrink-0 mt-0.5`} />
                              <div>
                                <span className={`text-[10px] uppercase font-bold ${isDarkMode ? "text-teal-400" : "text-teal-700"} font-mono tracking-wider`}>Continuous Renal Replacement Therapy (RRT / CVVH / CVVHDF) Guidelines:</span>
                                <p className={`text-xs ${isDarkMode ? "text-slate-300" : "text-slate-800"} mt-1 leading-normal font-sans`} dangerouslySetInnerHTML={{ __html: item.rrt }} />
                              </div>
                            </div>
                          </motion.div>
                        ))}
                        {getFilteredRenalICU().length === 0 && (
                          <div className={`text-center py-12 ${isDarkMode ? "text-slate-400" : "text-slate-700"} font-mono text-sm`}>
                            No matching antibiotics found.
                          </div>
                        )}
                      </div>
                    )}
                  </>
                ) : (
                  /* RENAL CATEGORY 2: COMMON MEDS WITH RENAL DOSING */
                  <div className="grid grid-cols-1 gap-4">
                    <div className={`p-4 rounded-xl bg-amber-500/5 border border-amber-500/10 text-xs ${isDarkMode ? "text-amber-400" : "text-amber-700"} leading-relaxed flex items-start gap-2.5 mb-2`}>
                      <Info className="w-4 h-4 flex-shrink-0 mt-0.5" />
                      <div>
                        Always perform clinical cross-checks for high-alert medications.
                      </div>
                    </div>

                    {getFilteredRenalCommon().map((item, i) => (
                      <motion.div 
                        initial={{ opacity: 0, y: 8 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: Math.min(i * 0.02, 0.4) }}
                        key={`renal-common-${item.drug}-${i}`}
                        className={`p-4 rounded-xl border flex flex-col md:flex-row md:items-start md:justify-between gap-4 transition-all ${
                          isDarkMode ? "bg-[#111827] border-slate-800 hover:border-slate-700" : "bg-white border-slate-200 hover:border-slate-300 shadow-sm"
                        }`}
                      >
                        <div className="md:w-1/4">
                          <h3 className={`font-bold ${isDarkMode ? "text-teal-400" : "text-teal-700"} text-base`}>{highlightMatch(item.drug, searchQuery)}</h3>
                          <span className={`text-[10px] ${isDarkMode ? "text-slate-400" : "text-slate-700"} mt-0.5 block`}>Standard Adult Dose:</span>
                          <span className={`text-xs font-semibold ${isDarkMode ? "text-slate-200" : "text-slate-900"} font-mono block mt-0.5`}>{highlightMatch(item.dose, searchQuery)}</span>
                        </div>

                        <div className={`md:w-3/4 p-3 border ${isDarkMode ? "bg-slate-950/25 border-slate-800/40" : "bg-slate-50 border-slate-200"} rounded-lg`}>
                          <div className="flex flex-wrap gap-2 text-xs font-mono mb-2">
                            {item.cr3050 && renderRenalBadge("CrCl 30-50", item.cr3050)}
                            {item.cr1030 && renderRenalBadge("CrCl 10-30", item.cr1030)}
                            {item.cr10 && renderRenalBadge("CrCl <10", item.cr10)}
                          </div>
                          {item.rrt && (
                            <div className="text-xs font-mono">
                              <span className={`text-[10px] uppercase font-bold ${isDarkMode ? "text-teal-400" : "text-teal-700"} tracking-wider`}>RRT / Dialysis Adjustments:</span>
                              <p className={`${isDarkMode ? "text-slate-300" : "text-slate-800"}`} dangerouslySetInnerHTML={{ __html: item.rrt }} />
                            </div>
                          )}
                        </div>
                      </motion.div>
                    ))}
                    {getFilteredRenalCommon().length === 0 && (
                      <div className={`text-center py-12 ${isDarkMode ? "text-slate-400" : "text-slate-700"} font-mono text-sm`}>
                        No matching common drugs found.
                      </div>
                    )}
                  </div>
                )}
              </div>
            )}

            {drugSubTab === "enteral" && (
              <div>
                {/* Protocol Info Header */}
                <div className={`p-4 rounded-xl border mb-6 ${
                  isDarkMode ? "bg-teal-950/10 border-teal-500/20 text-slate-300" : "bg-teal-50 border-teal-100 text-slate-800"
                }`}>
                  <div className="flex gap-3">
                    <div className={`p-2 rounded-lg ${isDarkMode ? "bg-teal-500/10 text-teal-400" : "bg-teal-100 text-teal-700"} flex-shrink-0 self-start`}>
                      <ClipboardList className="w-5 h-5" />
                    </div>
                    <div>
                      <h4 className={`font-bold text-sm mb-1 ${isDarkMode ? "text-teal-400" : "text-teal-800"}`}>
                        Protocol on Drug Administration Via Enteral Feeding Tubes 2022
                      </h4>
                      <p className="text-[11px] sm:text-xs leading-relaxed opacity-90">
                        A simplified, high-yield clinical decision reference focusing on whether standard oral solid forms can be crushed and administered via a <strong>Ryle's / Nasogastric (NG) tube</strong>, with safe alternatives.
                      </p>
                      
                      {/* Standard Safety Directives */}
                      <div className="mt-3 pt-3 border-t border-teal-500/10 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3 text-[10px] sm:text-xs font-medium">
                        <div className="flex items-start gap-1.5">
                          <span className="text-emerald-500">✔</span>
                          <span><strong>Flush Routine:</strong> Flush the feeding tube with 15-30mL of water <strong>before and after</strong> each drug administration.</span>
                        </div>
                        <div className="flex items-start gap-1.5">
                          <span className="text-red-500">❌</span>
                          <span><strong>No Multi-Mixing:</strong> Give each drug separately. NEVER mix multiple crushed drugs together in a single syringe.</span>
                        </div>
                        <div className="flex items-start gap-1.5">
                          <span className="text-amber-500">⚠</span>
                          <span><strong>Held Feeds:</strong> Stop enteral feedings 1-2 hours before and after for <strong>Phenytoin, Ciprofloxacin, and Levothyroxine</strong>.</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Drugs List Grid */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {getFilteredEnteral().map((item, i) => {
                    // Decide status badge styling
                    let statusBg = "";
                    let statusText = "";
                    let statusBorder = "";
                    let statusIcon = "✔";

                    if (item.canCrush === "Yes") {
                      statusBg = isDarkMode ? "bg-emerald-500/10 text-emerald-400 border-emerald-500/20" : "bg-emerald-100 text-emerald-800 border-emerald-200";
                      statusText = "YES - Safe to Crush";
                      statusIcon = "✔";
                      statusBorder = "border-emerald-500/30";
                    } else if (item.canCrush === "No") {
                      statusBg = isDarkMode ? "bg-rose-500/10 text-rose-400 border-rose-500/20" : "bg-rose-100 text-rose-800 border-rose-200";
                      statusText = "DO NOT CRUSH";
                      statusIcon = "❌";
                      statusBorder = "border-rose-500/30";
                    } else {
                      statusBg = isDarkMode ? "bg-amber-500/10 text-amber-400 border-amber-500/20" : "bg-amber-100 text-amber-800 border-amber-200";
                      statusText = "CAUTION";
                      statusIcon = "⚠";
                      statusBorder = "border-amber-500/30";
                    }

                    return (
                      <motion.div 
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: Math.min(i * 0.02, 0.4) }}
                        key={`enteral-${item.drug}-${i}`}
                        className={`p-4 rounded-xl border flex flex-col justify-between transition-all ${
                          isDarkMode ? "bg-[#111827] border-slate-800 hover:border-slate-700" : "bg-white border-slate-200 hover:border-slate-300 shadow-sm"
                        } ${statusBorder}`}
                      >
                        <div>
                          <div className="flex justify-between items-start gap-2 mb-2">
                            <div>
                              <div className="flex items-center gap-1.5 flex-wrap">
                                <h3 className={`font-bold text-base ${isDarkMode ? "text-slate-100" : "text-slate-900"}`}>
                                  {highlightMatch(item.drug, searchQuery)}
                                </h3>
                                <span className={`text-[9px] px-2 py-0.5 rounded-full uppercase font-bold tracking-wider ${
                                  isDarkMode ? "bg-slate-800 text-slate-400" : "bg-slate-100 text-slate-600 border border-slate-200"
                                }`}>
                                  {item.category}
                                </span>
                              </div>
                            </div>
                            <button 
                              onClick={() => handleCopy(`${item.drug} (Ryle's Tube Audit) -> Can Crush: ${item.canCrush} | Instructions: ${item.instructions} ${item.alternative ? `| Alternative: ${item.alternative}` : ""}`, item.drug)}
                              className={`p-1 rounded border text-[10px] font-semibold flex items-center gap-1 transition-all ${
                                copyFeedback === item.drug 
                                  ? "bg-teal-500 border-teal-500 text-slate-950 font-bold" 
                                  : isDarkMode 
                                    ? "bg-slate-900 border-slate-800 text-slate-300 hover:bg-slate-800" 
                                    : "bg-slate-100 border-slate-200 text-slate-700 hover:bg-slate-200"
                              }`}
                            >
                              <Copy className="w-3 h-3" />
                              {copyFeedback === item.drug ? "Copied!" : "Copy Advice"}
                            </button>
                          </div>

                          {/* Can Crush Badge */}
                          <div className="mb-3">
                            <span className={`inline-flex items-center gap-1 text-[10px] sm:text-xs font-bold px-2.5 py-1 rounded-full border ${statusBg}`}>
                              <span>{statusIcon}</span>
                              <span>{statusText}</span>
                            </span>
                          </div>

                          {/* Detail Instructions */}
                          <div className="space-y-2 text-xs leading-relaxed">
                            <div>
                              <strong className={`${isDarkMode ? "text-slate-400" : "text-slate-700"} block text-[10px] uppercase font-bold`}>Preparation & Administration</strong>
                              <p className={`${isDarkMode ? "text-slate-200" : "text-slate-700"}`}>{highlightMatch(item.instructions, searchQuery)}</p>
                            </div>

                            {item.alternative && item.alternative !== "None" && (
                              <div className={`p-2 rounded border ${isDarkMode ? "bg-slate-950/40 border-slate-800/60" : "bg-slate-50 border-slate-200"}`}>
                                <strong className={`${isDarkMode ? "text-teal-400" : "text-teal-700"} block text-[10px] uppercase font-bold`}>Preferred Alternate Pathway</strong>
                                <p className={`text-xs ${isDarkMode ? "text-slate-300" : "text-slate-700"}`}>{highlightMatch(item.alternative, searchQuery)}</p>
                              </div>
                            )}
                          </div>
                        </div>
                      </motion.div>
                    );
                  })}
                </div>

                {getFilteredEnteral().length === 0 && (
                  <div className={`text-center py-12 ${isDarkMode ? "text-slate-400" : "text-slate-700"} font-mono text-sm`}>
                    No matching enteral drug guidelines found. Try searching another drug name.
                  </div>
                )}
              </div>
            )}

            {drugSubTab === "iron" && (
              <div className="space-y-6">
                {/* Protocol Banner */}
                <div className={`p-4 rounded-xl border ${
                  isDarkMode 
                    ? "bg-gradient-to-r from-teal-950/20 via-slate-900 to-slate-900 border-teal-500/20 text-slate-300" 
                    : "bg-gradient-to-r from-teal-500/5 via-teal-50/10 to-white border-teal-500/20 text-slate-700 shadow-sm"
                }`}>
                  <div className="flex gap-3">
                    <div className={`p-2 rounded-lg ${isDarkMode ? "bg-teal-500/10 text-teal-400" : "bg-teal-500/10 text-teal-700"} h-fit`}>
                      <Activity className="w-5 h-5 animate-pulse" />
                    </div>
                    <div>
                      <h2 className={`font-bold text-base ${isDarkMode ? "text-slate-100" : "text-slate-900"}`}>
                        Iron infusion
                      </h2>
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-1 xl:grid-cols-12 gap-6 items-start">
                  {/* Left: Interactive Deficit & Dosing Calculator */}
                  <div className={`xl:col-span-7 p-6 rounded-2xl border ${
                    isDarkMode ? "bg-[#111827] border-slate-800" : "bg-white border-slate-200 shadow-sm"
                  }`}>
                    <div className="flex items-center justify-between mb-4 pb-3 border-b border-slate-800/20">
                      <div className="flex items-center gap-2">
                        <Calculator className="w-5 h-5 text-teal-500" />
                        <h3 className="font-bold text-base">IV Iron Dosing Calculator</h3>
                      </div>
                      <div className="flex gap-1 bg-slate-100 dark:bg-slate-950 p-1 rounded-lg border border-slate-800/20">
                        <button
                          onClick={() => setIronCalculationMethod("ganzoni")}
                          className={`px-3 py-1 rounded text-[10px] font-bold uppercase transition-all ${
                            ironCalculationMethod === "ganzoni"
                              ? "bg-teal-500 text-slate-950 shadow"
                              : "text-slate-500 hover:text-slate-400"
                          }`}
                        >
                          Ganzoni
                        </button>
                        <button
                          onClick={() => {
                            setIronCalculationMethod("simplified");
                            // If currently on a non-table-supported formulation, shift to ferinject
                            if (ironSelectedFormulation === "venofer" || ironSelectedFormulation === "cosmofer") {
                              setIronSelectedFormulation("ferinject");
                            }
                          }}
                          className={`px-3 py-1 rounded text-[10px] font-bold uppercase transition-all ${
                            ironCalculationMethod === "simplified"
                              ? "bg-teal-500 text-slate-950 shadow"
                              : "text-slate-500 hover:text-slate-400"
                          }`}
                        >
                          Simplified
                        </button>
                      </div>
                    </div>

                    {/* Weight & Hb inputs */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-5">
                      <div>
                        <label className={`text-xs block font-semibold mb-1.5 ${isDarkMode ? "text-slate-400" : "text-slate-600"}`}>
                          1. Patient Actual Weight (kg)
                        </label>
                        <div className="relative">
                          <input
                            type="number"
                            value={ironPatientWeight}
                            onChange={(e) => setIronPatientWeight(e.target.value)}
                            placeholder="e.g. 70"
                            className={`w-full p-2.5 rounded-lg border text-sm focus:outline-none focus:ring-2 focus:ring-teal-500/30 ${
                              isDarkMode ? "bg-slate-950 border-slate-800 text-slate-100" : "bg-slate-50 border-slate-200 text-slate-800"
                            }`}
                          />
                          <div className="absolute right-2 top-1.5 flex gap-1">
                            <button
                              onClick={() => setIronPatientWeight(w => Math.max(0, parseFloat(w) - 5).toString())}
                              className={`px-2 py-1 text-xs font-bold rounded ${isDarkMode ? "bg-slate-900 text-slate-400 hover:bg-slate-800" : "bg-slate-100 text-slate-600 hover:bg-slate-200"}`}
                            >
                              -5
                            </button>
                            <button
                              onClick={() => setIronPatientWeight(w => (parseFloat(w || "0") + 5).toString())}
                              className={`px-2 py-1 text-xs font-bold rounded ${isDarkMode ? "bg-slate-900 text-slate-400 hover:bg-slate-800" : "bg-slate-100 text-slate-600 hover:bg-slate-200"}`}
                            >
                              +5
                            </button>
                          </div>
                        </div>
                        <span className="text-[10px] text-slate-500 mt-1 block">
                          Determines target Hb ({parseFloat(ironPatientWeight) < 35 ? "13.0 g/dL" : "15.0 g/dL"}) and iron stores ({parseFloat(ironPatientWeight) < 35 ? "15 mg/kg" : "500 mg"}).
                        </span>
                      </div>

                      <div>
                        <label className={`text-xs block font-semibold mb-1.5 ${isDarkMode ? "text-slate-400" : "text-slate-600"}`}>
                          2. Actual Hemoglobin (g/dL)
                        </label>
                        <div className="relative">
                          <input
                            type="number"
                            step="0.1"
                            value={ironActualHb}
                            onChange={(e) => setIronActualHb(e.target.value)}
                            placeholder="e.g. 9.0"
                            className={`w-full p-2.5 rounded-lg border text-sm focus:outline-none focus:ring-2 focus:ring-teal-500/30 ${
                              isDarkMode ? "bg-slate-950 border-slate-800 text-slate-100" : "bg-slate-50 border-slate-200 text-slate-800"
                            }`}
                          />
                          <div className="absolute right-2 top-1.5 flex gap-1">
                            <button
                              onClick={() => setIronActualHb(h => Math.max(3, parseFloat(h) - 1).toFixed(1))}
                              className={`px-2 py-1 text-xs font-bold rounded ${isDarkMode ? "bg-slate-900 text-slate-400 hover:bg-slate-800" : "bg-slate-100 text-slate-600 hover:bg-slate-200"}`}
                            >
                              -1
                            </button>
                            <button
                              onClick={() => setIronActualHb(h => Math.min(15, parseFloat(h || "0") + 1).toFixed(1))}
                              className={`px-2 py-1 text-xs font-bold rounded ${isDarkMode ? "bg-slate-900 text-slate-400 hover:bg-slate-800" : "bg-slate-100 text-slate-600 hover:bg-slate-200"}`}
                            >
                              +1
                            </button>
                          </div>
                        </div>
                        <span className="text-[10px] text-slate-500 mt-1 block">
                          Current measured lab Hb value.
                        </span>
                      </div>
                    </div>

                    {ironCalculationMethod === "ganzoni" && (
                      <div className={`p-4 rounded-xl border mb-5 ${
                        isDarkMode ? "bg-slate-950 border-slate-800" : "bg-slate-50 border-slate-200"
                      }`}>
                        <div className="flex justify-between items-center mb-2">
                          <span className="text-xs font-bold text-teal-400 uppercase tracking-wider">Ganzoni Parameters (Editable Overrides)</span>
                          <button
                            onClick={() => {
                              setIronTargetHbOverride("");
                              setIronStoresOverride("");
                            }}
                            className="text-[10px] text-rose-400 hover:underline font-bold"
                          >
                            Reset to Defaults
                          </button>
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <label className="text-[10px] block font-semibold text-slate-400 mb-1">Target Hb (g/dL)</label>
                            <input
                              type="number"
                              placeholder={parseFloat(ironPatientWeight) < 35 ? "13 (Auto)" : "15 (Auto)"}
                              value={ironTargetHbOverride}
                              onChange={(e) => setIronTargetHbOverride(e.target.value)}
                              className={`w-full p-2 rounded border text-xs outline-none ${
                                isDarkMode ? "bg-slate-900 border-slate-800 text-slate-100" : "bg-white border-slate-200 text-slate-800"
                              }`}
                            />
                          </div>
                          <div>
                            <label className="text-[10px] block font-semibold text-slate-400 mb-1">Iron Stores (mg)</label>
                            <input
                              type="number"
                              placeholder={parseFloat(ironPatientWeight) < 35 ? `${Math.round(15 * (parseFloat(ironPatientWeight) || 0))} (Auto)` : "500 (Auto)"}
                              value={ironStoresOverride}
                              onChange={(e) => setIronStoresOverride(e.target.value)}
                              className={`w-full p-2 rounded border text-xs outline-none ${
                                isDarkMode ? "bg-slate-900 border-slate-800 text-slate-100" : "bg-white border-slate-200 text-slate-800"
                              }`}
                            />
                          </div>
                        </div>
                      </div>
                    )}

                    {/* Formulation selector */}
                    <div className="mb-5">
                      <label className={`text-xs block font-semibold mb-2 ${isDarkMode ? "text-slate-400" : "text-slate-600"}`}>
                        3. Selected Formulation (HKL Formulary)
                      </label>
                      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                        {[
                          { id: "venofer", name: "Iron Sucrose", brand: "Venofer", strength: "100mg/5mL", allowed: true },
                          { id: "cosmofer", name: "Iron Dextran", brand: "Cosmofer", strength: "100mg/2mL", allowed: true },
                          { id: "ferinject", name: "Ferric Carboxy.", brand: "Ferinject", strength: "500mg/10mL", allowed: true },
                          { id: "monofer", name: "Iron Isomalt.", brand: "Monofer", strength: "100mg/mL", allowed: true }
                        ].map((form) => (
                          <button
                            key={form.id}
                            disabled={!form.allowed}
                            onClick={() => setIronSelectedFormulation(form.id as any)}
                            className={`p-2.5 rounded-xl border text-left transition-all flex flex-col justify-between ${
                              !form.allowed
                                ? "opacity-40 cursor-not-allowed border-slate-900 bg-slate-900/10"
                                : ironSelectedFormulation === form.id
                                  ? isDarkMode
                                    ? "bg-teal-500/10 border-teal-500 text-slate-100 shadow-md shadow-teal-500/5 ring-1 ring-teal-500/30"
                                    : "bg-teal-50/50 border-teal-500 text-teal-950 shadow shadow-teal-500/10"
                                  : isDarkMode
                                    ? "bg-slate-950/40 border-slate-800 text-slate-400 hover:bg-slate-900"
                                    : "bg-white border-slate-200 text-slate-600 hover:bg-slate-50"
                            }`}
                          >
                            <span className="text-[10px] uppercase tracking-wider font-bold opacity-80">{form.brand}</span>
                            <span className="text-xs font-bold leading-tight block truncate mt-0.5">{form.name}</span>
                            <span className="text-[9px] font-mono opacity-60 mt-1">{form.strength}</span>
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* CALCULATION RESULTS DISPLAY */}
                    <div className={`p-5 rounded-2xl border ${
                      isDarkMode ? "bg-slate-950/60 border-slate-800" : "bg-teal-50/20 border-teal-100 shadow-sm"
                    }`}>
                      <div className="flex justify-between items-start gap-4 mb-4">
                        <div>
                          <span className={`text-[10px] font-bold uppercase tracking-widest ${isDarkMode ? "text-slate-500" : "text-slate-400"}`}>
                            Calculated Target Deficit
                          </span>
                          <div className="flex items-baseline gap-1.5 mt-0.5">
                            <h4 className="text-3xl font-extrabold text-teal-400">
                              {ironCalculationMethod === "ganzoni" ? ironResults.ganzoniDeficit : ironResults.simplifiedDose}
                              <span className="text-base font-normal text-slate-400 ml-1">mg</span>
                            </h4>
                          </div>
                        </div>
                        <div className="text-right">
                          <span className="text-[10px] text-slate-500 font-mono block">
                            Method: {ironCalculationMethod === "ganzoni" ? "Ganzoni Deficit" : "Simplified Table"}
                          </span>
                          {ironCalculationMethod === "ganzoni" && (
                            <span className="text-[10px] text-slate-500 font-mono block">
                              Stores: {ironResults.ironStores} mg | Target Hb: {ironResults.targetHb} g/dL
                            </span>
                          )}
                        </div>
                      </div>

                      {/* Formulation breakdown & advice */}
                      {(() => {
                        const doseToGive = ironCalculationMethod === "ganzoni" ? ironResults.ganzoniDeficit : ironResults.simplifiedDose;
                        const weight = parseFloat(ironPatientWeight) || 0;
                        
                        let prepAdvice = "";
                        let infSchedule = "";
                        let safetyCheck = "";
                        let totalVialsAmpoules = 0;
                        let clinicalOrder = "";

                        if (ironSelectedFormulation === "venofer") {
                          totalVialsAmpoules = Math.ceil(doseToGive / 100);
                          prepAdvice = `Total Ampoules Required: ${totalVialsAmpoules} ampoules (each ampoule of Venofer contains 100mg elemental iron in 5mL of water for injection).`;
                          infSchedule = `Since the maximum single dose of Iron Sucrose is 200mg, this patient requires ${Math.ceil(doseToGive / 200)} session(s) of replacement.
• Give 200mg (2 ampoules / 10mL) diluted in maximum 200mL of 0.9% NaCl (Normal Saline). Run over 30 to 60 minutes.
• Sessions should be spaced at least 24-48 hours apart, typically administered 2 to 3 times per week.`;
                          safetyCheck = `⚠️ CRITICAL: Venofer must ONLY be diluted in 0.9% NaCl (Normal Saline). Dilution in dextrose or water will destabilize the drug complex and trigger severe precipitation.`;
                          
                          clinicalOrder = `Patient Weight: ${weight}kg, Actual Hb: ${ironActualHb} g/dL
Parenteral Iron Deficit (Ganzoni): ${doseToGive} mg
Prescription Order: Iron Sucrose (Venofer) ${doseToGive} mg total.
Administration Schedule:
Administer in divided doses of 200 mg (2 ampoules / 10 mL) diluted in 200 mL 0.9% NaCl. 
Infuse over 30-60 minutes per session. Spaced 2-3 times per week. Total sessions required: ${Math.ceil(doseToGive / 200)}.`;
                        } 
                        else if (ironSelectedFormulation === "cosmofer") {
                          totalVialsAmpoules = Math.ceil(doseToGive / 100);
                          const maxTdiLimit = Math.round(weight * 20);
                          const isOverTdiLimit = doseToGive > maxTdiLimit;
                          
                          prepAdvice = `Total Ampoules Required: ${totalVialsAmpoules} ampoules (each ampoule of Cosmofer contains 100mg elemental iron in 2mL).`;
                          infSchedule = `Cosmofer is compatible with Total Dose Infusion (TDI) allowing the complete deficit to be corrected in a single visit if it does not exceed the safety cap of 20 mg/kg (${maxTdiLimit} mg).
• Single Session (TDI): Dilute ${isOverTdiLimit ? maxTdiLimit : doseToGive}mg in 500mL of 0.9% NaCl or 5% Glucose.
• Run first 25mg equivalent (test rate) very slowly over the first 15 minutes. If tolerated without any reaction, run the remaining infusion over 4 to 6 hours.
${isOverTdiLimit ? `• Note: The remaining deficit of ${doseToGive - maxTdiLimit} mg should be corrected in a secondary session at least 1 week later to avoid exceeding the 20 mg/kg safety threshold.` : ""}`;
                          safetyCheck = `⚠️ CRITICAL: Strict vital sign checking is mandatory. Crash cart containing Adrenaline must be on standby at the bedside.`;

                          clinicalOrder = `Patient Weight: ${weight}kg, Actual Hb: ${ironActualHb} g/dL
Parenteral Iron Deficit (Ganzoni): ${doseToGive} mg
Prescription Order: Iron Dextran (Cosmofer) ${isOverTdiLimit ? maxTdiLimit : doseToGive} mg as Total Dose Infusion (TDI).
Administration Schedule:
Dilute in 500 mL of 0.9% NaCl. Run first 25 mg equivalent slowly over 15 minutes as test rate. If uneventful, infuse the remainder over 4-6 hours. Bedside emergency kit on standby.`;
                        } 
                        else if (ironSelectedFormulation === "ferinject") {
                          totalVialsAmpoules = Math.ceil(doseToGive / 500);
                          const isDividedNeeded = doseToGive > 1000;
                          
                          prepAdvice = `Total Vials Required: ${totalVialsAmpoules} vial(s) of 500mg/10mL (each vial contains 500mg elemental iron).`;
                          infSchedule = `Ferric Carboxymaltose allows safe, high-dose administration without a test dose. Max single dose per week is 1000mg.
• Dose ≤ 500mg: Dilute in 100mL 0.9% NaCl and run over at least 6 minutes.
• Dose > 500mg to 1000mg: Dilute in 250mL 0.9% NaCl and run over at least 15 minutes.
${isDividedNeeded ? `• Note: Since the total deficit is ${doseToGive}mg, correct this in 2 weekly sessions (Session 1: 1000mg, Session 2: ${doseToGive - 1000}mg).` : ""}`;
                          safetyCheck = `⚠️ CRITICAL: Hypophosphatemia risk exists with high-dose Ferinject. Ensure renal function is stable and avoid in severe osteomalacia.`;

                          clinicalOrder = `Patient Weight: ${weight}kg, Actual Hb: ${ironActualHb} g/dL
Parenteral Iron Dose: ${doseToGive} mg (${ironCalculationMethod === "ganzoni" ? "Ganzoni" : "Simplified Table"})
Prescription Order: Ferric Carboxymaltose (Ferinject) ${isDividedNeeded ? 1000 : doseToGive} mg.
Administration Schedule:
Dilute in 250 mL of 0.9% NaCl. Infuse over at least 15 minutes.
${isDividedNeeded ? `Remaining ${doseToGive - 1000} mg to be given as a second session 1 week later.` : ""}`;
                        } 
                        else {
                          // Monofer
                          totalVialsAmpoules = Math.ceil(doseToGive / 100);
                          const maxMonoferSingle = Math.round(weight * 20);
                          const isDividedNeeded = doseToGive > maxMonoferSingle;

                          prepAdvice = `Total Vials Required: ${Math.ceil(doseToGive / 1000)} vial(s) of 1000mg/10mL (or ${totalVialsAmpoules} ampoules of 100mg/1mL).`;
                          infSchedule = `Monofer is designed for rapid single-visit high-dose infusion, correcting up to 20 mg/kg (${maxMonoferSingle} mg) in a single session. No test dose required.
• Dose ≤ 1000mg: Dilute in 100mL of 0.9% NaCl, run over 15 minutes.
• Dose > 1000mg: Dilute in 250mL of 0.9% NaCl, run over 30 minutes.
${isDividedNeeded ? `• Note: Since total deficit is ${doseToGive}mg and exceeds the 20 mg/kg threshold of ${maxMonoferSingle}mg, correct via 2 sessions spaced 1 week apart (Session 1: ${maxMonoferSingle}mg, Session 2: ${doseToGive - maxMonoferSingle}mg).` : ""}`;
                          safetyCheck = `⚠️ CRITICAL: Monofer allows total-dose replacement extremely rapidly. Avoid combining with oral iron within 5 days of infusion.`;

                          clinicalOrder = `Patient Weight: ${weight}kg, Actual Hb: ${ironActualHb} g/dL
Parenteral Iron Dose: ${doseToGive} mg (${ironCalculationMethod === "ganzoni" ? "Ganzoni" : "Simplified Table"})
Prescription Order: Iron Isomaltoside (Monofer) ${isDividedNeeded ? maxMonoferSingle : doseToGive} mg.
Administration Schedule:
Dilute in ${doseToGive > 1000 ? "250 mL" : "100 mL"} of 0.9% NaCl. Infuse over ${doseToGive > 1000 ? "30 minutes" : "15 minutes"}.
${isDividedNeeded ? `Remaining ${doseToGive - maxMonoferSingle} mg to be given as a second session 1 week later.` : ""}`;
                        }

                        return (
                          <div className="space-y-4 text-xs leading-relaxed mt-4 pt-4 border-t border-slate-800/20">
                            <div>
                              <strong className="block text-[10px] uppercase font-bold text-teal-400">1. Formulation Specific Breakdown</strong>
                              <p className={`mt-0.5 ${isDarkMode ? "text-slate-200" : "text-slate-700"}`}>{prepAdvice}</p>
                            </div>

                            <div>
                              <strong className="block text-[10px] uppercase font-bold text-teal-400">2. Administration Protocol & Schedule</strong>
                              <div className={`mt-1 p-3 rounded-lg border whitespace-pre-wrap ${isDarkMode ? "bg-slate-900 border-slate-800/80 text-slate-300" : "bg-white border-slate-200 text-slate-700"}`}>
                                {infSchedule}
                              </div>
                            </div>

                            <div className="text-[11px] font-semibold text-rose-400">
                              {safetyCheck}
                            </div>

                            <div className="pt-2 flex justify-end">
                              <button
                                onClick={() => handleCopy(clinicalOrder, "iron_copy")}
                                className={`px-4 py-2 rounded-lg text-xs font-bold uppercase transition-all flex items-center gap-1.5 cursor-pointer ${
                                  copyFeedback === "iron_copy"
                                    ? "bg-teal-500 text-slate-950 shadow shadow-teal-500/10 font-bold"
                                    : isDarkMode
                                      ? "bg-slate-900 hover:bg-slate-800 text-teal-400 border border-slate-800"
                                      : "bg-teal-50 hover:bg-teal-100 text-teal-700 border border-teal-100"
                                }`}
                              >
                                <Copy className="w-3.5 h-3.5" />
                                {copyFeedback === "iron_copy" ? "Copied Order!" : "Copy Ward Prescription Order"}
                              </button>
                            </div>
                          </div>
                        );
                      })()}
                    </div>
                  </div>

                  {/* Right: Protocol Reference & Bedside Safety Guide */}
                  <div className="xl:col-span-5 space-y-6">
                    {/* Simplified Dosing Grid Reference */}
                    <div className={`p-5 rounded-2xl border ${
                      isDarkMode ? "bg-[#111827] border-slate-800" : "bg-white border-slate-200 shadow-sm"
                    }`}>
                      <h3 className="font-bold text-sm mb-3 text-teal-400 flex items-center gap-1.5">
                        <Info className="w-4 h-4 text-teal-500" />
                        Simplified Dosing Reference (MOH)
                      </h3>
                      <p className={`text-[11px] ${isDarkMode ? "text-slate-400" : "text-slate-600"} mb-3`}>
                        Used for high-dose formulations (Ferinject/Monofer) to bypass the complex Ganzoni calculation:
                      </p>
                      <div className="overflow-x-auto">
                        <table className="w-full text-left text-[11px] border-collapse">
                          <thead>
                            <tr className={`border-b ${isDarkMode ? "border-slate-800" : "border-slate-200"}`}>
                              <th className="py-1.5 font-bold">Hb Level</th>
                              <th className="py-1.5 font-bold">Wt &lt; 50 kg</th>
                              <th className="py-1.5 font-bold">Wt 50 to &lt; 70 kg</th>
                              <th className="py-1.5 font-bold">Wt &ge; 70 kg</th>
                            </tr>
                          </thead>
                          <tbody>
                            <tr className={`border-b ${isDarkMode ? "border-slate-800/40" : "border-slate-100"}`}>
                              <td className="py-2 font-mono text-rose-400 font-bold">&lt; 10 g/dL</td>
                              <td className="py-2">1000 mg</td>
                              <td className="py-2 font-bold">1500 mg</td>
                              <td className="py-2 font-bold">2000 mg</td>
                            </tr>
                            <tr>
                              <td className="py-2 font-mono text-teal-400 font-semibold">&ge; 10 g/dL</td>
                              <td className="py-2">500 mg</td>
                              <td className="py-2">1000 mg</td>
                              <td className="py-2">1500 mg</td>
                            </tr>
                          </tbody>
                        </table>
                      </div>
                      <span className={`text-[9px] ${isDarkMode ? "text-slate-500" : "text-slate-400"} mt-2 block italic`}>
                        Note: For weight &lt; 35 kg, Ganzoni formula is mandatory (maximum dose 15 mg/kg).
                      </span>
                    </div>

                    {/* Criteria, Indications and Contraindications */}
                    <div className={`p-5 rounded-2xl border ${
                      isDarkMode ? "bg-[#111827] border-slate-800" : "bg-white border-slate-200 shadow-sm"
                    }`}>
                      <h3 className="font-bold text-sm mb-3 text-teal-400 flex items-center gap-1.5">
                        <CheckCircle2 className="w-4 h-4 text-teal-500" />
                        Indications & Criteria for IV Iron
                      </h3>
                      <ul className={`list-disc list-inside text-xs space-y-1.5 ${isDarkMode ? "text-slate-300" : "text-slate-700"}`}>
                        <li>Failure, intolerance, or non-compliance with oral iron therapy.</li>
                        <li>Anemia in pregnancy (2nd & 3rd trimester) with Hb &lt; 9.0 g/dL.</li>
                        <li>Chronic Kidney Disease (CKD) patients on erythropoietin therapy.</li>
                        <li>Active Inflammatory Bowel Disease (IBD) with iron deficiency.</li>
                        <li>Severe, symptomatic iron deficiency requiring rapid correction.</li>
                      </ul>

                      <h3 className="font-bold text-sm mt-5 mb-3 text-rose-400 flex items-center gap-1.5">
                        <X className="w-4 h-4 text-rose-500" />
                        Absolute Contraindications
                      </h3>
                      <ul className={`list-disc list-inside text-xs space-y-1.5 ${isDarkMode ? "text-slate-300" : "text-slate-700"}`}>
                        <li>First trimester of pregnancy (safety is not established).</li>
                        <li>Active, systemic bacteremia or acute infection (iron fuels pathogen growth).</li>
                        <li>Known hypersensitivity or history of anaphylaxis to IV iron.</li>
                        <li>Iron overload (hemochromatosis, hemosiderosis) or chronic hemolysis.</li>
                      </ul>
                    </div>

                    {/* Safety Reaction Protocol */}
                    <div className={`p-5 rounded-2xl border ${
                      isDarkMode ? "bg-[#111827] border-slate-800" : "bg-white border-slate-200 shadow-sm"
                    }`}>
                      <h3 className="font-bold text-sm mb-3 text-rose-500 flex items-center gap-1.5">
                        <AlertTriangle className="w-4 h-4 text-rose-500 animate-pulse" />
                        Reaction Protocol: Fishbane vs. Anaphylaxis
                      </h3>
                      <p className={`text-xs ${isDarkMode ? "text-slate-300" : "text-slate-700"} mb-3 leading-relaxed`}>
                        It is crucial to differentiate the benign <strong>Fishbane Reaction</strong> from life-threatening anaphylaxis to prevent unnecessary therapy cessation.
                      </p>
                      
                      <div className="space-y-3 text-[11px]">
                        <div className={`p-2.5 rounded-lg border ${isDarkMode ? "bg-amber-950/20 border-amber-500/20 text-amber-300" : "bg-amber-50/50 border-amber-200 text-amber-950"}`}>
                          <strong className="block uppercase font-bold text-xs">Fishbane Reaction (Mild/Moderate)</strong>
                          <p className="mt-0.5 leading-normal">
                            • Symptoms: Facial flushing, chest pressure, lower back pain, or arthralgia <strong>without</strong> pruritus, hives, wheezing, or hypotension.
                          </p>
                          <p className="mt-1 font-semibold text-[10px]">
                            👉 Action: STOP infusion immediately. Reassure patient. Wait 15 minutes. If symptoms completely resolve, restart infusion at HALF of the previous speed.
                          </p>
                        </div>

                        <div className={`p-2.5 rounded-lg border ${isDarkMode ? "bg-rose-950/20 border-rose-500/20 text-rose-300" : "bg-rose-50/50 border-rose-200 text-rose-950"}`}>
                          <strong className="block uppercase font-bold text-xs">Anaphylaxis (Severe/Life-Threatening)</strong>
                          <p className="mt-0.5 leading-normal">
                            • Symptoms: Generalized urticaria, severe pruritus, bronchospasm / stridor, angioedema, cyanosis, or profound hypotension.
                          </p>
                          <p className="mt-1 font-semibold text-[10px]">
                            👉 Action: STOP infusion. Call for help (Red Alert). Position patient flat with legs elevated. Start high-flow O2. Administer IM Adrenaline 0.5 mg (1:1000) and IV fluids. Do NOT restart infusion.
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        {/* TAB 6: EM DRUG DILUTION GUIDELINES */}
        {activeTab === "resus" && resusSubTab === "em_drugs" && (
          <div>
            <div className={`p-4 rounded-lg bg-emerald-500/5 border border-emerald-500/20 ${isDarkMode ? "text-emerald-400" : "text-emerald-700"} text-xs mb-6 max-w-3xl flex gap-2`}>
              <AlertTriangle className="w-4 h-4 flex-shrink-0 mt-0.5 animate-pulse" />
              <div>
                <strong>EM Drug Dilution Guidelines Integration:</strong> This library integrates clinical protocols for Emergency Medicine (EM) drug preparation and dilution based on international consensus and MOH guidelines. Click <strong>Copy Preparation Order</strong> to export complete clinical directives.
              </div>
            </div>

            {/* Bedside Emergency Infusion (Drip) Calculator */}
            <div className={`p-5 rounded-xl border mb-6 ${
              isDarkMode ? "bg-[#111827] border-emerald-500/10" : "bg-white border-emerald-200"
            }`}>
              <div className="flex items-center gap-2 mb-3">
                <Calculator className={`${isDarkMode ? "text-emerald-400" : "text-emerald-700"} h-5 w-5`} />
                <h2 className="text-base font-semibold">EM Bedside Drip Rate Calculator</h2>
                <span className={`text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/10 ${isDarkMode ? "text-emerald-400" : "text-emerald-700"} border border-emerald-500/20 font-mono`}>
                  Adaptive
                </span>
              </div>
              <p className={`text-xs ${isDarkMode ? "text-slate-400" : "text-slate-700"} mb-4`}>
                Instantly calculates pump flow rates in <strong>ml/hour</strong> for critical emergency infusions based on EM drug dilution guidelines.
              </p>

              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div>
                  <label className={`text-xs ${isDarkMode ? "text-slate-400" : "text-slate-700"} block mb-1`}>1. Select Emergency Drug</label>
                  <select
                    value={emtsSelectedDrug}
                    onChange={(e) => {
                      const drug = e.target.value as any;
                      setEmtsSelectedDrug(drug);
                      // Set default doses for selected drug
                      if (drug === "noradrenaline" || drug === "adrenaline") setEmtsDose("0.1");
                      else if (drug === "dopamine" || drug === "dobutamine") setEmtsDose("5");
                      else if (drug === "labetalol") setEmtsDose("1");
                    }}
                    className={`w-full p-2.5 rounded border text-xs outline-none ${
                      isDarkMode ? "bg-[#0b0f19] border-slate-800 text-slate-200" : "bg-white border-slate-200 text-slate-900 shadow-sm"
                    }`}
                  >
                    <option value="noradrenaline">Noradrenaline (mcg/kg/min)</option>
                    <option value="adrenaline">Adrenaline (mcg/kg/min)</option>
                    <option value="dopamine">Dopamine (mcg/kg/min)</option>
                    <option value="dobutamine">Dobutamine (mcg/kg/min)</option>
                    <option value="labetalol">Labetalol (mg/minute)</option>
                  </select>
                </div>

                {emtsSelectedDrug !== "labetalol" ? (
                  <div>
                    <label className={`text-xs ${isDarkMode ? "text-slate-400" : "text-slate-700"} block mb-1`}>2. Concentration Strength</label>
                    <select
                      value={emtsStrength}
                      onChange={(e) => setEmtsStrength(e.target.value as any)}
                      className={`w-full p-2.5 rounded border text-xs outline-none ${
                        isDarkMode ? "bg-[#0b0f19] border-slate-800 text-slate-200" : "bg-white border-slate-200 text-slate-900 shadow-sm"
                      }`}
                    >
                      <option value="single">Single Strength</option>
                      <option value="double">Double Strength</option>
                    </select>
                  </div>
                ) : (
                  <div>
                    <label className={`text-xs ${isDarkMode ? "text-slate-400" : "text-slate-700"} block mb-1`}>2. Concentration Strength</label>
                    <div className={`p-2.5 rounded border border-dashed text-xs font-semibold ${
                      isDarkMode ? "bg-[#0b0f19] border-slate-800 text-slate-400" : "bg-slate-100 border-slate-200 text-slate-700"
                    }`}>
                      Standard Dilution (2 mg/ml)
                    </div>
                  </div>
                )}

                {emtsSelectedDrug !== "labetalol" ? (
                  <div>
                    <label className={`text-xs ${isDarkMode ? "text-slate-400" : "text-slate-700"} block mb-1`}>3. Patient Weight (kg)</label>
                    <input
                      type="number"
                      placeholder="e.g. 70"
                      value={emtsWeight}
                      onChange={(e) => setEmtsWeight(e.target.value)}
                      className={`w-full p-2 rounded border text-xs outline-none ${
                        isDarkMode ? "bg-[#0b0f19] border-slate-800 text-slate-200" : "bg-white border-slate-200 text-slate-900 shadow-sm"
                      }`}
                    />
                  </div>
                ) : (
                  <div>
                    <label className={`text-xs ${isDarkMode ? "text-slate-400" : "text-slate-700"} block mb-1`}>3. Patient Weight (kg)</label>
                    <div className={`p-2.5 rounded border border-dashed text-xs font-semibold ${
                      isDarkMode ? "bg-[#0b0f19] border-slate-800 text-slate-400" : "bg-slate-100 border-slate-200 text-slate-700"
                    }`}>
                      N/A (Non-Weight Based)
                    </div>
                  </div>
                )}

                <div>
                  <label className={`text-xs ${isDarkMode ? "text-slate-400" : "text-slate-700"} block mb-1`}>
                    4. Target Dose {emtsSelectedDrug === "labetalol" ? "(mg/min)" : "(mcg/kg/min)"}
                  </label>
                  <input
                    type="number"
                    step="0.01"
                    placeholder={emtsSelectedDrug === "labetalol" ? "e.g. 1.0" : "e.g. 0.1"}
                    value={emtsDose}
                    onChange={(e) => setEmtsDose(e.target.value)}
                    className={`w-full p-2 rounded border text-xs outline-none ${
                      isDarkMode ? "bg-[#0b0f19] border-slate-800 text-slate-200" : "bg-white border-slate-200 text-slate-900 shadow-sm"
                    }`}
                  />
                </div>
              </div>

              {emtsResult && (
                <motion.div 
                  initial={{ opacity: 0, y: 5 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="mt-4 p-4 rounded-lg bg-rose-500/5 border border-rose-500/10 grid grid-cols-1 md:grid-cols-3 gap-4 items-center"
                >
                  <div>
                    <span className={`text-[10px] ${isDarkMode ? "text-slate-400" : "text-slate-700"} uppercase font-bold block`}>1. Preparation & Potency</span>
                    <p className={`text-xs font-semibold ${isDarkMode ? "text-slate-200" : "text-slate-700"} mt-0.5`}>{emtsResult.prepText}</p>
                    <span className={`text-[10px] ${isDarkMode ? "text-slate-400" : "text-slate-700"} mt-1 block`}>Concentration: <strong className={`${isDarkMode ? "text-teal-400" : "text-teal-700"}`}>{emtsResult.concentration} {emtsSelectedDrug === "labetalol" ? "mg/ml" : "mcg/ml"}</strong></span>
                  </div>
                  <div className="p-3 bg-rose-500/10 rounded-lg text-center border border-rose-500/20">
                    <span className={`text-[10px] ${isDarkMode ? "text-rose-400" : "text-rose-700"} uppercase font-bold block`}>Required Pump Rate</span>
                    <strong className="text-2xl text-white font-mono">{emtsResult.mlPerHour} ml/hour</strong>
                  </div>
                  <div>
                    <span className={`text-[10px] ${isDarkMode ? "text-slate-400" : "text-slate-700"} uppercase font-bold block`}>Bedside Ordering Order</span>
                    <button 
                      onClick={() => handleCopy(
                        `Emergency Infusion Order: ${emtsSelectedDrug.toUpperCase()} ${emtsStrength.toUpperCase()} Strength. Dose: ${emtsDose} ${emtsSelectedDrug === "labetalol" ? "mg/min" : "mcg/kg/min"}. Prep: ${emtsResult.prepText}. Run pump at ${emtsResult.mlPerHour} ml/hour.`,
                        "emts_calc"
                      )}
                      className={`w-full mt-1.5 py-1.5 rounded text-xs font-bold transition-all flex items-center justify-center gap-1 ${
                        copyFeedback === "emts_calc" 
                          ? "bg-teal-500 text-slate-950" 
                          : "bg-slate-850 text-slate-200 hover:bg-slate-700"
                      }`}
                    >
                      <Copy className="w-3.5 h-3.5" />
                      {copyFeedback === "emts_calc" ? "Copied Infusion Order!" : "Copy Infusion Order"}
                    </button>
                  </div>
                </motion.div>
              )}
            </div>

            {/* Quick Categories Filter row */}
            <div className="flex flex-wrap gap-2 mb-6">
              {["All", "Resuscitation", "Shock/Inotropes", "Hypertension", "Sedation/Analgesia", "Respiratory/Other"].map((cat) => (
                <button
                  key={cat}
                  onClick={() => setSelectedEMTSCategory(cat)}
                  className={`px-3 py-1.5 rounded-full text-xs font-semibold border transition-all cursor-pointer ${
                    selectedEMTSCategory === cat
                      ? "bg-emerald-500/20 text-emerald-400 border-emerald-500/40"
                      : isDarkMode
                        ? "bg-[#111827] border-slate-800 text-slate-400 hover:bg-slate-800 hover:text-slate-300"
                        : "bg-slate-100 border-slate-200 text-slate-600 hover:bg-slate-200 hover:text-slate-700"
                  }`}
                >
                  {cat === "All" && "📁 All EM Drugs"}
                  {cat === "Resuscitation" && "🚨 Resuscitation"}
                  {cat === "Shock/Inotropes" && "⚡ Shock & Inotropes"}
                  {cat === "Hypertension" && "🩸 Hypertension"}
                  {cat === "Sedation/Analgesia" && "🧠 Sedation & Analgesia"}
                  {cat === "Respiratory/Other" && "🌬️ Respiratory & Antidotes"}
                </button>
              ))}
            </div>

            {/* Drugs List Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {getFilteredEMTS().map((item, i) => (
                <motion.div 
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: Math.min(i * 0.03, 0.4) }}
                  key={`emts-${item.drug}-${i}`}
                  className={`p-5 rounded-xl border flex flex-col justify-between transition-all ${
                    isDarkMode ? "bg-[#111827] border-slate-800 hover:border-slate-700" : "bg-white border-slate-200 hover:border-slate-300 shadow-sm"
                  }`}
                >
                  <div>
                    <div className="flex justify-between items-start gap-4 mb-3">
                      <div>
                        <h3 className={`font-bold text-base ${isDarkMode ? "text-emerald-400" : "text-emerald-700"}`}>{highlightMatch(item.drug, searchQuery)}</h3>
                        <span className={`text-[10px] ${isDarkMode ? "text-slate-400" : "text-slate-700"} uppercase font-bold tracking-wider`}>{item.category}</span>
                      </div>
                      <button 
                        onClick={() => handleCopy(`${item.drug} -> Indications: ${item.indication} | Prep: ${item.preparation} | Bolus: ${item.bolus} | Infusion: ${item.infusion} | Safety Precautions: ${item.precautions}`, item.drug)}
                        className={`p-1.5 rounded border text-xs font-semibold flex items-center gap-1 transition-all ${
                          copyFeedback === item.drug 
                            ? "bg-emerald-500 border-emerald-500 text-slate-950 font-bold" 
                            : isDarkMode 
                              ? "bg-[#0b0f19] border-slate-800 text-slate-300 hover:bg-slate-800" 
                              : "bg-slate-100 border-slate-200 text-slate-700 hover:bg-slate-200"
                        }`}
                      >
                        <Copy className="w-3.5 h-3.5" />
                        {copyFeedback === item.drug ? "Copied Order!" : "Copy Order Layout"}
                      </button>
                    </div>

                    <div className="space-y-3 text-xs leading-normal">
                      <div>
                        <strong className={`${isDarkMode ? "text-slate-400" : "text-slate-700"} block text-[10px] uppercase font-bold`}>Indication</strong>
                        <p className={`${isDarkMode ? "text-slate-200" : "text-slate-700"}`}>{highlightMatch(item.indication, searchQuery)}</p>
                      </div>

                      <div>
                        <strong className={`${isDarkMode ? "text-slate-400" : "text-slate-700"} block text-[10px] uppercase font-bold`}>Preparation & Strengths</strong>
                        <p className={`${isDarkMode ? "text-slate-200" : "text-slate-700"} whitespace-pre-line`}>{highlightMatch(item.preparation, searchQuery)}</p>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div>
                          <strong className={`${isDarkMode ? "text-slate-400" : "text-slate-700"} block text-[10px] uppercase font-bold`}>Bolus Guideline</strong>
                          <p className={`${isDarkMode ? "text-slate-200" : "text-slate-700"} whitespace-pre-line`}>{highlightMatch(item.bolus, searchQuery)}</p>
                        </div>
                        <div>
                          <strong className={`${isDarkMode ? "text-slate-400" : "text-slate-700"} block text-[10px] uppercase font-bold`}>Infusion Guideline</strong>
                          <p className={`${isDarkMode ? "text-slate-200" : "text-slate-700"} whitespace-pre-line`}>{highlightMatch(item.infusion, searchQuery)}</p>
                        </div>
                      </div>

                      <div className="pt-2 border-t border-slate-800/60">
                        <strong className={`${isDarkMode ? "text-emerald-400" : "text-emerald-700"} block text-[10px] uppercase font-bold flex items-center gap-1`}>
                          <AlertTriangle className="w-3.5 h-3.5 text-emerald-500 animate-pulse" /> Bedside Precautions & Warnings
                        </strong>
                        <p className={`${isDarkMode ? "text-slate-300" : "text-slate-800"} mt-0.5`}>{highlightMatch(item.precautions, searchQuery)}</p>
                      </div>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>

            {getFilteredEMTS().length === 0 && (
              <div className={`text-center py-12 ${isDarkMode ? "text-slate-400" : "text-slate-700"} font-mono text-sm`}>
                No matching EM drug dilutions found. Try adjusting filters or search terms.
              </div>
            )}
          </div>
        )}

        {/* TAB 5: TELEPHONE DIRECTORY & REQUISITION FORMS */}
        {activeTab === "directory" && (
          <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
            
            {/* Column: Contacts & Forms */}
            <div className="space-y-6">
              
              {/* Operator Extensions */}
              <div className={`p-4 sm:p-5 rounded-xl border ${
                isDarkMode ? "bg-[#111827] border-slate-800" : "bg-white border-slate-200"
              }`}>
                <div className="flex items-center gap-2 mb-4">
                  <Phone className={`${isDarkMode ? "text-teal-400" : "text-teal-700"} h-5 w-5`} />
                  <h2 className="text-sm sm:text-base font-semibold">Hospital Directory & Lab Contacts</h2>
                </div>
                
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4">
                  {getFilteredDirectory().map((dept, idx) => (
                    <div key={idx} className={`p-2.5 border ${isDarkMode ? "bg-slate-950/20 border-slate-800" : "bg-slate-50 border-slate-200"} rounded-lg`}>
                      <span className={`text-[10px] font-semibold ${isDarkMode ? "text-teal-300" : "text-teal-700"} block mb-2 border-b ${isDarkMode ? "border-slate-800" : "border-slate-200"} pb-1`}>
                        {highlightMatch(dept.dept, searchQuery)}
                      </span>
                      <div className={`space-y-1.5 ${isDarkMode ? "text-slate-300" : "text-slate-800"} text-[10px] font-mono`}>
                        {dept.items.map((item, i) => (
                          <div key={i} className="flex justify-between items-center group">
                            <span className="truncate pr-2">{highlightMatch(item.name, searchQuery)}:</span>
                            <div className="flex gap-1">
                              {item.ext.split(" / ").map((num, nidx) => (
                                <a 
                                  key={nidx}
                                  href={`tel:${num.startsWith("0") ? num : (dept.dept.includes("HKL") || item.name.includes("HKL") ? "0326155555" : "") + (num.length === 4 ? "," + num : num)}`}
                                  className={`px-1 rounded ${isDarkMode ? "text-teal-400 bg-teal-500/5 hover:bg-teal-500/10" : "text-teal-700 bg-teal-50 hover:bg-teal-100"} transition-colors whitespace-nowrap`}
                                >
                                  {highlightMatch(num, searchQuery)}
                                </a>
                              ))}
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  ))}
                  {getFilteredDirectory().length === 0 && (
                    <div className={`col-span-2 text-center py-8 ${isDarkMode ? "text-slate-400" : "text-slate-700"} font-mono text-xs`}>
                      No matching directory contacts found.
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* Right Column: Requisition Forms */}
            <div className={`p-5 rounded-xl border ${
              isDarkMode ? "bg-[#111827] border-slate-800" : "bg-white border-slate-200 shadow-sm"
            }`}>
              <div className="flex items-center gap-2 mb-4">
                <FileText className={`${isDarkMode ? "text-teal-400" : "text-teal-700"} h-5 w-5`} />
                <h2 className="text-base font-semibold">Required Requisition Forms</h2>
              </div>
              <p className={`text-xs ${isDarkMode ? "text-slate-400" : "text-slate-700"} leading-normal mb-4`}>
                Ensure correct forms are used to avoid processing delays.
              </p>

              <div className="space-y-3 text-xs">
                {getFilteredForms().map((form, i) => (
                  <div key={i} className={`p-3 rounded-lg border ${isDarkMode ? "bg-slate-950/20 border-slate-800" : "bg-slate-50 border-slate-200"}`}>
                    <strong className={`block ${isDarkMode ? "text-teal-300" : "text-teal-700"} mb-1`}>
                      {highlightMatch(form.title, searchQuery)}
                    </strong>
                    <span className={`${isDarkMode ? "text-slate-400" : "text-slate-700"} text-[11px] leading-relaxed block`}>
                      {highlightMatch(form.desc, searchQuery)}
                    </span>
                  </div>
                ))}
                {getFilteredForms().length === 0 && (
                  <div className={`text-center py-8 ${isDarkMode ? "text-slate-400" : "text-slate-700"} font-mono text-xs`}>
                    No matching requisition forms found.
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {/* TAB: BEDSIDE PROCEDURES & SAMPLING GUIDE */}
        {activeTab === "ho_guide" && (
          <div className="space-y-6 animate-fade-in">
            {/* Header / Intro */}
            <div className={`p-5 rounded-2xl border ${
              isDarkMode ? "bg-[#111827] border-slate-800" : "bg-white border-slate-200 shadow-sm"
            }`}>
              <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                <div>
                  <h2 className={`text-lg sm:text-xl font-bold font-sans ${isDarkMode ? "text-teal-400" : "text-teal-700"} flex items-center gap-2`}>
                    <ClipboardList className="w-5 h-5" /> Bedside Procedures & Fluid Sampling Guide
                  </h2>
                  <p className={`text-xs mt-1 ${isDarkMode ? "text-slate-400" : "text-slate-500"}`}>
                    Comprehensive ward reference for interactive checklists, bottle-matching rules, concurrent blood requirements, and bedside clinical calculators.
                  </p>
                </div>
                <div className="flex gap-2 flex-wrap">
                  <button
                    onClick={() => setHoChecklist({})}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold uppercase tracking-wider transition-all border ${
                      isDarkMode 
                        ? "bg-[#ef4444]/10 text-rose-400 border-[#ef4444]/20 hover:bg-[#ef4444]/20" 
                        : "bg-rose-50 text-rose-700 border-rose-200 hover:bg-rose-100"
                    }`}
                  >
                    Reset All Checklists
                  </button>
                </div>
              </div>
            </div>

            {/* Protocol Tabs */}
            <div className="flex overflow-x-auto pb-1 scrollbar-none gap-2">
              {[
                { id: "pleural", label: "Pleural Fluid", desc: "Light's Criteria", icon: "🧪" },
                { id: "ascites", label: "Ascitic Fluid", desc: "SAAG Gradient", icon: "💧" },
                { id: "csf", label: "CSF Bedside", desc: "Meningitis Panel", icon: "🧠" },
                { id: "bma", label: "BMA & Trephine", desc: "BMAT & TB Marrow", icon: "🩸" },
                { id: "hemolytic", label: "Hemolytic Anemia", desc: "Hemolysis Workup", icon: "🔍" }
              ].map((sub) => {
                const isActive = hoActiveGuide === sub.id;
                return (
                  <button
                    key={sub.id}
                    onClick={() => setHoActiveGuide(sub.id as any)}
                    className={`flex-shrink-0 flex items-center gap-2.5 p-3 rounded-xl border transition-all text-left w-48 sm:w-52 cursor-pointer ${
                      isActive
                        ? isDarkMode
                          ? "bg-teal-500/10 border-teal-500 ring-1 ring-teal-500/20 shadow-md shadow-teal-500/5 text-teal-400"
                          : "bg-teal-50 border-teal-400 shadow-md shadow-teal-100 text-teal-900"
                        : isDarkMode
                          ? "bg-slate-900/60 border-slate-800/80 hover:bg-slate-800/80 text-slate-400"
                          : "bg-slate-50 border-slate-200 hover:bg-slate-100 text-slate-600"
                    }`}
                  >
                    <span className="text-xl">{sub.icon}</span>
                    <div className="truncate">
                      <div className="text-xs font-bold leading-tight">
                        {sub.label}
                      </div>
                      <div className="text-[10px] text-slate-500 leading-tight">
                        {sub.desc}
                      </div>
                    </div>
                  </button>
                );
              })}
            </div>

            {/* Active Guide Content */}
            <div className="grid grid-cols-1 xl:grid-cols-12 gap-6 items-start">
              
              {/* Left Column: Information, Guides & Calculations (7 cols) */}
              <div className="xl:col-span-7 space-y-6">
                
                {/* 1. PLEURAL FLUID INTERACTIVE GUIDE */}
                {hoActiveGuide === "pleural" && (
                  <div className="space-y-6">
                    {/* Clinical Overview Card */}
                    <div className={`p-4 sm:p-5 rounded-2xl border space-y-3 ${
                      isDarkMode ? "bg-[#111827] border-slate-800" : "bg-white border-slate-200 shadow-sm"
                    }`}>
                      <div className="flex items-center gap-2 text-rose-400 font-bold text-xs sm:text-sm uppercase tracking-wider">
                        <span>💡</span> Clinical Bedside Rule No. 1
                      </div>
                      <h3 className={`font-bold font-sans text-sm sm:text-base ${isDarkMode ? "text-slate-100" : "text-slate-900"}`}>
                        Matching Concurrent Serum Samples Required!
                      </h3>
                      <p className={`text-xs leading-relaxed ${isDarkMode ? "text-slate-300" : "text-slate-600"}`}>
                        When sending pleural fluid chemistry, you <strong className="text-rose-400">MUST</strong> draw matching concurrent blood/serum samples for <strong className="text-teal-400">Glucose, Protein, Albumin, and LDH</strong>. Ratios of fluid-to-serum are calculated to distinguish between **Exudate** and **Transudate** via Light's Criteria.
                      </p>
                      <div className={`p-3 rounded-xl border text-[11px] leading-relaxed ${isDarkMode ? "bg-slate-950/40 border-slate-800" : "bg-slate-50 border-slate-200"}`}>
                        <span className="font-bold text-amber-400 uppercase tracking-wider block mb-1">🧪 Bedside pH Pearl:</span>
                        For accurate pH, sample must be collected anaerobically in a heparinised syringe (pre-flushed like an ABG syringe) and sent on ice <strong className="text-rose-400">immediately</strong> to the lab. Exposed air or prolonged waiting alters the pleural pH.
                      </div>
                    </div>

                    {/* Light's Criteria Interactive Calculator */}
                    <div className={`p-5 rounded-2xl border space-y-4 ${
                      isDarkMode ? "bg-[#111827] border-slate-800" : "bg-white border-slate-200 shadow-sm"
                    }`}>
                      <div className="flex justify-between items-center border-b border-slate-800/60 pb-3">
                        <h3 className={`text-sm sm:text-base font-bold flex items-center gap-2 ${isDarkMode ? "text-teal-400" : "text-teal-700"}`}>
                          <span>🧮</span> Light's Criteria Calculator
                        </h3>
                        <span className="text-[10px] bg-teal-500/10 text-teal-400 font-mono font-bold px-2 py-0.5 rounded border border-teal-500/20">AUTOMATIC CALCULATION</span>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div className="space-y-3">
                          <h4 className={`text-xs font-bold uppercase tracking-wider ${isDarkMode ? "text-slate-400" : "text-slate-600"}`}>Pleural Fluid Chemistry</h4>
                          <div className="space-y-2">
                            <div>
                              <label className="text-[10px] font-bold text-slate-400 block mb-1">Pleural Protein (g/L)</label>
                              <input
                                type="number"
                                placeholder="e.g. 35"
                                value={hoPleuralFluidProtein}
                                onChange={(e) => setHoPleuralFluidProtein(e.target.value)}
                                className={`w-full p-2.5 rounded-xl border text-xs font-mono outline-none ${
                                  isDarkMode ? "bg-slate-900 border-slate-800 text-white" : "bg-slate-50 border-slate-200 text-slate-900"
                                }`}
                              />
                            </div>
                            <div>
                              <label className="text-[10px] font-bold text-slate-400 block mb-1">Pleural LDH (U/L)</label>
                              <input
                                type="number"
                                placeholder="e.g. 240"
                                value={hoPleuralFluidLdh}
                                onChange={(e) => setHoPleuralFluidLdh(e.target.value)}
                                className={`w-full p-2.5 rounded-xl border text-xs font-mono outline-none ${
                                  isDarkMode ? "bg-slate-900 border-slate-800 text-white" : "bg-slate-50 border-slate-200 text-slate-900"
                                }`}
                              />
                            </div>
                          </div>
                        </div>

                        <div className="space-y-3">
                          <h4 className={`text-xs font-bold uppercase tracking-wider ${isDarkMode ? "text-slate-400" : "text-slate-600"}`}>Serum / Blood Chemistry</h4>
                          <div className="space-y-2">
                            <div>
                              <label className="text-[10px] font-bold text-slate-400 block mb-1">Serum Protein (g/L)</label>
                              <input
                                type="number"
                                placeholder="e.g. 64"
                                value={hoSerumProtein}
                                onChange={(e) => setHoSerumProtein(e.target.value)}
                                className={`w-full p-2.5 rounded-xl border text-xs font-mono outline-none ${
                                  isDarkMode ? "bg-slate-900 border-slate-800 text-white" : "bg-slate-50 border-slate-200 text-slate-900"
                                }`}
                              />
                            </div>
                            <div>
                              <label className="text-[10px] font-bold text-slate-400 block mb-1">Serum LDH (U/L)</label>
                              <input
                                type="number"
                                placeholder="e.g. 180"
                                value={hoSerumLdh}
                                onChange={(e) => setHoSerumLdh(e.target.value)}
                                className={`w-full p-2.5 rounded-xl border text-xs font-mono outline-none ${
                                  isDarkMode ? "bg-slate-900 border-slate-800 text-white" : "bg-slate-50 border-slate-200 text-slate-900"
                                }`}
                              />
                            </div>
                          </div>
                        </div>
                      </div>

                      <div className="pt-2">
                        <label className="text-[10px] font-bold text-slate-400 block mb-1">Serum LDH Upper Limit of Normal (U/L)</label>
                        <input
                          type="number"
                          placeholder="e.g. 200"
                          value={hoSerumLdhUpperLimit}
                          onChange={(e) => setHoSerumLdhUpperLimit(e.target.value)}
                          className={`w-28 p-2 rounded-xl border text-xs font-mono outline-none ${
                            isDarkMode ? "bg-slate-900 border-slate-800 text-white" : "bg-slate-50 border-slate-200 text-slate-900"
                          }`}
                        />
                      </div>

                      {/* Result Box */}
                      {(() => {
                        const pfProt = parseFloat(hoPleuralFluidProtein);
                        const sProt = parseFloat(hoSerumProtein);
                        const pfLdh = parseFloat(hoPleuralFluidLdh);
                        const sLdh = parseFloat(hoSerumLdh);
                        const sLdhUln = parseFloat(hoSerumLdhUpperLimit) || 200;

                        if (isNaN(pfProt) || isNaN(sProt) || isNaN(pfLdh) || isNaN(sLdh)) {
                          return (
                            <div className="p-3 text-center text-[11px] text-slate-500 bg-slate-950/20 rounded-xl border border-dashed border-slate-800">
                              Input Pleural and Serum Protein & LDH values to calculate Light's Criteria.
                            </div>
                          );
                        }

                        const protRatio = pfProt / sProt;
                        const ldhRatio = pfLdh / sLdh;
                        const ldhLimit = (2/3) * sLdhUln;
                        const meetsLimit = pfLdh > ldhLimit;

                        const isProtExudate = protRatio > 0.5;
                        const isLdhExudate = ldhRatio > 0.6;
                        const isLimitExudate = meetsLimit;

                        const isExudate = isProtExudate || isLdhExudate || isLimitExudate;

                        return (
                          <div className={`p-4 rounded-xl border ${
                            isExudate 
                              ? isDarkMode ? "bg-rose-950/10 border-rose-500/20" : "bg-rose-50 border-rose-200"
                              : isDarkMode ? "bg-emerald-950/10 border-emerald-500/20" : "bg-emerald-50 border-emerald-200"
                          } space-y-3`}>
                            <div className="flex justify-between items-center">
                              <span className="text-[10px] uppercase font-bold text-slate-500 tracking-wider">Light's Criteria Result:</span>
                              <span className={`text-xs font-extrabold px-3 py-1 rounded-md uppercase ${
                                isExudate 
                                  ? "bg-rose-500/20 text-rose-400 border border-rose-500/30"
                                  : "bg-emerald-500/20 text-emerald-400 border border-emerald-500/30"
                              }`}>
                                {isExudate ? "EXUDATIVE PLEURAL EFFUSION" : "TRANSUDATIVE PLEURAL EFFUSION"}
                              </span>
                            </div>

                            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs font-mono">
                              <div className={`p-2.5 rounded-lg border ${isProtExudate ? "border-rose-500/20 bg-rose-500/5 text-rose-400" : "border-slate-800 bg-slate-950/10 text-slate-400"}`}>
                                <div className="text-[10px] uppercase text-slate-500 font-bold font-sans">Protein Ratio</div>
                                <div className="text-sm font-bold">{protRatio.toFixed(2)}</div>
                                <div className="text-[9px] mt-0.5">{isProtExudate ? "Meets (>0.5) ✓" : "Does not meet (≤0.5)"}</div>
                              </div>
                              <div className={`p-2.5 rounded-lg border ${isLdhExudate ? "border-rose-500/20 bg-rose-500/5 text-rose-400" : "border-slate-800 bg-slate-950/10 text-slate-400"}`}>
                                <div className="text-[10px] uppercase text-slate-500 font-bold font-sans">LDH Ratio</div>
                                <div className="text-sm font-bold">{ldhRatio.toFixed(2)}</div>
                                <div className="text-[9px] mt-0.5">{isLdhExudate ? "Meets (>0.6) ✓" : "Does not meet (≤0.6)"}</div>
                              </div>
                              <div className={`p-2.5 rounded-lg border ${isLimitExudate ? "border-rose-500/20 bg-rose-500/5 text-rose-400" : "border-slate-800 bg-slate-950/10 text-slate-400"}`}>
                                <div className="text-[10px] uppercase text-slate-500 font-bold font-sans">Fluid LDH</div>
                                <div className="text-sm font-bold">{pfLdh.toFixed(0)} <span className="text-[10px] text-slate-500">vs {ldhLimit.toFixed(0)}</span></div>
                                <div className="text-[9px] mt-0.5">{isLimitExudate ? "Meets (>2/3 ULN) ✓" : "Does not meet"}</div>
                              </div>
                            </div>

                            <p className="text-[11px] leading-relaxed text-slate-400">
                              {isExudate ? (
                                <span><strong>Common Exudate Etiology:</strong> Parapneumonic effusion/empyema, malignant effusion, tuberculosis, pulmonary embolism, connective tissue diseases, pancreatitis, drug-induced.</span>
                              ) : (
                                <span><strong>Common Transudate Etiology:</strong> Congestive cardiac failure (CCF), hepatic cirrhosis (hepatic hydrothorax), nephrotic syndrome, severe hypoalbuminemia, peritoneal dialysis, superior vena cava obstruction.</span>
                              )}
                            </p>
                          </div>
                        );
                      })()}
                    </div>
                  </div>
                )}

                {/* 2. ASCITIC FLUID INTERACTIVE GUIDE */}
                {hoActiveGuide === "ascites" && (
                  <div className="space-y-6">
                    {/* Clinical Overview Card */}
                    <div className={`p-4 sm:p-5 rounded-2xl border space-y-3 ${
                      isDarkMode ? "bg-[#111827] border-slate-800" : "bg-white border-slate-200 shadow-sm"
                    }`}>
                      <div className="flex items-center gap-2 text-rose-400 font-bold text-xs sm:text-sm uppercase tracking-wider">
                        <span>💡</span> Clinical Bedside Rule No. 2
                      </div>
                      <h3 className={`font-bold font-sans text-sm sm:text-base ${isDarkMode ? "text-slate-100" : "text-slate-900"}`}>
                        SAAG Gradient & Immediate Inoculation
                      </h3>
                      <p className={`text-xs leading-relaxed ${isDarkMode ? "text-slate-300" : "text-slate-600"}`}>
                        When sending ascitic fluid chemistry, you <strong className="text-rose-400">MUST</strong> draw a matching concurrent blood sample for <strong className="text-teal-400">Serum Albumin</strong>. This allows the calculation of the SAAG gradient.
                      </p>
                      <div className={`p-3 rounded-xl border text-[11px] leading-relaxed ${isDarkMode ? "bg-slate-950/40 border-slate-800" : "bg-slate-50 border-slate-200"}`}>
                        <span className="font-bold text-amber-400 uppercase tracking-wider block mb-1">🦠 Bedside Culture Pearl:</span>
                        For suspected **Spontaneous Bacterial Peritonitis (SBP)**, inoculate the fluid <strong className="text-rose-400">DIRECTLY into blood culture bottles (Aerobic & Anaerobic) at the bedside</strong>. Sending fluid in a sterile container has a significantly lower diagnostic yield due to rapid bactericidal action of cellular elements!
                      </div>
                    </div>

                    {/* SAAG Calculator */}
                    <div className={`p-5 rounded-2xl border space-y-4 ${
                      isDarkMode ? "bg-[#111827] border-slate-800" : "bg-white border-slate-200 shadow-sm"
                    }`}>
                      <div className="flex justify-between items-center border-b border-slate-800/60 pb-3">
                        <h3 className={`text-sm sm:text-base font-bold flex items-center gap-2 ${isDarkMode ? "text-teal-400" : "text-teal-700"}`}>
                          <span>🧮</span> SAAG (Serum-Ascites Albumin Gradient) Calculator
                        </h3>
                        <span className="text-[10px] bg-teal-500/10 text-teal-400 font-mono font-bold px-2 py-0.5 rounded border border-teal-500/20">AUTOMATIC CALCULATION</span>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div>
                          <label className="text-[10px] font-bold text-slate-400 block mb-1">Serum Albumin (g/L)</label>
                          <input
                            type="number"
                            placeholder="e.g. 32"
                            value={hoSerumAlbumin}
                            onChange={(e) => setHoSerumAlbumin(e.target.value)}
                            className={`w-full p-2.5 rounded-xl border text-xs font-mono outline-none ${
                              isDarkMode ? "bg-slate-900 border-slate-800 text-white" : "bg-slate-50 border-slate-200 text-slate-900"
                            }`}
                          />
                        </div>
                        <div>
                          <label className="text-[10px] font-bold text-slate-400 block mb-1">Ascitic Fluid Albumin (g/L)</label>
                          <input
                            type="number"
                            placeholder="e.g. 15"
                            value={hoAscitesAlbumin}
                            onChange={(e) => setHoAscitesAlbumin(e.target.value)}
                            className={`w-full p-2.5 rounded-xl border text-xs font-mono outline-none ${
                              isDarkMode ? "bg-slate-900 border-slate-800 text-white" : "bg-slate-50 border-slate-200 text-slate-900"
                            }`}
                          />
                        </div>
                      </div>

                      {/* SAAG Result */}
                      {(() => {
                        const sAlb = parseFloat(hoSerumAlbumin);
                        const aAlb = parseFloat(hoAscitesAlbumin);

                        if (isNaN(sAlb) || isNaN(aAlb)) {
                          return (
                            <div className="p-3 text-center text-[11px] text-slate-500 bg-slate-950/20 rounded-xl border border-dashed border-slate-800">
                              Input Serum and Ascitic Albumin values to calculate the SAAG.
                            </div>
                          );
                        }

                        const saagVal = sAlb - aAlb;
                        const isHighSaag = saagVal >= 11;

                        return (
                          <div className={`p-4 rounded-xl border ${
                            isHighSaag
                              ? isDarkMode ? "bg-[#b45309]/10 border-[#b45309]/20" : "bg-amber-50 border-amber-200"
                              : isDarkMode ? "bg-rose-950/10 border-rose-500/20" : "bg-rose-50 border-rose-200"
                          } space-y-3`}>
                            <div className="flex justify-between items-center">
                              <span className="text-[10px] uppercase font-bold text-slate-500 tracking-wider font-mono">SAAG Gradient:</span>
                              <span className={`text-xs font-extrabold px-3 py-1 rounded-md uppercase ${
                                isHighSaag
                                  ? "bg-amber-500/20 text-amber-400 border border-amber-500/30"
                                  : "bg-rose-500/20 text-rose-400 border border-rose-500/30"
                              }`}>
                                {isHighSaag ? "HIGH GRADIENT (SAAG ≥ 11 g/L)" : "LOW GRADIENT (SAAG < 11 g/L)"}
                              </span>
                            </div>

                            <div className="text-center p-3 rounded-lg bg-slate-950/40 border border-slate-800 text-sm font-mono text-white">
                              Calculated SAAG = <strong className="text-teal-400 text-base">{saagVal.toFixed(1)}</strong> g/L
                            </div>

                            <p className="text-[11px] leading-relaxed text-slate-400">
                              {isHighSaag ? (
                                <span><strong>High SAAG Differential (Portal Hypertension present - 97% accuracy):</strong> Liver cirrhosis, alcoholic hepatitis, congestive heart failure/cardiac ascites, Budd-Chiari syndrome, portal vein thrombosis, mixed ascites.</span>
                              ) : (
                                <span><strong>Low SAAG Differential (No Portal Hypertension - related to peritoneal pathology):</strong> Peritoneal carcinomatosis, peritoneal tuberculosis, pancreatitis, biliary leak, nephrotic syndrome, serositis (SLE/autoimmune).</span>
                              )}
                            </p>
                          </div>
                        );
                      })()}
                    </div>
                  </div>
                )}

                {/* 3. CSF INTERACTIVE GUIDE */}
                {hoActiveGuide === "csf" && (
                  <div className="space-y-6">
                    {/* Clinical Overview Card */}
                    <div className={`p-4 sm:p-5 rounded-2xl border space-y-3 ${
                      isDarkMode ? "bg-[#111827] border-slate-800" : "bg-white border-slate-200 shadow-sm"
                    }`}>
                      <div className="flex items-center gap-2 text-rose-400 font-bold text-xs sm:text-sm uppercase tracking-wider">
                        <span>💡</span> Clinical Bedside Rule No. 3
                      </div>
                      <h3 className={`font-bold font-sans text-sm sm:text-base ${isDarkMode ? "text-slate-100" : "text-slate-900"}`}>
                        CSF Opening Pressure, Inspection & Serum Glucose
                      </h3>
                      <p className={`text-xs leading-relaxed ${isDarkMode ? "text-slate-300" : "text-slate-600"}`}>
                        Before collecting fluid, ensure you measure the **Opening Pressure** (normal: 80–200 mmH₂O) and visually inspect the sample (e.g. crystal clear, turbid, blood-stained, xanthochromic). Always pair with an immediate <strong className="text-rose-400">Random Blood Sugar (RBS)</strong> or blood glucose.
                      </p>
                      <div className={`p-3 rounded-xl border text-[11px] leading-relaxed ${isDarkMode ? "bg-slate-950/40 border-slate-800" : "bg-slate-50 border-slate-200"}`}>
                        <span className="font-bold text-amber-400 uppercase tracking-wider block mb-1">🧪 Critical Storage Rule:</span>
                        Do <strong className="text-rose-400">NOT</strong> refrigerate CSF samples for culture. Keep them at room temperature or send immediately. Standard bacteria like Neisseria meningitidis are extremely sensitive to cold temperatures and will die!
                      </div>
                    </div>

                    {/* CSF Glucose Ratio Calculator */}
                    <div className={`p-5 rounded-2xl border space-y-4 ${
                      isDarkMode ? "bg-[#111827] border-slate-800" : "bg-white border-slate-200 shadow-sm"
                    }`}>
                      <div className="flex justify-between items-center border-b border-slate-800/60 pb-3">
                        <h3 className={`text-sm sm:text-base font-bold flex items-center gap-2 ${isDarkMode ? "text-teal-400" : "text-teal-700"}`}>
                          <span>🧮</span> CSF/Serum Glucose Ratio Calculator
                        </h3>
                        <span className="text-[10px] bg-teal-500/10 text-teal-400 font-mono font-bold px-2 py-0.5 rounded border border-teal-500/20">AUTOMATIC CALCULATION</span>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div>
                          <label className="text-[10px] font-bold text-slate-400 block mb-1">CSF Glucose (mmol/L)</label>
                          <input
                            type="number"
                            placeholder="e.g. 1.8"
                            value={hoCsfGlucose}
                            onChange={(e) => setHoCsfGlucose(e.target.value)}
                            className={`w-full p-2.5 rounded-xl border text-xs font-mono outline-none ${
                              isDarkMode ? "bg-slate-900 border-slate-800 text-white" : "bg-slate-50 border-slate-200 text-slate-900"
                            }`}
                          />
                        </div>
                        <div>
                          <label className="text-[10px] font-bold text-slate-400 block mb-1">Random Blood Sugar (mmol/L)</label>
                          <input
                            type="number"
                            placeholder="e.g. 6.5"
                            value={hoRandomBloodSugar}
                            onChange={(e) => setHoRandomBloodSugar(e.target.value)}
                            className={`w-full p-2.5 rounded-xl border text-xs font-mono outline-none ${
                              isDarkMode ? "bg-slate-900 border-slate-800 text-white" : "bg-slate-50 border-slate-200 text-slate-900"
                            }`}
                          />
                        </div>
                      </div>

                      {/* CSF Glucose Ratio Result */}
                      {(() => {
                        const csfG = parseFloat(hoCsfGlucose);
                        const rbsVal = parseFloat(hoRandomBloodSugar);

                        if (isNaN(csfG) || isNaN(rbsVal)) {
                          return (
                            <div className="p-3 text-center text-[11px] text-slate-500 bg-slate-950/20 rounded-xl border border-dashed border-slate-800">
                              Input CSF Glucose and RBS values to calculate the ratio.
                            </div>
                          );
                        }

                        const ratio = csfG / rbsVal;
                        const isLowRatio = ratio < 0.4;

                        return (
                          <div className={`p-4 rounded-xl border ${
                            isLowRatio
                              ? isDarkMode ? "bg-rose-950/10 border-rose-500/20" : "bg-rose-50 border-rose-200"
                              : isDarkMode ? "bg-emerald-950/10 border-emerald-500/20" : "bg-emerald-50 border-emerald-200"
                          } space-y-3`}>
                            <div className="flex justify-between items-center">
                              <span className="text-[10px] uppercase font-bold text-slate-500 tracking-wider font-mono">CSF/Serum Ratio:</span>
                              <span className={`text-xs font-extrabold px-3 py-1 rounded-md uppercase ${
                                isLowRatio
                                  ? "bg-rose-500/20 text-rose-400 border border-rose-500/30"
                                  : "bg-emerald-500/20 text-emerald-400 border border-emerald-500/30"
                              }`}>
                                {isLowRatio ? "LOW RATIO (Ratio < 0.4)" : "NORMAL/ELEVATED RATIO"}
                              </span>
                            </div>

                            <div className="text-center p-3 rounded-lg bg-slate-950/40 border border-slate-800 text-sm font-mono text-white">
                              Calculated Ratio = <strong className="text-teal-400 text-base">{ratio.toFixed(2)}</strong>
                            </div>

                            <p className="text-[11px] leading-relaxed text-slate-400">
                              {isLowRatio ? (
                                <span><strong>Significant Glucose Depletion (Typical of Bacterial, Fungal or TB Meningitis):</strong> High cells, high protein (&gt;0.45 g/L), and low glucose indicates consumption of glucose by pathogens or leukocytes. Low ratio + neutrophilic predominance is pathognomonic for Acute Bacterial Meningitis.</span>
                              ) : (
                                <span><strong>Preserved Glucose Level (Typical of Viral Meningitis):</strong> Normal or slightly elevated protein, mononuclear/lymphocytic predominance, and normal CSF/Serum ratio (&gt;0.5) is the classic hallmark of viral meningitis/aseptic meningitis.</span>
                              )}
                            </p>
                          </div>
                        );
                      })()}
                    </div>
                  </div>
                )}

                {/* 4. BMA & TREPHINE GUIDE */}
                {hoActiveGuide === "bma" && (
                  <div className="space-y-6">
                    {/* Clinical Overview Card */}
                    <div className={`p-4 sm:p-5 rounded-2xl border space-y-3 ${
                      isDarkMode ? "bg-[#111827] border-slate-800" : "bg-white border-slate-200 shadow-sm"
                    }`}>
                      <div className="flex items-center gap-2 text-rose-400 font-bold text-xs sm:text-sm uppercase tracking-wider">
                        <span>💡</span> BM Aspirate & Trephine (BMAT) Protocol
                      </div>
                      <h3 className={`font-bold font-sans text-sm sm:text-base ${isDarkMode ? "text-slate-100" : "text-slate-900"}`}>
                        Critical Clinical Bottle Tracker
                      </h3>
                      <p className={`text-xs leading-relaxed ${isDarkMode ? "text-slate-300" : "text-slate-600"}`}>
                        Bone marrow collections are scarce, precious, and painful bedside procedures. Standardize your bottle preparation strictly to prevent missing clinical samples or invalidating the draw.
                      </p>

                      {/* BMA Bottle Inoculation Rules */}
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-[11px] pt-1">
                        <div className={`p-3 rounded-xl border ${isDarkMode ? "bg-slate-950/40 border-slate-800" : "bg-slate-50 border-slate-200"}`}>
                          <strong className="text-rose-400 block mb-1">🍄 Fungal & Acid-Fast Culture:</strong>
                          Inoculate BMA fungal C&S and Mycobacterium tuberculosis cultures in <strong className="text-amber-400">Fungal C&S Bottles (Myco/F Lytic blood culture bottle)</strong>. Never put fungal cultures into standard CSF sterile containers!
                        </div>
                        <div className={`p-3 rounded-xl border ${isDarkMode ? "bg-slate-950/40 border-slate-800" : "bg-slate-50 border-slate-200"}`}>
                          <strong className="text-rose-400 block mb-1">🧪 TB PCR (Marrow):</strong>
                          Unlike TB cultures, TB PCR on bone marrow must be sent in a <strong className="text-violet-400">CSF sterile container / sterile plain bottle</strong>, NOT in the culture bottles.
                        </div>
                      </div>

                      <div className={`p-3 rounded-xl border text-[11px] leading-relaxed ${isDarkMode ? "bg-slate-950/40 border-slate-800" : "bg-slate-50 border-slate-200"}`}>
                        <span className="font-bold text-amber-400 uppercase tracking-wider block mb-1">📞 Trephine TB GeneXpert Approval:</span>
                        For **Trephine TB Gene Xpert**, you <strong className="text-rose-400">must call the IPR (Institute of Respiratory Medicine) Respi team for approval</strong> before sending the specimen!
                      </div>
                    </div>

                    {/* Standard BMAT Workup Package */}
                    <div className={`p-5 rounded-2xl border space-y-4 ${
                      isDarkMode ? "bg-[#111827] border-slate-800" : "bg-white border-slate-200 shadow-sm"
                    }`}>
                      <h3 className={`text-sm sm:text-base font-bold flex items-center gap-2 ${isDarkMode ? "text-teal-400" : "text-teal-700"}`}>
                        <span>🔬</span> Standard Bone Marrow Workup Road Map (BMAT)
                      </h3>
                      <div className="space-y-2.5 text-xs text-left">
                        <div className="flex gap-2.5 items-start">
                          <span className="text-teal-400 font-mono font-bold">1. Blood FBP:</span>
                          <p className={isDarkMode ? "text-slate-300" : "text-slate-700"}>Ensure a matching Full Blood Picture (FBP) is sent alongside BMA to allow immediate clinical correlation by the hematopathologist.</p>
                        </div>
                        <div className="flex gap-2.5 items-start border-t border-slate-800/40 pt-2">
                          <span className="text-teal-400 font-mono font-bold">2. BMA Smear:</span>
                          <p className={isDarkMode ? "text-slate-300" : "text-slate-700"}>Bedside preparation of thin BMA smears on clean glass slides. Must be dry-fixed immediately to preserve cytological morphology.</p>
                        </div>
                        <div className="flex gap-2.5 items-start border-t border-slate-800/40 pt-2">
                          <span className="text-teal-400 font-mono font-bold">3. Molecular:</span>
                          <p className={isDarkMode ? "text-slate-300" : "text-slate-700"}>Molecular studies (e.g. BCR-ABL, JAK2 mutation, CALR). Sent in Purple (EDTA) or Yellow (SST) tube depending on local pathology directions.</p>
                        </div>
                        <div className="flex gap-2.5 items-start border-t border-slate-800/40 pt-2">
                          <span className="text-teal-400 font-mono font-bold">4. Flow Cytometry:</span>
                          <p className={isDarkMode ? "text-slate-300" : "text-slate-700"}>BMA Immunophenotyping (usually sent in EDTA or heparinized tube, kept room temperature, sent rapidly to capture viable leukocytes).</p>
                        </div>
                        <div className="flex gap-2.5 items-start border-t border-slate-800/40 pt-2">
                          <span className="text-teal-400 font-mono font-bold">5. Cytogenetics:</span>
                          <p className={isDarkMode ? "text-slate-300" : "text-slate-700"}>Karyotyping & FISH (BMA cytogenetics must be inoculated directly into specialized **sodium heparin** tube to keep cells alive for chromosome analysis).</p>
                        </div>
                        <div className="flex gap-2.5 items-start border-t border-slate-800/40 pt-2">
                          <span className="text-teal-400 font-mono font-bold">6. Trephine:</span>
                          <p className={isDarkMode ? "text-slate-300" : "text-slate-700"}>Trephine biopsy tissue specimen. Must be placed immediately into **10% Formalin bottle** for histopathology and immunohistochemical staining.</p>
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                {/* 5. HEMOLYTIC ANEMIA CODES */}
                {hoActiveGuide === "hemolytic" && (
                  <div className="space-y-6">
                    {/* Clinical Overview Card */}
                    <div className={`p-4 sm:p-5 rounded-2xl border space-y-3 ${
                      isDarkMode ? "bg-[#111827] border-slate-800" : "bg-white border-slate-200 shadow-sm"
                    }`}>
                      <div className="flex items-center gap-2 text-rose-400 font-bold text-xs sm:text-sm uppercase tracking-wider">
                        <span>💡</span> Suspected Hemolytic Anemia Protocol
                      </div>
                      <h3 className={`font-bold font-sans text-sm sm:text-base ${isDarkMode ? "text-slate-100" : "text-slate-900"}`}>
                        Hemolysis Screen & Blood Film Importance
                      </h3>
                      <p className={`text-xs leading-relaxed ${isDarkMode ? "text-slate-300" : "text-slate-600"}`}>
                        Hemolysis must be suspected when there is a sudden drop in hemoglobin (Hb) paired with jaundice, dark urine, or splenomegaly. Workup must establish both **evidence of hemolysis** (LDH, unconjugated bilirubin, reticulocytes) and **etiology** (Direct/Indirect Coombs, peripheral blood film).
                      </p>
                    </div>

                    {/* Investigation Rationale Map */}
                    <div className={`p-5 rounded-2xl border space-y-4 ${
                      isDarkMode ? "bg-[#111827] border-slate-800" : "bg-white border-slate-200 shadow-sm"
                    }`}>
                      <h3 className={`text-sm sm:text-base font-bold flex items-center gap-2 ${isDarkMode ? "text-teal-400" : "text-teal-700"}`}>
                        <span>🩸</span> Hemolysis Screening Rationale
                      </h3>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                        <div className={`p-3 rounded-xl border ${isDarkMode ? "bg-slate-950/40 border-slate-800" : "bg-slate-50 border-slate-200"}`}>
                          <strong className="text-teal-400 block mb-1">📈 Reticulocyte Count (with FBC):</strong>
                          Evaluates bone marrow erythropoietic response. High reticulocytes indicate hyperactive marrow compensation for RBC destruction.
                        </div>
                        <div className={`p-3 rounded-xl border ${isDarkMode ? "bg-slate-950/40 border-slate-800" : "bg-slate-50 border-slate-200"}`}>
                          <strong className="text-teal-400 block mb-1">🧪 TSB (Direct & Indirect Bilirubin):</strong>
                          RBC rupture spills hemoglobin, which is metabolized into **indirect/unconjugated bilirubin**. High indirect fraction is hallmark!
                        </div>
                        <div className={`p-3 rounded-xl border ${isDarkMode ? "bg-slate-950/40 border-slate-800" : "bg-slate-50 border-slate-200"}`}>
                          <strong className="text-teal-400 block mb-1">⚡ Lactate Dehydrogenase (LDH):</strong>
                          LDH is abundant inside RBCs. Destructive hemolysis triggers marked serum LDH elevations, serving as a reliable severity index.
                        </div>
                        <div className={`p-3 rounded-xl border ${isDarkMode ? "bg-slate-950/40 border-slate-800" : "bg-slate-50 border-slate-200"}`}>
                          <strong className="text-teal-400 block mb-1">🛡️ Coombs Test (Direct & Indirect):</strong>
                          Differentiates immune-mediated hemolytic anemia (e.g., Warm/Cold AIHA, Drug-induced) from microangiopathic or hereditary causes.
                        </div>
                        <div className={`p-3 rounded-xl border ${isDarkMode ? "bg-slate-950/40 border-slate-800" : "bg-slate-50 border-slate-200"}`}>
                          <strong className="text-teal-400 block mb-1">🔍 UFEME (Urobilinogen):</strong>
                          Urinary urobilinogen is increased due to high bilirubin turnover. Hemoglobinuria can occur in intravascular hemolysis.
                        </div>
                        <div className={`p-3 rounded-xl border ${isDarkMode ? "bg-slate-950/40 border-slate-800" : "bg-slate-50 border-slate-200"}`}>
                          <strong className="text-teal-400 block mb-1">🔬 Peripheral Blood Film (PBF):</strong>
                          Crucial! Identifies **Schistocytes** (microangiopathic hemolysis e.g. TTP/HUS/DIC), **Spherocytes** (hereditary or autoimmune), or **Bite cells** (G6PD deficiency).
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                {/* BEDSIDE PROCEDURE NOTE GENERATOR */}
                {hoActiveGuide !== "hemolytic" && (
                  <div className={`p-5 rounded-2xl border space-y-4 ${
                    isDarkMode ? "bg-[#111827] border-slate-800" : "bg-white border-slate-200 shadow-sm"
                  }`}>
                    <div className="flex justify-between items-center border-b border-slate-800/60 pb-3">
                      <h3 className={`text-sm sm:text-base font-bold flex items-center gap-2 ${isDarkMode ? "text-teal-400" : "text-teal-700"}`}>
                        <span>📝</span> Bedside Procedure Note Generator
                      </h3>
                      <span className="text-[10px] bg-teal-500/10 text-teal-400 font-mono font-bold px-2 py-0.5 rounded border border-teal-500/20 flex items-center gap-1">
                        <Zap className="w-2.5 h-2.5" /> BURNOUT SAVER
                      </span>
                    </div>

                    <p className={`text-[11px] ${isDarkMode ? "text-slate-400" : "text-slate-500"}`}>
                      Quickly customize and generate a fully compliant, standardized bedside procedure note for the patient's physical/electronic records. Reduces clerical fatigue.
                    </p>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      {/* Left: Input Fields */}
                      <div className="space-y-3">
                        <div>
                          <label className="text-[10px] font-bold text-slate-400 block mb-1">Operator / Clinician</label>
                          <input
                            type="text"
                            value={procOperator}
                            onChange={(e) => setProcOperator(e.target.value)}
                            className={`w-full p-2 rounded-xl border text-xs outline-none ${
                              isDarkMode ? "bg-slate-900 border-slate-800 text-white" : "bg-slate-50 border-slate-200 text-slate-900"
                            }`}
                            placeholder="e.g. Doctor / Medical Officer"
                          />
                        </div>

                        <div>
                          <label className="text-[10px] font-bold text-slate-400 block mb-1">Indication</label>
                          <input
                            type="text"
                            value={procIndication}
                            onChange={(e) => setProcIndication(e.target.value)}
                            className={`w-full p-2 rounded-xl border text-xs outline-none ${
                              isDarkMode ? "bg-slate-900 border-slate-800 text-white" : "bg-slate-50 border-slate-200 text-slate-900"
                            }`}
                            placeholder="e.g. Diagnostic / Therapeutic"
                          />
                        </div>

                        <div className="grid grid-cols-2 gap-2">
                          <div>
                            <label className="text-[10px] font-bold text-slate-400 block mb-1">Volume Tapped (mL)</label>
                            <input
                              type="text"
                              value={procVolume}
                              onChange={(e) => setProcVolume(e.target.value)}
                              className={`w-full p-2 rounded-xl border text-xs outline-none font-mono ${
                                isDarkMode ? "bg-slate-900 border-slate-800 text-white" : "bg-slate-50 border-slate-200 text-slate-900"
                              }`}
                              placeholder="e.g. 20"
                            />
                          </div>
                          <div>
                            <label className="text-[10px] font-bold text-slate-400 block mb-1">Local Anaesthesia</label>
                            <input
                              type="text"
                              value={procAnaesthesia}
                              onChange={(e) => setProcAnaesthesia(e.target.value)}
                              className={`w-full p-2 rounded-xl border text-xs outline-none ${
                                isDarkMode ? "bg-slate-900 border-slate-800 text-white" : "bg-slate-50 border-slate-200 text-slate-900"
                              }`}
                              placeholder="e.g. 5ml 2% Lignocaine"
                            />
                          </div>
                        </div>
                      </div>

                      {/* Right: Selectors */}
                      <div className="space-y-3">
                        <div>
                          <label className="text-[10px] font-bold text-slate-400 block mb-1">Fluid Appearance</label>
                          <select
                            value={procAppearance}
                            onChange={(e) => setProcAppearance(e.target.value)}
                            className={`w-full p-2 rounded-xl border text-xs outline-none ${
                              isDarkMode ? "bg-slate-900 border-slate-800 text-white" : "bg-slate-50 border-slate-200 text-slate-900"
                            }`}
                          >
                            {hoActiveGuide === "csf" ? (
                              <>
                                <option value="clear and colourless">Clear and Colourless (Normal/Viral)</option>
                                <option value="turbid / purulent">Turbid / Purulent (Bacterial)</option>
                                <option value="xanthochromic">Xanthochromic (Subarachnoid Hemorrhage)</option>
                                <option value="blood-stained">Blood-stained (Traumatic tap/SAH)</option>
                              </>
                            ) : hoActiveGuide === "bma" ? (
                              <>
                                <option value="hemic with marrow fragments">Hemic with marrow fragments</option>
                                <option value="dry tap">Dry tap (Fibrosis/Aplastic)</option>
                                <option value="hypocellular specimen">Hypocellular specimen</option>
                              </>
                            ) : (
                              <>
                                <option value="clear straw-coloured">Clear straw-coloured (Transudate)</option>
                                <option value="turbid yellow">Turbid yellow (Parapneumonic/Exudate/SBP)</option>
                                <option value="blood-stained / hemorrhagic">Blood-stained / Hemorrhagic (Malignancy/Trauma)</option>
                                <option value="milky / chylous">Milky / Chylous (Lymphatic leak)</option>
                                <option value="bile-stained green">Bile-stained green (Perforated bowel)</option>
                              </>
                            )}
                          </select>
                        </div>

                        <div>
                          <label className="text-[10px] font-bold text-slate-400 block mb-1">Complications Encountered</label>
                          <select
                            value={procComplications}
                            onChange={(e) => setProcComplications(e.target.value)}
                            className={`w-full p-2 rounded-xl border text-xs outline-none ${
                              isDarkMode ? "bg-slate-900 border-slate-800 text-white" : "bg-slate-50 border-slate-200 text-slate-900"
                            }`}
                          >
                            <option value="None">None (Uncomplicated)</option>
                            <option value="Minor localized pain">Minor localized pain</option>
                            <option value="Minor oozing (controlled with pressure)">Minor oozing (controlled with pressure)</option>
                            <option value="Dry tap encountered">Dry tap encountered</option>
                            {hoActiveGuide === "csf" && <option value="Mild post-spinal headache anticipated">Mild post-spinal headache anticipated</option>}
                          </select>
                        </div>

                        <div className="flex items-center gap-3 pt-2">
                          <label className="flex items-center gap-2 cursor-pointer select-none">
                            <input
                              type="checkbox"
                              checked={procAseptic}
                              onChange={(e) => setProcAseptic(e.target.checked)}
                              className="accent-teal-500 rounded focus:ring-teal-500"
                            />
                            <span className="text-[10px] font-bold text-slate-400 uppercase">Strict Aseptic Technique</span>
                          </label>
                        </div>
                      </div>
                    </div>

                    {/* LIVE NOTE PREVIEW BOX */}
                    <div className="space-y-1.5 pt-2">
                      <div className="flex justify-between items-center">
                        <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Live Output Note Preview:</label>
                        <span className="text-[9px] text-slate-500">Auto-formatted in standard SOAP layout</span>
                      </div>
                      <div className={`p-4 rounded-xl border font-mono text-[10px] leading-relaxed max-h-[160px] overflow-y-auto whitespace-pre-wrap ${
                        isDarkMode ? "bg-slate-950 border-slate-800 text-slate-300" : "bg-slate-50 border-slate-200 text-slate-700 shadow-inner"
                      }`}>
                        {(() => {
                          const dateStr = new Date().toLocaleDateString("en-GB", {
                            day: "numeric",
                            month: "short",
                            year: "numeric"
                          });
                          const timeStr = new Date().toLocaleTimeString("en-GB", {
                            hour: "2-digit",
                            minute: "2-digit"
                          });

                          let title = "";
                          let technique = "";
                          let details = "";
                          let specimensSent = "";

                          if (hoActiveGuide === "pleural") {
                            title = "BEDSIDE PROCEDURE NOTE: PLEURAL TAP (PARACENTESIS THORACIS)";
                            technique = `Performed under strict aseptic technique. Skin prepped with Chlorhexidine, draped. Local anaesthesia (${procAnaesthesia}) infiltrated down to the parietal pleura.`;
                            details = `Using a cannula, a total volume of ${procVolume} mL of ${procAppearance} fluid was aspirated from the designated safety zone (upper border of the lower rib). Flow was smooth with no sudden distress or dry tap encountered.`;
                            specimensSent = `Samples dispatched immediately in sterile plain containers for Pleural Biochem (Protein, LDH, Amylase, Glucose, pH), FEME (cell count/differential), Gram Stain, Cytology, and Culture & Sensitivity.`;
                          } else if (hoActiveGuide === "ascites") {
                            title = "BEDSIDE PROCEDURE NOTE: ABDOMINAL PARACENTESIS (ASCITIC TAP)";
                            technique = `Performed under strict aseptic technique. Skin prepped with Chlorhexidine, draped. Local anaesthesia (${procAnaesthesia}) was infiltrated in the left lower quadrant (2cm medial, 2cm superior to ASIS, avoiding rectus sheath).`;
                            details = `A total volume of ${procVolume} mL of ${procAppearance} fluid was aspirated smoothly.`;
                            specimensSent = `Fluid inoculated directly into Blood Culture bottles at the bedside (Aerobic/Anaerobic), and sent in sterile plain containers for FEME (cell count & differential), Biochemistry (Albumin, Protein), Gram Stain, and Cytology.`;
                          } else if (hoActiveGuide === "csf") {
                            title = "BEDSIDE PROCEDURE NOTE: LUMBAR PUNCTURE";
                            technique = `Patient positioned in lateral recumbent position with knees flexed and chin to chest. Strict sterile prep & drape maintained. Local anaesthesia (${procAnaesthesia}) infiltrated at L3/L4 interspace.`;
                            details = `A 22G Quincke spinal needle was introduced. Clear CSF obtained. A total of ${procVolume} mL of ${procAppearance} CSF was collected sequentially in sterile tubes.`;
                            specimensSent = `CSF sent for FEME (Appearance, cell count, LAT, Gram, Indian Ink), Biochemistry (Protein & Glucose), Virology PCR, and Culture & Sensitivity.`;
                          } else if (hoActiveGuide === "bma") {
                            title = "BEDSIDE PROCEDURE NOTE: BONE MARROW ASPIRATION & TREPHINE BIOPSY";
                            technique = `Patient in lateral decubitus position. Posterior superior iliac spine (PSIS) identified. Sterile draping and full aseptic prep. Local anaesthesia (${procAnaesthesia}) infiltrated down to the periosteum.`;
                            details = `BMA needle inserted into the marrow space. Aspiration of ${procVolume} mL of marrow blood obtained (marrow particles observed). Trephine biopsy core of 1.5cm obtained successfully and stored in formalin.`;
                            specimensSent = `Smear slides prepared immediately at bedside. Specimens dispatched for cytology/morphology, cytogenetics, flow cytometry, and fungal/TB cultures.`;
                          }

                          return `=============================================
${title}
=============================================
Date: ${dateStr}   Time: ${timeStr}
Operator: ${procOperator}
Indication: ${procIndication}
Aseptic Technique: ${procAseptic ? "YES - Full sterile prep & drape" : "Standard prep"}
Anaesthesia: ${procAnaesthesia}

PROCEDURE DETAILS:
${technique}
${details}

COMPLICATIONS: ${procComplications}
PATIENT STATUS: Stable post-procedure, tolerated procedure well.

SPECIMENS COLLECTED & SENT:
${specimensSent}
=============================================
[Generated via Clinical Bedside Note Tool]`;
                        })()}
                      </div>
                    </div>

                    {/* COPY BUTTON */}
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        const dateStr = new Date().toLocaleDateString("en-GB", {
                          day: "numeric",
                          month: "short",
                          year: "numeric"
                        });
                        const timeStr = new Date().toLocaleTimeString("en-GB", {
                          hour: "2-digit",
                          minute: "2-digit"
                        });

                        let title = "";
                        let technique = "";
                        let details = "";
                        let specimensSent = "";

                        if (hoActiveGuide === "pleural") {
                          title = "BEDSIDE PROCEDURE NOTE: PLEURAL TAP (PARACENTESIS THORACIS)";
                          technique = `Performed under strict aseptic technique. Skin prepped with Chlorhexidine, draped. Local anaesthesia (${procAnaesthesia}) infiltrated down to the parietal pleura.`;
                          details = `Using a cannula, a total volume of ${procVolume} mL of ${procAppearance} fluid was aspirated from the designated safety zone (upper border of the lower rib). Flow was smooth with no sudden distress or dry tap encountered.`;
                          specimensSent = `Samples dispatched immediately in sterile plain containers for Pleural Biochem (Protein, LDH, Amylase, Glucose, pH), FEME (cell count/differential), Gram Stain, Cytology, and Culture & Sensitivity.`;
                        } else if (hoActiveGuide === "ascites") {
                          title = "BEDSIDE PROCEDURE NOTE: ABDOMINAL PARACENTESIS (ASCITIC TAP)";
                          technique = `Performed under strict aseptic technique. Skin prepped with Chlorhexidine, draped. Local anaesthesia (${procAnaesthesia}) was infiltrated in the left lower quadrant (2cm medial, 2cm superior to ASIS, avoiding rectus sheath).`;
                          details = `A total volume of ${procVolume} mL of ${procAppearance} fluid was aspirated smoothly.`;
                          specimensSent = `Fluid inoculated directly into Blood Culture bottles at the bedside (Aerobic/Anaerobic), and sent in sterile plain containers for FEME (cell count & differential), Biochemistry (Albumin, Protein), Gram Stain, and Cytology.`;
                        } else if (hoActiveGuide === "csf") {
                          title = "BEDSIDE PROCEDURE NOTE: LUMBAR PUNCTURE";
                          technique = `Patient positioned in lateral recumbent position with knees flexed and chin to chest. Strict sterile prep & drape maintained. Local anaesthesia (${procAnaesthesia}) infiltrated at L3/L4 interspace.`;
                          details = `A 22G Quincke spinal needle was introduced. Clear CSF obtained. A total of ${procVolume} mL of ${procAppearance} CSF was collected sequentially in sterile tubes.`;
                          specimensSent = `CSF sent for FEME (Appearance, cell count, LAT, Gram, Indian Ink), Biochemistry (Protein & Glucose), Virology PCR, and Culture & Sensitivity.`;
                        } else if (hoActiveGuide === "bma") {
                          title = "BEDSIDE PROCEDURE NOTE: BONE MARROW ASPIRATION & TREPHINE BIOPSY";
                          technique = `Patient in lateral decubitus position. Posterior superior iliac spine (PSIS) identified. Sterile draping and full aseptic prep. Local anaesthesia (${procAnaesthesia}) infiltrated down to the periosteum.`;
                          details = `BMA needle inserted into the marrow space. Aspiration of ${procVolume} mL of marrow blood obtained (marrow particles observed). Trephine biopsy core of 1.5cm obtained successfully and stored in formalin.`;
                          specimensSent = `Smear slides prepared immediately at bedside. Specimens dispatched for cytology/morphology, cytogenetics, flow cytometry, and fungal/TB cultures.`;
                        }

                        const finalNoteText = `=============================================
${title}
=============================================
Date: ${dateStr}   Time: ${timeStr}
Operator: ${procOperator}
Indication: ${procIndication}
Aseptic Technique: ${procAseptic ? "YES - Full sterile prep & drape" : "Standard prep"}
Anaesthesia: ${procAnaesthesia}

PROCEDURE DETAILS:
${technique}
${details}

COMPLICATIONS: ${procComplications}
PATIENT STATUS: Stable post-procedure, tolerated procedure well.

SPECIMENS COLLECTED & SENT:
${specimensSent}
=============================================
[Generated via Clinical Bedside Note Tool]`;

                        handleCopy(finalNoteText, "procedure-note");
                      }}
                      className={`w-full py-2.5 rounded-xl font-bold uppercase text-xs transition-all border flex items-center justify-center gap-2 cursor-pointer ${
                        copyFeedback === "procedure-note"
                          ? "bg-emerald-500/10 text-emerald-400 border-emerald-500/30 font-extrabold"
                          : isDarkMode 
                            ? "bg-teal-500/10 text-teal-400 border-teal-500/30 hover:bg-teal-500/20" 
                            : "bg-teal-50 border-teal-200 text-teal-700 hover:bg-teal-100 shadow-sm"
                      }`}
                    >
                      {copyFeedback === "procedure-note" ? "Procedure Note Copied! ✓" : "Copy Formatted Procedure Note (Save Writing!)"}
                    </button>
                  </div>
                )}

              </div>

              {/* Right Column: Interactive Bedside checklist & Tube Cap Matching Guide (5 cols) */}
              <div className="xl:col-span-5 space-y-6">
                {/* Checklist Panel */}
                <div className={`p-4 sm:p-5 rounded-2xl border ${
                  isDarkMode ? "bg-[#111827] border-slate-800" : "bg-white border-slate-200 shadow-sm"
                }`}>
                  <div className="flex justify-between items-center mb-3">
                    <h3 className="font-bold text-xs sm:text-sm uppercase tracking-wider text-rose-400 flex items-center gap-1.5">
                      <span>📝</span> Ward Checklist & Bottle Guide
                    </h3>
                    <span className="text-[10px] font-mono text-slate-500 font-bold">BEDSIDE TRACKER</span>
                  </div>

                  {/* Checklist progress bar */}
                  {(() => {
                    // Filter checklist items for the active guide
                    const getActiveChecklistItems = () => {
                      if (hoActiveGuide === "pleural") {
                        return [
                          { id: "pf_biochem", test: "Pleural Biochem (Alb, Prot, Glu, LDH, Chol, Amylase, pH)", container: "Sterile Plain Container" },
                          { id: "pf_feme", test: "Pleural Fluid FEME (Cell count/differential)", container: "Sterile Plain Container" },
                          { id: "pf_gram", test: "Pleural Gram Stain", container: "Sterile Plain Container" },
                          { id: "pf_cyt", test: "Pleural Cytology", container: "Sterile Plain Container" },
                          { id: "pf_cs", test: "Pleural Culture & Sensitivity", container: "Sterile Container / Inoculate Directly" },
                          { id: "pf_afb", test: "Pleural AFB (acid-fast bacilli smear)", container: "Sterile Plain Container" },
                          { id: "pf_tbpcr", test: "Pleural TB PCR", container: "Sterile Plain Container" },
                          { id: "pf_mtbcns", test: "Pleural MTB Culture n Sensitivity", container: "Sterile Plain Container" },
                          { id: "pf_tg", test: "Pleural Triglycerides & Cholesterol", container: "SST (Yellow)" },
                          { id: "pf_bloods", test: "SENT BLOODS: Glucose, Protein, Albumin, LDH (for Light's)", container: "SST (Yellow) & Fluoride (Grey)" }
                        ];
                      } else if (hoActiveGuide === "ascites") {
                        return [
                          { id: "as_app", test: "Ascites physical appearance record", container: "Bedside Record" },
                          { id: "as_feme", test: "FEME, cell count & differentials", container: "Sterile Plain Container" },
                          { id: "as_gram", test: "Ascites Gram Stain", container: "Sterile Plain Container" },
                          { id: "as_biochem", test: "Biochemistry (Alb, Prot, LDH, Amylase, TG, Bilirubin)", container: "Sterile Plain Container" },
                          { id: "as_cs", test: "Culture & Sensitivity (direct bottle inoculation)", container: "Blood Culture Bottles" },
                          { id: "as_cyt", test: "Ascites Cytology", container: "Sterile Plain Container" },
                          { id: "as_mtbcns", test: "Ascites MTB Culture & Sensitivity", container: "Sterile Plain Container" },
                          { id: "as_afb", test: "Ascites AFB Smear", container: "Sterile Plain Container" },
                          { id: "as_tbpcr", test: "Ascites TB PCR", container: "Sterile Plain Container" },
                          { id: "as_cea", test: "Ascites CEA marker", container: "SST (Yellow)" },
                          { id: "as_bloods", test: "SENT BLOODS: Serum Albumin (for SAAG)", container: "SST (Yellow)" }
                        ];
                      } else if (hoActiveGuide === "csf") {
                        return [
                          { id: "csf_press", test: "Opening/Closing Pressure, appearance observation", container: "Bedside Record" },
                          { id: "csf_biochem", test: "Biochemistry (Protein & Glucose)", container: "Fluoride (Grey) & Plain Tube" },
                          { id: "csf_feme", test: "FEME (Appearance, cell count, LAT, Gram, Indian Ink)", container: "Plain Container / Tube 1" },
                          { id: "csf_cyt", test: "CSF Cytology", container: "Plain Container" },
                          { id: "csf_cs", test: "CSF Culture and Sensitivity", container: "Plain Container / Tube 2 (Room Temp)" },
                          { id: "csf_mtbcns", test: "CSF MTB Culture and Sensitivity", container: "Plain Container" },
                          { id: "csf_vir", test: "CSF Virology (HSV 1 & 2, VZV)", container: "Plain Container / PCR Tube" },
                          { id: "csf_tbpcr", test: "CSF TB PCR", container: "Plain Container" },
                          { id: "csf_aqp", test: "CSF & Serum Aquaporin-4 (AQP4) Abs", container: "SST (Yellow) & Plain CSF Container" },
                          { id: "csf_ocb", test: "CSF & Serum Oligoclonal Bands (OCB)", container: "SST (Yellow) & Plain CSF Container" },
                          { id: "csf_bacag", test: "CSF Bacterial Antigen (Latex Agglutination)", container: "Plain Container" },
                          { id: "csf_crypto", test: "CSF Cryptococcal Antigen & Indian Ink", container: "Plain Container" },
                          { id: "csf_fungal", test: "CSF Fungal Culture and Sensitivity", container: "Plain Container" },
                          { id: "csf_vdrl", test: "CSF VDRL (Syphilis test)", container: "Plain Container" },
                          { id: "csf_cmv", test: "CSF CMV PCR", container: "Plain Container" },
                          { id: "csf_vzv", test: "CSF Varicella Zoster PCR", container: "Plain Container" },
                          { id: "csf_hsv", test: "CSF Herpes Simplex PCR", container: "Plain Container" },
                          { id: "csf_bloods", test: "SENT BLOODS: Random Blood Sugar (RBS)", container: "Fluoride (Grey)" }
                        ];
                      } else if (hoActiveGuide === "bma") {
                        return [
                          { id: "bma_fung", test: "Fungal C&S from marrow in fungal CNS bottle", container: "Myco/F Lytic Bottle" },
                          { id: "bma_myco", test: "Mycobacterium culture from marrow", container: "Myco/F Lytic Bottle" },
                          { id: "bma_bcs", test: "Marrow Culture and Sensitivity (Aerobic & Anaerobic)", container: "Blood Culture Bottles" },
                          { id: "bma_tbpcr", test: "TB PCR (marrow) in CSF bottle", container: "Plain Sterile Tube" },
                          { id: "bma_tbcns", test: "BMA TB C&S - Conventional", container: "Plain Sterile Tube / Lowenstein" },
                          { id: "bma_tbbact", test: "BMA TB Culture (BACTEC)", container: "Myco/F Lytic Bottle" },
                          { id: "bma_genex", test: "Trephine TB Gene Xpert (IPR Respi approved!)", container: "Sterile container (with approval)" },
                          { id: "bma_fbp", test: "BLOODS: Full Blood Picture (FBP)", container: "EDTA (Purple)" },
                          { id: "bma_smear", test: "BMA Smear Slides", container: "Dry Smears on glass slides" },
                          { id: "bma_mole", test: "BMA Molecular Studies", container: "EDTA (Purple)" },
                          { id: "bma_flow", test: "BMA Immunophenotyping (Flow cytometry)", container: "EDTA (Purple) / Heparin" },
                          { id: "bma_cyto", test: "BMA Cytogenetics (Karyotyping / FISH)", container: "Sodium Heparin" },
                          { id: "bma_treph", test: "Trephine Biopsy", container: "10% Formalin Bottle" }
                        ];
                      } else {
                        return [
                          { id: "ha_fbc", test: "FBC with Reticulocyte count", container: "EDTA (Purple)" },
                          { id: "ha_tsb", test: "TSB Direct & Indirect Bilirubin", container: "SST (Yellow)" },
                          { id: "ha_ldh", test: "Lactate Dehydrogenase (LDH)", container: "SST (Yellow)" },
                          { id: "ha_coombs", test: "Coombs Test (Direct & Indirect)", container: "EDTA (Purple) & SST" },
                          { id: "ha_ufeme", test: "UFEME (look for urobilinogen / dark urine)", container: "Urine Container" },
                          { id: "ha_pbf", test: "Peripheral Blood Film (PBF) for Schistocytes/Spherocytes", container: "EDTA (Purple) or Bedside Slides" }
                        ];
                      }
                    };

                    const allItems = getActiveChecklistItems();
                    const items = searchQuery.trim() 
                      ? allItems.filter(item => matchesQuery(`${item.test} ${item.container}`))
                      : allItems;
                    const checkedCount = allItems.filter(item => hoChecklist[item.id]).length;
                    const percent = Math.round((checkedCount / allItems.length) * 100) || 0;

                    return (
                      <div className="space-y-4">
                        {/* Progress meter */}
                        <div className="space-y-1.5">
                          <div className="flex justify-between items-center text-[10px] font-bold font-mono">
                            <span className={isDarkMode ? "text-slate-400" : "text-slate-500"}>SAMPLING COMPLETION STATUS:</span>
                            <span className={isDarkMode ? "text-teal-400" : "text-teal-700"}>{checkedCount} / {allItems.length} ({percent}%)</span>
                          </div>
                          <div className={`w-full h-2 rounded-full overflow-hidden ${isDarkMode ? "bg-slate-950" : "bg-slate-100"}`}>
                            <div 
                              className="h-full bg-teal-50 rounded-full transition-all duration-300"
                              style={{ width: `${percent}%` }}
                            ></div>
                          </div>
                        </div>

                        {/* Checklist items */}
                        <div className="space-y-2 max-h-[380px] overflow-y-auto pr-1 scrollbar-thin">
                          {items.map((item) => {
                            const isChecked = hoChecklist[item.id] || false;
                            return (
                              <div
                                key={item.id}
                                onClick={() => setHoChecklist(prev => ({ ...prev, [item.id]: !isChecked }))}
                                className={`flex items-start gap-2.5 p-2.5 rounded-xl border transition-all cursor-pointer ${
                                  isChecked
                                    ? isDarkMode 
                                      ? "bg-teal-500/5 border-teal-500/20 text-slate-300" 
                                      : "bg-teal-50/50 border-teal-200 text-slate-800"
                                    : isDarkMode
                                      ? "bg-[#111827] border-slate-800 hover:border-slate-700 text-slate-400"
                                      : "bg-white border-slate-200 hover:border-slate-300 text-slate-700 shadow-sm"
                                }`}
                              >
                                <div className={`w-4.5 h-4.5 rounded border flex items-center justify-center flex-shrink-0 transition-colors mt-0.5 ${
                                  isChecked
                                    ? "bg-teal-500 border-teal-500 text-slate-950"
                                    : isDarkMode 
                                      ? "border-slate-700 bg-slate-950" 
                                      : "border-slate-300 bg-slate-50"
                                }`}>
                                  {isChecked && <span className="text-[10px] font-black">✓</span>}
                                </div>
                                <div className="text-[11px] leading-tight flex-1">
                                  <div className={`font-semibold ${isChecked ? (isDarkMode ? "text-slate-100" : "text-slate-900") : ""}`}>
                                    {highlightMatch(item.test, searchQuery)}
                                  </div>
                                  <div className={`text-[9px] font-mono mt-0.5 ${isDarkMode ? "text-teal-400" : "text-teal-700"}`}>
                                    Container: {highlightMatch(item.container, searchQuery)}
                                  </div>
                                </div>
                              </div>
                            );
                          })}
                          {items.length === 0 && (
                            <div className={`text-center py-8 ${isDarkMode ? "text-slate-400" : "text-slate-700"} font-mono text-xs`}>
                              No matching checklist items found.
                            </div>
                          )}
                        </div>

                        {/* Copy To Clipboard Clinical Summary */}
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            const summaryText = `--- WARDSAMPLING SUMMARY [${hoActiveGuide.toUpperCase()}] ---\n` +
                              items.map(i => `${hoChecklist[i.id] ? "[✓]" : "[ ]"} ${i.test} -> Container: ${i.container}`).join("\n") +
                              `\nGenerated via Dr FH Liew Clinical Assistant`;
                            handleCopy(summaryText, `ho-guide-${hoActiveGuide}`);
                          }}
                          className={`w-full py-2.5 rounded-xl font-bold uppercase text-[10px] transition-all border flex items-center justify-center gap-2 cursor-pointer ${
                            copyFeedback === `ho-guide-${hoActiveGuide}`
                              ? "bg-emerald-500/10 text-emerald-400 border-emerald-500/30 font-extrabold"
                              : isDarkMode 
                                ? "bg-slate-900 border-slate-800 text-slate-300 hover:bg-slate-800" 
                                : "bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100 shadow-sm"
                          }`}
                        >
                          {copyFeedback === `ho-guide-${hoActiveGuide}` ? "Summary Copied! ✓" : "Copy Ward Summary"}
                        </button>
                      </div>
                    );
                  })()}
                </div>
              </div>

            </div>
          </div>
        )}


        {/* TAB: RESUS GUIDE */}
        {activeTab === "resus" && resusSubTab === "interactive" && (
          <ResusGuide
            isDarkMode={isDarkMode}
            resusActiveAlg={resusActiveAlg}
            setResusActiveAlg={setResusActiveAlg}
            resusRhythm={resusRhythm}
            setResusRhythm={setResusRhythm}
            resusCprTimeLeft={resusCprTimeLeft}
            setResusCprTimeLeft={setResusCprTimeLeft}
            resusCprTimerRunning={resusCprTimerRunning}
            setResusCprTimerRunning={setResusCprTimerRunning}
            resusAdrenalineCount={resusAdrenalineCount}
            setResusAdrenalineCount={setResusAdrenalineCount}
            resusAmiodaroneCount={resusAmiodaroneCount}
            setResusAmiodaroneCount={setResusAmiodaroneCount}
            resusCyclesCompleted={resusCyclesCompleted}
            setResusCyclesCompleted={setResusCyclesCompleted}
            resusMetronomeActive={resusMetronomeActive}
            setResusMetronomeActive={setResusMetronomeActive}
            resusTimeHistory={resusTimeHistory}
            setResusTimeHistory={setResusTimeHistory}
          />
        )}

        {activeTab === "resus" && resusSubTab === "nutrition" && (
          <CriticalCareNutrition isDarkMode={isDarkMode} />
        )}


        {/* TAB: NAG GUIDE */}
        {activeTab === "nag" && (
          <NAGGuide isDarkMode={isDarkMode} />
        )}

        {/* TAB: PALLIATIVE CARE */}
        {activeTab === "palliative" && (
          <PalliativeGuide isDarkMode={isDarkMode} />
        )}

        {/* TAB: BEDSIDE CALCULATORS (Active Tab) */}
        {activeTab === "calc" && (() => {
          // Calculate active infusion values on render to prevent infinite loop updates
          const weight = parseFloat(infWeight) || 70;
          let defaultConc = 80; // mcg/ml or units/ml
          let unit: "mcg/kg/min" | "mcg/min" | "units/hr" | "mg/hr" = "mcg/kg/min";
          let drugName = "Noradrenaline";
          let preparationText = "";
          let standardDoses = [0.05, 0.1, 0.25, 0.5];
          let clinicalNotes = "";

          if (infDrug === "noradrenaline") {
            unit = "mcg/kg/min";
            drugName = "Noradrenaline";
            standardDoses = [0.05, 0.1, 0.2, 0.5, 0.8];
            clinicalNotes = "First-line vasopressor for septic shock. Standard target Mean Arterial Pressure (MAP) is ≥65 mmHg. Always administer via a central venous catheter. Monitor infusion site closely for extravasation (consider phentolamine if occurs). Avoid abrupt cessation.";
            if (infPrep === "single") {
              defaultConc = 80; // 4mg in 50ml
              preparationText = "Dilute 4mg (1 ampoule) Noradrenaline in 46ml D5% (Total 50ml)";
            } else if (infPrep === "double") {
              defaultConc = 160; // 8mg in 50ml
              preparationText = "Dilute 8mg (2 ampoules) Noradrenaline in 42ml D5% (Total 50ml)";
            } else {
              defaultConc = parseFloat(infCustomConc) || 80;
              preparationText = `Custom Preparation: Concentration ${defaultConc} mcg/mL`;
            }
          } else if (infDrug === "adrenaline") {
            unit = "mcg/kg/min";
            drugName = "Adrenaline";
            standardDoses = [0.05, 0.1, 0.2, 0.5, 1.0];
            clinicalNotes = "Primary agent for anaphylaxis and cardiac arrest. Used as second-line add-on in refractory septic shock. Highly arrhythmogenic; watch for severe tachycardia, peripheral ischemia, and transient lactic acidosis.";
            if (infPrep === "single") {
              defaultConc = 60; // 3mg in 50ml
              preparationText = "Dilute 3mg (3 ampoules) Adrenaline in 47ml NS or D5% (Total 50ml)";
            } else if (infPrep === "double") {
              defaultConc = 120; // 6mg in 50ml
              preparationText = "Dilute 6mg (6 ampoules) Adrenaline in 44ml NS or D5% (Total 50ml)";
            } else {
              defaultConc = parseFloat(infCustomConc) || 60;
              preparationText = `Custom Preparation: Concentration ${defaultConc} mcg/mL`;
            }
          } else if (infDrug === "dopamine") {
            unit = "mcg/kg/min";
            drugName = "Dopamine";
            standardDoses = [2.5, 5.0, 10.0, 15.0, 20.0];
            clinicalNotes = "Beta-adrenergic inotrope that increases cardiac contractility. Highly arrhythmogenic. Mostly superseded by Noradrenaline and Dobutamine at the bedside. Run via central venous catheter.";
            if (infPrep === "single") {
              defaultConc = 4000; // 200mg in 50ml
              preparationText = "Dilute 200mg (1 ampoule) Dopamine in 45ml NS or D5% (Total 50ml)";
            } else if (infPrep === "double") {
              defaultConc = 8000; // 400mg in 50ml
              preparationText = "Dilute 400mg (2 ampoules) Dopamine in 40ml NS or D5% (Total 50ml)";
            } else {
              defaultConc = parseFloat(infCustomConc) || 4000;
              preparationText = `Custom Preparation: Concentration ${defaultConc} mcg/mL`;
            }
          } else if (infDrug === "dobutamine") {
            unit = "mcg/kg/min";
            drugName = "Dobutamine";
            standardDoses = [2.5, 5.0, 10.0, 15.0, 20.0];
            clinicalNotes = "First-line inotrope for cardiogenic shock and severe acute decompensated heart failure. Enhances myocardial contractility and stroke volume. May cause systemic vasodilation (mild hypotension) and tachyarrhythmias.";
            if (infPrep === "single") {
              defaultConc = 5000; // 250mg in 50ml
              preparationText = "Dilute 250mg (1 vial) Dobutamine in 30ml NS or D5% (Total 50ml)";
            } else if (infPrep === "double") {
              defaultConc = 10000; // 500mg in 50ml
              preparationText = "Dilute 500mg (2 vials) Dobutamine in 10ml NS or D5% (Total 50ml)";
            } else {
              defaultConc = parseFloat(infCustomConc) || 5000;
              preparationText = `Custom Preparation: Concentration ${defaultConc} mcg/mL`;
            }
          } else if (infDrug === "insulin") {
            unit = "units/hr";
            drugName = "Actrapid Insulin";
            defaultConc = 1; // 50 units in 50ml
            standardDoses = [0.5, 1.0, 2.0, 4.0, 6.0, 8.0];
            clinicalNotes = "Standard protocol for DKA, HHS, and severe hyperglycemia. Run via dedicated line. Monitor capillary blood glucose every 1-2 hours. Ensure serum potassium is >3.3 mmol/L before commencing insulin infusion.";
            preparationText = "Draw 50 units (0.5ml of 100 U/ml) Actrapid Insulin and dilute with 49.5ml NS (Total 50ml; Concentration 1 unit/ml)";
          } else if (infDrug === "heparin") {
            unit = "units/hr";
            drugName = "Unfractionated Heparin";
            defaultConc = 500; // 25,000 units in 50ml
            standardDoses = [500, 800, 1000, 1250, 1500, 1800];
            clinicalNotes = "Anticoagulation for ACS, PE, acute DVT, or arterial emboli. Requires baseline APTT/PT/INR. Typically adjusted dynamically based on sliding-scale aPTT protocols (checked every 6 hours). Watch for Heparin-Induced Thrombocytopenia (HIT).";
            preparationText = "Dilute 25,000 units Unfractionated Heparin (5ml) with 45ml NS or D5% (Total 50ml; Concentration 500 units/ml)";
          } else {
            unit = infCustomUnit;
            drugName = "Custom Infusion";
            defaultConc = parseFloat(infCustomConc) || 1;
            standardDoses = unit.includes("mcg/kg") ? [0.05, 0.1, 0.25, 0.5, 1.0] : [1, 2, 5, 10, 20];
            clinicalNotes = "Custom medication profile. Always perform dual independent clinician verification of concentrations, dosage units, and pump flow rates at the bedside before starting infusion.";
            preparationText = `Custom Infusion Setup: Concentration ${defaultConc} units/mL`;
          }

          // Dose to Rate calculation
          const targetDoseNum = parseFloat(infTargetDose) || 0;
          let calcRate = 0;
          if (unit === "mcg/kg/min") {
            calcRate = (targetDoseNum * weight * 60) / defaultConc;
          } else if (unit === "mcg/min") {
            calcRate = (targetDoseNum * 60) / defaultConc;
          } else if (unit === "units/hr" || unit === "mg/hr") {
            calcRate = targetDoseNum / defaultConc;
          }

          // Rate to Dose calculation
          const mlPerHourNum = parseFloat(infMlPerHour) || 0;
          let calcDose = 0;
          if (unit === "mcg/kg/min") {
            calcDose = (mlPerHourNum * defaultConc) / (weight * 60);
          } else if (unit === "mcg/min") {
            calcDose = (mlPerHourNum * defaultConc) / 60;
          } else if (unit === "units/hr" || unit === "mg/hr") {
            calcDose = mlPerHourNum * defaultConc;
          }

          const inf = {
            weight,
            concentration: defaultConc,
            unit,
            drugName,
            preparationText,
            standardDoses,
            clinicalNotes,
            calculatedRate: parseFloat(calcRate.toFixed(2)),
            calculatedDose: parseFloat(calcDose.toFixed(3)),
          };

          return (
            <div className="space-y-6 animate-fade-in">
              {/* Header */}
              <div className="px-1 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                <div>
                  <h2 className={`text-lg sm:text-xl font-bold font-sans ${isDarkMode ? "text-teal-400" : "text-teal-700"} flex items-center gap-2`}>
                    <span>🧮</span> Clinical Calculators & Infusions
                  </h2>
                  <p className={`text-[10px] sm:text-xs ${isDarkMode ? "text-slate-400" : "text-slate-700"} mt-0.5`}>
                    Validated calculators for renal clearance, calcium adjustment, and active drug infusion pump rates.
                  </p>
                </div>
                
                {/* SUB-TAB TOGGLES */}
                <div className="flex bg-slate-900/60 border border-slate-800 p-1 rounded-xl self-start sm:self-center">
                  <button
                    onClick={() => setCalcSubTab("standard")}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 ${
                      calcSubTab === "standard"
                        ? "bg-teal-500 text-slate-950 shadow-md"
                        : "text-slate-400 hover:text-slate-200"
                    }`}
                  >
                    📊 Standard
                  </button>
                  <button
                    onClick={() => setCalcSubTab("infusion")}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 ${
                      calcSubTab === "infusion"
                        ? "bg-teal-500 text-slate-950 shadow-md"
                        : "text-slate-400 hover:text-slate-200"
                    }`}
                    id="btn-subtab-infusion"
                  >
                    💉 Infusion Converter
                  </button>
                </div>
              </div>

              {/* SECTION A: STANDARD BEDSIDE CALCULATORS */}
              {calcSubTab === "standard" && (
                <div className="space-y-6">
                  {/* SEGMENTED CONTROL PICKER */}
                  <div className={`p-1 rounded-xl border flex flex-wrap gap-1 ${
                    isDarkMode ? "bg-slate-900/60 border-slate-800" : "bg-slate-100 border-slate-200"
                  }`}>
                    {[
                      { id: "fluids", label: "Fluids (4-2-1)", icon: <Droplet className="w-3.5 h-3.5" /> },
                      { id: "crcl", label: "CrCl (Cockcroft-Gault)", icon: <Calculator className="w-3.5 h-3.5" /> },
                      { id: "calcium", label: "Corrected Calcium", icon: <Calculator className="w-3.5 h-3.5" /> },
                      { id: "flow_rate", label: "Drip / Flow Rate", icon: <Calculator className="w-3.5 h-3.5" /> }
                    ].map((calc) => {
                      const isActive = selectedStandardCalc === calc.id;
                      return (
                        <button
                          key={calc.id}
                          onClick={() => {
                            setSelectedStandardCalc(calc.id as any);
                          }}
                          className={`flex-1 min-w-[130px] py-2 px-3 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-1.5 ${
                            isActive
                              ? "bg-teal-500 text-slate-950 shadow-md font-extrabold"
                              : isDarkMode
                                ? "text-slate-400 hover:text-slate-200 hover:bg-slate-800/40"
                                : "text-slate-600 hover:text-slate-800 hover:bg-white/40"
                          }`}
                        >
                          {calc.icon}
                          <span>{calc.label}</span>
                        </button>
                      );
                    })}
                  </div>

                  {/* ACTIVE CALCULATOR CONTAINER */}
                  <div className="max-w-xl mx-auto w-full animate-fade-in">
                    {/* Maintenance Fluid Calculator */}
                    {selectedStandardCalc === "fluids" && (
                      <motion.div 
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        className={`p-5 rounded-xl border ${
                          isDarkMode ? "bg-[#111827] border-slate-800" : "bg-white border-slate-200 shadow-sm"
                        }`}
                      >
                        <div className="flex items-center gap-2.5 mb-4 border-b pb-3 border-slate-800/40">
                          <div className={`p-2 rounded bg-sky-500/10 ${isDarkMode ? "text-sky-400" : "text-sky-700"}`}>
                            <Droplet className="h-4.5 w-4.5" />
                          </div>
                          <div>
                            <h3 className={`font-bold text-sm ${isDarkMode ? "text-slate-200" : "text-slate-850"}`}>Maintenance Fluids</h3>
                            <p className={`text-[10px] ${isDarkMode ? "text-slate-400" : "text-slate-700"}`}>Standard pediatric & adult 4-2-1 hourly fluid rule</p>
                          </div>
                        </div>
                        
                        <div className="space-y-4">
                          <div>
                            <label className={`text-[11px] font-semibold ${isDarkMode ? "text-slate-400" : "text-slate-700"} block mb-1`}>Patient Weight (kg)</label>
                            <input 
                              type="number" 
                              value={fluidWeight}
                              onChange={e => { setFluidWeight(e.target.value); setFluidResult(null); }}
                              className={`w-full p-2.5 rounded-lg text-sm border outline-none transition-all ${
                                isDarkMode 
                                  ? "bg-slate-900 border-slate-750 focus:border-sky-500 text-slate-200" 
                                  : "bg-white border-slate-300 focus:border-sky-500 text-slate-800 shadow-sm"
                              }`}
                              placeholder="e.g. 70"
                            />
                            <div className="flex gap-1.5 mt-2 flex-wrap">
                              {[10, 20, 50, 70, 85].map(v => (
                                <button key={v} type="button" onClick={() => { setFluidWeight(v.toString()); setFluidResult(null); }} className={`px-2 py-0.5 rounded text-[10px] ${isDarkMode ? "bg-slate-800 text-slate-300 hover:bg-slate-750" : "bg-slate-100 text-slate-800 hover:bg-slate-200"} font-mono`}>{v}kg</button>
                              ))}
                            </div>
                          </div>

                          <button 
                            onClick={calculateFluid}
                            className="w-full py-2.5 rounded-lg bg-sky-600 hover:bg-sky-500 text-white text-xs font-bold transition-colors uppercase tracking-wider shadow-md"
                          >
                            Calculate 4-2-1
                          </button>

                          {fluidResult !== null && (
                            <div className="p-3.5 rounded-lg bg-sky-500/10 border border-sky-500/20 text-center animate-fade-in">
                              <span className={`text-[10px] uppercase tracking-wider font-bold ${isDarkMode ? "text-sky-400" : "text-sky-700"} block mb-0.5`}>Maintenance Rate</span>
                              <div className="flex items-baseline justify-center gap-1">
                                <span className={`text-2xl font-bold ${isDarkMode ? "text-slate-100" : "text-slate-900"} font-mono`}>{fluidResult}</span>
                                <span className={`text-xs ${isDarkMode ? "text-slate-400" : "text-slate-500"} font-mono`}>mL/hr</span>
                              </div>
                            </div>
                          )}
                        </div>
                      </motion.div>
                    )}

                    {/* Cockcroft-Gault Calculator */}
                    {selectedStandardCalc === "crcl" && (
                      <motion.div 
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        className={`p-5 rounded-xl border ${
                          isDarkMode ? "bg-[#111827] border-slate-800" : "bg-white border-slate-200 shadow-sm"
                        }`}
                      >
                        <div className="flex items-center gap-2.5 mb-4 border-b pb-3 border-slate-800/40">
                          <div className={`p-2 rounded bg-teal-500/10 ${isDarkMode ? "text-teal-400" : "text-teal-700"}`}>
                            <Calculator className="h-4.5 w-4.5" />
                          </div>
                          <div>
                            <h3 className={`font-bold text-sm ${isDarkMode ? "text-slate-200" : "text-slate-850"}`}>Cockcroft-Gault CrCl</h3>
                            <p className={`text-[10px] ${isDarkMode ? "text-slate-400" : "text-slate-700"}`}>Renal Clearance Estimation</p>
                          </div>
                        </div>

                        <div className="space-y-3.5 text-xs text-left">
                          <div>
                            <label className={`text-[11px] font-semibold ${isDarkMode ? "text-slate-400" : "text-slate-700"} block mb-1`}>Age (years)</label>
                            <input 
                              type="number" 
                              value={cgAge} 
                              onChange={(e) => { setCgAge(e.target.value); setCgResult(null); }}
                              placeholder="e.g. 65" 
                              className={`w-full p-2.5 rounded-lg border outline-none transition-all ${
                                isDarkMode ? "bg-slate-900 border-slate-750 text-white focus:border-teal-500" : "bg-white border-slate-300 text-slate-900 focus:border-teal-500 shadow-sm"
                              }`}
                            />
                            <div className="flex gap-1 mt-1 flex-wrap">
                              {["45", "65", "80"].map(v => (
                                <button key={v} type="button" onClick={() => { setCgAge(v); setCgResult(null); }} className={`px-2 py-0.5 rounded text-[10px] ${isDarkMode ? "bg-slate-800 text-slate-300 hover:bg-slate-750" : "bg-slate-100 text-slate-800 hover:bg-slate-200"} font-mono`} id={`cg-age-preset-${v}`}>{v}y</button>
                              ))}
                            </div>
                          </div>

                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                            <div>
                              <label className={`text-[11px] font-semibold ${isDarkMode ? "text-slate-400" : "text-slate-700"} block mb-1`}>Weight (kg)</label>
                              <input 
                                type="number" 
                                value={cgWeight} 
                                onChange={(e) => { setCgWeight(e.target.value); setCgResult(null); }}
                                placeholder="e.g. 70" 
                                className={`w-full p-2.5 rounded-lg border outline-none transition-all ${
                                  isDarkMode ? "bg-slate-900 border-slate-750 text-white focus:border-teal-500" : "bg-white border-slate-300 text-slate-900 focus:border-teal-500 shadow-sm"
                                }`}
                              />
                            </div>
                            <div>
                              <label className={`text-[11px] font-semibold ${isDarkMode ? "text-slate-400" : "text-slate-700"} block mb-1`}>Height (cm) <span className="text-slate-500 font-normal">(opt)</span></label>
                              <input 
                                type="number" 
                                value={cgHeight} 
                                onChange={(e) => { setCgHeight(e.target.value); setCgResult(null); }}
                                placeholder="e.g. 170" 
                                className={`w-full p-2.5 rounded-lg border outline-none transition-all ${
                                  isDarkMode ? "bg-slate-900 border-slate-750 text-white focus:border-teal-500" : "bg-white border-slate-300 text-slate-900 focus:border-teal-500 shadow-sm"
                                }`}
                              />
                            </div>
                          </div>

                          <div>
                            <label className={`text-[11px] font-semibold ${isDarkMode ? "text-slate-400" : "text-slate-700"} block mb-1`}>Serum Creatinine (µmol/L)</label>
                            <input 
                              type="number" 
                              value={cgCreatinine} 
                              onChange={(e) => { setCgCreatinine(e.target.value); setCgResult(null); }}
                              placeholder="e.g. 110" 
                              className={`w-full p-2.5 rounded-lg border outline-none transition-all ${
                                isDarkMode ? "bg-slate-900 border-slate-750 text-white focus:border-teal-500" : "bg-white border-slate-300 text-slate-900 focus:border-teal-500 shadow-sm"
                              }`}
                            />
                            <div className="flex gap-1 mt-1 flex-wrap">
                              {["80", "120", "200"].map(v => (
                                <button key={v} type="button" onClick={() => { setCgCreatinine(v); setCgResult(null); }} className={`px-2 py-0.5 rounded text-[10px] ${isDarkMode ? "bg-slate-800 text-slate-300 hover:bg-slate-750" : "bg-slate-100 text-slate-800 hover:bg-slate-200"} font-mono`} id={`cg-scr-preset-${v}`}>{v}</button>
                              ))}
                            </div>
                          </div>

                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                            <div>
                              <label className={`text-[11px] font-semibold ${isDarkMode ? "text-slate-400" : "text-slate-700"} block mb-1`}>Sex</label>
                              <select 
                                value={cgSex} 
                                onChange={(e) => { setCgSex(e.target.value as "male" | "female"); setCgResult(null); }}
                                className={`w-full p-2.5 rounded-lg border outline-none transition-all ${
                                  isDarkMode ? "bg-slate-900 border-slate-750 text-white focus:border-teal-500" : "bg-white border-slate-300 text-slate-900 focus:border-teal-500 shadow-sm"
                                }`}
                              >
                                <option value="male">Male</option>
                                <option value="female">Female</option>
                              </select>
                            </div>

                            {cgCalculatedWeights && (
                              <div>
                                <label className={`text-[11px] font-semibold ${isDarkMode ? "text-slate-400" : "text-slate-700"} block mb-1`}>Patient BMI</label>
                                <div className={`p-2.5 rounded-lg border text-center font-bold text-xs ${
                                  cgCalculatedWeights.bmi >= 30 
                                    ? "bg-rose-500/10 text-rose-400 border-rose-500/20" 
                                    : "bg-teal-500/10 text-teal-400 border-teal-500/20"
                                }`}>
                                  {cgCalculatedWeights.bmi} {cgCalculatedWeights.bmi >= 30 ? "Obese" : ""}
                                </div>
                              </div>
                            )}
                          </div>

                          {cgCalculatedWeights && (
                            <div className={`p-2.5 rounded-lg border ${isDarkMode ? "bg-slate-950/40 border-slate-800/80" : "bg-slate-50 border-slate-200"} space-y-2`}>
                              <span className={`block text-[10px] font-bold ${isDarkMode ? "text-slate-400" : "text-slate-700"} uppercase tracking-wider`}>Weight Selection (Clinical Safety)</span>
                              <div className={`text-[10px] ${isDarkMode ? "text-slate-400" : "text-slate-700"} leading-normal`}>
                                {cgCalculatedWeights.isObese ? (
                                  <span className={`${isDarkMode ? "text-amber-400" : "text-amber-700"} font-semibold`}>⚠️ Patient is Obese. Recommend using Adjusted Body Weight (AjBW) to prevent dosage overestimation.</span>
                                ) : (
                                  <span>Recommend using Actual Body Weight.</span>
                                )}
                              </div>
                              <div className="grid grid-cols-3 gap-1">
                                <button 
                                  type="button" 
                                  onClick={() => setCgWeightType("actual")}
                                  className={`p-1.5 rounded border text-[10px] font-mono flex flex-col items-center justify-center transition-all ${
                                    cgWeightType === "actual" 
                                      ? "bg-teal-500/20 border-teal-500 text-teal-400 font-bold" 
                                      : isDarkMode 
                                        ? "bg-slate-900 border-slate-800 text-slate-400 hover:bg-slate-800" 
                                        : "bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100"
                                  }`}
                                >
                                  <span>Actual</span>
                                  <span className="text-[9px] text-slate-500">{cgWeight}kg</span>
                                </button>
                                <button 
                                  type="button" 
                                  onClick={() => setCgWeightType("ideal")}
                                  className={`p-1.5 rounded border text-[10px] font-mono flex flex-col items-center justify-center transition-all ${
                                    cgWeightType === "ideal" 
                                      ? "bg-teal-500/20 border-teal-500 text-teal-300 font-bold" 
                                      : isDarkMode 
                                        ? "bg-slate-900 border-slate-800 text-slate-400 hover:bg-slate-800" 
                                        : "bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100"
                                  }`}
                                >
                                  <span>Ideal (IBW)</span>
                                  <span className="text-[9px] text-slate-500">{cgCalculatedWeights.ibw}kg</span>
                                </button>
                                <button 
                                  type="button" 
                                  onClick={() => setCgWeightType("adjusted")}
                                  className={`p-1.5 rounded border text-[10px] font-mono flex flex-col items-center justify-center transition-all ${
                                    cgWeightType === "adjusted" 
                                      ? "bg-teal-500/20 border-teal-500 text-teal-300 font-bold" 
                                      : isDarkMode 
                                        ? "bg-slate-900 border-slate-800 text-slate-400 hover:bg-slate-800" 
                                        : "bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100"
                                  }`}
                                >
                                  <span>Adjusted</span>
                                  <span className="text-[9px] text-slate-500">{cgCalculatedWeights.ajbw}kg</span>
                                </button>
                              </div>
                            </div>
                          )}

                          <button 
                            onClick={calculateCrCl}
                            className="w-full bg-teal-500 hover:bg-teal-600 text-slate-950 font-bold py-2.5 rounded-lg text-xs transition-all cursor-pointer uppercase tracking-wider"
                            id="btn-calculate-crcl"
                          >
                            Recalculate CrCl
                          </button>
                        </div>

                        {cgResult !== null && (
                          <div className="p-3 bg-teal-500/10 border border-teal-500/20 rounded-lg text-center mt-3 animate-fade-in">
                            <span className={`block text-[10px] ${isDarkMode ? "text-slate-400" : "text-slate-700"}`}>Calculated Clearance ({cgWeightType.toUpperCase()})</span>
                            <strong className={`${isDarkMode ? "text-teal-400" : "text-teal-700"} font-mono text-base block`}>{cgResult.toFixed(1)} ml/min</strong>
                            {cgCalculatedWeights && (
                              <span className="text-[9px] text-slate-500 font-mono mt-0.5 block">
                                Using weight: {cgWeightType === "actual" ? `${cgWeight}kg` : cgWeightType === "ideal" ? `${cgCalculatedWeights.ibw}kg (IBW)` : `${cgCalculatedWeights.ajbw}kg (AjBW)`}
                              </span>
                            )}
                          </div>
                        )}
                      </motion.div>
                    )}

                    {/* Corrected Calcium Calculator */}
                    {selectedStandardCalc === "calcium" && (
                      <motion.div 
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        className={`p-5 rounded-xl border ${
                          isDarkMode ? "bg-[#111827] border-slate-800" : "bg-white border-slate-200 shadow-sm"
                        }`}
                      >
                        <div className="flex items-center gap-2.5 mb-4 border-b pb-3 border-slate-800/40">
                          <div className={`p-2 rounded bg-teal-500/10 ${isDarkMode ? "text-teal-400" : "text-teal-700"}`}>
                            <Calculator className="h-4.5 w-4.5" />
                          </div>
                          <div>
                            <h3 className={`font-bold text-sm ${isDarkMode ? "text-slate-200" : "text-slate-850"}`}>Corrected Calcium</h3>
                            <p className={`text-[10px] ${isDarkMode ? "text-slate-400" : "text-slate-700"}`}>Albumin-Adjusted Calcium</p>
                          </div>
                        </div>

                        <div className="space-y-3.5 text-xs text-left">
                          <div>
                            <label className={`text-[11px] font-semibold ${isDarkMode ? "text-slate-400" : "text-slate-700"} block mb-1`}>Measured Calcium (mmol/L)</label>
                            <input 
                              type="number" 
                              step="0.01"
                              value={caMeasured} 
                              onChange={(e) => { setCaMeasured(e.target.value); setCaResult(null); }}
                              placeholder="e.g. 1.85" 
                              className={`w-full p-2.5 rounded-lg border outline-none transition-all ${
                                isDarkMode ? "bg-slate-900 border-slate-750 text-white focus:border-teal-500" : "bg-white border-slate-300 text-slate-900 focus:border-teal-500 shadow-sm"
                              }`}
                            />
                            <div className="flex gap-1 mt-1 flex-wrap">
                              {["1.70", "1.90", "2.10"].map(v => (
                                <button key={v} type="button" onClick={() => { setCaMeasured(v); setCaResult(null); }} className={`px-2 py-0.5 rounded text-[10px] ${isDarkMode ? "bg-slate-800 text-slate-300 hover:bg-slate-750" : "bg-slate-100 text-slate-800 hover:bg-slate-200"} font-mono`} id={`ca-measured-preset-${v}`}>{v}</button>
                              ))}
                            </div>
                          </div>

                          <div>
                            <label className={`text-[11px] font-semibold ${isDarkMode ? "text-slate-400" : "text-slate-700"} block mb-1`}>Serum Albumin (g/L)</label>
                            <input 
                              type="number" 
                              value={caAlbumin} 
                              onChange={(e) => { setCaAlbumin(e.target.value); setCaResult(null); }}
                              placeholder="e.g. 25" 
                              className={`w-full p-2.5 rounded-lg border outline-none transition-all ${
                                isDarkMode ? "bg-slate-900 border-slate-750 text-white focus:border-teal-500" : "bg-white border-slate-300 text-slate-900 focus:border-teal-500 shadow-sm"
                              }`}
                            />
                            <div className="flex gap-1 mt-1 flex-wrap">
                              {["20", "28", "35"].map(v => (
                                <button key={v} type="button" onClick={() => { setCaAlbumin(v); setCaResult(null); }} className={`px-2 py-0.5 rounded text-[10px] ${isDarkMode ? "bg-slate-800 text-slate-300 hover:bg-slate-750" : "bg-slate-100 text-slate-800 hover:bg-slate-200"} font-mono`} id={`ca-albumin-preset-${v}`}>{v}</button>
                              ))}
                            </div>
                          </div>

                          <button 
                            onClick={calculateCalcium}
                            className="w-full bg-teal-500 hover:bg-teal-600 text-slate-950 font-bold py-2.5 px-3 rounded-lg text-xs transition-all mt-6 cursor-pointer uppercase tracking-wider animate-pulse"
                            id="btn-calculate-calcium"
                          >
                            Correct Calcium
                          </button>
                        </div>

                        {caResult !== null && (
                          <div className="p-3 bg-teal-500/10 border border-teal-500/20 rounded-lg text-center mt-3 animate-fade-in">
                            <span className={`block text-[10px] ${isDarkMode ? "text-slate-400" : "text-slate-700"}`}>Corrected Calcium</span>
                            <strong className={`font-mono text-base block mt-0.5 ${caResult < 2.15 ? "text-rose-400 animate-pulse font-bold" : "text-teal-400 font-bold"}`}>
                              {caResult.toFixed(2)} mmol/L
                            </strong>
                          </div>
                        )}
                      </motion.div>
                    )}

                    {/* Infusion Drip & Flow Rate Calculator */}
                    {selectedStandardCalc === "flow_rate" && (
                      <motion.div 
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        className={`p-5 rounded-xl border ${
                          isDarkMode ? "bg-[#111827] border-slate-800" : "bg-white border-slate-200 shadow-sm"
                        }`}
                      >
                        <div className="flex items-center gap-2.5 mb-4 border-b pb-3 border-slate-800/40">
                          <div className={`p-2 rounded bg-teal-500/10 ${isDarkMode ? "text-teal-400" : "text-teal-700"}`}>
                            <Calculator className="h-4.5 w-4.5" />
                          </div>
                          <div>
                            <h3 className={`font-bold text-sm ${isDarkMode ? "text-slate-200" : "text-slate-700"}`}>Infusion Flow Rate</h3>
                            <p className={`text-[10px] ${isDarkMode ? "text-slate-400" : "text-slate-700"}`}>mL/h & Drop Rate Converter</p>
                          </div>
                        </div>

                        <div className="space-y-3.5 text-xs text-left">
                          <div>
                            <label className={`text-[11px] font-semibold ${isDarkMode ? "text-slate-400" : "text-slate-700"} block mb-1`}>Total Volume (ml)</label>
                            <input 
                              type="number" 
                              value={infusionVol} 
                              onChange={(e) => { setInfusionVol(e.target.value); setInfusionResult(null); }}
                              placeholder="e.g. 500" 
                              className={`w-full p-2.5 rounded-lg border outline-none transition-all ${
                                isDarkMode ? "bg-slate-900 border-slate-750 text-white focus:border-teal-500" : "bg-white border-slate-300 text-slate-900 focus:border-teal-500 shadow-sm"
                              }`}
                            />
                            <div className="flex gap-1 mt-1 flex-wrap">
                              {["100", "250", "500"].map(v => (
                                <button key={v} type="button" onClick={() => { setInfusionVol(v); setInfusionResult(null); }} className={`px-2 py-0.5 rounded text-[10px] ${isDarkMode ? "bg-slate-800 text-slate-300 hover:bg-slate-750" : "bg-slate-100 text-slate-800 hover:bg-slate-200"} font-mono`} id={`infusion-vol-preset-${v}`}>{v}</button>
                              ))}
                            </div>
                          </div>

                          <div>
                            <label className={`text-[11px] font-semibold ${isDarkMode ? "text-slate-400" : "text-slate-700"} block mb-1`}>Duration (hours)</label>
                            <input 
                              type="number" 
                              value={infusionDuration} 
                              onChange={(e) => { setInfusionVolDuration(e.target.value); setInfusionResult(null); }}
                              placeholder="e.g. 4" 
                              className={`w-full p-2.5 rounded-lg border outline-none transition-all ${
                                isDarkMode ? "bg-slate-900 border-slate-750 text-white focus:border-teal-500" : "bg-white border-slate-300 text-slate-900 focus:border-teal-500 shadow-sm"
                              }`}
                            />
                            <div className="flex gap-1 mt-1 flex-wrap">
                              {["1", "4", "8", "12"].map(v => (
                                <button key={v} type="button" onClick={() => { setInfusionVolDuration(v); setInfusionResult(null); }} className={`px-2 py-0.5 rounded text-[10px] ${isDarkMode ? "bg-slate-800 text-slate-300 hover:bg-slate-750" : "bg-slate-100 text-slate-800 hover:bg-slate-200"} font-mono`} id={`infusion-dur-preset-${v}`}>{v}h</button>
                              ))}
                            </div>
                          </div>

                          <div>
                            <label className={`text-[11px] font-semibold ${isDarkMode ? "text-slate-400" : "text-slate-700"} block mb-1`}>Drop Factor (gtt/ml)</label>
                            <select 
                              value={infusionDropFactor} 
                              onChange={(e) => { setInfusionDropFactor(e.target.value); setInfusionResult(null); }}
                              className={`w-full p-2.5 rounded-lg border outline-none transition-all ${
                                isDarkMode ? "bg-slate-900 border-slate-750 text-white focus:border-teal-500" : "bg-white border-slate-300 text-slate-900 focus:border-teal-500 shadow-sm"
                              }`}
                            >
                              <option value="20">20 gtt/ml (Standard Blood/IV Set)</option>
                              <option value="15">15 gtt/ml (Macro Set)</option>
                              <option value="60">60 gtt/ml (Microdrip Set)</option>
                            </select>
                          </div>

                          <button 
                            onClick={calculateInfusion}
                            className="w-full bg-teal-500 hover:bg-teal-600 text-slate-950 font-bold py-2.5 px-3 rounded-lg text-xs transition-all mt-2 cursor-pointer uppercase tracking-wider"
                            id="btn-calculate-infusion"
                          >
                            Calculate Rates
                          </button>
                        </div>

                        {infusionResult !== null && (
                          <div className="p-2.5 bg-teal-500/10 border border-teal-500/20 rounded-lg text-center mt-3 flex flex-col gap-1 text-[11px] animate-fade-in">
                            <div className="flex justify-between items-center px-1">
                              <span className={`${isDarkMode ? "text-slate-400" : "text-slate-700"}`}>Flow Rate:</span>
                              <strong className={`${isDarkMode ? "text-teal-400" : "text-teal-700"} font-mono text-xs`}>{infusionResult.mlPerHour.toFixed(1)} ml/h</strong>
                            </div>
                            <div className="flex justify-between items-center border-t border-slate-800/45 px-1 pt-1 mt-1">
                              <span className={`${isDarkMode ? "text-slate-400" : "text-slate-700"}`}>Drip Rate:</span>
                              <strong className={`${isDarkMode ? "text-teal-400" : "text-teal-700"} font-mono text-xs`}>{infusionResult.dropsPerMin.toFixed(0)} drops/min</strong>
                            </div>
                          </div>
                        )}
                      </motion.div>
                    )}
                  </div>
                </div>
              )}

              {/* SECTION B: CRITICAL CARE DRUG & INFUSION CONVERTER (Bidirectional) */}
              {calcSubTab === "infusion" && (() => {
                return (
                  <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
                    
                    {/* INPUT PANEL (5 cols) */}
                    <div className={`p-5 rounded-2xl border lg:col-span-5 space-y-4 ${
                      isDarkMode ? "bg-[#111827] border-slate-800" : "bg-white border-slate-200 shadow-sm"
                    }`}>
                      <h3 className="font-bold text-sm tracking-wide text-teal-400 flex items-center gap-2">
                        <span>⚙️</span> Infusion Configuration
                      </h3>

                      {/* Weight Input with Presets */}
                      <div>
                        <label className={`text-[11px] font-semibold ${isDarkMode ? "text-slate-400" : "text-slate-700"} block mb-1`}>
                          Patient Weight (kg)
                        </label>
                        <input 
                          type="number"
                          value={infWeight}
                          onChange={(e) => setInfWeight(e.target.value)}
                          className="w-full p-2.5 rounded-lg border bg-slate-900 border-slate-800 text-white font-mono text-sm"
                          placeholder="70"
                        />
                        <div className="flex gap-1 mt-2 flex-wrap">
                          {["50", "60", "70", "80", "90"].map((wVal) => (
                            <button
                              key={wVal}
                              onClick={() => setInfWeight(wVal)}
                              className={`px-2 py-1 rounded text-[10px] font-mono ${
                                infWeight === wVal
                                  ? "bg-teal-500/20 text-teal-400 border border-teal-500/40"
                                  : "bg-slate-800 hover:bg-slate-700 text-slate-300"
                              }`}
                            >
                              {wVal}kg
                            </button>
                          ))}
                        </div>
                      </div>

                      {/* Drug Selection */}
                      <div>
                        <label className={`text-[11px] font-semibold ${isDarkMode ? "text-slate-400" : "text-slate-700"} block mb-1`}>
                          Select Infusion Drug
                        </label>
                        <select
                          value={infDrug}
                          onChange={(e) => {
                            const selected = e.target.value as any;
                            setInfDrug(selected);
                            // Set defaults for selected drug to avoid blank calculations
                            if (selected === "noradrenaline") {
                              setInfPrep("single");
                              setInfTargetDose("0.1");
                              setInfMlPerHour("3.75");
                            } else if (selected === "adrenaline") {
                              setInfPrep("single");
                              setInfTargetDose("0.1");
                              setInfMlPerHour("5.0");
                            } else if (selected === "dopamine") {
                              setInfPrep("single");
                              setInfTargetDose("5");
                              setInfMlPerHour("5.25");
                            } else if (selected === "dobutamine") {
                              setInfPrep("single");
                              setInfTargetDose("5");
                              setInfMlPerHour("4.2");
                            } else if (selected === "insulin") {
                              setInfTargetDose("2");
                              setInfMlPerHour("2.0");
                            } else if (selected === "heparin") {
                              setInfTargetDose("1000");
                              setInfMlPerHour("2.0");
                            } else {
                              setInfCustomUnit("mcg/kg/min");
                              setInfCustomConc("1");
                            }
                          }}
                          className="w-full p-2.5 rounded-lg border bg-slate-900 border-slate-800 text-white font-semibold text-xs"
                          id="select-infusion-drug"
                        >
                          <option value="noradrenaline">Noradrenaline (Levophed)</option>
                          <option value="adrenaline">Adrenaline (Epinephrine)</option>
                          <option value="dopamine">Dopamine</option>
                          <option value="dobutamine">Dobutamine</option>
                          <option value="insulin">Actrapid Insulin</option>
                          <option value="heparin">Heparin (UFH)</option>
                          <option value="custom">Custom Infusion Profile</option>
                        </select>
                      </div>

                      {/* Preparation / Strength */}
                      {infDrug !== "insulin" && infDrug !== "heparin" && infDrug !== "custom" && (
                        <div>
                          <label className={`text-[11px] font-semibold ${isDarkMode ? "text-slate-400" : "text-slate-700"} block mb-1`}>
                            Dilution Prep Strength
                          </label>
                          <div className="grid grid-cols-3 gap-1.5">
                            {[
                              { id: "single", label: "Single" },
                              { id: "double", label: "Double" },
                              { id: "custom", label: "Custom" }
                            ].map((pOpt) => (
                              <button
                                key={pOpt.id}
                                onClick={() => setInfPrep(pOpt.id as any)}
                                className={`py-2 px-1 rounded-lg border text-xs font-bold transition-all ${
                                  infPrep === pOpt.id
                                    ? "bg-teal-500/20 text-teal-400 border-teal-500/50"
                                    : "bg-slate-900 border-slate-800 text-slate-400 hover:bg-slate-800"
                                }`}
                              >
                                {pOpt.label}
                              </button>
                            ))}
                          </div>
                        </div>
                      )}

                      {/* Custom Concentration (when Custom Prep or Custom Drug is selected) */}
                      {((infPrep === "custom" && infDrug !== "insulin" && infDrug !== "heparin") || infDrug === "custom") && (
                        <div>
                          <label className={`text-[11px] font-semibold ${isDarkMode ? "text-slate-400" : "text-slate-700"} block mb-1`}>
                            Syringe Concentration ({infDrug === "custom" ? "Custom Units" : "mcg"}/mL)
                          </label>
                          <input
                            type="number"
                            value={infCustomConc}
                            onChange={(e) => setInfCustomConc(e.target.value)}
                            className="w-full p-2.5 rounded-lg border bg-slate-900 border-slate-800 text-white font-mono text-xs"
                            placeholder="e.g. 80"
                          />
                        </div>
                      )}

                      {/* Custom Drug Dose Units */}
                      {infDrug === "custom" && (
                        <div>
                          <label className={`text-[11px] font-semibold ${isDarkMode ? "text-slate-400" : "text-slate-700"} block mb-1`}>
                            Target Dose Units
                          </label>
                          <select
                            value={infCustomUnit}
                            onChange={(e) => setInfCustomUnit(e.target.value as any)}
                            className="w-full p-2.5 rounded-lg border bg-slate-900 border-slate-800 text-white text-xs"
                          >
                            <option value="mcg/kg/min">mcg/kg/min (weight-based min)</option>
                            <option value="mcg/min">mcg/min (absolute min)</option>
                            <option value="units/hr">units/hour (absolute hr)</option>
                            <option value="mg/hr">mg/hour (absolute hr)</option>
                          </select>
                        </div>
                      )}

                      {/* Dilution guide card */}
                      <div className="p-3.5 rounded-xl bg-slate-950/40 border border-slate-800/80 text-[11px] space-y-1 text-left leading-relaxed">
                        <strong className="text-teal-400 uppercase tracking-wider block text-[10px]">Preparation Guide:</strong>
                        <p className={isDarkMode ? "text-slate-300" : "text-slate-800"}>{inf.preparationText}</p>
                        <div className="pt-1.5 border-t border-slate-800/40 text-[10px] text-slate-500 font-mono">
                          Computed Concentration: {inf.concentration} {inf.unit.includes("units") ? "units" : inf.unit.includes("mg") ? "mg" : "mcg"}/mL
                        </div>
                      </div>
                    </div>

                    {/* DUAL CALCULATOR INTERLOCK (7 cols) */}
                    <div className="lg:col-span-7 space-y-4">
                      
                      {/* Active Titrator Selector */}
                      <div className="flex border border-slate-800 bg-slate-950/20 p-1 rounded-xl">
                        <button
                          onClick={() => setInfCalcMode("doseToRate")}
                          className={`flex-1 py-2 text-xs font-bold rounded-lg transition-all ${
                            infCalcMode === "doseToRate"
                              ? "bg-teal-500 text-slate-950 shadow"
                              : "text-slate-400 hover:text-slate-200"
                          }`}
                        >
                          🎯 Set Target Dose ➔ Get Rate (mL/h)
                        </button>
                        <button
                          onClick={() => setInfCalcMode("rateToDose")}
                          className={`flex-1 py-2 text-xs font-bold rounded-lg transition-all ${
                            infCalcMode === "rateToDose"
                              ? "bg-teal-500 text-slate-950 shadow"
                              : "text-slate-400 hover:text-slate-200"
                          }`}
                          id="btn-mode-rate-to-dose"
                        >
                          📈 Set Pump Rate (mL/h) ➔ Get Dose
                        </button>
                      </div>

                      {/* CASE A: TARGET DOSE TO INFUSION RATE */}
                      {infCalcMode === "doseToRate" && (
                        <div className={`p-5 rounded-2xl border space-y-4 ${
                          isDarkMode ? "bg-[#111827] border-slate-800" : "bg-white border-slate-200 shadow-sm"
                        }`}>
                          <div className="flex justify-between items-center">
                            <span className="text-xs font-bold uppercase tracking-wider text-teal-400">Target Dose Titration</span>
                            <span className="text-[10px] text-slate-500 font-mono font-bold">ACTIVE CALCULATOR</span>
                          </div>

                          <div className="space-y-3">
                            <div>
                              <label className={`text-[11px] font-semibold ${isDarkMode ? "text-slate-400" : "text-slate-700"} block mb-1`}>
                                Target Infusion Dose ({inf.unit})
                              </label>
                              <div className="flex items-center gap-2">
                                <input
                                  type="number"
                                  step="0.01"
                                  value={infTargetDose}
                                  onChange={(e) => setInfTargetDose(e.target.value)}
                                  className="flex-1 p-3 rounded-xl border bg-slate-900 border-slate-800 text-white font-mono text-base font-bold outline-none focus:border-teal-400"
                                  id="input-target-dose"
                                />
                                <span className="text-xs font-bold text-slate-400 w-20 truncate">{inf.unit.split("/")[0]}</span>
                              </div>
                            </div>

                            {/* Preset titration buttons */}
                            <div>
                              <span className={`text-[10px] font-bold block ${isDarkMode ? "text-slate-500" : "text-slate-600"} mb-1.5 uppercase`}>
                                Titration Presets
                              </span>
                              <div className="flex gap-1.5 flex-wrap">
                                {inf.standardDoses.map((dPreset) => (
                                  <button
                                    key={dPreset}
                                    onClick={() => setInfTargetDose(dPreset.toString())}
                                    className={`px-2.5 py-1 rounded-md text-xs font-mono transition-all border ${
                                      parseFloat(infTargetDose) === dPreset
                                        ? "bg-teal-500/20 text-teal-400 border-teal-500/40"
                                        : "bg-slate-900 border-slate-800 text-slate-400 hover:bg-slate-800"
                                    }`}
                                  >
                                    {dPreset}
                                  </button>
                                ))}
                              </div>
                            </div>
                          </div>

                          {/* OUTPUT WINDOW (RATE) */}
                          <div className="p-4 rounded-xl bg-teal-500/5 border border-teal-500/20 text-center space-y-1">
                            <span className="text-[10px] uppercase font-bold text-slate-500 tracking-wider">Required Syringe Pump Flow Rate</span>
                            <div className="flex items-baseline justify-center gap-1.5">
                              <span className="text-3xl font-extrabold text-teal-400 font-mono tracking-tight" id="calc-rate-output">
                                {inf.calculatedRate}
                              </span>
                              <span className="text-sm font-bold text-slate-400">mL/hr</span>
                            </div>
                            <p className="text-[10px] text-slate-400 font-medium">
                              Set syringe driver flow speed exactly to <strong className="text-slate-200">{inf.calculatedRate} mL/h</strong> to deliver a dosage of <strong className="text-teal-400">{infTargetDose} {inf.unit}</strong>.
                            </p>
                          </div>
                        </div>
                      )}

                      {/* CASE B: INFUSION RATE TO CLINICAL DOSE */}
                      {infCalcMode === "rateToDose" && (
                        <div className={`p-5 rounded-2xl border space-y-4 ${
                          isDarkMode ? "bg-[#111827] border-slate-800" : "bg-white border-slate-200 shadow-sm"
                        }`}>
                          <div className="flex justify-between items-center">
                            <span className="text-xs font-bold uppercase tracking-wider text-teal-400">Syringe Driver Speed</span>
                            <span className="text-[10px] text-slate-500 font-mono font-bold">ACTIVE CALCULATOR</span>
                          </div>

                          <div className="space-y-3">
                            <div>
                              <label className={`text-[11px] font-semibold ${isDarkMode ? "text-slate-400" : "text-slate-700"} block mb-1`}>
                                Infusion Rate (mL/hr)
                              </label>
                              <div className="flex items-center gap-2">
                                <input
                                  type="number"
                                  step="0.1"
                                  value={infMlPerHour}
                                  onChange={(e) => setInfMlPerHour(e.target.value)}
                                  className="flex-1 p-3 rounded-xl border bg-slate-900 border-slate-800 text-white font-mono text-base font-bold outline-none focus:border-teal-400"
                                  id="input-ml-per-hour"
                                />
                                <span className="text-xs font-bold text-slate-400 w-20">mL/hour</span>
                              </div>
                            </div>

                            {/* Preset rate buttons */}
                            <div>
                              <span className={`text-[10px] font-bold block ${isDarkMode ? "text-slate-500" : "text-slate-600"} mb-1.5 uppercase`}>
                                Standard Flow Rates
                              </span>
                              <div className="flex gap-1.5 flex-wrap">
                                {["0.5", "1.0", "2.0", "4.0", "8.0", "12.0", "16.0"].map((rPreset) => (
                                  <button
                                    key={rPreset}
                                    onClick={() => setInfMlPerHour(rPreset)}
                                    className={`px-2.5 py-1 rounded-md text-xs font-mono transition-all border ${
                                      parseFloat(infMlPerHour) === parseFloat(rPreset)
                                        ? "bg-teal-500/20 text-teal-400 border-teal-500/40"
                                        : "bg-slate-900 border-slate-800 text-slate-400 hover:bg-slate-800"
                                    }`}
                                  >
                                    {rPreset} ml/h
                                  </button>
                                ))}
                              </div>
                            </div>
                          </div>

                          {/* OUTPUT WINDOW (DOSE) */}
                          <div className="p-4 rounded-xl bg-teal-500/5 border border-teal-500/20 text-center space-y-1">
                            <span className="text-[10px] uppercase font-bold text-slate-500 tracking-wider">Delivered Patient Dosage</span>
                            <div className="flex items-baseline justify-center gap-1.5">
                              <span className="text-3xl font-extrabold text-teal-400 font-mono tracking-tight" id="calc-dose-output">
                                {inf.calculatedDose}
                              </span>
                              <span className="text-xs font-bold text-slate-400 truncate">{inf.unit}</span>
                            </div>
                            <p className="text-[10px] text-slate-400 font-medium">
                              Running at <strong className="text-slate-200">{infMlPerHour} mL/h</strong> delivers a continuous blood dosage of <strong className="text-teal-400">{inf.calculatedDose} {inf.unit}</strong> to a {weight}kg patient.
                            </p>
                          </div>
                        </div>
                      )}

                      {/* Clinical Guidance/Alert Panel */}
                      <div className="p-4 rounded-xl border border-slate-800/80 bg-slate-900/40 space-y-2 text-left">
                        <div className="flex items-center gap-2 text-amber-400 text-xs font-bold">
                          <span>🛡️</span> Bedside Clinical Notes ({inf.drugName})
                        </div>
                        <p className={`text-xs leading-relaxed ${isDarkMode ? "text-slate-300" : "text-slate-700"}`}>
                          {clinicalNotes}
                        </p>
                      </div>

                    </div>

                  </div>
                );
              })()}

            </div>
          );
        })()}

      </main>

      {/* FOOTER */}
      <footer className={`border-t py-8 text-center text-xs ${
        isDarkMode ? "bg-[#0b0f19] border-slate-900 text-slate-600" : "bg-slate-100 border-slate-200 text-slate-800"
      }`}>
        <div className="max-w-3xl mx-auto px-4">
          <p className={`font-semibold ${isDarkMode ? "text-slate-400" : "text-slate-700"} text-sm`}>
            Copyright Dr FH Liew(2026)
          </p>
          <p className="max-w-2xl mx-auto mt-2 leading-relaxed text-[11px]">
            Information is based on general Malaysian Ministry of Health (MOH) and Clinical Practice Guidelines (CPG) reference values, but is provided for educational and quick-reference purposes only. This initiative is undertaken on a free and voluntary basis, and the developers disclaim any responsibility for errors, omissions, or legal consequences. Always cross-verify with your local hospital pathology lab ranges and exercise professional clinical judgment at the bedside.
          </p>
        </div>
      </footer>

      {/* Floating Back to Top Button */}
      <AnimatePresence>
        {showScrollTop && (
          <motion.button
            initial={{ opacity: 0, scale: 0.8, y: 10 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.8, y: 10 }}
            onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
            className="fixed bottom-6 right-6 p-3.5 rounded-full bg-rose-500 hover:bg-rose-600 text-white shadow-xl z-50 flex items-center justify-center border border-rose-400/20 cursor-pointer hover:scale-105 active:scale-95 transition-all"
            title="Scroll to Top"
          >
            <ArrowUp className="w-5 h-5 font-bold" />
          </motion.button>
        )}
      </AnimatePresence>

    </div>
  );
}
