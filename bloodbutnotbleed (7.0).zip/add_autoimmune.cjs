const fs = require('fs');
const path = require('path');

const filePath = path.join(__dirname, 'src/data/labs.ts');
let content = fs.readFileSync(filePath, 'utf8');

const missingAutoimmune = `,
  {
    "test": "Extractable Nuclear Antigen (ENA) Antibodies Panel",
    "lab": "Ref: IMR Autoimmune Unit",
    "container": "Plain tube with gel (yellow cap)",
    "specimen": "Blood",
    "volume": "3 ml",
    "ltat": "14 to 30 working days",
    "remark": "FORM: PER-PAT 301. Usually ordered after a positive ANA. Includes Anti-Sm, Anti-RNP, Anti-SSA/Ro, Anti-SSB/La, Anti-Scl-70, and Anti-Jo-1.",
    "ranges": "Negative."
  },
  {
    "test": "Anti-Mitochondrial Antibody (AMA)",
    "lab": "Ref: IMR Autoimmune Unit",
    "container": "Plain tube with gel (yellow cap)",
    "specimen": "Blood",
    "volume": "3 ml",
    "ltat": "14 to 30 working days",
    "remark": "FORM: PER-PAT 301. Primary marker for Primary Biliary Cholangitis (PBC).",
    "ranges": "Negative. Titers >= 1:40 are considered clinically significant."
  },
  {
    "test": "Anti-Smooth Muscle Antibody (ASMA)",
    "lab": "Ref: IMR Autoimmune Unit",
    "container": "Plain tube with gel (yellow cap)",
    "specimen": "Blood",
    "volume": "3 ml",
    "ltat": "14 to 30 working days",
    "remark": "FORM: PER-PAT 301. Used in the evaluation of Autoimmune Hepatitis (Type 1).",
    "ranges": "Negative."
  },
  {
    "test": "Liver Kidney Microsomal Type 1 (LKM-1) Antibody",
    "lab": "Ref: IMR Autoimmune Unit",
    "container": "Plain tube with gel (yellow cap)",
    "specimen": "Blood",
    "volume": "3 ml",
    "ltat": "14 to 30 working days",
    "remark": "FORM: PER-PAT 301. Used in the evaluation of Autoimmune Hepatitis (Type 2).",
    "ranges": "Negative."
  },
  {
    "test": "Anti-Glomerular Basement Membrane (Anti-GBM) Antibody",
    "lab": "Ref: IMR Autoimmune Unit",
    "container": "Plain tube with gel (yellow cap)",
    "specimen": "Blood",
    "volume": "3 ml",
    "ltat": "7 to 14 working days",
    "remark": "FORM: PER-PAT 301. Crucial for diagnosing Goodpasture syndrome (Anti-GBM disease).",
    "ranges": "Negative."
  }
];`;

content = content.replace(/\];\s*$/, missingAutoimmune);

fs.writeFileSync(filePath, content, 'utf8');
console.log('Added autoimmune labs');
