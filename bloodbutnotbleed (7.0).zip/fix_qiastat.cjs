const fs = require('fs');
const path = require('path');

const filePath = path.join(__dirname, 'src/data/labs.ts');
let content = fs.readFileSync(filePath, 'utf8');

const regex = /\{\s*"test":\s*"QIAstatDx -Meningitis Panel"[\s\S]*?"ranges":\s*"[^"]*"\s*\}/;

const replacement = `{
    "test": "QIAstatDx - Meningitis Panel",
    "lab": "Microbiology",
    "container": "Sterile container",
    "specimen": "CSF",
    "volume": "0.5 ml",
    "ltat": "1 day",
    "remark": "Transport immediately. Do not refrigerate.",
    "ranges": "Multiplex molecular amplification targets key structural viral, bacterial, and fungal meningeal targets simultaneously."
  },
  {
    "test": "QIAstatDx - Respiratory Panel",
    "lab": "Microbiology",
    "container": "Swab UTM / VTM",
    "specimen": "Nasopharyngeal / Oropharyngeal swab",
    "volume": "1-3 ml",
    "ltat": "1 day",
    "remark": "Transport immediately in cold chain (2-8°C). Used for rapid multiplex detection of respiratory pathogens.",
    "ranges": "Multiplex PCR detecting common viral and bacterial respiratory pathogens."
  }`;

if (regex.test(content)) {
  content = content.replace(regex, replacement);
  fs.writeFileSync(filePath, content, 'utf8');
  console.log('Replaced successfully');
} else {
  console.log('Regex did not match');
}

