const fs = require('fs');
const path = require('path');

const filePath = path.join(__dirname, 'src/data/labs.ts');
let content = fs.readFileSync(filePath, 'utf8');

const missingLabs = `  {
    "test": "Urine FEME (Full Examination & Microscopic Examination)",
    "lab": "Pathology",
    "container": "Sterile container",
    "specimen": "Urine (Mid-stream)",
    "volume": "10 - 20 ml",
    "ltat": "4 hours",
    "remark": "Transport immediately to prevent cellular degradation. Used for screening UTI, hematuria, proteinuria, and kidney disease.",
    "ranges": "pH: 4.5 - 8.0, SG: 1.005 - 1.030. Negative for protein, glucose, ketones, bilirubin, blood, leukocyte esterase, and nitrites."
  },
  {
    "test": "Lipase",
    "lab": "Biochemistry",
    "container": "Plain tube (Red) / SST (Yellow)",
    "specimen": "Blood",
    "volume": "3 ml",
    "ltat": "4 hours",
    "remark": "More specific and sensitive than amylase for acute pancreatitis. Levels remain elevated longer than amylase.",
    "ranges": "13 - 60 U/L (Assay dependent). Acute pancreatitis suspected if > 3x upper limit of normal."
  },
  {
    "test": "Creatine Kinase-MB (CK-MB)",
    "lab": "Biochemistry",
    "container": "Plain tube (Red) / SST (Yellow)",
    "specimen": "Blood",
    "volume": "3 ml",
    "ltat": "4 hours",
    "remark": "Used for suspected myocardial infarction or re-infarction, though High Sensitivity Troponin is preferred.",
    "ranges": "0 - 24 U/L. If total CK is elevated, CK-MB index (CK-MB/Total CK) > 5% suggests cardiac source."
  },
`;

// Insert the missing labs before the closing bracket of the testDatabase array
// Wait, the testDatabase array ends with '];'
content = content.replace(/\];$/, missingLabs + '];');

fs.writeFileSync(filePath, content, 'utf8');
console.log('Added missing labs');
